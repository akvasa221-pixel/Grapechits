//
// Created by proco on 22.05.2022.
//

#ifndef Z9INJECTOR_RECT_H
#define Z9INJECTOR_RECT_H
class myRect {
public:
    float x;
    float y;
    float w;
    float h;
    myRect()
            : x(0)
            , y(0)
            , w(0)
            , h(0)
    {
    }
    myRect(float x1, float y1, float w1, float h1)
            : x(x1)
            , y(y1)
            , w(w1)
            , h(h1)
    {
    }
    myRect(const myRect& v);
    ~myRect();
};
myRect::myRect(const myRect& v)
        : x(v.x)
        , y(v.y)
        , w(v.w)
        , h(v.h)
{
}
myRect::~myRect() {}
#endif //Z9INJECTOR_RECT_H
