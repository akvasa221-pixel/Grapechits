#pragma once

#define _USE_MATH_DEFINES
#include <math.h>
#include <iostream>

#define SMALL_float 0.0000000001

#include "RotV3.h"
#include "Vector3.h"

struct RotQ
{
    union
    {
        struct
        {
            float X;
            float Y;
            float Z;
            float W;
        };
        float data[4];
    };


    /**
     * Constructors.
     */
    inline RotQ();
    inline RotQ(float data[]);
    inline RotQ(RotVector3 vector, float scalar);
    inline RotQ(float x, float y, float z, float w);


    /**
     * Constants for common RotQs.
     */
    static inline RotQ Identity();


    /**
     * Returns the angle between two RotQs.
     * The RotQs must be normalized.
     * @param a: The first RotQ.
     * @param b: The second RotQ.
     * @return: A scalar value.
     */
    static inline float Angle(RotQ a, RotQ b);

    /**
     * Returns the conjugate of a RotQ.
     * @param rotation: The RotQ in question.
     * @return: A new RotQ.
     */
    static inline RotQ Conjugate(RotQ rotation);

    /**
     * Returns the dot product of two RotQs.
     * @param lhs: The left side of the multiplication.
     * @param rhs: The right side of the multiplication.
     * @return: A scalar value.
     */
    static inline float Dot(RotQ lhs, RotQ rhs);

    /**
     * Creates a new RotQ from the angle-axis representation of
     * a rotation.
     * @param angle: The rotation angle in radians.
     * @param axis: The vector about which the rotation occurs.
     * @return: A new RotQ.
     */
    static inline RotQ FromAngleAxis(float angle, RotVector3 axis);

    /**
     * Create a new RotQ from the euler angle representation of
     * a rotation. The z, x and y values represent rotations about those
     * axis in that respective order.
     * @param rotation: The x, y and z rotations.
     * @return: A new RotQ.
     */
    static inline RotQ FromEuler(RotVector3 rotation);

    /**
     * Create a new RotQ from the euler angle representation of
     * a rotation. The z, x and y values represent rotations about those
     * axis in that respective order.
     * @param x: The rotation about the x-axis in radians.
     * @param y: The rotation about the y-axis in radians.
     * @param z: The rotation about the z-axis in radians.
     * @return: A new RotQ.
     */
    static inline RotQ FromEuler(float x, float y, float z);

    /**
     * Create a RotQ rotation which rotates "fromVector" to "toVector".
     * @param fromVector: The vector from which to start the rotation.
     * @param toVector: The vector at which to end the rotation.
     * @return: A new RotQ.
     */
    static inline RotQ FromToRotation(RotVector3 fromVector,
                                      RotVector3 toVector);

    /**
     * Returns the inverse of a rotation.
     * @param rotation: The RotQ in question.
     * @return: A new RotQ.
     */
    static inline RotQ Inverse(RotQ rotation);

    /**
     * Interpolates between a and b by t, which is clamped to the range [0-1].
     * The result is normalized before being returned.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @return: A new RotQ.
     */
    static inline RotQ Lerp(RotQ a, RotQ b, float t);

    /**
     * Interpolates between a and b by t. This normalizes the result when
     * complete.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new RotQ.
     */
    static inline RotQ LerpUnclamped(RotQ a, RotQ b,
                                     float t);

    /**
     * Creates a rotation with the specified forward direction. This is the
     * same as calling LookRotation with (0, 1, 0) as the upwards vector.
     * The output is undefined for parallel vectors.
     * @param forward: The forward direction to look toward.
     * @return: A new RotQ.
     */
    static inline RotQ LookRotation(RotVector3 forward);

    /**
     * Creates a rotation with the specified forward and upwards directions.
     * The output is undefined for parallel vectors.
     * @param forward: The forward direction to look toward.
     * @param upwards: The direction to treat as up.
     * @return: A new RotQ.
     */
    static inline RotQ LookRotation(RotVector3 forward, RotVector3 upwards);

    /**
     * Returns the norm of a RotQ.
     * @param rotation: The RotQ in question.
     * @return: A scalar value.
     */
    static inline float Norm(RotQ rotation);

    /**
     * Returns a RotQ with identical rotation and a norm of one.
     * @param rotation: The RotQ in question.
     * @return: A new RotQ.
     */
    static inline RotQ Normalized(RotQ rotation);

    /**
     * Returns a new RotQ created by rotating "from" towards "to" by
     * "maxRadiansDelta". This will not overshoot, and if a negative delta is
     * applied, it will rotate till completely opposite "to" and then stop.
     * @param from: The rotation at which to start.
     * @param to: The rotation at which to end.
     # @param maxRadiansDelta: The maximum number of radians to rotate.
     * @return: A new RotQ.
     */
    static inline RotQ RotateTowards(RotQ from, RotQ to,
                                     float maxRadiansDelta);

    /**
     * Returns a new RotQ interpolated between a and b, using spherical
     * linear interpolation. The variable t is clamped to the range [0-1]. The
     * resulting RotQ will be normalized.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new RotQ.
     */
    static inline RotQ Slerp(RotQ a, RotQ b, float t);

    /**
     * Returns a new RotQ interpolated between a and b, using spherical
     * linear interpolation. The resulting RotQ will be normalized.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new RotQ.
     */
    static inline RotQ SlerpUnclamped(RotQ a, RotQ b,
                                      float t);

    /**
     * Outputs the angle axis representation of the provided RotQ.
     * @param rotation: The input RotQ.
     * @param angle: The output angle.
     * @param axis: The output axis.
     */
    static inline void ToAngleAxis(RotQ rotation, float &angle,
                                   RotVector3 &axis);

    /**
     * Returns the Euler angle representation of a rotation. The resulting
     * vector contains the rotations about the z, x and y axis, in that order.
     * @param rotation: The RotQ to convert.
     * @return: A new vector.
     */
    static inline RotVector3 ToEuler(RotQ rotation);

    /**
     * Operator overloading.
     */
    inline struct RotQ& operator+=(const float rhs);
    inline struct RotQ& operator-=(const float rhs);
    inline struct RotQ& operator*=(const float rhs);
    inline struct RotQ& operator/=(const float rhs);
    inline struct RotQ& operator+=(const RotQ rhs);
    inline struct RotQ& operator-=(const RotQ rhs);
    inline struct RotQ& operator*=(const RotQ rhs);
};

inline RotQ operator-(RotQ rhs);
inline RotQ operator+(RotQ lhs, const float rhs);
inline RotQ operator-(RotQ lhs, const float rhs);
inline RotQ operator*(RotQ lhs, const float rhs);
inline RotQ operator/(RotQ lhs, const float rhs);
inline RotQ operator+(const float lhs, RotQ rhs);
inline RotQ operator-(const float lhs, RotQ rhs);
inline RotQ operator*(const float lhs, RotQ rhs);
inline RotQ operator/(const float lhs, RotQ rhs);
inline RotQ operator+(RotQ lhs, const RotQ rhs);
inline RotQ operator-(RotQ lhs, const RotQ rhs);
inline RotQ operator*(RotQ lhs, const RotQ rhs);
inline RotVector3 operator*(RotQ lhs, const RotVector3 rhs);
inline bool operator==(const RotQ lhs, const RotQ rhs);
inline bool operator!=(const RotQ lhs, const RotQ rhs);



/*******************************************************************************
 * Implementation
 */

RotQ::RotQ() : X(0), Y(0), Z(0), W(1) {}
RotQ::RotQ(float data[]) : X(data[0]), Y(data[1]), Z(data[2]),
                           W(data[3]) {}
RotQ::RotQ(RotVector3 vector, float scalar) : X(vector.X),
                                              Y(vector.Y), Z(vector.Z), W(scalar) {}
RotQ::RotQ(float x, float y, float z, float w) : X(x), Y(y),
                                                 Z(z), W(w) {}


RotQ RotQ::Identity() { return RotQ(0, 0, 0, 1); }


float RotQ::Angle(RotQ a, RotQ b)
{
    float dot = Dot(a, b);
    return acos(fmin(fabs(dot), 1)) * 2;
}

RotQ RotQ::Conjugate(RotQ rotation)
{
    return RotQ(-rotation.X, -rotation.Y, -rotation.Z, rotation.W);
}

float RotQ::Dot(RotQ lhs, RotQ rhs)
{
    return lhs.X * rhs.X + lhs.Y * rhs.Y + lhs.Z * rhs.Z + lhs.W * rhs.W;
}

RotQ RotQ::FromAngleAxis(float angle, RotVector3 axis)
{
    RotQ q;
    float m = sqrt(axis.X * axis.X + axis.Y * axis.Y + axis.Z * axis.Z);
    float s = sin(angle / 2) / m;
    q.X = axis.X * s;
    q.Y = axis.Y * s;
    q.Z = axis.Z * s;
    q.W = cos(angle / 2);
    return q;
}

RotQ RotQ::FromEuler(RotVector3 rotation)
{
    return FromEuler(rotation.X, rotation.Y, rotation.Z);
}

RotQ RotQ::FromEuler(float x, float y, float z)
{
    float cx = cos(x * 0.5);
    float cy = cos(y * 0.5);
    float cz = cos(z * 0.5);
    float sx = sin(x * 0.5);
    float sy = sin(y * 0.5);
    float sz = sin(z * 0.5);
    RotQ q;
    q.X = cx * sy * sz + cy * cz * sx;
    q.Y = cx * cz * sy - cy * sx * sz;
    q.Z = cx * cy * sz - cz * sx * sy;
    q.W = sx * sy * sz + cx * cy * cz;
    return q;
}

RotQ RotQ::FromToRotation(RotVector3 fromVector, RotVector3 toVector)
{
    float dot = RotVector3::Dot(fromVector, toVector);
    float k = sqrt(RotVector3::SqrMagnitude(fromVector) *
                   RotVector3::SqrMagnitude(toVector));
    if (fabs(dot / k + 1) < 0.00001)
    {
        RotVector3 ortho = RotVector3::Orthogonal(fromVector);
        return RotQ(RotVector3::Normalized(ortho), 0);
    }
    RotVector3 cross = RotVector3::Cross(fromVector, toVector);
    return Normalized(RotQ(cross, dot + k));
}

RotQ RotQ::Inverse(RotQ rotation)
{
    float n = Norm(rotation);
    return Conjugate(rotation) / (n * n);
}

RotQ RotQ::Lerp(RotQ a, RotQ b, float t)
{
    if (t < 0) return Normalized(a);
    else if (t > 1) return Normalized(b);
    return LerpUnclamped(a, b, t);
}

RotQ RotQ::LerpUnclamped(RotQ a, RotQ b, float t)
{
    RotQ RotQ;
    if (Dot(a, b) >= 0)
        RotQ = a * (1 - t) + b * t;
    else
        RotQ = a * (1 - t) - b * t;
    return Normalized(RotQ);
}

RotQ RotQ::LookRotation(RotVector3 forward)
{
    return LookRotation(forward, RotVector3(0, 1, 0));
}

RotQ RotQ::LookRotation(RotVector3 forward, RotVector3 upwards)
{
    // Normalize inputs
    forward = RotVector3::Normalized(forward);
    upwards = RotVector3::Normalized(upwards);
    // Don't allow zero vectors
    if (RotVector3::SqrMagnitude(forward) < SMALL_float || RotVector3::SqrMagnitude(upwards) < SMALL_float)
        return RotQ::Identity();
    // Handle alignment with up direction
    if (1 - fabs(RotVector3::Dot(forward, upwards)) < SMALL_float)
        return FromToRotation(RotVector3(0,0,1), forward);
    // Get orthogonal vectors
    RotVector3 right = RotVector3::Normalized(RotVector3::Cross(upwards, forward));
    upwards = RotVector3::Cross(forward, right);
    // Calculate rotation
    RotQ RotQ;
    float radicand = right.X + upwards.Y + forward.Z;
    if (radicand > 0)
    {
        RotQ.W = sqrt(1.0 + radicand) * 0.5;
        float recip = 1.0 / (4.0 * RotQ.W);
        RotQ.X = (upwards.Z - forward.Y) * recip;
        RotQ.Y = (forward.X - right.Z) * recip;
        RotQ.Z = (right.Y - upwards.X) * recip;
    }
    else if (right.X >= upwards.Y && right.X >= forward.Z)
    {
        RotQ.X = sqrt(1.0 + right.X - upwards.Y - forward.Z) * 0.5;
        float recip = 1.0 / (4.0 * RotQ.X);
        RotQ.W = (upwards.Z - forward.Y) * recip;
        RotQ.Z = (forward.X + right.Z) * recip;
        RotQ.Y = (right.Y + upwards.X) * recip;
    }
    else if (upwards.Y > forward.Z)
    {
        RotQ.Y = sqrt(1.0 - right.X + upwards.Y - forward.Z) * 0.5;
        float recip = 1.0 / (4.0 * RotQ.Y);
        RotQ.Z = (upwards.Z + forward.Y) * recip;
        RotQ.W = (forward.X - right.Z) * recip;
        RotQ.X = (right.Y + upwards.X) * recip;
    }
    else
    {
        RotQ.Z = sqrt(1.0 - right.X - upwards.Y + forward.Z) * 0.5;
        float recip = 1.0 / (4.0 * RotQ.Z);
        RotQ.Y = (upwards.Z + forward.Y) * recip;
        RotQ.X = (forward.X + right.Z) * recip;
        RotQ.W = (right.Y - upwards.X) * recip;
    }
    return RotQ;
}

float RotQ::Norm(RotQ rotation)
{
    return sqrt(rotation.X * rotation.X +
                rotation.Y * rotation.Y +
                rotation.Z * rotation.Z +
                rotation.W * rotation.W);
}

RotQ RotQ::Normalized(RotQ rotation)
{
    return rotation / Norm(rotation);
}

RotQ RotQ::RotateTowards(RotQ from, RotQ to,
                         float maxRadiansDelta)
{
    float angle = RotQ::Angle(from, to);
    if (angle == 0)
        return to;
    maxRadiansDelta = fmax(maxRadiansDelta, angle - M_PI);
    float t = fmin(1, maxRadiansDelta / angle);
    return RotQ::SlerpUnclamped(from, to, t);
}

RotQ RotQ::Slerp(RotQ a, RotQ b, float t)
{
    if (t < 0) return Normalized(a);
    else if (t > 1) return Normalized(b);
    return SlerpUnclamped(a, b, t);
}

RotQ RotQ::SlerpUnclamped(RotQ a, RotQ b, float t)
{
    float n1;
    float n2;
    float n3 = Dot(a, b);
    bool flag = false;
    if (n3 < 0)
    {
        flag = true;
        n3 = -n3;
    }
    if (n3 > 0.999999)
    {
        n2 = 1 - t;
        n1 = flag ? -t : t;
    }
    else
    {
        float n4 = acos(n3);
        float n5 = 1 / sin(n4);
        n2 = sin((1 - t) * n4) * n5;
        n1 = flag ? -sin(t * n4) * n5 : sin(t * n4) * n5;
    }
    RotQ RotQ;
    RotQ.X = (n2 * a.X) + (n1 * b.X);
    RotQ.Y = (n2 * a.Y) + (n1 * b.Y);
    RotQ.Z = (n2 * a.Z) + (n1 * b.Z);
    RotQ.W = (n2 * a.W) + (n1 * b.W);
    return Normalized(RotQ);
}

void RotQ::ToAngleAxis(RotQ rotation, float &angle, RotVector3 &axis)
{
    if (rotation.W > 1)
        rotation = Normalized(rotation);
    angle = 2 * acos(rotation.W);
    float s = sqrt(1 - rotation.W * rotation.W);
    if (s < 0.00001) {
        axis.X = 1;
        axis.Y = 0;
        axis.Z = 0;
    } else {
        axis.X = rotation.X / s;
        axis.Y = rotation.Y / s;
        axis.Z = rotation.Z / s;
    }
}

RotVector3 RotQ::ToEuler(RotQ rotation)
{
    float sqw = rotation.W * rotation.W;
    float sqx = rotation.X * rotation.X;
    float sqy = rotation.Y * rotation.Y;
    float sqz = rotation.Z * rotation.Z;
    // If normalized is one, otherwise is correction factor
    float unit = sqx + sqy + sqz + sqw;
    float test = rotation.X * rotation.W - rotation.Y * rotation.Z;
    RotVector3 v;
    // Singularity at north pole
    if (test > 0.4995f * unit)
    {
        v.Y = 2 * atan2(rotation.Y, rotation.X);
        v.X = M_PI_2;
        v.Z = 0;
        return v;
    }
    // Singularity at south pole
    if (test < -0.4995f * unit)
    {
        v.Y = -2 * atan2(rotation.Y, rotation.X);
        v.X = -M_PI_2;
        v.Z = 0;
        return v;
    }
    // Yaw
    v.Y = atan2(2 * rotation.W * rotation.Y + 2 * rotation.Z * rotation.X,
                1 - 2 * (rotation.X * rotation.X + rotation.Y * rotation.Y));
    // Pitch
    v.X = asin(2 * (rotation.W * rotation.X - rotation.Y * rotation.Z));
    // Roll
    v.Z = atan2(2 * rotation.W * rotation.Z + 2 * rotation.X * rotation.Y,
                1 - 2 * (rotation.Z * rotation.Z + rotation.X * rotation.X));
    return v;
}

struct RotQ& RotQ::operator+=(const float rhs)
{
    X += rhs;
    Y += rhs;
    Z += rhs;
    W += rhs;
    return *this;
}

struct RotQ& RotQ::operator-=(const float rhs)
{
    X -= rhs;
    Y -= rhs;
    Z -= rhs;
    W -= rhs;
    return *this;
}

struct RotQ& RotQ::operator*=(const float rhs)
{
    X *= rhs;
    Y *= rhs;
    Z *= rhs;
    W *= rhs;
    return *this;
}

struct RotQ& RotQ::operator/=(const float rhs)
{
    X /= rhs;
    Y /= rhs;
    Z /= rhs;
    W /= rhs;
    return *this;
}

struct RotQ& RotQ::operator+=(const RotQ rhs)
{
    X += rhs.X;
    Y += rhs.Y;
    Z += rhs.Z;
    W += rhs.W;
    return *this;
}

struct RotQ& RotQ::operator-=(const RotQ rhs)
{
    X -= rhs.X;
    Y -= rhs.Y;
    Z -= rhs.Z;
    W -= rhs.W;
    return *this;
}

struct RotQ& RotQ::operator*=(const RotQ rhs)
{
    RotQ q;
    q.W = W * rhs.W - X * rhs.X - Y * rhs.Y - Z * rhs.Z;
    q.X = X * rhs.W + W * rhs.X + Y * rhs.Z - Z * rhs.Y;
    q.Y = W * rhs.Y - X * rhs.Z + Y * rhs.W + Z * rhs.X;
    q.Z = W * rhs.Z + X * rhs.Y - Y * rhs.X + Z * rhs.W;
    *this = q;
    return *this;
}

RotQ operator-(RotQ rhs) { return rhs * -1; }
RotQ operator+(RotQ lhs, const float rhs) { return lhs += rhs; }
RotQ operator-(RotQ lhs, const float rhs) { return lhs -= rhs; }
RotQ operator*(RotQ lhs, const float rhs) { return lhs *= rhs; }
RotQ operator/(RotQ lhs, const float rhs) { return lhs /= rhs; }
RotQ operator+(const float lhs, RotQ rhs) { return rhs += lhs; }
RotQ operator-(const float lhs, RotQ rhs) { return rhs -= lhs; }
RotQ operator*(const float lhs, RotQ rhs) { return rhs *= lhs; }
RotQ operator/(const float lhs, RotQ rhs) { return rhs /= lhs; }
RotQ operator+(RotQ lhs, const RotQ rhs)
{
    return lhs += rhs;
}
RotQ operator-(RotQ lhs, const RotQ rhs)
{
    return lhs -= rhs;
}
RotQ operator*(RotQ lhs, const RotQ rhs)
{
    return lhs *= rhs;
}

RotVector3 operator*(RotQ lhs, const RotVector3 rhs)
{
    RotVector3 u = RotVector3(lhs.X, lhs.Y, lhs.Z);
    float s = lhs.W;
    return u * (RotVector3::Dot(u, rhs) * 2)
           + rhs * (s * s - RotVector3::Dot(u, u))
           + RotVector3::Cross(u, rhs) * (2.0 * s);
}

bool operator==(const RotQ lhs, const RotQ rhs)
{
    return lhs.X == rhs.X &&
           lhs.Y == rhs.Y &&
           lhs.Z == rhs.Z &&
           lhs.W == rhs.W;
}

bool operator!=(const RotQ lhs, const RotQ rhs)
{
    return !(lhs == rhs);
}