//
// Created by proco on 22.05.2022.
//

#ifndef Z9INJECTOR_VECTOR3_H
#define Z9INJECTOR_VECTOR3_H

#include <math.h>
class Vvector3 {
public:
    float x;
    float y;
    float z;
    Vvector3() : x(0), y(0), z(0) {}
    Vvector3(float x1, float y1, float z1) : x(x1), y(y1), z(z1) {}
    Vvector3(const Vvector3 &v);
    ~Vvector3();
    void operator=(const Vvector3 &v);
    Vvector3 operator+(const Vvector3 &v);
    Vvector3 operator-(const Vvector3 &v);
    Vvector3 operator/(const Vvector3 &v);
    Vvector3 operator*(const Vvector3 &v);
    Vvector3 operator+(float f);
    Vvector3 operator-(float f);
    Vvector3 operator/(float f);
    Vvector3 operator*(float f);
    Vvector3 static Normalize(Vvector3 vec);
    float static SqrMagnitude(Vvector3 v);
    Vvector3 static Cross(Vvector3 a, Vvector3 b);
    float dot(const Vvector3 &v);
    float length();
    void clear();
    void normalized();
    Vvector3 static Lerp(Vvector3 start, Vvector3 end, float percent);
    Vvector3 cross(const Vvector3 &v);
    static float distance(const Vvector3 &a, const Vvector3 &b);
};


const double uZero = 1e-6;

Vvector3 Vvector3::Lerp(Vvector3 start, Vvector3 end, float percent) {
    return (start + (end - start) * percent);
}

Vvector3::Vvector3(const Vvector3 &v) : x(v.x), y(v.y), z(v.z) {

}



Vvector3::~Vvector3() {

}

void Vvector3::operator=(const Vvector3 &v) {
    x = v.x;
    y = v.y;
    z = v.z;
}

Vvector3 Vvector3::operator+(const Vvector3 &v) {
    return Vvector3(x + v.x, y + v.y, z + v.z);
}

Vvector3 Vvector3::operator-(const Vvector3 &v) {
    return Vvector3(x - v.x, y - v.y, z - v.z);
}

Vvector3 Vvector3::operator/(const Vvector3 &v) {
    if (fabsf(v.x) <= uZero || fabsf(v.y) <= uZero || fabsf(v.z) <= uZero) {
        return *this;
    }
    return Vvector3(x / v.x, y / v.y, z / v.z);
}

Vvector3 Vvector3::operator*(const Vvector3 &v) {
    return Vvector3(x * v.x, y * v.y, z * v.z);
}

Vvector3 Vvector3::operator+(float f) {
    return Vvector3(x + f, y + f, z + f);
}

Vvector3 Vvector3::operator-(float f) {
    return Vvector3(x - f, y - f, z - f);
}

void Vvector3::clear() {
    x = y = z = 0;
}

Vvector3 Vvector3::operator/(float f) {
    if (fabsf(f) < uZero) {
        return *this;
    }
    return Vvector3(x / f, y / f, z / f);
}

Vvector3 Vvector3::operator*(float f) {
    return Vvector3(x * f, y * f, z * f);
}

float Vvector3::dot(const Vvector3 &v) {
    return x * v.x + y * v.y + z * v.z;
}

Vvector3 Vvector3::Cross(Vvector3 lhs, Vvector3 rhs)
{
    float x = lhs.y * rhs.z - lhs.z * rhs.y;
    float y = lhs.z * rhs.x - lhs.x * rhs.z;
    float z = lhs.x * rhs.y - lhs.y * rhs.x;
    return Vvector3(x, y, z);
}

float Vvector3::length() {
    return sqrtf(dot(*this));
}
float Vvector3::SqrMagnitude(Vvector3 v) {
    return v.x * v.x + v.y * v.y + v.z * v.z;
}

void Vvector3::normalized() {
    float len = length();
    if (len < uZero) len = 1;
    len = 1 / len;

    x *= len;
    y *= len;
    z *= len;
}

Vvector3 Vvector3::Normalize(Vvector3 vec) {
    vec.normalized();
    return vec;
}


float Vvector3::distance(const Vvector3 &point1, const Vvector3 &point2) {
    float distance = sqrt((point1.x - point2.x) * (point1.x - point2.x) +
                          (point1.y - point2.y) * (point1.y - point2.y) +
                          (point1.z - point2.z) * (point1.z - point2.z));
    return distance;
}
#endif //Z9INJECTOR_VECTOR3_H
