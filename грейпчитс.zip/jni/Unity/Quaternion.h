//
// Created by proco on 23.05.2022.
//

#ifndef Z9INJECTOR_QUATERNION_H
#define Z9INJECTOR_QUATERNION_H

class Qquaternion {
public:
    float x;
    float y;
    float z;
    float w;
    Qquaternion()
            : x(0)
            , y(0)
            , z(0)
            , w(0)
    {
    }
    Qquaternion(float x1, float y1, float z1, float w1)
            : x(x1)
            , y(y1)
            , z(z1)
            , w(w1)
    {
    }
    Qquaternion(const Qquaternion& v);
    ~Qquaternion();
};
Qquaternion::Qquaternion(const Qquaternion& v)
        : x(v.x)
        , y(v.y)
        , z(v.z)
        , w(v.w)
{
}
Qquaternion::~Qquaternion() {}
#endif //Z9INJECTOR_QUATERNION_H
