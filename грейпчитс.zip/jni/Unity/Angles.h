//
// Created by proco on 23.05.2022.
//

#ifndef Z9INJECTOR_ANGLES_H
#define Z9INJECTOR_ANGLES_H
#include "Vector3.h"
#define SMALL_float 0.0000000001
Vvector3 ToEulerAngles(Qquaternion rotation)
{
    float sqw = rotation.w * rotation.w;
    float sqx = rotation.x * rotation.x;
    float sqy = rotation.y * rotation.y;
    float sqz = rotation.z * rotation.z;
    // If normalized is one, otherwise is correction factor
    float unit = sqx + sqy + sqz + sqw;
    float test = rotation.x * rotation.w - rotation.y * rotation.z;
    Vvector3 v;
    // Singularity at north pole
    if (test > 0.4995f * unit)
    {
        v.y = 2 * atan2(rotation.y, rotation.x);
        v.x = M_PI_2;
        v.z = 0;
        return v;
    }
    // Singularity at south pole
    if (test < -0.4995f * unit)
    {
        v.y = -2 * atan2(rotation.y, rotation.x);
        v.x = -M_PI_2;
        v.z = 0;
        return v;
    }
    // yaw
    v.y = atan2(2 * rotation.w * rotation.y + 2 * rotation.z * rotation.x,
                1 - 2 * (rotation.x * rotation.x + rotation.y * rotation.y));
    // Pitch
    v.x = asin(2 * (rotation.w * rotation.x - rotation.y * rotation.z));
    // Roll
    v.z = atan2(2 * rotation.w * rotation.z + 2 * rotation.x * rotation.y,
                1 - 2 * (rotation.z * rotation.z + rotation.x * rotation.x));
    return v;
}

float NormalizeAngle (float angle){
    while (angle>360)
        angle -= 360;
    while (angle<0)
        angle += 360;
    return angle;
}

RotVector3 NormalizeAngles (RotVector3 angles){
    angles.X = NormalizeAngle (angles.X);
    angles.Y = NormalizeAngle (angles.Y);
    angles.Z = NormalizeAngle (angles.Z);
    return angles;
}
//������� toeulerangles - �����! �� �� ������� � ����� � ����� �� ������. ���� toeuler �������.
RotVector3 ToEulerRad(RotQ q1){
    float Rad2Deg2 = 360.0f / (M_PI * 2.0f);

    float sqw = q1.W * q1.W;
    float sqx = q1.X * q1.X;
    float sqy = q1.Y * q1.Y;
    float sqz = q1.Z * q1.Z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.X * q1.W - q1.Y * q1.Z;
    RotVector3 v;

    if (test>0.4995f*unit) {
        v.Y = 2.0f * atan2f (q1.Y, q1.X);
        v.X = M_PI / 2.0f;
        v.Z = 0;
        return NormalizeAngles(v * Rad2Deg2);
    }
    if (test<-0.4995f*unit) {
        v.Y = -2.0f * atan2f (q1.Y, q1.X);
        v.X = -M_PI / 2.0f;
        v.Z = 0;
        return NormalizeAngles (v * Rad2Deg2);
    }
    RotQ q(q1.W, q1.Z, q1.X, q1.Y);
    v.Y = atan2f (2.0f * q.X * q.W + 2.0f * q.Y * q.Z, 1 - 2.0f * (q.Z * q.Z + q.W * q.W)); // YaW
    v.X = asinf (2.0f * (q.X * q.Z - q.W * q.Y)); // pitch
    v.Z = atan2f (2.0f * q.X * q.Y + 2.0f * q.Z * q.W, 1 - 2.0f * (q.Y * q.Y + q.Z * q.Z)); // roll
    return NormalizeAngles (v * Rad2Deg2);
}

#endif //Z9INJECTOR_ANGLES_H
