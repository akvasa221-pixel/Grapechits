#ifndef Z9INJECTOR_DRAWING_H
#define Z9INJECTOR_DRAWING_H
#include "Unity/Rot.h"
#include "Unity/RotV3.h"
#include "Cheat.h"
#include "Dobby/dobby.h"
#include "Includes/Logger.h"
#include "ByNameModding/BNM.hpp"
#include "Includes/Utils.h"
#include <dlfcn.h>
#include <array>
#include "ImGui_Impl_AndroidOpenGL2.h"
#include "EGL/egl.h"
#include "GLES3/gl3.h"
#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include <android/asset_manager_jni.h>
#include <android/native_window.h>
#include <android/input.h>
#include <android/log.h>
#include "Unity/Vector2.h"
#include "Unity/Vector3.h"
#include "Unity/Rect.h"
#include "Unity/Quaternion.h"
#include "Unity/Angles.h"
#include <vector>
#include <ctime>
#include <iostream>
#include <unistd.h>
#include <KittyMemory/MemoryPatch.h>
#include <Substrate/CydiaSubstrate.h>
#include "JSON/JSON.h"
#include "obfuscator.h"
#define targetLibName ozObfuscate("lib/arm/libil2cpp.so")
#define getRealOffset(offset) getAbsoluteAddress(targetLibName, offset)
#define radians_to_degrees(x)  ( (float)(x) * (float)(180.f / PI) )
#define degrees_to_radians(x) ( (float)(x) * (float)(PI /180.f) )
float startTime, screenWidth, screenHeight;
using namespace BNM::UNITY_STRUCTS; // Vector3, Vector2 and etc
using namespace BNM::MONO_STRUCTS; // monoString, monoArray and etc
using namespace BNM;
using namespace std;
uintptr_t string2Offset(const char *c) {
    return strtoul(c, nullptr, 16);
}
int renderFunction = 3;
bool dontClear = false;
bool chatspam, clantag, animid, fastknife, fastfire, infammo = false;
float flyvalue = 0;
struct UnityEngine_Vector2_Fields {
float x;
float y;
};
struct UnityEngine_Vector2_o { UnityEngine_Vector2_Fields fields; };
enum TouchPhase { Began = 0,Moved = 1,Stationary = 2,Ended = 3,Canceled = 4 };
float Vvector3Magnitude(Vvector3 v) { return sqrt(v.x * v.x + v.y * v.y + v.z * v.z); }
struct UnityEngine_Touch_Fields { int32_t m_FingerId; struct UnityEngine_Vector2_o m_Position; struct UnityEngine_Vector2_o m_RawPosition; struct UnityEngine_Vector2_o m_PositionDelta;float m_TimeDelta;int32_t m_TapCount;int32_t m_Phase;int32_t m_Type;float m_Pressure;float m_maximumPossiblePressure;float m_Radius;float m_RadiusVariance;float m_AltitudeAngle;float m_AzimuthAngle; };
void (*RPC)(...);
void* (*GetView)(...);
bool (*IsMasterClient)(...);
bool (*SetMasterClient)(...);
bool clearMousePos = true, setup = false;
int  glWidth, glHeight;
bool HandleInputEvent(JNIEnv *env, int motionEvent, int x, int y, int p);
typedef enum { TOUCH_ACTION_DOWN = 0, TOUCH_ACTION_UP, TOUCH_ACTION_MOVE } TOUCH_ACTION;
typedef struct { TOUCH_ACTION action;float x;float y;int pointers;float y_velocity;float x_velocity; } TOUCH_EVENT;
TOUCH_EVENT g_LastTouchEvent;
#include "ImGui/imgui_impl_opengl3.cpp"
int address = 0;
EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (!setup) {
        ImGui_ImplOpenGL3_Init("#version 100");
        setup = true;
    }
    ImGuiIO &io = ImGui::GetIO();
    int touchCount = (((int (*)())(address+0x249CF98))()); // public static int get_touchCount() { }
    if (touchCount > 0) {
        UnityEngine_Touch_Fields touch = ((UnityEngine_Touch_Fields (*)(int))(address+0x249C974))(0); // public static Touch GetTouch(int index) { }
        float reverseY = io.DisplaySize.y - touch.m_Position.fields.y;
        switch (touch.m_Phase) {
            case TouchPhase::Began:
            case TouchPhase::Stationary:
                io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
                io.MouseDown[0] = true;
                break;
            case TouchPhase::Ended:
            case TouchPhase::Canceled:
                io.MouseDown[0] = false;
                clearMousePos = true;
                break;
            case TouchPhase::Moved:
                io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
                break;
            default:
                break;
        }
    }
    Render();
    return old_eglSwapBuffers(dpy, surface);
}
int getSkinIDForG22(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 41101;
            break;
        case 2:
            ret = 11008;
            break;
        case 3:
            ret = 11002;
            break;
        case 4:
            ret = 121100;
            break;
        case 5:
            ret = 81107;
            break;
        case 6:
            ret = 71104;
            break;
        case 7:
            ret = 61101;
            break;
        case 8:
            ret = 41102;
            break;
    }
    return ret;
}
int getSkinIDForUSP(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 12001;
            break;
        case 2:
            ret = 12002;
            break;
        case 3:
            ret = 12003;
            break;
        case 4:
            ret = 170020;
            break;
        case 5:
            ret = 161200;
            break;
        case 6:
            ret = 121200;
            break;
        case 7:
            ret = 81200;
            break;
        case 8:
            ret = 61201;
            break;
        case 9:
            ret = 41212;
            break;
    }
    return ret;
}
int getSkinIDForP350(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 13001;
            break;
        case 2:
            ret = 13003;
            break;
        case 3:
            ret = 13004;
            break;
        case 4:
            ret = 170018;
            break;
        case 5:
            ret = 121300;
            break;
        case 6:
            ret = 101300;
            break;
        case 7:
            ret = 91300;
            break;
        case 8:
            ret = 81300;
            break;
        case 9:
            ret = 71306;
            break;
    }
    return ret;
}
int getSkinIDForDeagle(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 170004;
            break;
        case 2:
            ret = 131500;
            break;
        case 3:
            ret = 121500;
            break;
        case 4:
            ret = 41502;
            break;
        case 5:
            ret = 15006;
            break;
        case 6:
            ret = 15004;
            break;
        case 7:
            ret = 15003;
            break;
        case 8:
            ret = 15001;
            break;
    }
    return ret;
}
int getSkinIDForTEC9(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 170019;
            break;
        case 2:
            ret = 161600;
            break;
        case 3:
            ret = 151600;
            break;
        case 4:
            ret = 141600;
            break;
        case 5:
            ret = 121600;
            break;
        case 6:
            ret = 81613;
            break;
        case 7:
            ret = 71607;
            break;
        case 8:
            ret = 61601;
            break;
        case 9:
            ret = 51601;
            break;
        case 10:
            ret = 41605;
            break;
    }
    return ret;
}
int getSkinIDForFiveSeven(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 170007;
            break;
        case 2:
            ret = 151700;
            break;
        case 3:
            ret = 141700;
            break;
        case 4:
            ret = 131700;
            break;
        case 5:
            ret = 81700;
            break;
        case 6:
            ret = 81725;
            break;
        case 7:
            ret = 81726;
            break;
        case 8:
            ret = 71702;
            break;
        case 9:
            ret = 71701;
            break;
        case 10:
            ret = 51701;
            break;
        case 11:
            ret = 41703;
            break;
        case 12:
            ret = 41701;
            break;
    }
    return ret;
}
int getSkinIDForM9(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 71005;
            break;
        case 2:
            ret = 71002;
            break;
        case 3:
            ret = 71003;
            break;
        case 4:
            ret = 71004;
            break;
        case 5:
            ret = 71001;
            break;
    }
    return ret;
}
int getSkinIDForJKommando(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 73003;
            break;
        case 2:
            ret = 73004;
            break;
        case 3:
            ret = 73002;
            break;
        case 4:
            ret = 73006;
            break;
        case 5:
            ret = 97300;
            break;
        case 6:
            ret = 157300;
            break;
    }
    return ret;
}
int getSkinIDForDaggers(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 170022;
            break;
        case 2:
            ret = 170024;
            break;
        case 3:
            ret = 170021;
            break;
        case 4:
            ret = 170023;
            break;
        case 5:
            ret = 180000;
            break;
    }
    return ret;
}
int getSkinIDForTanto(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 148000;
            break;
        case 2:
            ret = 138004;
            break;
        case 3:
            ret = 138005;
            break;
        case 4:
            ret = 138003;
            break;
        case 5:
            ret = 138000;
            break;
        case 6:
            ret = 138002;
            break;
        case 7:
            ret = 158000;
            break;
    }
    return ret;
}
int getSkinIDForScorpion(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 157900;
            break;
        case 2:
            ret = 87922;
            break;
        case 3:
            ret = 97900;
            break;
        case 4:
            ret = 87919;
            break;
        case 5:
            ret = 87921;
            break;
    }
    return ret;
}
int getSkinIDForKunai(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 77815;
            break;
        case 2:
            ret = 157800;
            break;
        case 3:
            ret = 97801;
            break;
        case 4:
            ret = 77813;
            break;
        case 5:
            ret = 77817;
            break;
        case 6:
            ret = 97800;
            break;
        case 7:
            ret = 77816;
            break;
        case 8:
            ret = 77814;
            break;
    }
    return ret;
}
int getSkinIDForFlipKnife(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 67701;
            break;
        case 2:
            ret = 67702;
            break;
        case 3:
            ret = 157700;
            break;
        case 4:
            ret = 97700;
            break;
        case 5:
            ret = 67703;
            break;
        case 6:
            ret = 67704;
            break;
        case 7:
            ret = 67705;
            break;
    }
    return ret;
}
int getSkinIDForKarambit(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 72002;
            break;
        case 2:
            ret = 72003;
            break;
        case 3:
            ret = 72004;
            break;
        case 4:
            ret = 72007;
            break;
        case 5:
            ret = 72006;
            break;
        case 6:
            ret = 157200;
            break;
        case 7:
            ret = 97203;
            break;
        case 8:
            ret = 97201;
            break;
        case 9:
            ret = 97200;
            break;
    }
    return ret;
}
int getSkinIDForButterfly(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 47503;
            break;
        case 2:
            ret = 47502;
            break;
        case 3:
            ret = 47504;
            break;
        case 4:
            ret = 47505;
            break;
        case 5:
            ret = 157500;
            break;
        case 6:
            ret = 97500;
            break;
        case 7:
            ret = 57501;
            break;
    }
    return ret;
}
int getSkinIDForM40(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 65201;
            break;
        case 2:
            ret = 125200;
            break;
        case 3:
            ret = 75205;
            break;
    }
    return ret;
}
int getSkinIDForAWM(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 85127;
            break;
        case 2:
            ret = 95100;
            break;
        case 3:
            ret = 51004;
            break;
        case 4:
            ret = 51002;
            break;
        case 5:
            ret = 125100;
            break;
        case 6:
            ret = 51001;
            break;
        case 7:
            ret = 65101;
            break;
        case 8:
            ret = 51008;
            break;
        case 9:
            ret = 51006;
            break;
        case 10:
            ret = 51007;
            break;
        case 11:
            ret = 51003;
            break;
        case 12:
            ret = 44002;
            break;
    }
    return ret;
}
int getSkinIDForM110(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 45301;
            break;
        case 2:
            ret = 95300;
            break;
    }
    return ret;
}
int getSkinIDForFabM(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 170005;
            break;
        case 2:
            ret = 76218;
            break;
        case 3:
            ret = 86300;
            break;
        case 4:
            ret = 86318;
            break;
    }
    return ret;
}
int getSkinIDForSM1014(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 62003;
            break;
        case 2:
            ret = 62002;
            break;
        case 3:
            ret = 66201;
            break;
    }
    return ret;
}
int getSkinIDForM60(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 126400;
            break;
        case 2:
            ret = 136400;
            break;
        case 3:
            ret = 126401;
            break;
    }
    return ret;
}
int getSkinIDForUMP45(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 73208;
            break;
        case 2:
            ret = 32005;
            break;
        case 3:
            ret = 32004;
            break;
        case 4:
            ret = 43202;
            break;
        case 5:
            ret = 83201;
            break;
        case 6:
            ret = 32001;
            break;
        case 7:
            ret = 73209;
            break;
    }
    return ret;
}
int getSkinIDForMP5(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 93600;
            break;
        case 2:
            ret = 73611;
            break;
        case 3:
            ret = 73612;
            break;
    }
    return ret;
}
int getSkinIDForMP7(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 43402;
            break;
        case 2:
            ret = 83410;
            break;
        case 3:
            ret = 34003;
            break;
        case 4:
            ret = 93400;
            break;
        case 5:
            ret = 34002;
            break;
        case 6:
            ret = 63401;
            break;
        case 7:
            ret = 34004;
            break;
        case 8:
            ret = 34001;
            break;
    }
    return ret;
}
int getSkinIDForP90(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 35002;
            break;
        case 2:
            ret = 93500;
            break;
        case 3:
            ret = 170017;
            break;
        case 4:
            ret = 83512;
            break;
        case 5:
            ret = 133500;
            break;
    }
    return ret;
}
int getSkinIDForFNFAL(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 44901;
            break;
        case 2:
            ret = 44903;
            break;
    }
    return ret;
}
int getSkinIDForFAMAS(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 48001;
            break;
        case 2:
            ret = 84800;
            break;
        case 3:
            ret = 74800;
            break;
        case 4:
            ret = 124800;
            break;
        case 5:
            ret = 48002;
            break;
        case 6:
            ret = 154800;
            break;
    }
    return ret;
}
int getSkinIDForAKR(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 44006;
            break;
        case 2:
            ret = 170001;
            break;
        case 3:
            ret = 44007;
            break;
        case 4:
            ret = 1044004;
            break;
        case 5:
            ret = 44005;
            break;
        case 6:
            ret = 84402;
            break;
        case 7:
            ret = 44002;
            break;
    }
    return ret;
}
int getSkinIDForAKR12(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 104400;
            break;
        case 2:
            ret = 84500;
            break;
        case 3:
            ret = 45001;
            break;
        case 4:
            ret = 84400;
            break;
    }
    return ret;
}
int getSkinIDForM4(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 46001;
            break;
        case 2:
            ret = 46007;
            break;
        case 3:
            ret = 44601;
            break;
        case 4:
            ret = 46002;
            break;
        case 5:
            ret = 44603;
            break;
        case 6:
            ret = 134600;
            break;
    }
    return ret;
}
int getSkinIDForM4A1(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 124301;
            break;
        case 2:
            ret = 154300;
            break;
        case 3:
            ret = 134300;
            break;
        case 4:
            ret = 170009;
            break;
        case 5:
            ret = 124300;
            break;
    }
    return ret;
}
int getSkinIDForM16(int id) {
    int ret;
    switch (id) {
        case 1:
            ret = 94700;
            break;
        case 2:
            ret = 134700;
            break;
        case 3:
            ret = 47002;
            break;
        case 4:
            ret = 104700;
            break;
    }
    return ret;
}
void* bombManager = nullptr;
int glovess = 0;
int knife = 0;
int m9skin = 0,karambitskin = 0,jkommandoskin = 0,butterflyskin = 0,flipknifeskin = 0,kunaiskin = 0,scorpionskin = 0,tantoskin = 0,daggersskin = 0;
int g22skin = 0,uspskin = 0,p350skin = 0,deagleskin = 0,tec9skin = 0,fivesevenskin = 0,ump45skin = 0,mp7skin = 0,p90skin = 0,mp5skin = 0,m4a1skin = 0,akrskin = 0,akr12skin = 0,m4skin = 0,m16skin = 0,famasskin = 0,fnfalskin = 0,awmskin = 0,m40skin = 0,m110skin = 0,sm1014skin = 0,fabmskin = 0,m60skin = 0;
bool grenadeesp, enableaim, vischeck, firechec, silentaim = false;
bool needFire = false;
bool telekill, masskill = false;
float aimfov, aimsmooth;
int aimtype = 1;
bool autofire = false;
bool handspos, worldfov = false;
float handsx, handsy, handsz, fovvalue = 0.0f;
bool grenadepr, bombesp, esp,pline, espline, espbox, espnick, espdist, espweapon, esparrows, esphp, espskeleton = false;
bool bhop = false;
float bhopvalue;
ImVec4 espVisibleColor = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
ImVec4 espInvisibleColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 espElementsColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
void writefile(const char* path, const char* text) {
    FILE* fs = fopen(path, ozObfuscate("w+"));
    int len = strlen(text);
    fwrite(text, sizeof(char), len, fs);
    fclose(fs);
}
std::string gen_random(const int len) {
    srand((unsigned)time(NULL) * getpid());
    static const char alphanum[] =
            "0123456789"
            "abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);

    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }

    return tmp_s;
}
const char* bool2str(bool b) { return b ? ozObfuscate("true") : ozObfuscate("false"); }
std::string ReplaceString(std::string str, const std::string& search, const std::string& replace) {
    size_t pos = 0;
    while ((pos = str.find(search, pos)) != std::string::npos) {
        str.replace(pos, search.length(), replace);
        pos += replace.length();
    }
    return str;
}
std::map<void*, bool> playersOcclusion;
bool needshoot = false;
bool vis1, vis2, vis3 = false;
bool usefov, usesmooth = false;
bool isinit = false;
Vvector3 whereToShoot = Vvector3(-1337,-228,-66);
void (*Fire)(void* gun, bool sound);
float (*GetDeltaTime)(void* nul);
void* camera;
void* (*GetCamera2)(void* nul);
void* GetCamera(void* n = NULL) { return camera; }
void* (*GetTransform)(void* nul);
void (*SendToAll)(void* chatManager, monoString* message);
void (*SetTPS)(void* a);
void (*SetFPS)(void* a);

void (*SetClanTag)(void* photonPlayer, monoString* tag);
void (*GetTransformPosition_Injected)(void* transform, Vvector3 *ret);
void (*WorldToScreen_Injected)(void* camera, Vvector3 pos, int type, Vvector3 *ret);
void (*WorldToViewport_Injected)(void* camera, Vvector3 pos, int type, Vvector3 *ret);
int (*GetPlayerHealth)(void* player);
int (*GetPlayerTeam)(void* player);
bool (*IsTimeToDetonate)(void* player);
monoString* (*GetNickName)(void* player);
void* (*GetActiveWeapon)(void* weaponryController);
int (*GetWeaponID)(void* weapon);
bool (*IsLocal)(void* player);
Vvector3 (*GetTransformForward)(void* transform);
Vvector3 (*GetTransformRight)(void* transform);
Vvector3 (*getAxis)(void* transform);
bool (*IsBombPlanted)(void* player);
void (*Done)(void* player, bool defused, double time);
Vvector3 (*GetBombPosition)(void* player);
bool autowin = false;
double (*GetBombTime)(void* player);
void (*Hit)(void* player);
#include "ByNameModding/BNM_data/Il2CppHeaders/2019.4.h"
void (*SetTransformPosition)(void* nulds, Vvector3 a);
struct RayCastHit {Vvector3 m_Point;Vvector3 m_Normal;unsigned int m_FaceID;float m_Distance;Vvector2 m_UV;int m_Colider; };
void* (*GetPhotonPlayer)(void* transform);
const char* WeaponID2Str(int id) {
    const char* out = "?";
    switch (id) {
        case 11:
            out = ozObfuscate("G22");
            break;
        case 12:
            out = ozObfuscate("USP");
            break;
        case 13:
            out = ozObfuscate("P350");
            break;
        case 15:
            out = ozObfuscate("DesertEagle");
            break;
        case 16:
            out = ozObfuscate("TEC-9");
            break;
        case 17:
            out = ozObfuscate("FiveSeven");
            break;
        case 32:
            out = ozObfuscate("UMP45");
            break;
        case 34:
            out = ozObfuscate("MP7");
            break;
        case 35:
            out = ozObfuscate("P90");
            break;
        case 36:
            out = ozObfuscate("MP5");
            break;
        case 43:
            out = ozObfuscate("M4A1");
            break;
        case 44:
            out = ozObfuscate("AKR");
            break;
        case 45:
            out = ozObfuscate("AKR12");
            break;
        case 46:
            out = ozObfuscate("M4");
            break;
        case 47:
            out = ozObfuscate("M16");
            break;
        case 48:
            out = ozObfuscate("FAMAS");
            break;
        case 49:
            out = ozObfuscate("FnFAL");
            break;
        case 51:
            out = ozObfuscate("AWM");
            break;
        case 52:
            out = ozObfuscate("M40");
            break;
        case 53:
            out = ozObfuscate("M110");
            break;
        case 62:
            out = ozObfuscate("SM1014");
            break;
        case 63:
            out = ozObfuscate("FabM");
            break;
        case 64:
            out = ozObfuscate("M40");
            break;
        case 100:
            out = ozObfuscate("Bomb");
            break;
        case 91:
            out = ozObfuscate("GrenadeHE");
            break;
        case 92:
            out = ozObfuscate("GrenadeSmoke");
            break;
        case 93:
            out = ozObfuscate("GrenadeFlash");
            break;
        case 70:
            out = ozObfuscate("Knife");
            break;
        case 71:
            out = ozObfuscate("KnifeBayonet");
            break;
        case 72:
            out = ozObfuscate("KnifeKarambit");
            break;
        case 73:
            out = ozObfuscate("jKommando");
            break;
        case 75:
            out = ozObfuscate("KnifeButterfly");
            break;
        case 77:
            out = ozObfuscate("FlipKnife");
            break;
        case 78:
            out = ozObfuscate("KunaiKnife");
            break;
        case 79:
            out = ozObfuscate("ScorpionKnife");
            break;
        case 80:
            out = ozObfuscate("Tanto");
            break;
        case 81:
            out = ozObfuscate("Daggers");
            break;
    }
    return out;
}
bool IsKnife(int weapon) {return weapon == 100 || weapon == 81 || weapon == 80 || weapon == 78 || weapon == 79 ||weapon == 77 || weapon == 75 || weapon == 73 || weapon == 72 || weapon == 71 || weapon == 70;}
bool IsPlayerDead(void *player) {
    if(GetPlayerHealth(GetPhotonPlayer(player)) < 1) {
        LOGD("Dread!");
        return true;
    } else {
        LOGD("Alive!");
        return false;
    }
    return false;
}
Vvector3 WorldToScreen(void* camera, Vvector3 pos) {
    Vvector3 out;
    WorldToScreen_Injected(camera, pos, 2, &out);
    return out;
}
Vvector3 GetTransformLocation(void* player) {
    Vvector3 returnv;
    GetTransformPosition_Injected(player, &returnv);
    return returnv;
}
Vvector3 GetPlayerLocation(void* player) {
    Vvector3 returnv;
    GetTransformPosition_Injected(GetTransform(player), &returnv);
    return returnv;
}
Vvector3 GetPosition(void* player) {
    Vvector3 returnv;
    GetTransformPosition_Injected(player, &returnv);
    return returnv;
}
Vvector2 GetAimRotation(void* player) {
    void* ac = *(void **)((uint64_t) player + 0x2C);
    if (ac) {
        void* ad = *(void **)((uint64_t) ac + 0x5C);
        if (ad) {
            Vvector3 angles =  *(Vvector3 *)((uint64_t) ad + 0x10);
            return Vvector2(angles.x, angles.y);
        }
    }
}
int GetActiveWeaponID(void* player) {
    int id = 0;
    void* weaponry = *(void **)((uint64_t) player + 0x30);
    if (weaponry) {
        void* weapon = GetActiveWeapon(weaponry);
        if (weapon) {
            id = GetWeaponID(weapon);
        }
    }
    return id;
}

void* GetBones(void* p) {return *(void **) ((uint64_t) p + 0x18);}
Vvector3 GetPlayerHead(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0xC);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerNeck(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x10);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerHip(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x3C);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerleftLowerArm(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x24);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerLeftHand(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x28);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerRightHand(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x38);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerleftUpperArm(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x20);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerrightLowerArm(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x34);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerrightUpperArm(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x30);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerleftLowerLeg(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x48);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerleftUpperLeg(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x44);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerrightLowerLeg(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x54);
    return GetTransformLocation(bone);
}
Vvector3 GetPlayerrightUpperLeg(void *player) {
    void* bone = *(void **) ((uint64_t) GetBones(player) + 0x50);
    return GetTransformLocation(bone);
}
void* myPlayer = NULL;
bool IsPlayerVisible(void* player) {
    if (playersOcclusion.find(player) == playersOcclusion.end()) {
        return false;
    } else {
        return playersOcclusion[player];
    }
}
bool IsInFovCircle(void* playerFov){
    Vvector3 target = GetPlayerLocation(playerFov) - GetPlayerLocation(myPlayer);
    Vvector3 dest = GetTransformForward(GetTransform(GetCamera(NULL))) * 100;
    float aimAngle = Vector3::Angle(Vector3(target.x, target.y, target.z), Vector3(dest.x, dest.y, dest.z));
    if (aimAngle <= (aimfov / 700.0f)) {
        return true;
    } else {
        return false;
    }
}
struct enemy_t {
    void *object;
    bool isVisible = false;
    float health = 0;
    int team = 0;
    int armor = 0;
    int ammo = 0;
    std::string name = " ";
    std::string weapon = " ";
    Vvector3 wts1 = Vvector3(0,0,0);
    Vvector3 wts2 = Vvector3(0,0,0);
    Vvector3 pos = Vvector3(0,0,0);
    Vvector3 rot = Vvector3(0,0,0);
};
void* occlusionControl = NULL;
void* gunController = NULL;
bool moveb = false;
void (*old_movebefore)(...);
void movebefore(void* a,void* b) {
    if (moveb) return;
    old_movebefore(a,b);
}
bool dontr = false;
void (*old_dontreturn)(...);
void dontreturn(void* a) {
    if (dontr) return;
    old_dontreturn(a);
}

bool camf = true;

class EntityList {

public:
    std::vector<enemy_t *> *enemies;

    EntityList() {
        enemies = new std::vector<enemy_t *>();
    }

    bool isEnemyPresent(void *enemyObject) {
        for (std::vector<enemy_t *>::iterator it = enemies->begin(); it != enemies->end(); it++) {
            if ((*it)->object == enemyObject) {
                return true;
            }
        }
        return false;
    }

    void tryAddEnemy(void *enemyObject) {
        if (isEnemyPresent(enemyObject)) {
            return;
        }
        if (!enemyObject) {
            return;
        }
        enemy_t *newEnemy = new enemy_t();
        newEnemy->object = enemyObject;
        enemies->push_back(newEnemy);
    }

    void fixPlayerList() {
        if (!enemies->empty()) {
            for (int i = 0; i < enemies->size(); i++) {
                enemy_t *current = (*enemies)[i];
                if (!current->object) {
                    enemies->erase(enemies->begin() + i);
                } else if (!GetPhotonPlayer(current->object) || !GetBones(current->object)) {
                    enemies->erase(enemies->begin() + i);
                }
            }
        }
    }

    void updateEnemy() {
        if (!enemies->empty()) {
            for (int i = 0; i < enemies->size(); i++) {
                enemy_t *current = (*enemies)[i];
                if (current->object) {
                    auto op = GetPhotonPlayer(current->object);
                    if (op) {
                        current->pos = GetPlayerLocation(current->object);
                        current->health = GetPlayerHealth(op);
                        current->team = GetPlayerTeam(op);
                        if (GetNickName(op)) current->name = GetNickName(op)->get_string();
                        current->isVisible = IsPlayerVisible(current->object);
                        auto w1 = *(void **) ((uint64_t) current->object + 0x30);
                        if (w1) {
                            auto w2 = *(void **) ((uint64_t) w1 + 0x50);
                            if (w2) {
                                auto w3 = *(void **) ((uint64_t) w2 + 0x3C);
                                if (w3) {
                                    auto w4 = *(monoString **) ((uint64_t) w3 + 0x10);
                                    if (w4) {
                                        current->weapon = w4->get_string();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
};
struct grenade_t { void* object; };
class GrenadesList {
public:
    GrenadesList(){
        grenades = new std::vector<grenade_t *>();
    }

    bool isEnemyPresent(void *enemyObject){
        for(std::vector<grenade_t *>::iterator it = grenades->begin(); it != grenades->end(); it++){
            if((*it)->object == enemyObject){
                return true;
            }
        }

        return false;
    }

    void removeGrenade(grenade_t *enemy){
        for(int i = 0; i<grenades->size(); i++){
            if((*grenades)[i] == enemy){
                grenades->erase(grenades->begin() + i);
                return;
            }
        }
    }

    void addGrenade(void *enemyObject){
        if(isEnemyPresent(enemyObject)){
            return;
        }

        if(IsTimeToDetonate(enemyObject)){
            return;
        }

        grenade_t *newEnemy = new grenade_t();
        newEnemy->object = enemyObject;
        grenades->push_back(newEnemy);
    }

    void updateEnemies(void *enemyObject){
        for(int i=0; i<grenades->size(); i++){
            grenade_t *current = (*grenades)[i];

            if(current->object == NULL){
                grenades->erase(grenades->begin() + i);
            }

            if(IsTimeToDetonate(current->object)){
                grenades->erase(grenades->begin() + i);
            }
        }
    }

    void removeEnemyGivenObject(void *enemyObject){
        for(int i = 0; i<grenades->size(); i++){
            if((*grenades)[i]->object == enemyObject){
                grenades->erase(grenades->begin() + i);
                return;
            }
        }
    }
    std::vector<grenade_t *> *grenades;
};
RotVector3 VV3toV3(Vvector3 v) {
    return RotVector3(v.x, v.y, v.z);
}
Qquaternion QtQQ(Quaternion q) {
    return Qquaternion(q.x, q.y, q.z, q.w);
}
void SetAimRotation(void* a, Vvector3 b) {
    void* ac = *(void **)((uint64_t) a + 0x2C);
    if (ac) {
        void* ad = *(void **)((uint64_t) ac + 0x5C);
        if (ad) {
            *(Vvector3 *)((uint64_t) ad + 0x10) = b;
            *(Vvector3 *)((uint64_t) ad + 0x1C) = b;
        }
    }
}
int(*GetCameraMode)(void *player);

uint64_t chat_offset = 0;
void* chat_object = nullptr;
void* enemyPlayer = nullptr;
int chat_step = 0;
bool isCrouching = false;
bool crouchcheck = false;
float shootdelay = 0;
EntityList *entityList;
GrenadesList *grenadesList;
float chatTime, clantagTime = 0;
std::string customCT;
int letterCT = 1;
std::string CT;
int m_team = 0;
void* potentialPlayer = NULL;
float aimy = -0.65f;
Vector3 aimedPlayerHeadPos = Vector3(0,0,0);
bool aimeds = false;
typedef struct {
public:
    void* main(RotVector3 startPoint, RotVector3 endPoint);
    RotVector3 get_StartPoint;
    RotVector3 get_EndPoint;
private:
    void* set_EndPoint(RotVector3 value);
    float get_RestPenetrationPower;
    void* set_RestPenetrationPower(float value);
} Hits;

float silentChance;
bool chance;
Hits* (*old_CastHit)(...);
Hits* CastHit(Vector3 startPosition, Vector3 direction, void* parameters) {
    if (silentaim && aimeds && silentChance >= rand() % 100) direction = Vector3::Normalize(aimedPlayerHeadPos - startPosition);
    return old_CastHit(startPosition, direction, parameters);
}

float CalcAngle(void*a, void*b) {
    if ((vischeck || IsPlayerVisible(b)) && GetCamera(NULL)) {
        Vvector3 target = GetPosition(a) - GetPosition(GetTransform(GetCamera(NULL)));
        return Vector3::Angle(Vector3(target.x,target.y,target.z), Vector3((GetTransformForward(GetTransform(GetCamera(NULL))) * 100).x,(GetTransformForward(GetTransform(GetCamera(NULL))) * 100).y,(GetTransformForward(GetTransform(GetCamera(NULL))) * 100).z));
    }
    return 999;
}
bool AimHead;
bool AimBody;
bool AimArms;
bool AimLegs;
bool killen = false;


void(*old_Arms1)(...);
void Arms1(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms1(a);
}
void(*old_Arms2)(...);
void Arms2(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms2(a);
}

void(*old_Arms3)(...);
void Arms3(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms3(a);
}
void(*old_Arms4)(...);
void Arms4(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms4(a);
}
void(*old_Arms5)(...);
void Arms5(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms5(a);
}
void(*old_Arms6)(...);
void Arms6(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);

    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms6(a);
}
void(*old_Arms7)(...);
void Arms7(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms7(a);
}
void(*old_Arms8)(...);
void Arms8(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);

    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms8(a);
}
void(*old_Arms9)(...);
void Arms9(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);

    if (handspos) {
        *(Vvector3 *)((uint64_t) a + 0x94) = Vvector3(handsx, handsy, handsz);
        *(bool *)((uint64_t) a + 0x44) = false; //resetToCamPos
    }
    old_Arms9(a);
}

struct position_info {
public:
    Vvector3 pos;
    Color color;
};
std::deque<position_info>position_data;

bool m3r = false;
bool m1r = false;


void(*SetLocalPosition)(void *a, Vvector3 b);

void(*old_Player_Update)(void *player);
void Player_Update(void *player) {
    old_Player_Update(player);
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);



    if (player) {
        entityList->tryAddEnemy(player);
        entityList->updateEnemy();

        float closestDistance = 9999.0f;
        if (GetPhotonPlayer(player)) {
            if (IsLocal(GetPhotonPlayer(player))) {

                if (m3r) {
                    SetTPS(player);
                    m3r = false;
                }
                if (m1r) {
                    SetFPS(player);
                    m1r = false;
                }


                if (pline) {
                    position_data.push_back(
                            {GetPosition(GetTransform(player)),Color(50, 255, 50)});
                    if (position_data.size() > 255) {
                        position_data.pop_front();
                    }
                }


                camera = GetCamera2(NULL);

                //LOGD("Local player found: %p", player);
                myPlayer = player;
                m_team = GetPlayerTeam(GetPhotonPlayer(myPlayer));
                if (chatspam) {
                    chatTime += GetDeltaTime(NULL);
                }
                if (clantag && GetPhotonPlayer(myPlayer)) {
                    clantagTime += GetDeltaTime(NULL) * 50;
                    if ((clantagTime - 12.f) > 0) {
                        if(letterCT >= 16) letterCT = 1;
                        std::string color = std::string(ozObfuscate("#ff0000"));
                        switch(letterCT) {
                            case 1:
                                customCT = std::string(ozObfuscate("t"));
                                break;
                            case 2:
                                customCT = std::string(ozObfuscate("t."));
                                break;
                            case 3:
                                customCT = std::string(ozObfuscate("t.m"));
                                break;
                            case 4:
                                customCT = std::string(ozObfuscate("t.me"));
                                break;
                            case 5:
                                customCT = std::string(ozObfuscate("t.me/"));
                                break;
                            case 6:
                                customCT = std::string(ozObfuscate("t.me/g"));
                                break;
                            case 7:
                                customCT = std::string(ozObfuscate("t.me/gr"));
                                break;
                            case 8:
                                customCT = std::string(ozObfuscate("t.me/gra"));
                                break;
                            case 9:
                                customCT = std::string(ozObfuscate("t.me/grap"));
                                break;
                            case 10:
                                customCT = std::string(ozObfuscate("t.me/grape"));
                                break;
                            case 11:
                                customCT = std::string(ozObfuscate("t.me/grapec"));
                                break;
                            case 12:
                                customCT = std::string(ozObfuscate("t.me/grapech"));
                                break;
                            case 13:
                                customCT = std::string(ozObfuscate("t.me/grapeche"));
                                break;
                            case 14:
                                customCT = std::string(ozObfuscate("t.me/grapechea"));
                                break;
                            case 15:
                                customCT = std::string(ozObfuscate("t.me/grapecheat"));
                                break;
                            case 16:
                                customCT = std::string(ozObfuscate("t.me/grapecheats"));
                                break;
                        }
                        letterCT++;
                        CT = (std::string(ozObfuscate("<color=")) + color + std::string(ozObfuscate(">")) + customCT + std::string(ozObfuscate("</color>")));
                        SetClanTag(GetPhotonPlayer(myPlayer), CreateMonoString(CT.c_str()));
                        clantagTime = 0.f;
                    }
                }
                if (chatspam && chat_object) {
                    if ((chatTime - 2.f) > 0) {
                        chat_step++;
                        if (chat_step >= 10) {
                            chat_step = 0;
                        }
                        switch (chat_step) {
                            case 0:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("Мощнейший чит без бана - t.me/grapecheats")));
                                break;
                            case 1:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("GrapeCheats.store - самые лучшие читы без бана аккаунта на Android только тут")));
                                break;
                            case 2:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("telegram: grapecheats - турнирный / легитный / rage чит на Android абсолютно без бана")));
                                break;
                            case 3:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("telegram: grapecheats - РАЗЪЕБИ ВСЕХ И ТЕБЯ НЕ ЗАБАНЯТ")));
                                break;
                            case 4:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("telegram: grapecheats - Полностью безопасный чит.")));
                                break;
                            case 5:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("telegram: grapecheats - Скинченджер, аимбот, ESP на Андроид, да еще и без бана?")));
                                break;
                            case 6:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("t.me/grapecheats")));
                                break;
                            case 7:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("t.me/grapecheats - Покупка любым удобным способом")));
                                break;
                            case 8:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("t.me/grapecheats - 79 рублей/день! Разъеби любого!")));
                                break;
                            case 9:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("GrapeCheats - превосходство.")));
                                break;
                            case 10:
                                SendToAll(chat_object, CreateMonoString(ozObfuscate("GrapeCheats - играй без бана.")));
                                break;
                        }
                        chatTime = 0.f;
                    }
                }
                aimeds = false;
                if (!entityList->enemies->empty()) {
                    for (int i = 0; i < entityList->enemies->size(); i++) {
                        void *player = (*entityList->enemies)[i]->object;
                        if (player) {
                            if (GetPlayerTeam(GetPhotonPlayer(player)) != m_team) {
                                if (telekill) {
                                    Vvector3 enemyLocation = GetPlayerLocation(player);
                                    SetTransformPosition(GetTransform(myPlayer), Vvector3(enemyLocation.x, enemyLocation.y, enemyLocation.z - 1));
                                }
                                if (masskill) {
                                    Vvector3 enemyLocation = GetPlayerLocation(myPlayer);
                                    SetTransformPosition(GetTransform(player), Vvector3(enemyLocation.x, enemyLocation.y, enemyLocation.z + 1));
                                }
                                if (silentaim && GetPlayerHealth(GetPhotonPlayer(player)) > 0) {
                                    auto biped = GetBones(player);
                                    if (biped && GetCamera(NULL) && (vischeck || IsPlayerVisible(player))) {

                                        float Head1 = 999;
                                        float Head2 = 999;

                                        float Body1 = 999;
                                        float Body2 = 999;
                                        float Body3 = 999;

                                        float Arml1 = 999;
                                        float Arml2 = 999;
                                        float Arml3 = 999;
                                        float Arml4 = 999;
                                        float Armr1 = 999;
                                        float Armr2 = 999;
                                        float Armr3 = 999;
                                        float Armr4 = 999;

                                        float Legl1 = 999;
                                        float Legl2 = 999;
                                        float Legl3 = 999;
                                        float Legl4 = 999;
                                        float Legr1 = 999;
                                        float Legr2 = 999;
                                        float Legr3 = 999;
                                        float Legr4 = 999;

                                        if (*(void **) ((uint64_t) biped + 0xC) &&
                                            *(void **) ((uint64_t) biped + 0x14) &&
                                            *(void **) ((uint64_t) biped + 0x18) &&
                                            *(void **) ((uint64_t) biped + 0x3C) &&
                                            *(void **) ((uint64_t) biped + 0x10) &&
                                            *(void **) ((uint64_t) biped + 0x1C) &&
                                            *(void **) ((uint64_t) biped + 0x20) &&
                                            *(void **) ((uint64_t) biped + 0x24) &&
                                            *(void **) ((uint64_t) biped + 0x28) &&
                                            *(void **) ((uint64_t) biped + 0x2C) &&
                                            *(void **) ((uint64_t) biped + 0x30) &&
                                            *(void **) ((uint64_t) biped + 0x34) &&
                                            *(void **) ((uint64_t) biped + 0x38) &&
                                            *(void **) ((uint64_t) biped + 0x40) &&
                                            *(void **) ((uint64_t) biped + 0x44) &&
                                            *(void **) ((uint64_t) biped + 0x48) &&
                                            *(void **) ((uint64_t) biped + 0x4C) &&
                                            *(void **) ((uint64_t) biped + 0x50) &&
                                            *(void **) ((uint64_t) biped + 0x54)) {


                                            if (AimHead || AimBody || AimArms || AimLegs) {

                                                if (AimHead) {
                                                    Head1 = CalcAngle(*(void **) ((uint64_t) biped + 0xC), player);
                                                    Head2 = CalcAngle(*(void **) ((uint64_t) biped + 0x10), player);
                                                }
                                                if (AimBody) {
                                                    Body1 = CalcAngle(*(void **) ((uint64_t) biped + 0x14), player);
                                                    Body2 = CalcAngle(*(void **) ((uint64_t) biped + 0x18), player);
                                                    Body3 = CalcAngle(*(void **) ((uint64_t) biped + 0x3C), player);
                                                }
                                                if (AimArms) {
                                                    Arml1 = CalcAngle(*(void **) ((uint64_t) biped + 0x1C), player);
                                                    Arml2 = CalcAngle(*(void **) ((uint64_t) biped + 0x20), player);
                                                    Arml3 = CalcAngle(*(void **) ((uint64_t) biped + 0x24), player);
                                                    Arml4 = CalcAngle(*(void **) ((uint64_t) biped + 0x28), player);

                                                    Armr1 = CalcAngle(*(void **) ((uint64_t) biped + 0x2C), player);
                                                    Armr2 = CalcAngle(*(void **) ((uint64_t) biped + 0x30), player);
                                                    Armr3 = CalcAngle(*(void **) ((uint64_t) biped + 0x34), player);
                                                    Armr4 = CalcAngle(*(void **) ((uint64_t) biped + 0x38), player);
                                                }
                                                if (AimLegs) {
                                                    Legl1 = CalcAngle(*(void **) ((uint64_t) biped + 0x40), player);
                                                    Legl2 = CalcAngle(*(void **) ((uint64_t) biped + 0x44), player);
                                                    Legl3 = CalcAngle(*(void **) ((uint64_t) biped + 0x48), player);
                                                    //Legl4 = CalcAngle(*(void * *) ((uint64_t) biped + 0xC));

                                                    Legr1 = CalcAngle(*(void **) ((uint64_t) biped + 0x4C), player);
                                                    Legr2 = CalcAngle(*(void **) ((uint64_t) biped + 0x50), player);
                                                    Legr3 = CalcAngle(*(void **) ((uint64_t) biped + 0x54), player);
                                                    //Legr4 = CalcAngle(*(void * *) ((uint64_t) biped + 0xC));
                                                }


                                                void *aimedpos;
                                                float aimedin = std::min(
                                                        {Head1, Head2, Body1, Body2, Body3, Arml1, Arml2,
                                                         Arml3, Arml4,
                                                         Armr1, Armr2, Armr3, Armr4, Legl1, Legl2, Legl3,
                                                         Legr1,
                                                         Legr2, Legr3});

                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0xC), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0xC);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x14), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x14);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x18), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x18);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x3C), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x3C);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x10), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x10);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x1C), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x1C);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x20), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x20);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x24), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x24);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x28), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x28);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x2C), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x2C);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x30), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x30);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x34), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x34);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x38), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x38);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x40), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x40);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x44), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x44);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x48), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x48);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x4C), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x4C);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x50), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x50);
                                                if (CalcAngle(*(void **) ((uint64_t) biped + 0x54), player) ==
                                                    aimedin)
                                                    aimedpos = *(void **) ((uint64_t) biped + 0x54);

                                                if (aimedpos) {
                                                    Vvector3 target = GetPosition(aimedpos) -
                                                                      GetPosition(GetTransform(
                                                                              GetCamera(NULL)));
                                                    float aimAngle = Vector3::Angle(Vector3(target.x,target.y,target.z), Vector3((GetTransformForward(GetTransform(GetCamera(NULL))) * 100).x,(GetTransformForward(GetTransform(GetCamera(NULL))) * 100).y,(GetTransformForward(GetTransform(GetCamera(NULL))) * 100).z));


                                                    if (aimAngle <= aimfov / 700.0f) {
                                                        aimedPlayerHeadPos = Vector3(GetPosition(aimedpos).x,GetPosition(aimedpos).y,GetPosition(aimedpos).z);

                                                        aimeds = true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

bool freez = false;

bool infjump;
bool (*old_IsGrounded)(void *player);
bool IsGrounded(void *player) {
    if (infjump) {
        return true;
    }
    return freez || old_IsGrounded(player);
}
bool triggerbot = false;
float shotTimer = 0;
#define FIELDFUNCTION(type, object, offset) *(type *)((uint64_t) object + offset)

void setShort(void* a,short b) {
    FIELDFUNCTION(int,a,0xC) = (int)b + FIELDFUNCTION(int,a,0x8);
}
void setFloat(void* a,float b) {
    FIELDFUNCTION(float,a,0xC) = b + FIELDFUNCTION(float,a,0x8);
}

short getShort(void* a) {
    return (short)(FIELDFUNCTION(int,a,0xC) - FIELDFUNCTION(int,a,0x8));
}
float getFloat(void* a) {
    return FIELDFUNCTION(float,a,0xC) - FIELDFUNCTION(float,a,0x8);
}
bool wall = false;

float (*old_wallf)(...);
float wallf(void *a, int b, float c) {
    if (wall) return 50;
    return old_wallf(a,b,c);
}

bool recoil = false;
void(*old_GunController_Update)(void *a);
void GunController_Update(void *a) {
    if (infammo) {
        if (getShort(FIELDFUNCTION(void*,a,0x80)) < 1) setShort(FIELDFUNCTION(void*,a,0x80),9);
        if (getShort(FIELDFUNCTION(void*,a,0x84)) < 1) setShort(FIELDFUNCTION(void*,a,0x84),9);
    }
    if (fastfire) {
        setFloat(FIELDFUNCTION(void*,a,0x6C),0);
    }
    if (recoil) {
        FIELDFUNCTION(float,a,0xF4) = 0;
        FIELDFUNCTION(float,a,0xF8) = 0;
        FIELDFUNCTION(float,a,0xE8) = 0;

        auto rec = FIELDFUNCTION(void*,a,0x8C);
        if (rec) {
            FIELDFUNCTION(float,rec,0x10) = 0;
            FIELDFUNCTION(float,rec,0x8) = 0;
            FIELDFUNCTION(float,rec,0xC) = 0;
            FIELDFUNCTION(Vector2,rec,0x14) = Vector2(0,0);
        }
    }
    old_GunController_Update(a);
}


void(*old_OnOcclusionBecameInvisible)(void *player);
void OnOcclusionBecameInvisible(void *player) {
    if (player) {
        playersOcclusion[player] = false;
    }
    //old_OnOcclusionBecameInvisible(player);
}
void(*old_OnOcclusionBecameVisible)(void *player);
void OnOcclusionBecameVisible(void *player) {
    if (player) {
        playersOcclusion[player] = true;
    }
    old_OnOcclusionBecameVisible(player);
}
void(*old_BombManager_Update)(void *player);
void BombManager_Update(void *player) {
    if (player) {
        if (!bombManager) {
           // LOGD("BOMBMANAGER %p", player);
            bombManager = player;
        }
    }
    old_BombManager_Update(player);
}
int (*old_GetEquippedSkinID)(void *player, int weapon, int team);
int GetEquippedSkinID(void *player, int weapon, int team) {
    if (player) {
        //pistols
        if (weapon == 11 && g22skin != 0) {
            return getSkinIDForG22(g22skin);
        }
        else if (weapon == 12 && uspskin != 0) {
            return getSkinIDForUSP(uspskin);
        }
        else if (weapon == 13 && p350skin != 0) {
            return getSkinIDForP350(p350skin);
        }
        else if (weapon == 15 && deagleskin != 0) {
            return getSkinIDForDeagle(deagleskin);
        }
        else if (weapon == 16 && tec9skin != 0) {
            return getSkinIDForTEC9(tec9skin);
        }
        else if (weapon == 17 && fivesevenskin != 0) {
            return getSkinIDForFiveSeven(fivesevenskin);
        }
        //smg
        else if (weapon == 32 && ump45skin != 0) {
            return getSkinIDForUMP45(ump45skin);
        }
        else if (weapon == 34 && mp7skin != 0) {
            return getSkinIDForMP7(mp7skin);
        }
        else if (weapon == 36 && mp5skin != 0) {
            return getSkinIDForMP5(mp5skin);
        }
        else if (weapon == 35 && p90skin != 0) {
            return getSkinIDForP90(p90skin);
        }
        //rifles
        else if (weapon == 43 && m4a1skin != 0) {
            return getSkinIDForM4A1(m4a1skin);
        }
        else if (weapon == 44 && akrskin != 0) {
            return getSkinIDForAKR(akrskin);
        }
        else if (weapon == 46 && m4skin != 0) {
            return getSkinIDForM4(m4skin);
        }
        else if (weapon == 47 && m16skin != 0) {
            return getSkinIDForM16(m16skin);
        }
        else if (weapon == 45 && akr12skin != 0) {
            return getSkinIDForAKR12(akr12skin);
        }
        else if (weapon == 48 && famasskin != 0) {
            return getSkinIDForFAMAS(famasskin);
        }
        else if (weapon == 49 && fnfalskin != 0) {
            return getSkinIDForFNFAL(fnfalskin);
        }
        //heavy
        else if (weapon == 62 && sm1014skin != 0) {
            return getSkinIDForSM1014(sm1014skin);
        }
        else if (weapon == 63 && fabmskin != 0) {
            return getSkinIDForFabM(fabmskin);
        }
        else if (weapon == 64 && m60skin != 0) {
            return getSkinIDForM60(m60skin);
        }
        //snipers
        else if (weapon == 51 && awmskin != 0) {
            return getSkinIDForAWM(awmskin);
        }
        else if (weapon == 53 && m110skin != 0) {
            return getSkinIDForM110(m110skin);
        }
        else if (weapon == 52 && m40skin != 0) {
            return getSkinIDForM40(m40skin);
        }
        else if (weapon == 71 && m9skin != 0) {
            return getSkinIDForM9(m9skin);
        }
        //knifes
        else if (weapon == 72 && karambitskin != 0) {
            return getSkinIDForKarambit(karambitskin);
        }
        else if (weapon == 73 && jkommandoskin != 0) {
            return getSkinIDForJKommando(jkommandoskin);
        }
        else if (weapon == 75 && butterflyskin != 0) {
            return getSkinIDForButterfly(butterflyskin);
        }
        else if (weapon == 77 && flipknifeskin != 0) {
            return getSkinIDForFlipKnife(flipknifeskin);
        }
        else if (weapon == 78 && kunaiskin != 0) {
            return getSkinIDForKunai(kunaiskin);
        }
        else if (weapon == 79 && scorpionskin != 0) {
            return getSkinIDForScorpion(scorpionskin);
        }
        else if (weapon == 80 && tantoskin != 0) {
            return getSkinIDForTanto(tantoskin);
        }
        else if (weapon == 81 && daggersskin != 0) {
            return getSkinIDForDaggers(daggersskin);
        }
    }
    return old_GetEquippedSkinID(player, weapon, team);
}
int (*old_GetEquippedKnifeID)(void* player);
int GetEquippedKnifeID(void* player) {
    if (player) {
        switch (knife) {
            case 0:
                return 70; //Default Knife
                break;
            case 1:
                return 71;
                break;
            case 2:
                return 72;
                break;
            case 3:
                return 73;
                break;
            case 4:
                return 75;
                break;
            case 5:
                return 77;
                break;
            case 6:
                return 78;
                break;
            case 7:
                return 79;
                break;
            case 8:
                return 80;
                break;
            case 9:
                return 81;
                break;
        }
    }
    return old_GetEquippedKnifeID(player);
}
int (*old_GetGloves)(void* player);
int GetGloves(void* player) {
    if (player) {
        switch (glovess) {
            case 0:
                return old_GetGloves(player);
                break;
            case 1:
                return 3001;
                break;
            case 2:
                return 3007;
                break;
            case 3:
                return 3004;
                break;
            case 4:
                return 3005;
                break;
            case 5:
                return 3003;
                break;
            case 6:
                return 3000;
                break;
            case 7:
                return 3002;
                break;
            case 8:
                return 3009;
                break;
        }
    }
    return old_GetGloves(player);
}

void(*old_GrenadeManager_Update)(void *player);
void GrenadeManager_Update(void *player) {
    if (player) {
        monoDictionary<int, void*>* grenades = *(monoDictionary<int, void*>**)((uint64_t)player + 0x10);
        if (grenades != NULL) {
            std::vector<void*> objects = grenades->getValues();
            for (int u = 0; u < objects.size(); u++) {
                if (objects[u] != nullptr) {
                    grenadesList->addGrenade(objects[u]);
                }
                grenadesList->updateEnemies(objects[u]);
            }
        }
    }
    old_GrenadeManager_Update(player);
}
#define ozObfuscate_std(str) std::string(ozObfuscate(str))

bool contains(std::string in, std::string target) {
    if(strstr(in.c_str(), target.c_str())) {
        return true;
    }
    return false;
}
std::string ReplaceStringFuck(std::string subject, const std::string& search, const std::string& replace) {
    size_t pos = 0;
    while ((pos = subject.find(search, pos)) != std::string::npos) {
        subject.replace(pos, search.length(), replace);
        pos += replace.length();
    }
    return subject;
}

extern "C" {

JNIEXPORT jobjectArray JNICALL
Java_com_axlebolt_service_ServiceStarter_add(
        JNIEnv *env,
        jobject thiz,
        jobjectArray stringArray) {
    jobjectArray ret;
    int stringCount = env->GetArrayLength(stringArray);
    const char *files[5];
    for (int i = 0; i < stringCount; i++) {
        jstring string = (jstring) (env->GetObjectArrayElement(stringArray, i));
        const char *rawString = env->GetStringUTFChars(string, 0);
        files[i] = rawString;
    }
    int arsize = (sizeof files / sizeof files[0]);
    ret = (jobjectArray) env->NewObjectArray(arsize,
                                             env->FindClass(ozObfuscate("java/lang/String")),
                                             env->NewStringUTF(""));
    int o;
    for (o = 0; o < arsize; o++) {
        if (contains(files[o], ozObfuscate_std("classes.dex"))) {
            env->SetObjectArrayElement(ret, o, env->NewStringUTF(ozObfuscate("3253021603")));
        } else if (contains(files[o], ozObfuscate_std("resources.arsc"))) {
            env->SetObjectArrayElement(ret, o, env->NewStringUTF(ozObfuscate("2028666601")));
        } else if (contains(files[o], ozObfuscate_std("AndroidManifest.xml"))) {
            env->SetObjectArrayElement(ret, o, env->NewStringUTF(ozObfuscate("489218931")));
        } else if (contains(files[o], ozObfuscate_std("META-INF/MANIFEST.MF"))) {
            env->SetObjectArrayElement(ret, o, env->NewStringUTF(ozObfuscate("3211727376")));
        } else if (contains(files[o], ozObfuscate_std("META-INF/CERT.SF"))) {
            env->SetObjectArrayElement(ret, o, env->NewStringUTF(ozObfuscate("3016769869")));
        } else {
            exit(228);
        }
    }
    return ret;
}
}

typedef std::string gggomg;



monoString* (*old_services)(...);
monoString* services(void* inst, void* inst2, void* inst3) {
    std::string valtostd(old_services(inst, inst2, inst3)->c_str());
    //   LOGI("Services : %s", valtostd.c_str());
    if (contains(valtostd, ozObfuscate_std("MessageForwardingService"))) {
        return CreateMonoString(ozObfuscate("com.google.firebase.messaging.MessageForwardingService|com.applovin.impl.sdk.utils.AppKilledService|com.applovin.impl.adview.activity.FullscreenAdService|com.google.android.gms.measurement.AppMeasurementService|com.google.android.gms.measurement.AppMeasurementJobService|com.google.firebase.components.ComponentDiscoveryService|com.google.android.gms.auth.api.signin.RevocationBoundService|com.google.firebase.messaging.FirebaseMessagingService|com.google.firebase.messaging.cpp.ListenerService|com.google.firebase.messaging.cpp.RegistrationIntentService|com.axlebolt.bolt.android.notifications.BoltFirebaseMessagingService|com.google.android.datatransport.runtime.backends.TransportBackendDiscovery|com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService"));
    } else if (contains(valtostd, ozObfuscate_std("MessagingUnityPlayerActivity"))) {
        return CreateMonoString(ozObfuscate("com.google.firebase.MessagingUnityPlayerActivity|com.axlebolt.vkintegration.VKLoginActivity|com.facebook.unity.FBUnityLoginActivity|com.facebook.unity.FBUnityDialogsActivity|com.facebook.unity.FBUnityAppLinkActivity|com.facebook.unity.FBUnityDeepLinkingActivity|com.facebook.unity.FBUnityGameRequestActivity|com.facebook.unity.FBUnityCreateGameGroupActivity|com.facebook.unity.FBUnityJoinGameGroupActivity|com.facebook.unity.AppInviteDialogActivity|com.adcolony.sdk.AdColonyInterstitialActivity|com.adcolony.sdk.AdColonyAdViewActivity|com.facebook.FacebookActivity|com.facebook.CustomTabMainActivity|com.facebook.CustomTabActivity|com.applovin.adview.AppLovinInterstitialActivity|com.applovin.adview.AppLovinFullscreenActivity|com.applovin.sdk.AppLovinWebViewActivity|com.applovin.mediation.MaxDebuggerActivity|com.applovin.mediation.MaxDebuggerDetailActivity|com.applovin.mediation.MaxDebuggerMultiAdActivity|com.applovin.mediation.MaxDebuggerAdUnitsListActivity|com.applovin.mediation.MaxDebuggerAdUnitDetailActivity|com.applovin.mediation.MaxDebuggerTestLiveNetworkActivity|com.chartboost.sdk.CBImpressionActivity|com.google.android.gms.auth.api.signin.internal.SignInHubActivity|com.google.android.gms.common.api.GoogleApiActivity|com.unity3d.services.ads.adunit.AdUnitActivity|com.unity3d.services.ads.adunit.AdUnitTransparentActivity|com.unity3d.services.ads.adunit.AdUnitTransparentSoftwareActivity|com.unity3d.services.ads.adunit.AdUnitSoftwareActivity|com.ironsource.sdk.controller.ControllerActivity|com.ironsource.sdk.controller.InterstitialActivity|com.ironsource.sdk.controller.OpenUrlActivity|com.huawei.hms.activity.BridgeActivity|com.huawei.hms.activity.EnableServiceActivity|com.huawei.updatesdk.service.otaupdate.AppUpdateActivity|com.huawei.updatesdk.support.pm.PackageInstallerActivity|com.android.billingclient.api.ProxyBillingActivity|com.axlebolt.bolt.android.playgames.GoogleSignInActivity"));
    } else {
        return old_services(inst, inst2, inst3);
    }
}


static void* (*run_method)(const void * method, void *obj, void **params, void **exc);
static const MethodInfo* (*get_method)(void * klass, const char* name, int argsCount);
static void* (*get_domain)();
static const void** (*get_assemblies)(const void * domain, size_t * size);
static const Il2CppImage* (*get_image)(const void * assembly);
static Il2CppClass* (*class_with_name)(const void * image, const char* namespaze, const char *name);
static void* (*unbox)(Il2CppObject* obj);
static Il2CppObject* (*box)(Il2CppClass* clas,void* data);
static uintptr_t (*new_object)(const void * klass);
static Il2CppArray* (*new_array)(Il2CppClass *arrayTypeInfo, il2cpp_array_size_t length);
static FieldInfo* (*get_field_from_name)(Il2CppClass *klass, const char* name);
static void (*static_field_get_value)(FieldInfo *field, void *value);
void grab() {
    if(!get_field_from_name) {
        *(void**)(&get_field_from_name) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_class_get_field_from_name");
    }
    if(!new_array) {
        *(void**)(&new_array) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_array_new");
    }
    if(!static_field_get_value) {
        *(void**)(&static_field_get_value) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_field_static_get_value");
    }
    if(!run_method)
        *(void**)(&run_method) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_runtime_invoke");
    if(!get_method)
        *(void**)(&get_method) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_class_get_method_from_name");
    if(!get_domain)
        *(void**)(&get_domain) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_domain_get");
    if(!get_assemblies)
        *(void**)(&get_assemblies) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_domain_get_assemblies");
    if(!get_image)
        *(void**)(&get_image) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_assembly_get_image");
    if(!class_with_name)
        *(void**)(&class_with_name) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_class_from_name");
    if(!unbox)
        *(void**)(&unbox) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_object_unbox");
    if(!box)
        *(void**)(&box) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_value_box");
    if(!new_object)
        *(void**)(&new_object) = dlsym(dlopen(OBFUSCATE_BNM("libil2cpp.so"), RTLD_LAZY), "il2cpp_object_new");
}
Il2CppClass* get_class(const char* name_space, const char* type_name) {
    grab();
    void* domik = get_domain();
    if (!domik) {
        return nullptr;
    }
    size_t asm_count;
    const void** all = get_assemblies(domik, &asm_count);

    for (int i = 0; i < asm_count; i++) {
        const void* ass = all[i];
        auto img = get_image(ass); //static const void*
        if (!img) {
            continue;
        }
        auto klass = class_with_name(img, name_space, type_name);
        if (klass) {
            return klass;
        }
    }
    return nullptr;
}

bool bandetect = false;
void  (*_ServiceName)(void*instance,monoString* serviceName, monoString* methodName, void** paramToBytes, void* returnFromBytes, bool encryption);
void ServiceName(void*instance, monoString *serviceName, monoString *methodName, void** paramToBytes, void* returnFromBytes, bool encryption){
    std::string text = serviceName->get_string() + methodName->get_string();
    if (text.find("banMe") != std::string::npos or text.find("banMe2") != std::string::npos) {
        serviceName = CreateMonoString("");
        methodName = CreateMonoString("");
    }
    else {
        _ServiceName(instance,serviceName,methodName,paramToBytes,returnFromBytes,encryption);
    }
}

monoString* (*old_anticheat1)(...);
monoString* anticheat1(monoString*a){
    return old_anticheat1(a);

    auto t = old_anticheat1(a);
    LOGI("anticheat1 '%s' '%s'", a->get_string().c_str(), t->get_string().c_str());
    return t;
}
monoString* (*old_anticheat2)(...);
monoString* anticheat2(void*a){
    auto t = old_anticheat2(a);
    LOGI("anticheat3 '%s'", t->c_str());
    return t;
}
void* (*old_anticheat3)(...);
void* anticheat3(monoString*a){
    auto t = old_anticheat3(a);
    LOGI("anticheat3 '%s'", a->c_str());
    return t;
}
monoString* (*old_anticheat4)(...);
monoString* anticheat4(){
    auto t = old_anticheat4();
    LOGI("anticheat4 '%s'", t->c_str());
    return t;
}
monoString* (*old_anticheat5)(...);
monoString* anticheat5(){
    auto t = old_anticheat5();
    LOGI("anticheat5 '%s'", t->c_str());
    return t;
}
monoString* (*old_anticheat6)(...);
monoString* anticheat6(void*a,void*b){
    auto t = old_anticheat6(a,b);
    LOGI("anticheat6 '%s'", t->c_str());
    return t;
}
monoString* (*old_anticheat7)(...);
monoString* anticheat7(void*a,void*b){
    auto t = old_anticheat7(a,b);
    LOGI("anticheat7 '%s'", t->c_str());
    return t;
}
monoString* (*old_anticheat8)(...);
monoString* anticheat8(void*a){
    auto t = old_anticheat8(a);
    LOGI("anticheat8 '%s'", t->c_str());
    return t;
}
monoString* (*old_anticheat9)(...);
monoString* anticheat9(monoString*a){
    auto t = old_anticheat9(a);
    LOGI("anticheat9 '%s' '%s'", a->c_str(), t->c_str());
    return t;
}
monoString* (*old_anticheat10)(...);
monoString* anticheat10(void*a, monoString*b){
    auto t = old_anticheat10(a,b);
    LOGI("anticheat10 '%s' '%s'", b->c_str(), t->c_str());
    return t;
}
monoString* (*old_anticheat11)(...);
monoString* anticheat11(monoString*a){
    auto t = old_anticheat11(a);
    LOGI("anticheat11 '%s' '%s'", a->c_str(), t->c_str());
    return t;
}
monoString* (*old_anticheat12)(...);
monoString* anticheat12(monoString*a){
    auto t = old_anticheat12(a);
    LOGI("anticheat1 '%s' '%s'", a->c_str(), t->c_str());
    return t;
}
monoString* (*old_anticheat13)(...);
monoString* anticheat13(monoString*a){
    auto t = old_anticheat13(a);
    LOGI("anticheat13 '%s' '%s'", a->c_str(), t->c_str());
    return t;
}



monoString* (*old_safevalue)(...);
monoString* safevalue(void* inst) {
    /*InitIl2cppMethods();
    LOGDBNM("shit");
    //gays
    //InitNewClasses(Classes4Add);
    BNM_LibLoaded = true;

    auto test0 = 34;
    auto test01 = LoadClass("System","Int32");
    LOGD("TEST0: '%p'", test01);
    auto test1 = test01.BoxObject((void*)&test0);
    LOGD("TEST1: '%p'", test1);
    auto test2 = *((int*)BNM::UnboxObject2(test1));
    LOGD("TEST2: '%d'", test2);*/

    gggomg valtostd(old_safevalue(inst)->c_str());
    if (contains(valtostd, ozObfuscate_std("|main.")) &&
        contains(valtostd, ozObfuscate_std("base.apk:"))) {
        return CreateMonoString(ozObfuscate(
                                        "base.apk:6f6cf259378ad133551a4ba6258690ee:95399650|main.2001.com.axlebolt.standoff2.obb:44557c609dfde14d67d267eaf1144824:1400723649"));
    }
    if (contains(valtostd, ozObfuscate_std("base.apk:")) &&
               !contains(valtostd, ozObfuscate_std("/data")) &&
               !contains(valtostd, ozObfuscate_std("|"))) {
        return CreateMonoString(ozObfuscate("base.apk:6f6cf259378ad133551a4ba6258690ee:95399650"));
    }
    if (contains(valtostd, ozObfuscate_std("=")) &&
               !contains(valtostd, ozObfuscate_std("data"))) {
        return CreateMonoString(ozObfuscate("lcG7acvUIg0k4FQSQmAbyw1tN0o="));
    }
        /*else if (!contains(valtostd, ozObfuscate_std("=")) &&
                   !contains(valtostd, ozObfuscate_std("/data")) &&
                   contains(valtostd, ozObfuscate_std("3"))) {
            return CreateMonoString(gen_random(atoi(ozObfuscate("16"))).c_str())        }
        /*else if (contains(valtostd, ozObfuscate_std("/data/")) &&
                   contains(valtostd, ozObfuscate_std("/arm")) &&
                   contains(valtostd, ozObfuscate_std("|"))) {
            gggomg lib1 = ozObfuscate_std("/data/data/com.axlebolt.standoff2/cache/libil2cpp.so");
            gggomg lib2 = ozObfuscate_std("/data/user/0/com.axlebolt.standoff2/cache/libil2cpp.so");
            if (contains(valtostd, lib1)) {
                gggomg basicString;
                basicString += ReplaceString(valtostd, (lib1 + "|"), (""));
                return CreateMonoString(basicString.c_str());
            } else if (contains(valtostd, lib2)) {
                gggomg basicString;
                basicString += ReplaceString(valtostd, (lib2 + "|"), (""));
                return CreateMonoString(basicString.c_str());
            } else {
                pause();
            }
        }*/
    else {
        return old_safevalue(inst);
    }
}
void (*old_camera_update)(...);
void camera_update(void *a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    if (a) {
        if (worldfov) *(float *)((uint64_t) a + 0x18) = fovvalue;
        else *(float *)((uint64_t) a + 0x18) = 60;
    }
    old_camera_update(a);
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);




}

bool xphack = false;

bool (*old_xph1)(...);
bool xph1(void *a) {
    return xphack || old_xph1(a);
}

bool (*old_xph2)(...);
bool xph2(void *a) {
    return xphack || old_xph2(a);
}

float (*old_Bunnyhop)(void *player);
float Bunnyhop(void *player) {
    if (player && bhop) {
        return bhopvalue;
    }
    return old_Bunnyhop(player);
}
void(*old_ChatManager_SendToAll)(void *player, monoString* msg);
void ChatManager_SendToAll(void *player, monoString* msg) {
        chat_object = player;
    old_ChatManager_SendToAll(player, msg);
}
bool fly = false;
float flySpeed = 20;

void (*old_SetInputs)(void* a,Vector3 b);
void SetInputs(void* a,Vector3 b) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);



    if (fly && a && myPlayer) {
        freez = true;
        float x = getAxis(a).x;
        float y = getAxis(a).y;

        Vvector3 transfer = GetTransformForward(GetTransform(GetCamera(NULL))) * y;
        transfer = transfer + GetTransformRight(GetTransform(GetCamera(NULL))) * x;

        SetTransformPosition(GetTransform(myPlayer), GetTransformLocation(GetTransform(myPlayer)) + transfer * GetDeltaTime(NULL) * flySpeed);
    }
    else freez = false;
    old_SetInputs(a,b);
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


}

Vvector3 (*old_Velocity)(...);
Vvector3 Velocity(void* a) {
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    return freez ? Vvector3(0,0,0) : old_Velocity(a);
}

float (*old_Velo4)(...);
float Velo4(void* a) {
    if (freez) {
        FIELDFUNCTION(Vvector3,a,0xA0) = Vvector3(0,0,0);
        FIELDFUNCTION(float,a,0x8) = 0;
        FIELDFUNCTION(float,a,0xC) = 0;
        FIELDFUNCTION(float,a,0x10) = 0;
        FIELDFUNCTION(float,a,0x6C) = 0;
        FIELDFUNCTION(float,a,0x70) = 0;
        FIELDFUNCTION(float,a,0x74) = 0;

    }
    return freez ? 0 : old_Velo4(a);
}
float (*old_Velo5)(...);
float Velo5(void* a) {
    if (freez) {
        FIELDFUNCTION(Vvector3,a,0xA0) = Vvector3(0,0,0);
        FIELDFUNCTION(float,a,0x8) = 0;
        FIELDFUNCTION(float,a,0xC) = 0;
        FIELDFUNCTION(float,a,0x10) = 0;
        FIELDFUNCTION(float,a,0x6C) = 0;
        FIELDFUNCTION(float,a,0x70) = 0;
        FIELDFUNCTION(float,a,0x74) = 0;

    }
    return freez ? 0 : old_Velo5(a);
}
float (*old_jump4)(...);
float jump4(void* a) {
    if (freez) {
        FIELDFUNCTION(Vvector3,a,0xA0) = Vvector3(0,0,0);
        FIELDFUNCTION(float,a,0x8) = 0;
        FIELDFUNCTION(float,a,0xC) = 0;
        FIELDFUNCTION(float,a,0x10) = 0;
        FIELDFUNCTION(float,a,0x6C) = 0;
        FIELDFUNCTION(float,a,0x70) = 0;
        FIELDFUNCTION(float,a,0x74) = 0;
    }
    return old_jump4(a);
}
Vector3 (*w2s)(...);

void* dasdasd(void* arguments){
    auto addr = (uintptr_t)dlsym(RTLD_DEFAULT, ozObfuscate("eglSwapBuffers"));
    MSHookFunction((void *)addr, (void *)hook_eglSwapBuffers, (void **)&old_eglSwapBuffers);
     while (!isLibraryLoaded(ozObfuscate("lib/arm/libil2cpp.so"))) sleep(1);
    entityList = new EntityList();
    grenadesList = new GrenadesList();

    RPC = (void (*)(...)) getRealOffset(string2Offset(ozObfuscate("0xD0B358"))); // upd f2
    GetView = (void* (*)(...)) getRealOffset(string2Offset(ozObfuscate("0xDFFDE8"))); // upd f2
    SetMasterClient = (bool (*)(...)) getRealOffset(string2Offset(ozObfuscate("0x8C55DC"))); // upd f2
    IsMasterClient = (bool (*)(...)) getRealOffset(string2Offset(ozObfuscate("0xD01410"))); // upd f2
    GetTransformRight = (Vvector3 (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x2192658"))); // upd f2
    GetTransformForward = (Vvector3 (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x2192A30"))); // upd f2
    getAxis = (Vvector3 (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xE8FB7C"))); // upd f2
    GetWeaponID = (int (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xB35CAC"))); // upd f2
    GetActiveWeapon = (void *(*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xB9EC5C"))); // upd f2
    GetCamera2 = (void *(*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x1BBD7B4"))); //upd f2
    GetDeltaTime = (float (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x2190E08"))); //upd f2
    GetTransform = (void *(*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x1BC0720"))); //upd f2
    GetNickName = (monoString *(*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xD0121C"))); // upd f2
    GetTransformPosition_Injected = (void (*)(void *, Vvector3 *)) getRealOffset(string2Offset(ozObfuscate("0x2191F18"))); // upd f2
    SetTransformPosition = (void (*)(void *, Vvector3)) getRealOffset(string2Offset(ozObfuscate("0x2191FD0"))); // upd f2
    WorldToScreen_Injected = (void (*)(void *, Vvector3, int, Vvector3 *)) getRealOffset(string2Offset(ozObfuscate("0x1BBCD5C"))); // upd f2

    w2s = (Vector3 (*)(...)) getRealOffset(string2Offset(ozObfuscate("0x1BBD0D0"))); // upd f2

    WorldToViewport_Injected = (void (*)(void *, Vvector3, int, Vvector3 *)) getRealOffset(string2Offset(ozObfuscate("0x1BBCE60"))); // upd f2
    //IsBombPlanted = (bool (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xDBB5B4"))); // upd f2
    //GetBombPosition = (Vvector3 (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xD61F68"))); // upd f2
    //GetBombTime = (double (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xD658BC"))); // upd f2
    //IsTimeToDetonate = (bool (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xDCF2F4"))); // upd f2
    IsLocal = (bool (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xD028E8"))); // upd f2
    GetPlayerTeam = (int (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0x984E50"))); // upd f2
    GetPlayerHealth = (int (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xA028B0"))); // upd f2 0xE42490
    GetPhotonPlayer = (void* (*)(void *)) getRealOffset(string2Offset(ozObfuscate("0xE028D0"))); // upd f2
    SetClanTag = (void (*)(void *, monoString*)) getRealOffset(string2Offset(ozObfuscate("0x986B5C")));
    SendToAll = (void (*)(void *, monoString*)) getRealOffset(string2Offset(ozObfuscate("0x8CBAA4")));
    SetTPS = (void (*)(void*)) getRealOffset(string2Offset(ozObfuscate("0xE02E04")));
    SetFPS = (void (*)(void*)) getRealOffset(string2Offset(ozObfuscate("0xE05938")));
    GetCameraMode = (int (*)(void*)) getRealOffset(string2Offset(ozObfuscate("0xE01E7C")));
    SetLocalPosition = (void (*)(void*, Vvector3)) getRealOffset(string2Offset(ozObfuscate("0x2192160")));

    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xE042C8"))), (void*) Player_Update, (void**)&old_Player_Update); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xED8574"))), (void*) Arms1, (void**)&old_Arms1); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDA03C"))), (void*) Arms2, (void**)&old_Arms2); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDA2B0"))), (void*) Arms3, (void**)&old_Arms3); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDA3C4"))), (void*) Arms4, (void**)&old_Arms4); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xED8548"))), (void*) Arms5, (void**)&old_Arms5); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDA9AC"))), (void*) Arms6, (void**)&old_Arms6); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDABD0"))), (void*) Arms7, (void**)&old_Arms7); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDA5FC"))), (void*) Arms8, (void**)&old_Arms8); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xEDAE98"))), (void*) Arms9, (void**)&old_Arms9); // upd f2

    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xE008C0"))), (void*) OnOcclusionBecameVisible, (void**)&old_OnOcclusionBecameVisible); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xE00A84"))), (void*) OnOcclusionBecameInvisible, (void**)&old_OnOcclusionBecameInvisible); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xD27CFC"))), (void*) GrenadeManager_Update, (void**)&old_GrenadeManager_Update); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xDBCC50"))), (void*) BombManager_Update, (void**)&old_BombManager_Update); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xD69CF4"))), (void*) camera_update, (void**)&old_camera_update); // upd f2

    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xBA0E34"))), (void*) xph1, (void**)&old_xph1); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xBA0E94"))), (void*) xph2, (void**)&old_xph2); // upd f2

    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xB3F70C"))), (void*) GetEquippedKnifeID, (void**)&old_GetEquippedKnifeID); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xB3D094"))), (void*) GetEquippedSkinID, (void**)&old_GetEquippedSkinID); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8F62C0"))), (void*) GetGloves, (void**)&old_GetGloves); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8CBAA4"))), (void*) ChatManager_SendToAll, (void**)&old_ChatManager_SendToAll);
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xD2C6D4"))), (void*) GunController_Update, (void**)&old_GunController_Update); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xD2E704"))), (void*) CastHit, (void**)&old_CastHit); // upd f2
    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x245278C"))), (void*) IsGrounded, (void**)&old_IsGrounded); // upd f2

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x245278C"))), (void*) IsGrounded, (void**)&old_IsGrounded); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x245278C"))), (void*) IsGrounded, (void**)&old_IsGrounded); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x245278C"))), (void*) IsGrounded, (void**)&old_IsGrounded); // upd f2

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0xECCA14"))), (void*) SetInputs, (void**)&old_SetInputs); // upd f2  0xECC4D0
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x2596E5C"))), (void*) Velocity, (void**)&old_Velocity); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x99FBC0"))), (void*) Velo4, (void**)&old_Velo4); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x98F618"))), (void*) Velo5, (void**)&old_Velo5); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x99FE80"))), (void*) jump4, (void**)&old_jump4); // upd f

    DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x1411A18"))), (void*) ServiceName, (void**)&_ServiceName); // upd f2

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8A86A8"))), (void*) anticheat1, (void**)&old_anticheat1); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8A86AC"))), (void*) anticheat2, (void**)&old_anticheat2); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8A8D5C"))), (void*) anticheat3, (void**)&old_anticheat3); // upd f2

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118A240"))), (void*) anticheat4, (void**)&old_anticheat4); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118A8D8"))), (void*) anticheat5, (void**)&old_anticheat5); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118AF58"))), (void*) anticheat6, (void**)&old_anticheat6); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118B720"))), (void*) anticheat7, (void**)&old_anticheat7); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118B4E0"))), (void*) anticheat8, (void**)&old_anticheat8); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D23C"))), (void*) anticheat9, (void**)&old_anticheat9); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D2D4"))), (void*) anticheat10, (void**)&old_anticheat10); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D61C"))), (void*) anticheat11, (void**)&old_anticheat11); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D824"))), (void*) anticheat12, (void**)&old_anticheat12); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D2D0"))), (void*) anticheat13, (void**)&old_anticheat13); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x118D2D4"))), (void*) anticheat14, (void**)&old_anticheat14); // upd f2

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x12A624C"))), (void*) movebefore, (void**)&old_movebefore); // upd f2
    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x8A57EC"))), (void*) dontreturn, (void**)&old_dontreturn); // upd f2

    //gameanticheatmanager
    /*MemoryPatch::createWithHex("libil2cpp.so",0xD4841C,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD487B4,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD47054,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD473E8,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD46CDC,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD46DBC,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD47A58,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD47EB4,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD4804C,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD481E4,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD489C4,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD48D80,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xD490C0,"1E FF 2F E1").Modify();

    //anticheatmanager
    MemoryPatch::createWithHex("libil2cpp.so",0xB7A514,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7A5FC,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7AA90,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7AEF0,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7AC38,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B114,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B270,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B034,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B424,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B5B0,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B838,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0xB7B9AC,"1E FF 2F E1").Modify();

    //closeconnection
    MemoryPatch::createWithHex("libil2cpp.so",0xE704B4,"1E FF 2F E1").Modify();
    MemoryPatch::createWithHex("libil2cpp.so",0x17E6CF8,"1E FF 2F E1").Modify();*/

    //DobbyHook((void*) getRealOffset(string2Offset(ozObfuscate("0x97EA54"))), (void*) wallf, (void**)&old_wallf); // upd f2

    address = findLibrary(targetLibName);
    return 0;
}
#endif
