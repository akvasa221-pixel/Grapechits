#include <pthread.h>
#include <jni.h>
#include "Includes/Logger.h"
#include <vector> //std vector
#include <ctime> // time header to support timeval structure
#include <unistd.h> //uni std
#include <pthread.h> // pthread header
#include <string>//std string
#include <set> //std set (bionic linker)
#include <iostream>
#include <locale>
#include <codecvt>
#include <sstream>
#include <dlfcn.h>
#include "Dobby/dobby.h"
#include "ImGui_Impl_AndroidOpenGL2.h" // my gui implementation
#include "EGL/egl.h"  // EGL
#include "GLES3/gl3.h"
#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "Drawing.h"
#include <android/asset_manager_jni.h> //JNI + JNI Asset Manager
#include <android/native_window.h> // native window header is used to
#include <android/input.h> //input consts
#include <android/log.h>
#include "ImGui_Impl_AndroidOpenGL2.h"
#include "Requests.h"
//#include "obfuscator.h"

#include <dirent.h>
#include <sys/types.h>

//#define ozObfuscate(str) str


using namespace BNM::UNITY_STRUCTS; // Vector3, Vector2 and etc
using namespace BNM::MONO_STRUCTS; // monoString, monoArray and etc
using namespace BNM;
using namespace std;


jobject UnityPlayer_CurrentActivity_fid;
float lerp(float a, float b, float f)
{
    return a + f * (b - a);
}

float currentTimeInMilliseconds(){
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}




void UpdateInput() {
}
bool HandleInputEvent(JNIEnv *env, int motionEvent, int x, int y, int p) {
    LOGI("Touch - %d,%d", motionEvent, p);
    float velocity_y = (float)((float)y - g_LastTouchEvent.y) / 100.f;
    //LOGD("Velocity Y-axis = %f", velocity_y);
    g_LastTouchEvent = {.action = (TOUCH_ACTION) motionEvent, .x = static_cast<float>(x), .y = static_cast<float>(y), .pointers = p, .y_velocity = velocity_y};
    //LOGD("1");
    ImGuiIO &io = ImGui::GetIO();
    //LOGD("2");
    io.MousePos.x = g_LastTouchEvent.x;
    //LOGD("3");
    io.MousePos.y = g_LastTouchEvent.y;
    //LOGD("4");
    if(motionEvent == 2){
    //LOGD("5");
        if (g_LastTouchEvent.pointers > 1) {
            //LOGD("6");
            io.MouseWheel = g_LastTouchEvent.y_velocity;
            io.MouseDown[0] = false;
        }
        else {
            //LOGD("7");
            io.MouseWheel = 0;
        }
    }
    if(motionEvent == 0){
        //LOGD("8");
        io.MouseDown[0] = true;
    }
    if(motionEvent == 1){
        //LOGD("9");
        io.MouseDown[0] = false;
    }
    //LOGD("10");
    return true;
}

void InitTheme() {
    LOGD("Loading.. 20%");
    ImGuiStyle* style = &ImGui::GetStyle();
    style->WindowBorderSize = 3;

    style->WindowTitleAlign = ImVec2(0.5, 0.5);
    //style->WindowMinSize = ImVec2(900, 430);
    style->FrameRounding = 12.0f;
    style->GrabRounding = 12.0f;
    style->Colors[ImGuiCol_BorderShadow] = ImVec4(1.0f, 0.1f, 0.1f, 1.0f);
    style->Colors[ImGuiCol_CheckMark] = ImVec4(1.0f, 0.0f, 0.0f, 1.00f);
    style->Colors[ImGuiCol_Button] = ImColor(31, 30, 31, 255);
    style->Colors[ImGuiCol_ButtonActive] = ImColor(41, 40, 41, 255);
    style->Colors[ImGuiCol_ButtonHovered] = ImColor(41, 40, 41, 255);
    style->Colors[ImGuiCol_TitleBg]                = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
    style->Colors[ImGuiCol_TitleBgActive]          = ImVec4(75.0f/255.0f, 0.0f, 130.0f/255.0f, 1.00f);
    style->Colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    style->Colors[ImGuiCol_Separator] = ImColor(70, 70, 70, 255);
    style->Colors[ImGuiCol_SeparatorActive] = ImColor(76, 76, 76, 255);
    style->Colors[ImGuiCol_SeparatorHovered] = ImColor(76, 76, 76, 255);
    style->Colors[ImGuiCol_FrameBgHovered] = ImColor(37, 36, 37, 255);
    style->Colors[ImGuiCol_Header] = ImColor(0, 0, 0, 0);
    style->Colors[ImGuiCol_HeaderActive] = ImColor(0, 0, 0, 255);
    style->Colors[ImGuiCol_HeaderHovered] = ImColor(46, 46, 46, 255);
    LOGD("Settings theme ok");
}
float menuOpacity = 255;
float menuRounded = 10;
#include "font.h"

void InitNewTheme() {
    LOGD("Settings white theme");
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    ImGui::StyleColorsLight(style);
    style->FramePadding = ImVec2(4, 8); // 4,2
    style->ItemSpacing = ImVec2(10, 2);
    style->WindowPadding = ImVec2(6, 8);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 15;

    style->WindowRounding = menuRounded;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->DisplaySafeAreaPadding = ImVec2(4, 4);

    ImGui::GetStyle().WindowRounding = 10;
    ImGui::GetStyle().Alpha = 255;
    ImGui::GetStyle().WindowMinSize = ImVec2(650,450); // 600,400
    io.BackendPlatformName = (ozObfuscate("imgui_impl_android"));
    io.IniFilename =  nullptr;

    LOGD("Settings done");
}
ImVec2 padding = ImVec2(4, 10);
bool setupGraphics(float w, float h) {
    LOGD("Loading.. 20%");
    IMGUI_CHECKVERSION();
    LOGD("Loading.. 30%");
    ImGui::CreateContext();
    LOGD("Loading.. 40%");
    ImGuiIO& io = ImGui::GetIO();
    LOGD("Loading.. 50%");
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;
    colors[ImGuiCol_Text]                   = ImVec4(0.92f, 0.92f, 0.92f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.44f, 0.44f, 0.44f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
    colors[ImGuiCol_Border]                 = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg]                = ImVec4(0.11f, 0.11f, 0.11f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.11f, 0.11f, 0.11f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.06f, 0.06f, 0.06f, 0.53f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.47f, 0.47f, 0.47f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.81f, 0.83f, 0.81f, 1.00f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_Button]                 = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.93f, 0.65f, 0.14f, 1.00f);
    colors[ImGuiCol_Separator]              = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_Tab]                    = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_TabHovered]             = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_TabActive]              = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_TabUnfocused]           = ImVec4(0.07f, 0.10f, 0.15f, 0.97f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.14f, 0.26f, 0.42f, 1.00f);
    colors[ImGuiCol_PlotLines]              = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
    colors[ImGuiCol_NavHighlight]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);

    style->FramePadding = padding; // 4,2
    style->ItemSpacing = ImVec2(10, 2);
    style->WindowPadding = ImVec2(6, 8);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 15;

    style->WindowRounding = menuRounded;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->DisplaySafeAreaPadding = ImVec2(4, 4);

    ImGui::GetStyle().WindowRounding = 10;
    ImGui::GetStyle().Alpha = menuOpacity;
    ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200
    io.BackendPlatformName = (ozObfuscate("imgui_impl_android"));
    io.IniFilename =  nullptr;


    LOGD("Loading.. 60%");
    return true;
}
bool setupWhite() {
    LOGD("Settings white theme");
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    ImGui::StyleColorsLight(style);
    style->FramePadding = padding;
    style->ItemSpacing = ImVec2(10, 2);
    style->WindowPadding = ImVec2(6, 8);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 15;

    style->WindowRounding = menuRounded;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->DisplaySafeAreaPadding = ImVec2(4, 4);

    ImGui::GetStyle().WindowRounding = 10;
    ImGui::GetStyle().Alpha = 255;
    ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200
    io.BackendPlatformName = (ozObfuscate("imgui_impl_android"));
    io.IniFilename =  nullptr;

    LOGD("Settings done");
    return true;
}
bool setupBlack() {
    LOGD("Settings dark theme");
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    ImGui::StyleColorsDark(style);
    style->FramePadding = padding;
    style->ItemSpacing = ImVec2(10, 2);
    style->WindowPadding = ImVec2(6, 8);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 15;

    style->WindowRounding = menuRounded;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->DisplaySafeAreaPadding = ImVec2(4, 4);

    ImGui::GetStyle().WindowRounding = 10;
    ImGui::GetStyle().Alpha = 255;
    ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200
    io.BackendPlatformName = (ozObfuscate("imgui_impl_android"));
    io.IniFilename =  nullptr;

    LOGD("Settings done");
    return true;
}

bool setupDefaultImgui() {
    LOGD("Settings setupDefaultImgui theme");
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    ImGui::StyleColorsClassic(style);
    style->FramePadding = padding;
    style->ItemSpacing = ImVec2(10, 2);
    style->WindowPadding = ImVec2(6, 8);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 15;

    style->WindowRounding = menuRounded;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->DisplaySafeAreaPadding = ImVec2(4, 4);

    ImGui::GetStyle().WindowRounding = 10;
    ImGui::GetStyle().Alpha = 255;
    ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200
    io.BackendPlatformName = (ozObfuscate("imgui_impl_android"));
    io.IniFilename =  nullptr;



    LOGD("Settings done");
    return true;
}
bool DrawBehindMenu = true;
ImDrawList* getDrawList(){
    return ImGui::GetBackgroundDrawList();
}

void AddColorPicker(const char* name, ImVec4 &color) {
    ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
    static ImVec4 backup_color;

    bool open_popup = ImGui::ColorButton((std::string(name) + "##3b").c_str(), color, misc_flags);
    if (open_popup)
    {
        ImGui::OpenPopup(name);
        backup_color = color;
    }
    if (ImGui::BeginPopup(name))
    {
        ImGui::Text("%s", std::string(name).c_str());
        ImGui::Separator();
        ImGui::ColorPicker4("##picker", (float*)&color, misc_flags | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview);
        ImGui::SameLine();

        ImGui::BeginGroup(); // Lock X position
        ImGui::Text("Current");
        ImGui::ColorButton("##current", color, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(60, 40));
        ImGui::Text("Previous");
        if (ImGui::ColorButton("##previous", backup_color, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(60, 40)))
            color = backup_color;
        ImGui::EndGroup();
        ImGui::EndPopup();
    }
}
ImVec2 world2screen_i(Vector3 pos) {
    Vector3 worldPoint = w2s(GetCamera(NULL), pos);
    return ImVec2(worldPoint.x,screenHeight - worldPoint.y);
}
ImVec2 world2screen_v(Vvector3 pos) {
    Vector3 worldPoint = w2s(GetCamera(NULL), Vector3(pos.x,pos.y,pos.z));
    return ImVec2(worldPoint.x,screenHeight - worldPoint.y);
}
ImVec2 world2screen_c(Vvector3 pos, bool &checker) {
    Vector3 worldPoint = w2s(GetCamera(NULL),  Vector3(pos.x,pos.y,pos.z));
    checker = worldPoint.z > 0;
    return ImVec2(worldPoint.x,screenHeight - worldPoint.y);
}

Vvector2 ImV_to_UV(ImVec2 v) {
    return Vvector2(v.x,v.y);
};

ImVec2 UV_to_ImV(Vvector2 v) {
    return ImVec2(v.X, v.Y);
};

static Vvector3 RotatePoint(Vvector3 EntityPos, Vvector3 LocalPlayerPos, int posX, int posY, int sizeX, int sizeY, float angle, float zoom, bool* viewCheck)
{
    float r_1, r_2;
    float x_1, y_1;

    r_1 = -(EntityPos.y - LocalPlayerPos.y);
    r_2 = EntityPos.x - LocalPlayerPos.x;
    float Yaw = angle - 90.0f;

    float yawToRadian = Yaw * (float)(M_PI / 180.0F);
    x_1 = (float)(r_2 * (float)cos((double)(yawToRadian)) - r_1 * sin((double)(yawToRadian))) / 20;
    y_1 = (float)(r_2 * (float)sin((double)(yawToRadian)) + r_1 * cos((double)(yawToRadian))) / 20;

    *viewCheck = y_1 < 0;

    x_1 *= zoom;
    y_1 *= zoom;

    int sizX = sizeX / 2;
    int sizY = sizeY / 2;

    x_1 += sizX;
    y_1 += sizY;

    if (x_1 < 5)
        x_1 = 5;

    if (x_1 > sizeX - 5)
        x_1 = sizeX - 5;

    if (y_1 < 5)
        y_1 = 5;

    if (y_1 > sizeY - 5)
        y_1 = sizeY - 5;


    x_1 += posX;
    y_1 += posY;


    return Vvector3(x_1, y_1, 0);
}

Vvector3 VectorAnglesRadar(Vvector3 forward) {
    Vvector3 angles;
    if (forward.x == 0.f && forward.y == 0.f)
    {
        angles.x = forward.z > 0.f ? -90.f : 90.f;
        angles.y = 0.f;
    }
    else
    {
        angles.x = radians_to_degrees(atan2(-forward.z, Vvector3Magnitude(forward)));
        angles.y = radians_to_degrees(atan2(forward.y, forward.x));
    }
    angles.z = 0.f;
    return angles;
}
void RotateTriangle(std::array<Vvector3, 3>& points, float rotation)
{
    const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
    for (auto& point : points)
    {
        point = point - points_center;

        const auto temp_x = point.x;
        const auto temp_y = point.y;

        const auto theta = degrees_to_radians(rotation);
        const auto c = cosf(theta);
        const auto s = sinf(theta);

        point.x = temp_x * c - temp_y * s;
        point.y = temp_x * s + temp_y * c;

        point = point + points_center;
    }
}
float fillopacity;
bool fillbox;

void Draw3DBox(Vvector3 pos, float lerpvalue, float angle, Vvector3 scale, ImColor color, float stroke = 2, float outline_size = 0, float cornersize = 50) {
    cornersize /= 10;

    bool checker;
    world2screen_c(pos,checker);

    if (!checker) {
        return;
    }
    Vvector3 scaleRot = Vvector3(sin((double) angle *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) angle *(PI *2) /(double) 360)*(scale.z) /2 );
    scaleRot = Vvector3(sin((double) (angle + 0) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 0) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto down_leftup = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y - scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 90) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 90) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto down_rightup = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y - scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 270) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 270) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto down_leftbottom = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y - scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 180) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 180) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto down_rightbottom = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y - scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 0) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 0) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto top_leftup = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y + scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 90) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 90) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto top_rightup = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y + scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 270) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 270) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto top_leftbottom = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y + scaleRot.y, pos.z + scaleRot.z)));
    scaleRot = Vvector3(sin((double) (angle + 180) *(PI *2) /(double) 360)*(scale.x) /2 ,scale.y/2,cos((double) (angle + 180) *(PI *2) /(double) 360)*(scale.z) /2 );
    auto top_rightbottom = ImVec2(world2screen_i(Vector3(pos.x + scaleRot.x, pos.y + scaleRot.y, pos.z + scaleRot.z)));
    auto old_col = color;
    stroke += outline_size;
    color = ImColor(0,0,0,255);

    if (fillbox) {
        auto Colr = ImColor(old_col.Value.x,old_col.Value.y,old_col.Value.z,fillopacity/255);

        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);

        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightbottom);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);

        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightup);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);

        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);

        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_leftbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_leftbottom);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);

        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightup);
        ImGui::GetBackgroundDrawList()->PathLineTo(top_rightbottom);
        ImGui::GetBackgroundDrawList()->PathLineTo(down_rightbottom);
        ImGui::GetBackgroundDrawList()->PathFillConvex(Colr);
    }


    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
    stroke = outline_size;
    color = old_col;
    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftup),ImV_to_UV(top_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftup),ImV_to_UV(down_leftup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightup),ImV_to_UV(top_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightup,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightup),ImV_to_UV(down_rightup),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_rightbottom),ImV_to_UV(top_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_rightbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_rightbottom),ImV_to_UV(down_rightbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(down_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(down_leftbottom),ImV_to_UV(top_leftbottom),lerpvalue)),color,stroke);
    ImGui::GetBackgroundDrawList()->AddLine(top_leftbottom,UV_to_ImV(Vvector2::Lerp(ImV_to_UV(top_leftbottom),ImV_to_UV(down_leftbottom),lerpvalue)),color,stroke);
}
void GetVal(Json::Value &config, int* setting)
{
    if (config.isNull())
        return;

    *setting = config.asInt();
}

void GetVal(Json::Value &config, bool* setting)
{
    if (config.isNull())
        return;

    *setting = config.asBool();
}

void GetVal(Json::Value &config, float* setting)
{
    if (config.isNull())
        return;

    *setting = config.asFloat();
}
void PackColor(Json::Value &config, ImVec4 color) {
    config["R"] = color.x;
    config["G"] = color.y;
    config["B"] = color.z;
    config["A"] = color.w;
}
void GetVal(Json::Value &config, ImVec4 &setting)
{
    if (config.isNull())
        return;

    static float R, G, B, A;

    GetVal(config["R"], &R);
    GetVal(config["G"], &G);
    GetVal(config["B"], &B);
    GetVal(config["A"], &A);

    setting = ImVec4(R,G,B,A);
}

float x,y;
float a1, a2, a3 = 0;
bool line;
int boxtype = 0;
float rounded = 0;
bool fillboxg;

float stroke = 1;
float csizer = 0.5;


float timerID = 0.f;
void LoadConfig(std::string path2file) {
    FILE *infile = fopen(path2file.c_str(), ozObfuscate("r"));
    if (infile == NULL) {
        writefile(path2file.c_str(), "");
    }
    fseek(infile, 0, SEEK_END);
    long filesize = ftell(infile);
    char *buf = new char[filesize + 1];
    fseek(infile, 0, SEEK_SET);
    fread(buf, 1, filesize, infile);
    fclose(infile);

    buf[filesize] = '\0';
    std::stringstream ss;
    ss.str(buf);
    delete[] buf;

    Json::Value settings;
    ss >> settings;

    //LOGD(ozObfuscate("Config that we will load - %s"), std::string(ss.str()).c_str());
    //esp
    GetVal(settings["ESP"]["Enabled"], &esp);
    GetVal(settings["ESP"]["Box"], &espbox);
    GetVal(settings["ESP"]["BoxType"], &boxtype);
    GetVal(settings["ESP"]["Roundness"], &rounded);
    GetVal(settings["ESP"]["Fill"], &fillbox);
    GetVal(settings["ESP"]["FillGradient"], &fillboxg);
    GetVal(settings["ESP"]["FillValue"], &fillopacity);
    GetVal(settings["ESP"]["Stroke"], &stroke);
    GetVal(settings["ESP"]["Csizer"], &csizer);
    GetVal(settings["ESP"]["Line"], &espline);
    GetVal(settings["ESP"]["Name"], &espnick);
    GetVal(settings["ESP"]["Health"], &esphp);
    GetVal(settings["ESP"]["Distance"], &espdist);
    GetVal(settings["ESP"]["Weapon"], &espweapon);
    GetVal(settings["ESP"]["Skeleton"], &espskeleton);
    GetVal(settings["ESP"]["OffScreen"], &esparrows);
    GetVal(settings["ESP"]["VisibleColor"], espVisibleColor);
    GetVal(settings["ESP"]["InvisibleColor"], espInvisibleColor);
    GetVal(settings["ESP"]["GrenadeESP"], &grenadeesp);
    GetVal(settings["ESP"]["BombESP"], &bombesp);
    GetVal(settings["ESP"]["ElementsColor"], espElementsColor);

    GetVal(settings["PlayerLine"]["Enabled"], &pline);

    //aimbot
    GetVal(settings["Aimbot"]["Enabled"], &enableaim);
    GetVal(settings["Aimbot"]["Silent"], &silentaim);
    GetVal(settings["Aimbot"]["AimHead"], &AimHead);
    GetVal(settings["Aimbot"]["AimBody"], &AimBody);
    GetVal(settings["Aimbot"]["AimLegs"], &AimLegs);
    GetVal(settings["Aimbot"]["AimArms"], &AimArms);

    GetVal(settings["Aimbot"]["VisibleCheck"], &vischeck);
    GetVal(settings["Aimbot"]["FOV"], &aimfov);
    GetVal(settings["Aimbot"]["Smooth"], &aimsmooth);
    GetVal(settings["Aimbot"]["SilentChance"], &silentChance);
    GetVal(settings["Aimbot"]["TargetBone"], &aimtype);
    //rage
    GetVal(settings["Rage"]["Telekill"], &telekill);
    GetVal(settings["Rage"]["Masskill"], &masskill);
    GetVal(settings["Rage"]["ClanTag"], &clantag);
    GetVal(settings["Rage"]["ChatSpam"], &chatspam);
    GetVal(settings["Rage"]["FastFire"], &fastfire);

    GetVal(settings["Rage"]["recoil"], &recoil);

    GetVal(settings["Rage"]["InfAmmo"], &infammo);
    GetVal(settings["Rage"]["Wallshot"], &wall);

    GetVal(settings["Rage"]["AirJump"], &infjump);
    GetVal(settings["Rage"]["BunnyHop"], &bhop);
    GetVal(settings["Rage"]["BunnyHopSpeed"], &bhopvalue);

    GetVal(settings["Profile"]["Medal Hack"], &xphack);

    //viewmodel
    GetVal(settings["Viewmodel"]["Position"], &handspos);
    GetVal(settings["Viewmodel"]["PositionX"], &handsx);
    GetVal(settings["Viewmodel"]["PositionY"], &handsy);
    GetVal(settings["Viewmodel"]["PositionZ"], &handsz);
    GetVal(settings["Viewmodel"]["FieldOfViewChanger"], &worldfov);
    GetVal(settings["Viewmodel"]["FOV"], &fovvalue);
    //skinchanger
    GetVal(settings["Skinchanger"]["G22"], &g22skin);
    GetVal(settings["Skinchanger"]["USP"], &uspskin);
    GetVal(settings["Skinchanger"]["P350"], &p350skin);
    GetVal(settings["Skinchanger"]["Deagle"], &deagleskin);
    GetVal(settings["Skinchanger"]["Tec9"], &tec9skin);
    GetVal(settings["Skinchanger"]["FiveSeven"], &fivesevenskin);
    GetVal(settings["Skinchanger"]["UMP45"], &ump45skin);
    GetVal(settings["Skinchanger"]["MP5"], &mp5skin);
    GetVal(settings["Skinchanger"]["MP7"], &mp7skin);
    GetVal(settings["Skinchanger"]["P90"], &p90skin);
    GetVal(settings["Skinchanger"]["M60"], &m60skin);
    GetVal(settings["Skinchanger"]["SM1014"], &sm1014skin);
    GetVal(settings["Skinchanger"]["FabM"], &fabmskin);
    GetVal(settings["Skinchanger"]["AKR"], &akrskin);
    GetVal(settings["Skinchanger"]["AKR12"], &akr12skin);
    GetVal(settings["Skinchanger"]["M4"], &m4skin);
    GetVal(settings["Skinchanger"]["M4A1"], &m4a1skin);
    GetVal(settings["Skinchanger"]["M16"], &m16skin);
    GetVal(settings["Skinchanger"]["AWM"], &awmskin);
    GetVal(settings["Skinchanger"]["M40"], &m40skin);
    GetVal(settings["Skinchanger"]["M110"], &m110skin);
    GetVal(settings["Skinchanger"]["TargetKnife"], &knife);
    GetVal(settings["Skinchanger"]["Bayonet"], &m9skin);
    GetVal(settings["Skinchanger"]["Karambit"], &karambitskin);
    GetVal(settings["Skinchanger"]["jKommando"], &jkommandoskin);
    GetVal(settings["Skinchanger"]["Butterfly"], &butterflyskin);
    GetVal(settings["Skinchanger"]["FlipKnife"], &flipknifeskin);
    GetVal(settings["Skinchanger"]["Kunai"], &kunaiskin);
    GetVal(settings["Skinchanger"]["Scorpion"], &scorpionskin);
    GetVal(settings["Skinchanger"]["Tanto"], &tantoskin);
    GetVal(settings["Skinchanger"]["Daggers"], &daggersskin);
    GetVal(settings["Skinchanger"]["Gloves"], &glovess);
    //LOGD("Loading completed!");
}
void SaveConfig(std::string path2file) {
    Json::Value settings;
    //esp
    settings["ESP"]["Enabled"] = esp;
    settings["ESP"]["Box"] = espbox;
    settings["ESP"]["BoxType"] = boxtype;
    settings["ESP"]["Roundness"] = rounded;
    settings["ESP"]["Fill"] = fillbox;
    settings["ESP"]["FillGradient"] = fillboxg;
    settings["ESP"]["FillValue"] = fillopacity;
    settings["ESP"]["Stroke"] = stroke;
    settings["ESP"]["Csizer"] = csizer;
    settings["ESP"]["Line"] = espline;
    settings["ESP"]["Name"] = espnick;
    settings["ESP"]["Health"] = esphp;
    settings["ESP"]["Distance"] = espdist;
    settings["ESP"]["Weapon"] = espweapon;
    settings["ESP"]["Skeleton"] = espskeleton;
    settings["ESP"]["OffScreen"] = esparrows;
    settings["ESP"]["GrenadeESP"] = grenadeesp;
    settings["ESP"]["BombESP"] = bombesp;
    PackColor(settings["ESP"]["VisibleColor"], espVisibleColor);
    PackColor(settings["ESP"]["InvisibleColor"], espInvisibleColor);
    PackColor(settings["ESP"]["ElementsColor"], espElementsColor);

    settings["PlayerLine"]["Enabled"] = pline;

    //aim
    settings["Aimbot"]["Enabled"] = enableaim;
    settings["Aimbot"]["Silent"] = silentaim;

    settings["Aimbot"]["AimHead"] = AimHead;
    settings["Aimbot"]["AimBody"] = AimBody;
    settings["Aimbot"]["AimArms"] = AimArms;
    settings["Aimbot"]["AimLegs"] = AimLegs;

    settings["Aimbot"]["VisibleCheck"] = vischeck;
    settings["Aimbot"]["FOV"] = aimfov;
    settings["Aimbot"]["SilentChance"] = silentChance;
    settings["Aimbot"]["Smooth"] = aimsmooth;
    settings["Aimbot"]["TargetBone"] = aimtype;
    //rage
    settings["Rage"]["Telekill"] = telekill;
    settings["Rage"]["Masskill"] = masskill;
    settings["Rage"]["ClanTag"] = clantag;
    settings["Rage"]["ChatSpam"] = chatspam;
    settings["Rage"]["FastFire"] = fastfire;
    settings["Rage"]["recoil"] = recoil;

    settings["Rage"]["Wallshot"] = wall;

    settings["Rage"]["InfAmmo"] = infammo;
    settings["Rage"]["AirJump"] = infjump;
    settings["Rage"]["BunnyHop"] = bhop;
    settings["Rage"]["BunnyHopSpeed"] = bhopvalue;

    settings["Profile"]["Medal"] = xphack;

    //aim
    settings["Viewmodel"]["Position"] = handspos;
    settings["Viewmodel"]["PositionX"] = handsx;
    settings["Viewmodel"]["PositionY"] = handsy;
    settings["Viewmodel"]["PositionZ"] = handsz;
    settings["Viewmodel"]["FieldOfViewChanger"] = worldfov;
    settings["Viewmodel"]["FOV"] = fovvalue;
    //skinchanger
    settings["Skinchanger"]["G22"] = g22skin;
    settings["Skinchanger"]["USP"] = uspskin;
    settings["Skinchanger"]["P350"] = p350skin;
    settings["Skinchanger"]["Deagle"] = deagleskin;
    settings["Skinchanger"]["Tec9"] = tec9skin;
    settings["Skinchanger"]["FiveSeven"] = fivesevenskin;
    settings["Skinchanger"]["UMP45"] = ump45skin;
    settings["Skinchanger"]["MP5"] = mp5skin;
    settings["Skinchanger"]["MP7"] = mp7skin;
    settings["Skinchanger"]["P90"] = p90skin;
    settings["Skinchanger"]["M60"] = m60skin;
    settings["Skinchanger"]["SM1014"] = sm1014skin;
    settings["Skinchanger"]["FabM"] = fabmskin;
    settings["Skinchanger"]["AKR"] = akrskin;
    settings["Skinchanger"]["AKR12"] = akr12skin;
    settings["Skinchanger"]["M4"] = m4skin;
    settings["Skinchanger"]["M4A1"] = m4a1skin;
    settings["Skinchanger"]["M16"] = m16skin;
    settings["Skinchanger"]["FAMAS"] = famasskin;
    settings["Skinchanger"]["FnFAL"] = fnfalskin;
    settings["Skinchanger"]["AWM"] = awmskin;
    settings["Skinchanger"]["M40"] = m40skin;
    settings["Skinchanger"]["M110"] = m110skin;
    settings["Skinchanger"]["TargetKnife"] = knife;
    settings["Skinchanger"]["Bayonet"] = m9skin;
    settings["Skinchanger"]["Karambit"] = karambitskin;
    settings["Skinchanger"]["Butterfly"] = butterflyskin;
    settings["Skinchanger"]["jKommando"] = jkommandoskin;
    settings["Skinchanger"]["FlipKnife"] = flipknifeskin;
    settings["Skinchanger"]["Kunai"] = kunaiskin;
    settings["Skinchanger"]["Scorpion"] = scorpionskin;
    settings["Skinchanger"]["Tanto"] = tantoskin;
    settings["Skinchanger"]["Daggers"] = daggersskin;
    settings["Skinchanger"]["Gloves"] = glovess;
    Json::StyledWriter styledWriter;
    std::string strJson = styledWriter.write(settings);
    //LOGD("Cfg %s", strJson.c_str());
    FILE* file = fopen(path2file.c_str(), ozObfuscate("w+"));
    if (file) {
        //LOGD("writing cfg!");
        fwrite(strJson.c_str(), 1, strJson.length(), file);
        fclose(file);
        //LOGD("ok!");
    } else {
        //LOGD("Failed to open for read!");
    }
}
static const char* current_cfg = ozObfuscate("none");
std::vector<std::string> configs = {}; //std::string(ozObfuscate("legit.cfg")), std::string(ozObfuscate("rage.cfg"))
const char* cfgDirectory = ozObfuscate("/storage/emulated/0/Download/configs/");
void UpdateCFG() {
    //LOGD("Updating config list!");
    configs.clear(); // erasing all because we are updating list!
    struct dirent *entry;
    DIR *dir = opendir(ozObfuscate("/storage/emulated/0/Download/configs/"));
    if (dir == NULL) {
        //LOGD("error!");
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        const char* file = entry->d_name;
        const char* file_full_path = std::string(std::string(cfgDirectory) + std::string(entry->d_name)).c_str();
        LOGD("New file: %s", file);
        LOGD("New file path: %s", file_full_path);
        if (!strstr(file, ozObfuscate("cfg"))) {
            //LOGD("Bad cfg - %s!", file);
        } else {
            LOGD("Valid cfg! %s", file);
            configs.push_back(std::string(file));
        }
    }
    closedir(dir);
    LOGD("List updated! Size of list %d", configs.size());
}
static jobject getGlobalContext(JNIEnv *env)
{

    jclass activityThread = env->FindClass(ozObfuscate("android/app/ActivityThread"));
    jmethodID currentActivityThread = env->GetStaticMethodID(activityThread, ozObfuscate("currentActivityThread"), ozObfuscate("()Landroid/app/ActivityThread;"));
    jobject at = env->CallStaticObjectMethod(activityThread, currentActivityThread);

    jmethodID getApplication = env->GetMethodID(activityThread, ozObfuscate("getApplication"), ozObfuscate("()Landroid/app/Application;"));
    jobject context = env->CallObjectMethod(at, getApplication);
    return context;
}
bool authorized = false;
std::string token = "";
int theme = 0; // gold
ImVec2 ImprovedW2S(Vvector3 pos, bool &checker) {
    auto cam = GetCamera(NULL);
    if (!cam) return ImVec2(0,0);
    Vvector3 worldPoint = WorldToScreen(cam,pos);
    checker = worldPoint.z > 0;
    return ImVec2(worldPoint.x, screenHeight - worldPoint.y);
}
void Draw3dCapsule(Vvector3 pos, float radius, float height, ImColor color) {
    bool checker;
    ImprovedW2S(pos, checker);
    if (!checker) { return; }
    for (int i = 0; i < 100; i++) {
        if (i < 100) {
            float val = 0;
            if (i < 76 && i > 24) {
                val = height / 2 - radius / 2;
            } else {
                val = (height * -1) / 2 + radius / 2;
            }
            Vvector3 pos1 = Vvector3( pos.x, pos.y - val + radius * cos((i) * (PI * 2) / 100), pos.z + radius * sin((i) * (PI * 2) / 100));
            Vvector3 pos2 = Vvector3( pos.x, pos.y - val + radius * cos((i + 1) * (PI * 2) / 100), pos.z + radius * sin((i + 1) * (PI * 2) / 100));
            {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos2, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
        }
    }
    for (int i = 0; i < 100; i++) {
        if (i < 100) {
            float val = 0;
            if (i < 76 && i > 24) {
                val = height / 2 - radius / 2;
            } else {
                val = (height * -1) / 2 + radius / 2;
            }
            Vvector3 pos1 = Vvector3( pos.x + radius * sin((i) * (PI * 2) / 100), pos.y - val + radius * cos((i) * (PI * 2) / 100), pos.z);
            Vvector3 pos2 = Vvector3( pos.x + radius * sin((i + 1) * (PI * 2) / 100), pos.y - val + radius * cos((i + 1) * (PI * 2) / 100), pos.z);
            {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos2, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
        }
    }
    for (int i = 0; i < 100; i++) {
        if (i < 100) {
            Vvector3 pos1 = Vvector3( pos.x + radius * cos((i) * (PI * 2) / 100), pos.y - (height / 2) + (radius / 2), pos.z + radius * sin((i) * (PI * 2) / 100));
            Vvector3 pos2 = Vvector3( pos.x + radius * cos((i + 1) * (PI * 2) / 100), pos.y - (height / 2) + (radius / 2), pos.z + radius * sin((i + 1) * (PI * 2) / 100));
            {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos2, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
            Vvector3 pos3 = pos1;
            Vvector3 pos4 = pos2;
            pos3.y += height - radius;
            pos4.y += height - radius;
            {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos3, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos4, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
            if (i == 0) {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos3, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
            if (i == 25) {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos3, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
            if (i == 50) {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos3, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
            if (i == 75) {
                bool checker1;
                bool checker2;
                ImVec2 ScreenPos1 = ImprovedW2S(pos1, checker1);
                ImVec2 ScreenPos2 = ImprovedW2S(pos3, checker2);
                if (checker1 && checker2) {
                    ImGui::GetBackgroundDrawList()->AddLine(ScreenPos1, ScreenPos2, ImColor(255, 255, 255, 200), 3);
                }
            }
        }
    }
}
void DrawCorneredBox(int X, int Y, int W, int H, ImColor color, int thickness) {
    float lineW = (W / 3);
    float lineH = (H / 3);
    ImDrawList* Renderer = getDrawList();
    Renderer->AddLine(ImVec2(X, Y), ImVec2(X, Y + lineH), color, thickness);
    Renderer->AddLine(ImVec2(X, Y), ImVec2(X + lineW, Y), color, thickness);
    Renderer->AddLine(ImVec2(X + W - lineW, Y), ImVec2(X + W, Y), color, thickness);
    Renderer->AddLine(ImVec2(X + W, Y), ImVec2(X + W, Y + lineH), color, thickness);
    Renderer->AddLine(ImVec2(X, Y + H - lineH), ImVec2(X, Y + H), color, thickness);
    Renderer->AddLine(ImVec2(X, Y + H), ImVec2(X + lineW, Y + H), color, thickness);
    Renderer->AddLine(ImVec2(X + W - lineW, Y + H), ImVec2(X + W, Y + H), color, thickness);
    Renderer->AddLine(ImVec2(X + W, Y + H - lineH), ImVec2(X + W, Y + H), color, thickness);
}

JavaVM* gJavaVM = NULL;
void SearchActivity(JNIEnv * globalEnv){
    jclass prcls = globalEnv->FindClass(ozObfuscate("com/unity3d/player/UnityPlayer"));
    if(prcls != nullptr){
        LOGD("found class");
        jfieldID UnityPlayer_CurrentActivity_fid2 = globalEnv->GetStaticFieldID(prcls, ozObfuscate("currentActivity"), ozObfuscate("Landroid/app/Activity;"));
        if(UnityPlayer_CurrentActivity_fid2 != nullptr){
            LOGW("got activity");
            jobject resultObject=globalEnv->GetStaticObjectField(prcls, UnityPlayer_CurrentActivity_fid2);
            if(resultObject!=nullptr){
                LOGW("crated activity");
                UnityPlayer_CurrentActivity_fid = globalEnv->NewGlobalRef(resultObject);
            }
        }
    }
}
void displayKeyboard() {
    LOGI("Display keyboard!");
    JNIEnv* env;
    gJavaVM->AttachCurrentThread(&env, nullptr);
    jclass aycls = env->FindClass(ozObfuscate("android/app/Activity"));
    jmethodID gss = env->GetMethodID(aycls, ozObfuscate("getSystemService"),ozObfuscate("(Ljava/lang/String;)Ljava/lang/Object;"));
    jobject ss = env->CallObjectMethod(UnityPlayer_CurrentActivity_fid, gss, env->NewStringUTF(ozObfuscate("input_method")));
    jclass imcls = env->FindClass(ozObfuscate("android/view/inputmethod/InputMethodManager"));
    jmethodID tgsifm = env->GetMethodID(imcls, ozObfuscate("toggleSoftInput"), ozObfuscate("(II)V"));
    env->CallVoidMethod(ss, tgsifm, 2,0);
}
float bx = 1, by = 2, bz = 1;

bool boels;
bool bil2;
int csel = 1;
void styles() {
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    colors[ImGuiCol_Text]                   = ImVec4(0.92f, 0.92f, 0.92f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.44f, 0.44f, 0.44f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
    colors[ImGuiCol_Border]                 = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_FrameBg]                = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_TitleBg]                = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.11f, 0.11f, 0.11f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.06f, 0.06f, 0.06f, 0.53f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.47f, 0.47f, 0.47f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.81f, 0.83f, 0.81f, 1.00f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_Button]                 = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.4f, 0.4f, 0.4f, 1.00f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.4f, 0.4f, 0.4f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0, 0, 0, 0);
    colors[ImGuiCol_Separator]              = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(0.21f, 0.21f, 0.21f, 1.00f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_Tab]                    = ImVec4(0.51f, 0.36f, 0.15f, 1.00f);
    colors[ImGuiCol_TabHovered]             = ImVec4(0.91f, 0.64f, 0.13f, 1.00f);
    colors[ImGuiCol_TabActive]              = ImVec4(0.78f, 0.55f, 0.21f, 1.00f);
    colors[ImGuiCol_TabUnfocused]           = ImVec4(0.07f, 0.10f, 0.15f, 0.97f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.14f, 0.26f, 0.42f, 1.00f);
    colors[ImGuiCol_PlotLines]              = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);

    colors[ImGuiCol_DragDropTarget]         = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
    colors[ImGuiCol_NavHighlight]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);

    //style->FramePadding = ImVec2(0, 0);
    style->ItemSpacing = ImVec2(4, 4);
    style->IndentSpacing = 0;
    style->ScrollbarSize = 10;

    style->WindowRounding = 0;
    style->FrameRounding = 0;
    style->PopupRounding = 0;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;

    style->WindowTitleAlign = ImVec2(0, 0);
    style->DisplaySafeAreaPadding = ImVec2(0, 0);

    ImGui::GetStyle().WindowRounding = 0;
    ImGui::GetStyle().Alpha = 255;
    ImGui::GetStyle().WindowPadding = ImVec2(0,0);

    ImGui::GetStyle().Colors[ImGuiCol_FrameBg] = ImVec4(0, 0, 0, 0);
    ImGui::GetStyle().Colors[ImGuiCol_FrameBgActive] = ImVec4(0, 0, 0, 0);
    ImGui::GetStyle().Colors[ImGuiCol_FrameBgHovered] = ImVec4(0, 0, 0, 0);
    //ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200
}
void featurese(int sel, int ch) {
    if (sel == 1) {
        if (ch == 1) {
            //ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("world")).c_str());
            //ImGui::Checkbox(ozObfuscate("Bomb ESP"), &bombesp);
            //ImGui::Checkbox(ozObfuscate("Grenade ESP"), &grenadeesp);
            if (ImGui::CollapsingHeader("esp")) {
                ImGui::Checkbox(ozObfuscate("enable   "), &esp);
                if (esp) {
                    ImGui::Checkbox(ozObfuscate("box"), &espbox);
                    if (espbox) {
                        const char *types[] = {ozObfuscate("3d"), ozObfuscate("2d")};
                        ImGui::Combo(ozObfuscate("dimension"), &boxtype, types,
                                     IM_ARRAYSIZE(types));
                        ImGui::Checkbox(ozObfuscate("fill"), &fillbox);
                        if (boxtype == 1 && fillbox)
                            ImGui::Checkbox(ozObfuscate("gradient"), &fillboxg);
                        if (fillbox)
                            ImGui::SliderFloat(ozObfuscate("percent"), &fillopacity, 0, 255,
                                               ozObfuscate("%.2f"));
                        ImGui::SliderFloat(ozObfuscate("stroke"), &stroke, 0.5, 3,
                                           ozObfuscate("%.2f"));
                        if (boxtype == 0)
                            ImGui::SliderFloat(ozObfuscate("corner"), &csizer, 0.2, 1,
                                               ozObfuscate("%.2f"));
                        if (boxtype == 1)
                            ImGui::SliderFloat(ozObfuscate("round"), &rounded, 0, 5,
                                               ozObfuscate("%.2f"));
                    }
                    //ImGui::Checkbox(ozObfuscate("Off Screen Arrows"), &esparrows);
                    ImGui::Checkbox(ozObfuscate("snaplines"), &espline);
                    ImGui::Checkbox(ozObfuscate("health"), &esphp);
                    ImGui::Checkbox(ozObfuscate("name"), &espnick);
                    ImGui::Checkbox(ozObfuscate("weapon"), &espweapon);
                    ImGui::Checkbox(ozObfuscate("distance"), &espdist);
                    ImGui::Checkbox(ozObfuscate("skeleton"), &espskeleton);
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("colors")).c_str());
                    AddColorPicker(ozObfuscate("invisible"), *(ImVec4 *) &espInvisibleColor);
                    ImGui::SameLine();
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("invisible")).c_str());
                    AddColorPicker(ozObfuscate("visible"), *(ImVec4 *) &espVisibleColor);
                    ImGui::SameLine();
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("visible")).c_str());
                    AddColorPicker(ozObfuscate("elements"), *(ImVec4 *) &espElementsColor);
                    ImGui::SameLine();
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("elements")).c_str());
                }
            }
            if (ImGui::CollapsingHeader("player line")) {
                ImGui::Checkbox(ozObfuscate("enable    "), &pline);
            }

            if (ImGui::Button(ozObfuscate("3rd"))) m3r = true;
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("1rd"))) m1r = true;
            //ImGui::Checkbox(ozObfuscate("cam"), &camf);


        }
        if (ch == 2) {
            if (ImGui::CollapsingHeader("viewmodel")) {
                ImGui::Checkbox(ozObfuscate("enable "), &handspos);
                if (handspos) {
                    ImGui::SliderFloat(ozObfuscate("x"), &handsx, -1, 1, ozObfuscate("%.5f"));
                    ImGui::SliderFloat(ozObfuscate("y"), &handsy, -1, 1, ozObfuscate("%.5f"));
                    ImGui::SliderFloat(ozObfuscate("z"), &handsz, -1, 1, ozObfuscate("%.5f"));
                }
            }
            if (ImGui::CollapsingHeader("fov")) {
                ImGui::Checkbox(ozObfuscate("enable  "), &worldfov);
                if (worldfov) {
                    ImGui::SliderFloat(ozObfuscate("value"), &fovvalue, 0, 180,
                                       ozObfuscate("%.1f"));
                }
            }
        }
    }
    if (sel == 2) {
        if (ch == 1) {
            if (ImGui::CollapsingHeader("silent aim")) {            //ImGui::Checkbox(ozObfuscate("Aimbot"), &enableaim);
                ImGui::Checkbox(ozObfuscate("enable"), &silentaim);
                if (silentaim) {
                    ImGui::SliderFloat(ozObfuscate("hitchance"), &silentChance, 1, 100,
                                       ozObfuscate("%.1f%"));
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("hitboxes")).c_str());
                    ImGui::Checkbox(ozObfuscate("head"), &AimHead);
                    ImGui::Checkbox(ozObfuscate("body"), &AimBody);
                    ImGui::Checkbox(ozObfuscate("arms"), &AimArms);
                    ImGui::Checkbox(ozObfuscate("legs"), &AimLegs);
                    ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("settings")).c_str());
                    ImGui::Checkbox(ozObfuscate("vis check"), &vischeck);
                    ImGui::SliderFloat(ozObfuscate("fov"), &aimfov, 0, 180, ozObfuscate("%.2f°"));
                }
            }
            if (ImGui::CollapsingHeader("profile")) {
                ImGui::Checkbox(ozObfuscate("medalhack"), &xphack);
            }
            //ImGui::SliderFloat(ozObfuscate("smooth"), &aimsmooth, 0, 15, ozObfuscate("%.2fms"));
        }
        if (ch == 2) {
            if (ImGui::CollapsingHeader("rage")) {
                ImGui::Checkbox(ozObfuscate("telekill"), &telekill);
                ImGui::Checkbox(ozObfuscate("masskill"), &masskill);
                ImGui::Checkbox(ozObfuscate("clantag"), &clantag);
                ImGui::Checkbox(ozObfuscate("chatspam"), &chatspam);
                ImGui::Checkbox(ozObfuscate("firerate"), &fastfire);
                ImGui::Checkbox(ozObfuscate("no recoil"), &recoil);
                //ImGui::Checkbox(ozObfuscate("wall shoot"), &wall);
                ImGui::Checkbox(ozObfuscate("inf ammo"), &infammo);
            }
            if (ImGui::CollapsingHeader("movement")) {
                ImGui::Checkbox(ozObfuscate("bhop"), &bhop);
                if (bhop)
                    ImGui::SliderFloat(ozObfuscate("value"), &bhopvalue, 0, 100,
                                       ozObfuscate("%.1f"));
                ImGui::Checkbox(ozObfuscate("air jump"), &infjump);
                ImGui::Checkbox(ozObfuscate("fly"), &fly);
                if (fly)
                    ImGui::SliderFloat(ozObfuscate("Speed"), &flySpeed, 0, 100,
                                       ozObfuscate("%.1f"));
            }
        }
    }
    if (sel == 3) {
        if (ch == 1) {
            if (ImGui::CollapsingHeader("pistols")) {
                const char *g22skins[] = {ozObfuscate("none"), ozObfuscate("relic"),
                                          ozObfuscate("frost Wyrm"), ozObfuscate("nest"),
                                          ozObfuscate("scale"), ozObfuscate("carbon"),
                                          ozObfuscate("white carbon"), ozObfuscate("new1"),
                                          ozObfuscate("starfall")};
                ImGui::Combo(ozObfuscate("g22"), &g22skin, g22skins, IM_ARRAYSIZE(g22skins));
                const char *uspskins[] = {ozObfuscate("none"), ozObfuscate("genesis"),
                                          ozObfuscate("2 years"), ozObfuscate("2 years red"),
                                          ozObfuscate("purple camo"), ozObfuscate("sticker bomb"),
                                          ozObfuscate("chameleon"), ozObfuscate("geometric"),
                                          ozObfuscate("winter 2020"), ozObfuscate("pisces")};
                ImGui::Combo(ozObfuscate("usp"), &uspskin, uspskins, IM_ARRAYSIZE(uspskins));
                const char *p350skins[] = {ozObfuscate("none"), ozObfuscate("cyber"),
                                           ozObfuscate("forest spirit"), ozObfuscate("rally"),
                                           ozObfuscate("tag king"), ozObfuscate("oni"),
                                           ozObfuscate("4 years"), ozObfuscate("blizzard"),
                                           ozObfuscate("autumn"), ozObfuscate("poison")};
                ImGui::Combo(ozObfuscate("p350"), &p350skin, p350skins, IM_ARRAYSIZE(p350skins));
                const char *deagleskins[] = {ozObfuscate("none"), ozObfuscate("glory"),
                                             ozObfuscate("mafia"), ozObfuscate("orochi"),
                                             ozObfuscate("ace"), ozObfuscate("dragon glass"),
                                             ozObfuscate("red dragon"), ozObfuscate("predator"),
                                             ozObfuscate("captain morgan")};
                ImGui::Combo(ozObfuscate("deagle"), &deagleskin, deagleskins,
                             IM_ARRAYSIZE(deagleskins));
                const char *tec9skins[] = {ozObfuscate("none"), ozObfuscate("needle"),
                                           ozObfuscate("sticker bomb"),
                                           ozObfuscate("holiday frost"), ozObfuscate("restless"),
                                           ozObfuscate("tropic"), ozObfuscate("spot"),
                                           ozObfuscate("reactor"), ozObfuscate("winter 2020"),
                                           ozObfuscate("competive"), ozObfuscate("fable")};
                ImGui::Combo(ozObfuscate("tec9"), &tec9skin, tec9skins, IM_ARRAYSIZE(tec9skins));
                const char *fivesevenskins[] = {ozObfuscate("none"), ozObfuscate("zap"),
                                                ozObfuscate("holiday Frost"),
                                                ozObfuscate("demonic Fog"), ozObfuscate("enforcer"),
                                                ozObfuscate("rush"), ozObfuscate("sight red"),
                                                ozObfuscate("sight grey"), ozObfuscate("zone"),
                                                ozObfuscate("poison"), ozObfuscate("competive"),
                                                ozObfuscate("tactical"), ozObfuscate("venom")};
                ImGui::Combo(ozObfuscate("five seven"), &fivesevenskin, fivesevenskins,
                             IM_ARRAYSIZE(fivesevenskins));
            }
            if (ImGui::CollapsingHeader("smg")) {
                const char *ump45skins[] = {ozObfuscate("none"), ozObfuscate("gas"),
                                            ozObfuscate("beast"), ozObfuscate("winged"),
                                            ozObfuscate("cerberus"), ozObfuscate("spirit"),
                                            ozObfuscate("cyberpunk"), ozObfuscate("white carbon")};
                ImGui::Combo(ozObfuscate("ump45"), &ump45skin, ump45skins,
                             IM_ARRAYSIZE(ump45skins));
                const char *mp5skins[] = {ozObfuscate("none"), ozObfuscate("northern fury"),
                                          ozObfuscate("reactor"), ozObfuscate("zone")};
                ImGui::Combo(ozObfuscate("mp5"), &mp5skin, mp5skins, IM_ARRAYSIZE(mp5skins));
                const char *mp7skins[] = {ozObfuscate("none"), ozObfuscate("lich"),
                                          ozObfuscate("graffiti"), ozObfuscate("2 years"),
                                          ozObfuscate("blizzard"), ozObfuscate("arcade"),
                                          ozObfuscate("winter sport"), ozObfuscate("2 years red"),
                                          ozObfuscate("offroad")};
                ImGui::Combo(ozObfuscate("mp7"), &mp7skin, mp7skins, IM_ARRAYSIZE(mp7skins));
                const char *p90skins[] = {ozObfuscate("none"), ozObfuscate("ghoul"),
                                          ozObfuscate("iron will"), ozObfuscate("oops"),
                                          ozObfuscate("samurai"), ozObfuscate("ronin mk9")};
                ImGui::Combo(ozObfuscate("p90"), &p90skin, p90skins, IM_ARRAYSIZE(p90skins));
            }
            if (ImGui::CollapsingHeader("heavy")) {
                const char *fabmskins[] = {ozObfuscate("none"), ozObfuscate("boom"),
                                           ozObfuscate("reactor"), ozObfuscate("flight"),
                                           ozObfuscate("parrot")};
                ImGui::Combo(ozObfuscate("fabm"), &fabmskin, fabmskins, IM_ARRAYSIZE(fabmskins));
                const char *sm1014skins[] = {ozObfuscate("none"), ozObfuscate("necromancer"),
                                             ozObfuscate("pathfinder"), ozObfuscate("arctic")};
                ImGui::Combo(ozObfuscate("sm1014"), &sm1014skin, sm1014skins,
                             IM_ARRAYSIZE(sm1014skins));
                const char *m60skins[] = {ozObfuscate("none"), ozObfuscate("grunge"),
                                          ozObfuscate("mecha"), ozObfuscate("steam beast")};
                ImGui::Combo(ozObfuscate("m60"), &m60skin, m60skins, IM_ARRAYSIZE(m60skins));
            }
            if (ImGui::CollapsingHeader("rifles")) {
                const char *fnfalskins[] = {ozObfuscate("none"), ozObfuscate("leather"),
                                            ozObfuscate("tactical")};
                ImGui::Combo(ozObfuscate("fnfal"), &fnfalskin, fnfalskins,
                             IM_ARRAYSIZE(fnfalskins));
                const char *famasskins[] = {ozObfuscate("none"), ozObfuscate("beagle"),
                                            ozObfuscate("autumn"), ozObfuscate("monster"),
                                            ozObfuscate("anger"), ozObfuscate("fury"),
                                            ozObfuscate("christmas symbol")};
                ImGui::Combo(ozObfuscate("famas"), &famasskin, famasskins,
                             IM_ARRAYSIZE(famasskins));
                const char *akrskins[] = {ozObfuscate("none"), ozObfuscate("carbon"),
                                          ozObfuscate("tag king"), ozObfuscate("2 years red"),
                                          ozObfuscate("sport"), ozObfuscate("necromancer"),
                                          ozObfuscate("dragon"), ozObfuscate("treasure hunter")};
                ImGui::Combo(ozObfuscate("akr"), &akrskin, akrskins, IM_ARRAYSIZE(akrskins));
                const char *akr12skins[] = {ozObfuscate("none"), ozObfuscate("4 years"),
                                            ozObfuscate("carbon"), ozObfuscate("railgun"),
                                            ozObfuscate("geometric")};
                ImGui::Combo(ozObfuscate("akr12"), &akr12skin, akr12skins,
                             IM_ARRAYSIZE(akr12skins));
                const char *m4skins[] = {ozObfuscate("none"), ozObfuscate("predator"),
                                         ozObfuscate("grand prix"), ozObfuscate("lizard"),
                                         ozObfuscate("necromancer"), ozObfuscate("samurai"),
                                         ozObfuscate("ronin")};
                ImGui::Combo(ozObfuscate("m4"), &m4skin, m4skins, IM_ARRAYSIZE(m4skins));
                const char *m4a1skins[] = {ozObfuscate("none"), ozObfuscate("kitsune"),
                                           ozObfuscate("tiger"), ozObfuscate("king v703"),
                                           ozObfuscate("sour"), ozObfuscate("bubblegum")};
                ImGui::Combo(ozObfuscate("m4a1"), &m4a1skin, m4a1skins, IM_ARRAYSIZE(m4a1skins));
                const char *m16skins[] = {ozObfuscate("none"), ozObfuscate("iron Will"),
                                          ozObfuscate("triumphant"), ozObfuscate("winged"),
                                          ozObfuscate("4 years")};
                ImGui::Combo(ozObfuscate("m16"), &m16skin, m16skins, IM_ARRAYSIZE(m16skins));
            }
            if (ImGui::CollapsingHeader("snipers")) {
                const char *m40skins[] = {ozObfuscate("none"), ozObfuscate("winter track"),
                                          ozObfuscate("cursed fire"), ozObfuscate("monster")};
                ImGui::Combo(ozObfuscate("m40"), &m40skin, m40skins, IM_ARRAYSIZE(m40skins));
                const char *awmskins[] = {ozObfuscate("none"), ozObfuscate("dragon"),
                                          ozObfuscate("polar night"), ozObfuscate("scratch"),
                                          ozObfuscate("phoenix"), ozObfuscate("boom"),
                                          ozObfuscate("sport"), ozObfuscate("winter sport"),
                                          ozObfuscate("2 years red"), ozObfuscate("sport v2"),
                                          ozObfuscate("genesis"), ozObfuscate("gear"),
                                          ozObfuscate("treasure hunter")};
                ImGui::Combo(ozObfuscate("awm"), &awmskin, awmskins, IM_ARRAYSIZE(awmskins));
                const char *m110skins[] = {ozObfuscate("none"), ozObfuscate("cyber"),
                                           ozObfuscate("flow")};
                ImGui::Combo(ozObfuscate("m110"), &m110skin, m110skins, IM_ARRAYSIZE(m110skins));
            }
        }
        if (ch == 2) {
            if (ImGui::CollapsingHeader("knifes")) {
                const char *knifes[] = {ozObfuscate("none"), ozObfuscate("bayonet"),
                                        ozObfuscate("karambit"), ozObfuscate("jkommando"),
                                        ozObfuscate("butterfly"), ozObfuscate("flip knife"),
                                        ozObfuscate("kunai"), ozObfuscate("scorpion"),
                                        ozObfuscate("tanto"), ozObfuscate("daggers")};
                ImGui::Combo(ozObfuscate("knife"), &knife, knifes, IM_ARRAYSIZE(knifes));
                if (knife == 1) {
                    const char *m9bayonetskins[] = {ozObfuscate("none"),
                                                    ozObfuscate("dragon glass"),
                                                    ozObfuscate("ancient"), ozObfuscate("scratch"),
                                                    ozObfuscate("universe"),
                                                    ozObfuscate("blueblood")};
                    ImGui::Combo(ozObfuscate("skin"), &m9skin, m9bayonetskins,
                                 IM_ARRAYSIZE(m9bayonetskins));
                }
                if (knife == 2) {
                    const char *karambitskins[] = {ozObfuscate("none"), ozObfuscate("claw"),
                                                   ozObfuscate("gold"), ozObfuscate("dragon glass"),
                                                   ozObfuscate("universe"), ozObfuscate("scratch"),
                                                   ozObfuscate("year of the tiger"),
                                                   ozObfuscate("snow camo"), ozObfuscate("frozen"),
                                                   ozObfuscate("cold flame")};
                    ImGui::Combo(ozObfuscate("skin"), &karambitskin, karambitskins,
                                 IM_ARRAYSIZE(karambitskins));
                }
                if (knife == 3) {
                    const char *jkommandoskins[] = {ozObfuscate("none"), ozObfuscate("reaper"),
                                                    ozObfuscate("floral"), ozObfuscate("ancient"),
                                                    ozObfuscate("luxury"), ozObfuscate("frozen"),
                                                    ozObfuscate("augustine")};
                    ImGui::Combo(ozObfuscate("skin"), &jkommandoskin, jkommandoskins,
                                 IM_ARRAYSIZE(jkommandoskins));
                }
                if (knife == 4) {
                    const char *butterflyskins[] = {ozObfuscate("none"),
                                                    ozObfuscate("dragon glass"),
                                                    ozObfuscate("legacy"),
                                                    ozObfuscate("red floral"),
                                                    ozObfuscate("starfall"), ozObfuscate("kumo"),
                                                    ozObfuscate("cold flame"),
                                                    ozObfuscate("winter")};
                    ImGui::Combo(ozObfuscate("skin"), &butterflyskin, butterflyskins,
                                 IM_ARRAYSIZE(butterflyskins));
                }
                if (knife == 5) {
                    const char *flipKnifeskins[] = {ozObfuscate("none"), ozObfuscate("stone cold"),
                                                    ozObfuscate("frozen"),
                                                    ozObfuscate("holiday frost"),
                                                    ozObfuscate("snow camo"), ozObfuscate("vortex"),
                                                    ozObfuscate("dragon glass"),
                                                    ozObfuscate("arctic")};
                    ImGui::Combo(ozObfuscate("skin"), &flipknifeskin, flipKnifeskins,
                                 IM_ARRAYSIZE(flipKnifeskins));
                }
                if (knife == 6) {
                    const char *kunaiskins[] = {ozObfuscate("none"), ozObfuscate("poison"),
                                                ozObfuscate("augustite"), ozObfuscate("snow camo"),
                                                ozObfuscate("bone"), ozObfuscate("reaper"),
                                                ozObfuscate("cold flame"), ozObfuscate("radiation"),
                                                ozObfuscate("luxury")};
                    ImGui::Combo(ozObfuscate("skin"), &kunaiskin, kunaiskins,
                                 IM_ARRAYSIZE(kunaiskins));
                }
                if (knife == 7) {
                    const char *scorpionskins[] = {ozObfuscate("none"),
                                                   ozObfuscate("holiday frost"),
                                                   ozObfuscate("starfall"),
                                                   ozObfuscate("cold flame"), ozObfuscate("veil"),
                                                   ozObfuscate("scratch")};
                    ImGui::Combo(ozObfuscate("skin"), &scorpionskin, scorpionskins,
                                 IM_ARRAYSIZE(scorpionskins));
                }
                if (knife == 8) {
                    const char *tantoskins[] = {ozObfuscate("none"), ozObfuscate("restless"),
                                                ozObfuscate("transistor"), ozObfuscate("flow"),
                                                ozObfuscate("pearl abyss"), ozObfuscate("dojo"),
                                                ozObfuscate("malachite"), ozObfuscate("tiger")};
                    ImGui::Combo(ozObfuscate("skin"), &tantoskin, tantoskins,
                                 IM_ARRAYSIZE(tantoskins));
                }
                if (knife == 9) {
                    const char *daggersskins[] = {ozObfuscate("none"), ozObfuscate("demonic steel"),
                                                  ozObfuscate("molten"), ozObfuscate("acid"),
                                                  ozObfuscate("grunge"), ozObfuscate("harmony")};
                    ImGui::Combo(ozObfuscate("skin"), &daggersskin, daggersskins,
                                 IM_ARRAYSIZE(daggersskins));
                }
            }
            if (ImGui::CollapsingHeader("gloves")) {
                const char *glovesskins[] = {ozObfuscate("none"), ozObfuscate("autumn"),
                                             ozObfuscate("punk"), ozObfuscate("living flame"),
                                             ozObfuscate("neuro"), ozObfuscate("retro wave"),
                                             ozObfuscate("phoenix risen"), ozObfuscate("geometric"),
                                             ozObfuscate("steam rider")};
                ImGui::Combo(ozObfuscate("skin"), &glovess, glovesskins, IM_ARRAYSIZE(glovesskins));
            }
        }
    }
    if (sel == 4) {
        if (ch == 1) {
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("buttons size")).c_str());
            if (ImGui::Button(ozObfuscate("small"))) {
                ImGui::GetStyle().FramePadding = ImVec2(4, 2);
                padding = ImVec2(4, 2);
            }
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("big"))) {
                ImGui::GetStyle().FramePadding = ImVec2(4, 10);
                padding = ImVec2(4, 10);
            }
            /*ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("menu colors")).c_str());
            if (ImGui::Button(ozObfuscate("yellow"))) {
                setupGraphics(0,0);
            }
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("blue"))) {
                setupDefaultImgui();
            }
            if (ImGui::Button(ozObfuscate("black"))) {
                setupBlack();
            }
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("white"))) {
                setupWhite();
            }*/
        }
        if (ch == 2) {
            ImGui::Text(ozObfuscate("%s"), std::string(std::string(ozObfuscate("config: ")) + std::string(current_cfg)).c_str());
            if (ImGui::Button(ozObfuscate("update"))) {
                UpdateCFG();
            }
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("load"))) {
                LOGD(ozObfuscate("Loading selected cfg! %s"), current_cfg);
                LoadConfig(std::string(std::string(cfgDirectory) + std::string(current_cfg)));
            }
            if (ImGui::Button(ozObfuscate("save"))) {
                LOGD(ozObfuscate("Saving selected cfg! %s"), current_cfg);
                SaveConfig(std::string(std::string(cfgDirectory) + std::string(current_cfg)));
            }
            ImGui::SameLine();
            if (ImGui::Button(ozObfuscate("delete"))) {
                LOGD(ozObfuscate("Removing selected cfg! %s"), current_cfg);
                remove(std::string(std::string(cfgDirectory) + std::string(current_cfg)).c_str());
            }
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate(" ")).c_str());
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("cfg list")).c_str());
            for (int i = 0; i < configs.size(); i++) {
                if (ImGui::Button(configs[i].c_str())) {
                    current_cfg = configs[i].c_str();
                }
            }
        }
    }
    if (sel == 5) {
        if (ch == 1) {
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("modded by")).c_str());
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("procode unmaxing ise")).c_str());
        }
        if (ch == 2) {
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("t.me/grapecheats")).c_str());
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("t.me/grapecheats_bot")).c_str());
            ImGui::Text(ozObfuscate("%s"), std::string(ozObfuscate("grapecheats.store")).c_str());
        }
    }
}

void DrawMenu2() {
    styles();

    ImGui::GetStyle().Alpha = 20;
    ImGui::GetStyle().Colors[ImGuiCol_FrameBg] = ImVec4(0, 0, 0, 0);
    ImGui::GetStyle().Colors[ImGuiCol_FrameBgActive] = ImVec4(0, 0, 0, 0);
    ImGui::GetStyle().Colors[ImGuiCol_FrameBgHovered] = ImVec4(0, 0, 0, 0);
    ImGui::GetStyle().WindowMinSize = ImVec2(600,400); // 200,200

    ImGui::SetNextWindowPos(ImVec2(400, 400), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(600, 450), ImGuiCond_FirstUseEver);

    ImGui::Begin("", &boels, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);
    ImGui::GetWindowDrawList()->AddRectFilled(ImGui::GetWindowPos(), ImVec2(ImGui::GetWindowPos().x + 600, ImGui::GetWindowPos().y + 450),ImColor(60,60,60,180));
    ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(ImGui::GetWindowPos().x + 6, ImGui::GetWindowPos().y + 6), ImVec2(ImGui::GetWindowPos().x + 600 - 6, ImGui::GetWindowPos().y + 450 - 6),ImColor(15,15,15));
    ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(ImGui::GetWindowPos().x + 30, ImGui::GetWindowPos().y + 40 + 5), ImVec2(ImGui::GetWindowPos().x + 600 - 30, ImGui::GetWindowPos().y + 40 + 4  + 5),ImColor(224,66,37));
    ImGui::GetWindowDrawList()->AddText(ImGui::GetFont(),26,ImVec2(ImGui::GetWindowPos().x + 300 + 6 - (ImGui::CalcTextSize("grapecheat").x / 22 * 26) / 2,ImGui::GetWindowPos().y + 26 - (ImGui::CalcTextSize("grapecheat").y / 22 * 26) / 2),ImColor(255,255,255),"grapecheat");

    ImGui::SetCursorPos(ImVec2(30 + 0, 40 + 5 + 10));
    if (ImGui::Button("visual",ImVec2(103,30))) csel = 1;

    ImGui::SetCursorPos(ImVec2(30 + 103 + 6, 40 + 5 + 10));
    if (ImGui::Button("aim",ImVec2(103,30))) csel = 2;

    ImGui::SetCursorPos(ImVec2(30 + 103 + 103 + 12, 40 + 5 + 10));
    if (ImGui::Button("skins",ImVec2(103,30))) csel = 3;

    ImGui::SetCursorPos(ImVec2(30 + 103 + 103 + 103 + 18, 40 + 5 + 10));
    if (ImGui::Button("settings",ImVec2(103,30))) csel = 4;

    ImGui::SetCursorPos(ImVec2(30 + 103 + 103 + 103 + 103 + 24, 40 + 5 + 10));
    if (ImGui::Button("info",ImVec2(103,30))) csel = 5;

    ImGui::SetCursorPos(ImVec2(30, 40 + 5 + 10 + 30 + 10 + 5));
    if (ImGui::BeginListBox(" ", ImVec2(265, 300))) {
        featurese(csel, 1);
        ImGui::EndListBox();
    }
    ImGui::SetCursorPos(ImVec2(30 + 265 + 10, 40 + 5 + 10 + 30 + 10 + 5));
    if (ImGui::BeginListBox("  ", ImVec2(265, 300))) {
        featurese(csel, 2);
        ImGui::EndListBox();
    }
    ImGui::GetWindowDrawList()->AddRect(ImVec2(ImGui::GetWindowPos().x + 30, ImGui::GetWindowPos().y + 40 + 5 + 10 + 30 + 10 + 5), ImVec2(ImGui::GetWindowPos().x + 30 + 265, ImGui::GetWindowPos().y + 40 + 5 + 10 + 30 + 10 + 5 + 300),ImColor(180,180,180));
    ImGui::GetWindowDrawList()->AddRect(ImVec2(ImGui::GetWindowPos().x + 30 + 265 + 10, ImGui::GetWindowPos().y + 40 + 5 + 10 + 30 + 10 + 5), ImVec2(ImGui::GetWindowPos().x + 30 + 265 + 265 + 10, ImGui::GetWindowPos().y + 40 + 5 + 10 + 30 + 10 + 5 + 300),ImColor(180,180,180));

    ImGui::End();
}

template <typename T>
T clamp(const T& n, const T& lower, const T& upper) {
    return std::max(lower, std::min(n, upper));
}
void DrawLineGlow(ImVec2 start,ImVec2 end,ImColor col,float size, int gsize) {

    ImGui::GetBackgroundDrawList()->AddLine(start,end,col,size);
    for(int i = 0; i < gsize; i++) {
        ImGui::GetBackgroundDrawList()->AddLine(start,end,ImColor(col.Value.x,col.Value.y,col.Value.z,col.Value.w * (1.0f / (float)gsize) * (((float)(gsize - i))/(float)gsize)),size + i);
    }
}
void Render() {
    ImGuiIO &io = ImGui::GetIO();
    ImGui_ImplAndroidGLES2_NewFrame(ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y,
                                      currentTimeInMilliseconds());

    if (pline && !position_data.empty()) {
        for (auto i = 0; i < position_data.size() - 1; i++)
        {
            auto color = position_data[i].color;
            auto cur2 = position_data[i].pos;
            auto next2 = position_data[i + 1].pos;
            //Render::Get().RenderLine(x / 2 + 90 - (i - 1) * 5, y / 2 + 430 - (std::clamp(cur, 0, 450) * 75 / 320), x / 2 + 90 - i * 5, y / 2 + 130 - (clamp(next, 0, 450) * 75 / 320), Color(200, 200, 200, 255));

            auto checker1 = false;
            auto checker2 = false;

            auto cur = world2screen_c(cur2,checker1);
            auto next = world2screen_c(next2,checker2);

            if (checker1 && checker2) {
                if (true) {
                    DrawLineGlow(ImVec2(cur.x, cur.y),  ImVec2(next.x, next.y),ImColor(color.r / 255,color.g / 255,color.b / 255,(float)i / 255),3,20);
                }
                else {
                    ImGui::GetBackgroundDrawList()->AddLine(ImVec2(cur.x, cur.y),  ImVec2(next.x, next.y),ImColor(color.r / 255,color.g / 255,color.b / 255,(float)i / 255),3);
                }
            }
        }
    }

    if (myPlayer && !IsKnife(GetActiveWeaponID(myPlayer)) && (silentaim || enableaim)) {
        getDrawList()->AddCircle(ImVec2(screenWidth / 2, screenHeight / 2), screenWidth / 720 * aimfov, ImColor((int)(espElementsColor.x * 255), (int)(espElementsColor.y * 255), (int)(espElementsColor.z * 255), (int)(espElementsColor.w * 255)), 0, 1);
    }

    if (grenadeesp) {
        if (!grenadesList->grenades->empty() && GetCamera(NULL)) {
            for (int i = 0; i < grenadesList->grenades->size(); i++) {
                void *grenade = (*grenadesList->grenades)[i]->object;
                if (grenade != NULL && !IsTimeToDetonate(grenade)) {
                    void* params = *(void **)((uint64_t) grenade + 0xC);
                    float damage_radius = *(float *)((uint64_t) params + 0x64);
                    int grenadeID = *(int *)((uint64_t) params + 0xC);
                    std::string type = "";
                    switch (grenadeID) {
                        case 91:
                            type = std::string(ozObfuscate("HE Grenade ("));
                            break;
                        case 92:
                            type = std::string(ozObfuscate("Smoke ("));
                            break;
                        case 93:
                            type = std::string(ozObfuscate("Flashbang ("));
                            break;
                    }
                    void* transform = GetTransform(grenade);
                    Vvector3 pos = GetTransformLocation(transform);
                    float distance = Vvector3::distance(GetPlayerLocation(myPlayer), pos);
                    if (distance <= damage_radius && grenadeID == 91) {
                        getDrawList()->AddText(ImGui::GetFont(), 50,
                                               ImVec2(screenWidth / 2, screenHeight / 15),
                                               ImColor(255,0,0,255),
                                               std::string(ozObfuscate("MOVE!!! MOVE!!! MOVE!!!")).c_str(),
                                               nullptr,
                                               0.0f, nullptr);
                    }
                    Vvector3 world_screen = WorldToScreen(GetCamera(NULL), pos);
                    if (world_screen.z < 1) {
                        return;
                    };
                    std::string bomb = std::string(type + std::to_string((int) distance) + std::string(ozObfuscate("M)")));
                    ImVec2 TargetPos = ImVec2(world_screen.x, screenHeight - world_screen.y);
                    static bool state = true;
                    ImColor color = ImColor(105, 0,0,255);
                    if(state)
                        color = ImColor(105, 0,0,255);
                    else {
                        color = ImColor(255,0,0,255);
                    }
                    timerID += GetDeltaTime(NULL);
                    if ((timerID - 1.0f > 0)) {
                        state = !state;
                        timerID = 0.f;
                    }
                    Draw3dCapsule(pos, 0.1, 0.1, color);
                    getDrawList()->AddText(ImGui::GetFont(), 30,
                                           ImVec2(TargetPos.x - ImGui::CalcTextSize(bomb.c_str()).x / 2,TargetPos.y - ImGui::CalcTextSize(bomb.c_str()).y / 2),
                                           color,
                                           bomb.c_str());
                }
            }
        }
    }
    if (bombesp && bombManager/* != NULL && IsBombPlanted(bombManager)*/) {
        if (GetCamera(NULL)) {
            Vvector3 pos = GetBombPosition(bombManager);
            //LOGD("TESETE2");
            float distance = Vvector3::distance(GetPlayerLocation(myPlayer), pos);
            //LOGD("TESETE5");
            double time = GetBombTime(bombManager);
            //LOGD("TESETE3");
            Vvector3 world_screen = WorldToScreen(GetCamera(NULL), pos);
            //LOGD("TESETE4");
            if (world_screen.z < 1) {
                return;
            }
            //LOGD("TESETE6");
            float bomb_damage = 0.0f;
            if (distance < 30.f) {
                bomb_damage = (distance / 30.0f) * 1700;
            }
            //LOGD("TESETE7");
            std::string bomb = std::string("Bomb (" + std::to_string((int) distance) + "M / Time Left: " + std::to_string((int) time) + "s / Damage: " + std::to_string((int) bomb_damage) + ")");
            ImVec2 TargetPos = ImVec2(world_screen.x, screenHeight - world_screen.y);
            //LOGD("TESETE0");
            getDrawList()->AddText(ImGui::GetFont(), 15,
                                   TargetPos,
                                   ImColor((int)(espElementsColor.x * 255), (int)(espElementsColor.y * 255), (int)(espElementsColor.z * 255), (int)(espElementsColor.w * 255)),
                                   bomb.c_str(),
                                   nullptr,
                                   0.0f, nullptr);
        }
        //LOGD("TESETE");

    }

    entityList->fixPlayerList();

    if (esp) {
        if (!entityList->enemies->empty() && GetCamera(NULL)) {
            for (std::vector<enemy_t *>::iterator e = entityList->enemies->begin();
                 e < entityList->enemies->end(); e++) {
                void *player = (*e)->object;
                if (player) {
                    if ((*e)->health > 0 && (*e)->team != m_team) {
                        auto health = (int)((*e)->health);
                        auto team = (*e)->team;

                        auto vis = (*e)->isVisible;

                        auto pos = (*e)->pos;
                        auto playername = (*e)->name;
                        auto weapname = (*e)->weapon;

                        std::string name = "";
                        name = playername;
                        std::transform(name.begin(), name.end(), name.begin(), ::tolower);


                        auto checker1 = false;
                        auto checker2 = false;

                        auto w2sTop = world2screen_c(pos + Vvector3(0, 1.8, 0),checker1);
                        auto w2sBottom = world2screen_c(pos + Vvector3(0, 0, 0),checker2);

                        auto pmtXtop = w2sTop.x;
                        auto pmtXbottom = w2sBottom.x;

                        if (w2sTop.x > w2sBottom.x) {
                            pmtXtop = w2sBottom.x;
                            pmtXbottom = w2sTop.x;
                        }

                        auto ray = true;//rayPlayer(player);

                        ImColor color = vis ? espVisibleColor : espInvisibleColor;

                        auto healthL = (float) health;

                        const auto hayasaka = (clamp<float>(healthL, 25, 75) - 25.f) / 50.f;

                        auto hpcolor = ImColor(int(120 + 135 * (1 - hayasaka)), int(50.f + 175.f * hayasaka), int(80));

                        std::string wpn = "";
                        wpn = weapname;
                        std::transform(wpn.begin(), wpn.end(), wpn.begin(), ::tolower);

                        //auto wpn1 = FIELDFUNCTION(void*,player,0xB8);
                        //if (wpn1) {
                        //    auto wpn2 = FIELDFUNCTION(void*,wpn1,0xC);
                        //    if (wpn2) {
                        //        auto wpn3 = FIELDFUNCTION(monoString*,wpn2,0x14);
                        //        wpn = wpn3->get_string_old();
                        //        std::transform(wpn.begin(),wpn.end(),wpn.begin(), ::tolower);
                        //    }
                        //}

                        if (checker1 && checker2) {
                            if (espskeleton) {
                                auto cam = GetCamera(NULL);

                                if (cam && GetBones(player)) {
                                    ImVec2 PosHead = world2screen_v(GetPlayerHead(player));
                                    ImVec2 PosRightHand = world2screen_v(GetPlayerRightHand(player));
                                    ImVec2 PosLeftHand = world2screen_v(GetPlayerLeftHand(player));
                                    ImVec2 PosNeck = world2screen_v(GetPlayerNeck(player));
                                    ImVec2 PosHips = world2screen_v(GetPlayerHip(player));
                                    ImVec2 PosleftUpperArm = world2screen_v(GetPlayerleftUpperArm(player));
                                    ImVec2 leftLowerArm = world2screen_v(GetPlayerleftLowerArm(player));
                                    ImVec2 rightUpperArm = world2screen_v(GetPlayerrightUpperArm(player));
                                    ImVec2 rightLowerArm = world2screen_v(GetPlayerrightLowerArm(player));
                                    ImVec2 leftUpperLeg = world2screen_v(GetPlayerleftUpperLeg(player));
                                    ImVec2 leftLowerLeg = world2screen_v(GetPlayerleftLowerLeg(player));
                                    ImVec2 rightUpperLeg = world2screen_v(GetPlayerrightUpperLeg(player));
                                    ImVec2 rightLowerLeg = world2screen_v(GetPlayerrightLowerLeg(player));
                                    getDrawList()->AddLine(PosHead, PosNeck, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosNeck, PosHips, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosNeck, PosleftUpperArm, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosleftUpperArm, leftLowerArm, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(leftLowerArm, PosLeftHand, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosNeck, rightUpperArm, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(rightUpperArm, rightLowerArm, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(rightLowerArm, PosRightHand, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosHips, leftUpperLeg, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(leftUpperLeg, leftLowerLeg, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(PosHips, rightUpperLeg, ImColor(255, 255, 255, 255), 1);
                                    getDrawList()->AddLine(rightUpperLeg, rightLowerLeg, ImColor(255, 255, 255, 255), 1);
                                }
                           }


                            if (espline) {
                                ImGui::GetBackgroundDrawList()->AddLine(
                                        ImVec2(screenWidth / 2, screenHeight),
                                        ImVec2(w2sBottom.x, w2sBottom.y), ImColor(255, 255, 255), 2);
                            }
                            if (espbox) {
                                if (boxtype == 0) {

                                    Draw3DBox(pos + Vvector3(0, 0.9, 0), csizer / 2,
                                              (GetAimRotation(player).X + 45) * (180 / PI),
                                              Vvector3(bx - 0.1, by - 0.2, bz - 0.1),
                                              color, stroke, 1,
                                              1);
                                }
                                else {
                                    if (fillbox) {
                                        ImGui::GetBackgroundDrawList()->AddRectFilled(
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sTop.y),
                                                ImVec2(pmtXbottom +
                                                       abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sTop.y + rounded),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), !fillboxg ? (int)fillopacity : 10), rounded,
                                                ImDrawFlags_RoundCornersTop);
                                        ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sTop.y + rounded),
                                                ImVec2(pmtXbottom +
                                                       abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sBottom.y - rounded),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), !fillboxg ? (int)fillopacity : 10),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), !fillboxg ? (int)fillopacity : 10),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), (int)fillopacity),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), (int)fillopacity));
                                        ImGui::GetBackgroundDrawList()->AddRectFilled(
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sBottom.y - rounded),
                                                ImVec2(pmtXbottom +
                                                       abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sBottom.y),
                                                ImColor((int) (color.Value.x * 255),
                                                        (int) (color.Value.y * 255),
                                                        (int) (color.Value.z * 255), (int)fillopacity), rounded,
                                                ImDrawFlags_RoundCornersBottom);
                                    }

                                    if (true)
                                        ImGui::GetBackgroundDrawList()->AddRect(
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sTop.y),
                                                ImVec2(pmtXbottom +
                                                       abs((w2sTop.y - w2sBottom.y) / 4),
                                                       w2sBottom.y), ImColor(0, 0, 0), rounded, 0,
                                                stroke + 2);
                                    ImGui::GetBackgroundDrawList()->AddRect(
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4),
                                                   w2sTop.y),
                                            ImVec2(pmtXbottom + abs((w2sTop.y - w2sBottom.y) / 4),
                                                   w2sBottom.y), color, rounded, 0, stroke);
                                }
                            }
                            if (espnick) {
                                if (true) {
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sTop.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   name.c_str()).x / 22 * 18) /
                                                                                   2 - 1, w2sTop.y -
                                                                                    (ImGui::CalcTextSize(
                                                                                            name.c_str()).y / 22 * 18) -
                                                                                          1 - 3),
                                                                            ImColor(0, 0, 0),
                                                                            name.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sTop.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   name.c_str()).x / 22 * 18) /
                                                                                   2 + 1, w2sTop.y -
                                                                                    (ImGui::CalcTextSize(
                                                                                            name.c_str()).y / 22 * 18) -
                                                                                          1 - 3),
                                                                            ImColor(0, 0, 0),
                                                                            name.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sTop.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   name.c_str()).x / 22 * 18) /
                                                                                   2 - 1, w2sTop.y -
                                                                                    (ImGui::CalcTextSize(
                                                                                            name.c_str()).y / 22 * 18) +
                                                                                          1 - 3),
                                                                            ImColor(0, 0, 0),
                                                                            name.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sTop.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   name.c_str()).x / 22 * 18) /
                                                                                   2 + 1, w2sTop.y -
                                                                                    (ImGui::CalcTextSize(
                                                                                            name.c_str()).y / 22 * 18) +
                                                                                          1 - 3),
                                                                            ImColor(0, 0, 0),
                                                                            name.c_str());
                                }

                                ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                        18, ImVec2(w2sTop.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   name.c_str()).x / 22 * 18) /
                                                                                              2,
                                                                                              w2sTop.y -
                                                                                                      (ImGui::CalcTextSize(
                                                                                                              name.c_str()).y / 22 * 18) -
                                                                                              3),
                                                                        ImColor(255, 255, 255),
                                                                        name.c_str());
                            }
                            if (esphp) {
                                if (true)
                                    ImGui::GetBackgroundDrawList()->AddLine(
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                   (3 / 2) - 6, w2sBottom.y + 1),
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                   (3 / 2) - 6, w2sTop.y - 1),
                                            ImColor(0,
                                                                                                      0,
                                                                                                      0,
                                                                                                      220),
                                            2 + 2);
                                else
                                    ImGui::GetBackgroundDrawList()->AddLine(
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                   (3 / 2) - 6, w2sBottom.y),
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                   (3 / 2) - 6, w2sTop.y),
                                            ImColor(0,
                                                                                                      0,
                                                                                                      0,
                                                                                                      220),
                                            2);

                                ImGui::GetBackgroundDrawList()->AddLine(
                                        ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                               (3 / 2) - 6, w2sBottom.y),
                                        ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                               (3 / 2) - 6,
                                               lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f)),
                                        hpcolor, 2);

                                if (health < 100 && true) {
                                    if (true) {
                                        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),18,
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                       3 - 6 - 2 - (ImGui::CalcTextSize(
                                                               std::to_string(health).c_str()).x / 22 * 18) - 1,
                                                       lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f) -
                                                               (ImGui::CalcTextSize(
                                                                       std::to_string(health).c_str()).y / 22 * 18) / 2 -
                                                       1), ImColor(0, 0, 0),
                                                std::to_string(health).c_str());
                                        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),18,
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                       3 - 6 - 2 - (ImGui::CalcTextSize(
                                                               std::to_string(health).c_str()).x / 22 * 18) + 1,
                                                       lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f) -
                                                               (ImGui::CalcTextSize(
                                                                       std::to_string(health).c_str()).y / 22 * 18) / 2 -
                                                       1), ImColor(0, 0, 0),
                                                std::to_string(health).c_str());
                                        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),18,
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                       3 - 6 - 2 - (ImGui::CalcTextSize(
                                                               std::to_string(health).c_str()).x / 22 * 18) - 1,
                                                       lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f) -
                                                               (ImGui::CalcTextSize(
                                                                       std::to_string(health).c_str()).y / 22 * 18) / 2 +
                                                       1), ImColor(0, 0, 0),
                                                std::to_string(health).c_str());
                                        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),18,
                                                ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                       3 - 6 - 2 - (ImGui::CalcTextSize(
                                                               std::to_string(health).c_str()).x / 22 * 18) + 1,
                                                       lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f) -
                                                       (ImGui::CalcTextSize(
                                                               std::to_string(health).c_str()).y / 22 * 18) / 2 +
                                                       1), ImColor(0, 0, 0),
                                                std::to_string(health).c_str());
                                    }
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),18,
                                            ImVec2(pmtXtop - abs((w2sTop.y - w2sBottom.y) / 4) -
                                                   3 - 6 - 2 - (ImGui::CalcTextSize(
                                                           std::to_string(health).c_str()).x / 22 * 18),
                                                   lerp(w2sBottom.y, w2sTop.y, healthL / 100.0f) -
                                                   (ImGui::CalcTextSize(
                                                           std::to_string(health).c_str()).y / 22 * 18) / 2),
                                            hpcolor,
                                            std::to_string(health).c_str());
                                }
                            }
                            if (espweapon) {
                                if (true) {
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sBottom.x -
                                                                                   (ImGui::CalcTextSize(
                                                                                           wpn.c_str()).x / 22 * 18) /
                                                                                   2 - 1,
                                                                                   w2sBottom.y + 2 - 1),
                                                                            ImColor(0, 0, 0),
                                                                            wpn.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sBottom.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   wpn.c_str()).x / 22 * 18) /
                                                                                   2 + 1,
                                                                                   w2sBottom.y + 2 - 1),
                                                                            ImColor(0, 0, 0),
                                                                            wpn.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sBottom.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   wpn.c_str()).x / 22 * 18) /
                                                                                   2 - 1,
                                                                                   w2sBottom.y + 2 + 1),
                                                                            ImColor(0, 0, 0),
                                                                            wpn.c_str());
                                    ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                            18,
                                                                            ImVec2(w2sBottom.x -
                                                                                           (ImGui::CalcTextSize(
                                                                                                   wpn.c_str()).x / 22 * 18) /
                                                                                   2 + 1,
                                                                                   w2sBottom.y + 2 + 1),
                                                                            ImColor(0, 0, 0),
                                                                            wpn.c_str());
                                }

                                ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(),
                                                                        18,
                                                                        ImVec2(w2sBottom.x -
                                                                                       (ImGui::CalcTextSize(
                                                                                               wpn.c_str()).x / 22 * 18) / 2,
                                                                               w2sBottom.y + 2),
                                                                        ImColor(255, 255, 255),
                                                                        wpn.c_str());
                            }
                        }
                    }
                }
            }
        }
    }
    if (myPlayer && GetCameraMode(myPlayer) == 2 && camf && GetCamera2(NULL)) SetTransformPosition(GetTransform(GetCamera2(NULL)), GetPosition(GetTransform(myPlayer)) + Vvector3(0,1.8,0) + GetTransformForward(GetTransform(GetCamera2(NULL))) * -3);


    //ImGui::End();

    DrawMenu2();

    ImGui::EndFrame(); //End ImGui Frame
    ImGui::Render(); // Render ImGui

    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);

    ImGui_ImplAndroidGLES2_RenderDrawLists(ImGui::GetDrawData());
}


/*

bool (*old_nativeInjectEvent )(JNIEnv*, jobject ,jobject event);
bool hook_nativeInjectEvent(JNIEnv* env, jobject instance,jobject event){
    jclass tchcls = env->FindClass(ozObfuscate("android/view/MotionEvent"));
    if(!tchcls){
        LOGI("Can't find MotionEvent!");
    }

    jclass kycls = env->FindClass(ozObfuscate("android/view/KeyEvent"));
    if(!kycls){
        LOGI("Can't find KeyEvent!");
    }
    jmethodID ga = env->GetMethodID(kycls, ozObfuscate("getAction"),
                                    ozObfuscate("()I"));
    if(!ga){
        LOGI("Can't find KeyEvent.getAction!");
    }
    LOGD("Processing Touch Event! (not sure)");
    if(!env->IsInstanceOf(event, tchcls)){
        return old_nativeInjectEvent(env, instance, event);
    }
    LOGD("Processing Touch Event!");
    jmethodID id_getAct = env->GetMethodID(tchcls, ozObfuscate("getActionMasked"), ozObfuscate("()I"));
    jmethodID id_getX = env->GetMethodID(tchcls, ozObfuscate("getX"), ozObfuscate("()F"));
    jmethodID id_getY = env->GetMethodID(tchcls, ozObfuscate("getY"), ozObfuscate("()F"));
    jmethodID id_getPs = env->GetMethodID(tchcls, ozObfuscate("getPointerCount"), ozObfuscate("()I"));
    HandleInputEvent(env, env->CallIntMethod(event, id_getAct),env->CallFloatMethod(event, id_getX), env->CallFloatMethod(event, id_getY), env->CallIntMethod(event, id_getPs));
    if (!ImGui::GetIO().MouseDownOwnedUnlessPopupClose[0]){
        LOGD("A");
        return old_nativeInjectEvent(env, instance, event);
    }
    return false;
}*/


jboolean new_nativeInjectEvent(JNIEnv* env, jobject as, jobject event) {
    jclass tchcls = env->FindClass(ozObfuscate("android/view/MotionEvent"));
    if(!tchcls){
        //LOGI("Can't find MotionEvent!"); //на логах можно ; не ставить :)
    }

    jclass kycls = env->FindClass(ozObfuscate("android/view/KeyEvent"));
    if(!kycls){
        //LOGI("Can't find KeyEvent!");
    }
    jmethodID ga = env->GetMethodID(kycls, ozObfuscate("getAction"),
                                    ozObfuscate("()I"));
    if(!ga){
        //LOGI("Can't find KeyEvent.getAction!");
    }
    if(env->IsInstanceOf(event, kycls) && env->CallIntMethod(event, ga) == 0) {
        //LOGI("Keyboard");
        jmethodID gkc = env->GetMethodID(kycls, ozObfuscate("getKeyCode"), ozObfuscate("()I"));
        if(!gkc){
            //LOGI("Can't find KeyEvent.getKeyCode!");
        }
        jmethodID guc = env->GetMethodID(kycls, ozObfuscate("getUnicodeChar"), ozObfuscate("(I)I"));
        if(!guc){
            //LOGI("Can't find KeyEvent.getUnicodeChar!");
        }
        jmethodID gms = env->GetMethodID(kycls, ozObfuscate("getMetaState"), ozObfuscate("()I")); //I need it for ctrl, alt, etc.
        if(!gms){
           // LOGI("Can't find KeyEvent.getMetaState!");
        }
        int keyCode = env->CallIntMethod(event, gkc);
        ImGuiIO& io = ImGui::GetIO();
        switch (keyCode) {
            case 19:
                LOGI("Key Code: 19");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 20:
                LOGI("Key Code: 20");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 21:
                LOGI("Key Code: 21");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 22:
                LOGI("Key Code: 22");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 61:
                LOGI("Key Code: 61");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 66:
                LOGI("Key Code: Enter");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 67:
                LOGI("Key Code: Del");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 92:
                LOGI("Key Code: 92");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 93:
                LOGI("Key Code: 93");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 111:
                LOGI("Key Code: 111");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 112:
                LOGI("Key Code: 112");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 122:
                LOGI("Key Code: 122");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 123:
                LOGI("Key Code: 123");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            case 124:
                LOGI("Key Code: 124");
                ImGui::GetIO().AddInputCharacter(keyCode);
                break;
            default:
                LOGI("Key Code: Other");
                ImGui::GetIO().AddInputCharacter(env->CallIntMethod(event, guc, env->CallIntMethod(event, gms)));
                break;
        }
        return true;
    }
   // LOGD("Processing Touch Event! (not sure)");
    if(!env->IsInstanceOf(event, tchcls)){
        return true;
    }
   // LOGD("Processing Touch Event!");
    jmethodID id_getAct = env->GetMethodID(tchcls, ozObfuscate("getActionMasked"), ozObfuscate("()I"));
    jmethodID id_getX = env->GetMethodID(tchcls, ozObfuscate("getX"), ozObfuscate("()F"));
    jmethodID id_getY = env->GetMethodID(tchcls, ozObfuscate("getY"), ozObfuscate("()F"));
    jmethodID id_getPs = env->GetMethodID(tchcls, ozObfuscate("getPointerCount"), ozObfuscate("()I"));
    HandleInputEvent(env, env->CallIntMethod(event, id_getAct),env->CallFloatMethod(event, id_getX), env->CallFloatMethod(event, id_getY), env->CallIntMethod(event, id_getPs));
    if (!ImGui::GetIO().MouseDownOwnedUnlessPopupClose[0]){
        return true;
    }
    return false;
}


int32_t (*old_ANativeWindow_getWidth)(ANativeWindow* window);
int32_t new_ANativeWindow_getWidth(ANativeWindow* window){
    int32_t returnValue = old_ANativeWindow_getWidth(window);
    LOGI(ozObfuscate("Screen width: %d"), returnValue);
    screenWidth = returnValue;
    ImGui::GetIO().DisplaySize.x = screenWidth;
    return returnValue;
}

int32_t (*old_ANativeWindow_getHeight)(ANativeWindow* window);
int32_t new_ANativeWindow_getHeight(ANativeWindow* window) {
    int32_t returnValue = old_ANativeWindow_getHeight(window);
    LOGI(ozObfuscate("Screen height: %d"), returnValue);
    screenHeight = returnValue;
    ImGui::GetIO().DisplaySize.y = screenHeight;
    return returnValue;
}

void StartBackend(JNIEnv* env){
    LOGD("%s", std::string(ozObfuscate("Loading.. 10% ")).c_str());
    //Setup Start time
    startTime = currentTimeInMilliseconds();
    //Default Display Size
    screenWidth = atoi(ozObfuscate("2340"));
    screenHeight = atoi(ozObfuscate("1080"));

    //Setup
    //InitNewTheme();
    setupGraphics(screenWidth, screenHeight);

    ImGuiIO& io = ImGui::GetIO();

    io.Fonts->ClearFonts();

    ImGui::GetStyle().ScaleAllSizes(3);
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    font_cfg.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();

    io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 22.0f,&font_cfg);

    //код рендера в другом файле. если поместить его здесь то будет краш
    LOGI("test434343 1");
    //Display size
    DobbyHook((void*)ANativeWindow_getWidth, (void*)new_ANativeWindow_getWidth, (void **)&old_ANativeWindow_getWidth);
    LOGI("test434343 2");

    DobbyHook((void*)ANativeWindow_getHeight, (void*)new_ANativeWindow_getHeight, (void **)&old_ANativeWindow_getHeight);
    LOGI("test434343 3");

}

bool checkFileContains(const char *file, const char* content) {
    char line[512] = {0};
    FILE *fp = fopen(file, ozObfuscate("rt"));
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, content)) {
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}
std::string getClipboardText() {
    jobject object = getGlobalContext(gJNIEnv);
    std::string result;
    JNIEnv *env;
    gJavaVM->AttachCurrentThread(&env, 0);
    auto ContextClass = env->FindClass(ozObfuscate("android/content/Context"));
    auto getSystemServiceMethod = env->GetMethodID(ContextClass, ozObfuscate("getSystemService"), ozObfuscate("(Ljava/lang/String;)Ljava/lang/Object;"));
    auto str = env->NewStringUTF(ozObfuscate("clipboard"));
    auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
    env->DeleteLocalRef(str);
    auto ClipboardManagerClass = env->FindClass(ozObfuscate("android/content/ClipboardManager"));
    auto getText = env->GetMethodID(ClipboardManagerClass, ozObfuscate("getText"), ozObfuscate("()Ljava/lang/CharSequence;"));
    auto CharSequenceClass = env->FindClass(ozObfuscate("java/lang/CharSequence"));
    auto toStringMethod = env->GetMethodID(CharSequenceClass, ozObfuscate("toString"), ozObfuscate("()Ljava/lang/String;"));
    auto text = env->CallObjectMethod(clipboardManager, getText);
    if (text) {
        str = (jstring) env->CallObjectMethod(text, toStringMethod);
        result = env->GetStringUTFChars(str, 0);
        env->DeleteLocalRef(str);
        env->DeleteLocalRef(text);
    }
    env->DeleteLocalRef(CharSequenceClass);
    env->DeleteLocalRef(ClipboardManagerClass);
    env->DeleteLocalRef(clipboardManager);
    env->DeleteLocalRef(ContextClass);
    return result;
}
bool checkVPN() {
    JNIEnv *env;
    gJavaVM->AttachCurrentThread(&env, 0);
    jclass ctx = env->FindClass(ozObfuscate("android/content/Context"));
    jobject context = getGlobalContext(env);
    jmethodID service = env->GetMethodID(ctx, ozObfuscate("getSystemService"), ozObfuscate("(Ljava/lang/String;)Ljava/lang/Object;"));
    jstring str = env->NewStringUTF(ozObfuscate("connectivity"));
    jobject conn_service = env->CallObjectMethod(context, service, str);
    env->DeleteLocalRef(str);
    jclass connectivity = env->FindClass(ozObfuscate("android/net/ConnectivityManager"));
    jclass capabils = env->FindClass(ozObfuscate("android/net/NetworkCapabilities"));
    jmethodID has1 = env->GetMethodID(capabils, ozObfuscate("hasCapability"), ozObfuscate("(I)Z"));
    jmethodID has = env->GetMethodID(capabils, ozObfuscate("hasTransport"), ozObfuscate("(I)Z"));
    jmethodID getCapabil = env->GetMethodID(connectivity, ozObfuscate("getNetworkCapabilities"), ozObfuscate("(Landroid/net/Network;)Landroid/net/NetworkCapabilities;"));
    jmethodID getActive = env->GetMethodID(connectivity, ozObfuscate("getActiveNetwork"), ozObfuscate("()Landroid/net/Network;"));
    jobject activenetwork = env->CallObjectMethod(conn_service, getActive);
    jobject activecapabilities = env->CallObjectMethod(conn_service, getCapabil, activenetwork);
    jboolean hasvpn1 = env->CallBooleanMethod(activecapabilities, has, 4);
    jboolean hasvpn2 = env->CallBooleanMethod(activecapabilities, has1, 4);
    LOGD(ozObfuscate("Globals: %p %p"), hasvpn1, hasvpn2);
    if (hasvpn1 || hasvpn2) {
        env->DeleteLocalRef(activenetwork);
        env->DeleteLocalRef(activecapabilities);
        env->DeleteLocalRef(conn_service);
        env->DeleteLocalRef(ctx);
        env->DeleteLocalRef(context);
        env->DeleteLocalRef(capabils);
        env->DeleteLocalRef(connectivity);
        return true;
    } else {
        env->DeleteLocalRef(activenetwork);
        env->DeleteLocalRef(activecapabilities);
        env->DeleteLocalRef(conn_service);
        env->DeleteLocalRef(ctx);
        env->DeleteLocalRef(context);
        env->DeleteLocalRef(capabils);
        env->DeleteLocalRef(connectivity);
        return false;
    }
}
void setDialog(jobject ctx, JNIEnv *env, const char *title, const char *msg){
    jclass Alert = env->FindClass(ozObfuscate("android/app/AlertDialog$Builder"));
    jmethodID AlertCons = env->GetMethodID(Alert, ozObfuscate("<init>"), ozObfuscate("(Landroid/content/Context;)V"));
    jobject MainAlert = env->NewObject(Alert, AlertCons, ctx);
    jmethodID setTitle = env->GetMethodID(Alert, ozObfuscate("setTitle"), ozObfuscate("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setTitle, env->NewStringUTF(title));
    jmethodID setMsg = env->GetMethodID(Alert, ozObfuscate("setMessage"), ozObfuscate("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setMsg, env->NewStringUTF(msg));
    jmethodID setCa = env->GetMethodID(Alert, ozObfuscate("setCancelable"), ozObfuscate("(Z)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setCa, false);
    jmethodID setPB = env->GetMethodID(Alert, ozObfuscate("setPositiveButton"), ozObfuscate("(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setPB, env->NewStringUTF("Ok"), static_cast<jobject>(NULL));
    jmethodID create= env->GetMethodID(Alert, ozObfuscate("create"), ozObfuscate("()Landroid/app/AlertDialog;"));
    jobject creaetob = env->CallObjectMethod(MainAlert, create);
    jclass AlertN = env->FindClass(ozObfuscate("android/app/AlertDialog"));
    jmethodID show = env->GetMethodID(AlertN, ozObfuscate("show"), ozObfuscate("()V"));
    env->CallVoidMethod(creaetob, show);
}
void Toast(JNIEnv *env, jobject thiz, const char *text, int length) {
    jstring jstr = env->NewStringUTF(text);
    jclass toast = env->FindClass(ozObfuscate("android/widget/Toast"));
    jmethodID methodMakeText =env->GetStaticMethodID(toast,ozObfuscate("makeText"),ozObfuscate("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"));
    jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText,thiz, jstr, length);
    jmethodID methodShow = env->GetMethodID(toast, ozObfuscate("show"), ozObfuscate("()V"));
    env->CallVoidMethod(toastobj, methodShow);
}
////////////////////////////////////////////////////////
//authorization
////////////////////////////////////////////////////////
#include "hash/sha384.h"
#include "rapidjson/document.h"

using namespace rapidjson;
const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(ozObfuscate("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, ozObfuscate("MODEL"), ozObfuscate("Ljava/lang/String;"));

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}
const char *GetDevice(JNIEnv *env) {
    jclass buildClass = env->FindClass(ozObfuscate("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, ozObfuscate("DEVICE"), ozObfuscate("Ljava/lang/String;"));

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}
const char *GetDeviceBoard(JNIEnv *env) {
    jclass buildClass = env->FindClass(ozObfuscate("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, ozObfuscate("BOARD"), ozObfuscate("Ljava/lang/String;"));

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}
const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(ozObfuscate("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, ozObfuscate("BRAND"), ozObfuscate("Ljava/lang/String;"));

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}
const char *GetDeviceManufacturer(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, ozObfuscate("MANUFACTURER"), ozObfuscate("Ljava/lang/String;"));

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}
const char* GetAndroidID(JNIEnv* env, jobject context) {
    jclass contextClass = env->FindClass(ozObfuscate("android/content/Context"));
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, ozObfuscate("getContentResolver"), ozObfuscate("()Landroid/content/ContentResolver;"));
    jclass settingSecureClass = env->FindClass(ozObfuscate("android/provider/Settings$Secure"));
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, ozObfuscate("getString"), ozObfuscate("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(ozObfuscate("android_id")));
    return env->GetStringUTFChars(str, 0);
}



#define UNITY_CALLING_CONVENTION __fastcall*
void *g_unity_handle{ nullptr };
jboolean unload(JNIEnv *env, jclass clazz) {

    if (g_unity_handle != nullptr) {
        JavaVM* java_vm = nullptr;
        jint pc = env->GetJavaVM(&java_vm);
        if (pc < 0) {
            env->FatalError("Unable to retrieve Java VM");
        } else {
            void* m_pOnUnload = dlsym(g_unity_handle,"JNI_OnUnload");
            if (m_pOnUnload != nullptr) {
                reinterpret_cast<void(UNITY_CALLING_CONVENTION)(JavaVM*, void*)>(m_pOnUnload)(java_vm, nullptr);
            }
            dlclose(g_unity_handle);
        }
    }

    return JNI_TRUE;
}

std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, ("getBytes"), ("(Ljava/lang/String;)[B"));
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF(("UTF-8")));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

jboolean load(JNIEnv *env, jclass clazz, jstring native_library_dir) {
    if (g_unity_handle != nullptr) return JNI_FALSE;

    std::string libDir = jstring2string(env, native_library_dir);

    JavaVM *java_vm = nullptr;
    jint rc = env->GetJavaVM(&java_vm);
    if (rc < 0) {
        env->FatalError("Unable to retrieve Java VM");
        return JNI_FALSE;
    }

    g_unity_handle = dlopen((libDir + "/libunity.so").c_str(), 1);
    if (g_unity_handle == nullptr) {
        g_unity_handle = dlopen("libunity.so", 1);
        if (g_unity_handle == nullptr) {
            dlerror();
            env->FatalError("Unable to load library:");
            return JNI_FALSE;
        }
    }

    void *m_pOnLoad = dlsym(g_unity_handle, "JNI_OnLoad");
    if (m_pOnLoad != nullptr) {
        jint ret = reinterpret_cast<jint(UNITY_CALLING_CONVENTION)(JavaVM *, void *)>(m_pOnLoad)(
                java_vm, nullptr);
        if (ret < 0x10007) {
            //StartBackend(gJNIEnv);
            //LOGI(("test22"));
            //registerTouches(gJNIEnv);

            //InitMods();


            return JNI_TRUE;
        } else {
            env->FatalError("Unsupported VM version");
            return JNI_FALSE;
        }
    }

    return JNI_FALSE;
}

int registerTouches(JNIEnv* env) {
    JNINativeMethod methods[] = {
            {ozObfuscate("nativeTsomjer"), ozObfuscate("(Landroid/view/InputEvent;)Z"), reinterpret_cast<void *>(new_nativeInjectEvent)},
    };
    LOGD(ozObfuscate("JSEngine - %p"), methods);
    jclass unity = env->FindClass(ozObfuscate("com/unity3d/player/UnityPlayer"));
    if (!unity) {
        return JNI_ERR;
    }
    if (env->RegisterNatives(unity, methods, sizeof(methods) / sizeof(methods[0])) != 0) {
        return JNI_ERR;
    }
    //LOGD("registered");
    return JNI_OK;
    //LOGD("registered2");
}
jclass prcls;
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    LOGI(ozObfuscate("JNI_OnLoa d %p"), vm);
    gJavaVM = vm;
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);


    JNINativeMethod methods[] = {
            {"load", "(Ljava/lang/String;)Z", (void *)&load},
            {"unload", "()Z", (void *)&unload},
    };


    jclass clazz = globalEnv->FindClass("com/unity3d/player/NativeLoader");
    jint rc = globalEnv->RegisterNatives(clazz, methods, 2);
    if (rc < 0) {
        globalEnv->FatalError("com/unity3d/player/NativeLoader");
        return -1;
    }

    gJNIEnv = globalEnv;


    //auto addr = (uintptr_t)dlsym(RTLD_DEFAULT, "nativeInjectEvent");
    //LOGD("eglSwapBuffers address: 0x%X", addr);

    //DobbyHook((void*)getAbsoluteAddress("lib/arm/libunity.so", 0x26D814+1), (void*)hook_nativeInjectEvent, (void **)&old_nativeInjectEvent);
    //DobbyHook((void*)getAbsoluteAddress("lib/arm/libunity.so", 0x26D814), (void*)hook_nativeInjectEvent, (void **)&old_nativeInjectEvent);

    //0x26d825
    StartBackend(globalEnv);
    //registerTouches(globalEnv);

    //DobbyHook((void*)getAbsoluteAddress("lib/arm/libunity.so", 0x26d825), (void*)hook_nativeInjectEvent, (void **)&old_nativeInjectEvent);

    //registerTouches(globalEnv);
    pthread_t ptid;
    pthread_create(&ptid, NULL, dasdasd, NULL);

    //pthread_t ptid2;
    //pthread_create(&ptid2, NULL, dasdasd2, NULL);


    //token = getClipboardText();
    //LOGD(ozObfuscate("Clipboard text (key): %s"), token.c_str());
    //jclass loader = globalEnv->FindClass(ozObfuscate("com/unity3d/a"));
    //LOGD(ozObfuscate("A %p"), loader);
    //jfieldID ctx = globalEnv->GetStaticFieldID(loader, ozObfuscate("c"), ozObfuscate("Landroid/content/Context;"));
    //LOGD(ozObfuscate("B %p"), ctx);
    //jobject Context = globalEnv->GetStaticObjectField(loader, ctx);
    //LOGD(ozObfuscate("C = %p"), Context);
    //if (checkVPN()) {
    //    Toast(globalEnv, Context, ozObfuscate("VPN detected"), 1);
    //} else {
    //    if (strstr(token.c_str(), ozObfuscate("GRAPE_"))) {
    //        LOGD("Key found in clipboard");
    //        const char* model = GetDeviceModel(globalEnv);
    /*        const char* brand = GetDeviceBrand(globalEnv);
            const char* device = GetDevice(globalEnv);
            const char* board = GetDeviceBoard(globalEnv);
            const char* manufacturer = GetDeviceManufacturer(globalEnv);
            const char* hwid = GetAndroidID(globalEnv, Context);
            std::string separator = std::string(ozObfuscate("|"));
            std::string hardware;
            hardware += GetAndroidID(globalEnv, Context);
            hardware += separator;
            hardware += GetDeviceModel(globalEnv);
            hardware += separator;
            hardware += GetDeviceBoard(globalEnv);
            hardware += separator;
            hardware += GetDevice(globalEnv);
            hardware += separator;
            hardware += GetDeviceBrand(globalEnv);
            hardware += separator;
            hardware += GetDeviceManufacturer(globalEnv);
            LOGD(ozObfuscate("HWID: %s"), sha384(hardware).c_str());
            char data[8192];
            sprintf(data, ozObfuscate("http://taigaman.xyz/login.php?a=%s&b=%s&c=%s&d=%s"), token.c_str(), sha384(hardware).c_str(), sha384(token).c_str(), sha384(sha384(hardware)).c_str());

            LOGD(ozObfuscate("data: %s"), data);
            http::Request request{data};
            const auto response = request.send(std::string(ozObfuscate("GET")));
            LOGD("request!");
            int code = response.status.code;
            LOGD("request3!");
            std::string answer = {response.body.begin(), response.body.end()};
            LOGD("request2!");
            LOGD(ozObfuscate("Server answer code: %d"), code);
            Document document;
            document.Parse(answer.c_str());
            const char* error_message = document["a"].GetString();
            const char* error_hash = document["b"].GetString();
            const char* clienthash = sha384(std::string(error_message)).c_str();
            LOGD("Error message: %s", error_message);
            if (!strstr(error_hash, clienthash)) {
                Toast(globalEnv, Context, ozObfuscate("Server error #1"), 1);
            } else {
                if (strstr(error_message, ozObfuscate("ServerError"))) {
                    Toast(globalEnv, Context, ozObfuscate("Server error #2"), 1);
                } else if (strstr(error_message, ozObfuscate("InvalidHWID"))) {
                    Toast(globalEnv, Context, ozObfuscate("HWID error"), 1);
                } else if (strstr(error_message, ozObfuscate("InvalidKey"))) {
                    std::string msg = std::string(ozObfuscate("Key is invalid. This may be because key time is expired. Clipboard data - ")) + token;
                    Toast(globalEnv, Context, ozObfuscate("Invalid Key"), 1);
                } else if (strstr(error_message, ozObfuscate("Expired"))) {
                    Toast(globalEnv, Context, ozObfuscate("Expired Key"), 1);
                } else if (strstr(error_message, ozObfuscate("True"))) {
                    LOGD("ааааааааааааа ААААААААААААА УРА НАХУЙ Й");
                    for (int i = 0; i != 5; i++) {
                        Toast(globalEnv, Context, ozObfuscate("Authorized successfully"), 0);
                    }*/



    //Toast(globalEnv, Context, ozObfuscate("Syncronized successfully!"), 1);
                //} else {
                //    LOGD("ЗАЛУПА ПИЗДА Я ЕБАЛ ВРОТ НАХУЙ");
                //    std::string msg = std::string(ozObfuscate("Responce is invalid. Error code - ")) + std::to_string(code);
               //     Toast(globalEnv, Context, ozObfuscate("Server error"), 1);
                //}
            //}
        //} else {
        //    LOGD("ЗАЛУПА КОНСКАЯ");
        //    std::string bs = std::string(std::string(ozObfuscate("Error! String in clipboard isnt key. String in clipboard - ")) + token);
        //    Toast(globalEnv, Context, ozObfuscate("Key not found in clipboard, copy key"), 1);
        //}
    //}
    return JNI_VERSION_1_6;
}