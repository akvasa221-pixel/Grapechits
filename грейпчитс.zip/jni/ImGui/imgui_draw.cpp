// dear imgui, v1.85
// (drawing and font code)

/*

Index of this file:

// [SECTION] STB libraries implementation
// [SECTION] Style functions
// [SECTION] ImDrawList
// [SECTION] ImDrawListSplitter
// [SECTION] ImDrawData
// [SECTION] Helpers ShadeVertsXXX functions
// [SECTION] ImFontConfig
// [SECTION] ImFontAtlas
// [SECTION] ImFontAtlas glyph ranges helpers
// [SECTION] ImFontGlyphRangesBuilder
// [SECTION] ImFont
// [SECTION] ImGui Internal Render Helpers
// [SECTION] Decompression code
// [SECTION] Default font data (ProggyClean.ttf)

*/

#if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "imgui.h"
#ifndef IMGUI_DISABLE

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#pragma  once
#include "imgui_internal.h"
#ifdef IMGUI_ENABLE_FREETYPE
#include "misc/freetype/imgui_freetype.h"
#endif

#include <stdio.h>      // vsnprintf, sscanf, printf
#if !defined(alloca)
#if defined(__GLIBC__) || defined(__sun) || defined(__APPLE__) || defined(__NEWLIB__)
#include <alloca.h>     // alloca (glibc uses <alloca.h>. Note that Cygwin may have _WIN32 defined, so the order matters here)
#elif defined(_WIN32)
#include <malloc.h>     // alloca
#if !defined(alloca)
#define alloca _alloca  // for clang with MS Codegen
#endif
#else
#include <stdlib.h>     // alloca
#endif
#endif

// Visual Studio warnings
#ifdef _MSC_VER
#pragma warning (disable: 4127)     // condition expression is constant
#pragma warning (disable: 4505)     // unreferenced local function has been removed (stb stuff)
#pragma warning (disable: 4996)     // 'This function or variable may be unsafe': strcpy, strdup, sprintf, vsnprintf, sscanf, fopen
#pragma warning (disable: 6255)     // [Static Analyzer] _alloca indicates failure by raising a stack overflow exception.  Consider using _malloca instead.
#pragma warning (disable: 26451)    // [Static Analyzer] Arithmetic overflow : Using operator 'xxx' on a 4 byte value and then casting the result to a 8 byte value. Cast the value to the wider type before calling operator 'xxx' to avoid overflow(io.2).
#pragma warning (disable: 26812)    // [Static Analyzer] The enum type 'xxx' is unscoped. Prefer 'enum class' over 'enum' (Enum.3). [MSVC Static Analyzer)
#endif

// Clang/GCC warnings with -Weverything
#if defined(__clang__)
#if __has_warning("-Wunknown-warning-option")
#pragma clang diagnostic ignored "-Wunknown-warning-option"         // warning: unknown warning group 'xxx'                      // not all warnings are known by all Clang versions and they tend to be rename-happy.. so ignoring warnings triggers new warnings on some configuration. Great!
#endif
#if __has_warning("-Walloca")
#pragma clang diagnostic ignored "-Walloca"                         // warning: use of function '__builtin_alloca' is discouraged
#endif
#pragma clang diagnostic ignored "-Wunknown-pragmas"                // warning: unknown warning group 'xxx'
#pragma clang diagnostic ignored "-Wold-style-cast"                 // warning: use of old-style cast                            // yes, they are more terse.
#pragma clang diagnostic ignored "-Wfloat-equal"                    // warning: comparing floating point with == or != is unsafe // storing and comparing against same constants ok.
#pragma clang diagnostic ignored "-Wglobal-constructors"            // warning: declaration requires a global destructor         // similar to above, not sure what the exact difference is.
#pragma clang diagnostic ignored "-Wsign-conversion"                // warning: implicit conversion changes signedness
#pragma clang diagnostic ignored "-Wzero-as-null-pointer-constant"  // warning: zero as null pointer constant                    // some standard header variations use #define nullptr 0
#pragma clang diagnostic ignored "-Wcomma"                          // warning: possible misuse of comma operator here
#pragma clang diagnostic ignored "-Wreserved-id-macro"              // warning: macro name is a reserved identifier
#pragma clang diagnostic ignored "-Wdouble-promotion"               // warning: implicit conversion from 'float' to 'double' when passing argument to function  // using printf() is a misery with this as C++ va_arg ellipsis changes float to double.
#pragma clang diagnostic ignored "-Wimplicit-int-float-conversion"  // warning: implicit conversion from 'xxx' to 'float' may lose precision
#elif defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wpragmas"                  // warning: unknown option after '#pragma GCC diagnostic' kind
#pragma GCC diagnostic ignored "-Wunused-function"          // warning: 'xxxx' defined but not used
#pragma GCC diagnostic ignored "-Wdouble-promotion"         // warning: implicit conversion from 'float' to 'double' when passing argument to function
#pragma GCC diagnostic ignored "-Wconversion"               // warning: conversion to 'xxxx' from 'xxxx' may alter its value
#pragma GCC diagnostic ignored "-Wstack-protector"          // warning: stack protector not protecting local variables: variable length buffer
#pragma GCC diagnostic ignored "-Wclass-memaccess"          // [__GNUC__ >= 8] warning: 'memset/memcpy' clearing/writing an object of type 'xxxx' with no trivial copy-assignment; use assignment or value-initialization instead
#endif

//-------------------------------------------------------------------------
// [SECTION] STB libraries implementation
//-------------------------------------------------------------------------

// Compile time options:
//#define IMGUI_STB_NAMESPACE           ImStb
//#define IMGUI_STB_TRUETYPE_FILENAME   "my_folder/stb_truetype.h"
//#define IMGUI_STB_RECT_PACK_FILENAME  "my_folder/stb_rect_pack.h"
//#define IMGUI_DISABLE_STB_TRUETYPE_IMPLEMENTATION
//#define IMGUI_DISABLE_STB_RECT_PACK_IMPLEMENTATION

#ifdef IMGUI_STB_NAMESPACE
namespace IMGUI_STB_NAMESPACE
{
#endif

#ifdef _MSC_VER
#pragma warning (push)
#pragma warning (disable: 4456)                             // declaration of 'xx' hides previous local declaration
#pragma warning (disable: 6011)                             // (stb_rectpack) Dereferencing nullptr pointer 'cur->next'.
#pragma warning (disable: 6385)                             // (stb_truetype) Reading invalid data from 'buffer':  the readable size is '_Old_3`kernel_width' bytes, but '3' bytes may be read.
#pragma warning (disable: 28182)                            // (stb_rectpack) Dereferencing nullptr pointer. 'cur' contains the same nullptr value as 'cur->next' did.
#endif

#if defined(__clang__)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-function"
#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wimplicit-fallthrough"
#pragma clang diagnostic ignored "-Wcast-qual"              // warning: cast from 'const xxxx *' to 'xxx *' drops const qualifier
#endif

#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wtype-limits"              // warning: comparison is always true due to limited range of data type [-Wtype-limits]
#pragma GCC diagnostic ignored "-Wcast-qual"                // warning: cast from type 'const xxxx *' to type 'xxxx *' casts away qualifiers
#endif

#ifndef STB_RECT_PACK_IMPLEMENTATION                        // in case the user already have an implementation in the _same_ compilation unit (e.g. unity builds)
#ifndef IMGUI_DISABLE_STB_RECT_PACK_IMPLEMENTATION          // in case the user already have an implementation in another compilation unit
#define STBRP_STATIC
#define STBRP_ASSERT(x)     do { IM_ASSERT(x); } while (0)
#define STBRP_SORT          ImQsort
#define STB_RECT_PACK_IMPLEMENTATION
#endif
#ifdef IMGUI_STB_RECT_PACK_FILENAME
#include IMGUI_STB_RECT_PACK_FILENAME
#else
#include "imstb_rectpack.h"
#endif
#endif

#ifdef  IMGUI_ENABLE_STB_TRUETYPE
#ifndef STB_TRUETYPE_IMPLEMENTATION                         // in case the user already have an implementation in the _same_ compilation unit (e.g. unity builds)
#ifndef IMGUI_DISABLE_STB_TRUETYPE_IMPLEMENTATION           // in case the user already have an implementation in another compilation unit
#define STBTT_malloc(x,u)   ((void)(u), IM_ALLOC(x))
#define STBTT_free(x,u)     ((void)(u), IM_FREE(x))
#define STBTT_assert(x)     do { IM_ASSERT(x); } while(0)
#define STBTT_fmod(x,y)     ImFmod(x,y)
#define STBTT_sqrt(x)       ImSqrt(x)
#define STBTT_pow(x,y)      ImPow(x,y)
#define STBTT_fabs(x)       ImFabs(x)
#define STBTT_ifloor(x)     ((int)ImFloorSigned(x))
#define STBTT_iceil(x)      ((int)ImCeil(x))
#define STBTT_STATIC
#define STB_TRUETYPE_IMPLEMENTATION
#else
#define STBTT_DEF extern
#endif
#ifdef IMGUI_STB_TRUETYPE_FILENAME
#include IMGUI_STB_TRUETYPE_FILENAME
#else
#include "imstb_truetype.h"
#endif
#endif
#endif // IMGUI_ENABLE_STB_TRUETYPE

#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

#if defined(__clang__)
#pragma clang diagnostic pop
#endif

#if defined(_MSC_VER)
#pragma warning (pop)
#endif

#ifdef IMGUI_STB_NAMESPACE
} // namespace ImStb
using namespace IMGUI_STB_NAMESPACE;
#endif

//-----------------------------------------------------------------------------
// [SECTION] Style functions
//-----------------------------------------------------------------------------

void ImGui::StyleColorsDark(ImGuiStyle* dst)
{
    ImGuiStyle* style = dst ? dst : &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    colors[ImGuiCol_Text]                   = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.00f, 0.00f, 0.00f, 0.90f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
    colors[ImGuiCol_Border]                 = ImVec4(0.43f, 0.43f, 0.50f, 0.50f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 1.0f);
    colors[ImGuiCol_FrameBg]                = ImVec4(0.16f, 0.29f, 0.48f, 0.54f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(75/255, 0.0f, 130/255, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.0f, 0.0f, 0.98f, 1.00f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.24f, 0.52f, 0.88f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_Button]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.06f, 0.53f, 0.98f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.31f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 0.80f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_Separator]              = colors[ImGuiCol_Border];
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.10f, 0.40f, 0.75f, 0.78f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.10f, 0.40f, 0.75f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(0.26f, 0.59f, 0.98f, 0.20f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    colors[ImGuiCol_Tab]                    = ImLerp(colors[ImGuiCol_Header],       colors[ImGuiCol_TitleBgActive], 0.80f);
    colors[ImGuiCol_TabHovered]             = colors[ImGuiCol_HeaderHovered];
    colors[ImGuiCol_TabActive]              = ImLerp(colors[ImGuiCol_HeaderActive], colors[ImGuiCol_TitleBgActive], 0.60f);
    colors[ImGuiCol_TabUnfocused]           = ImLerp(colors[ImGuiCol_Tab],          colors[ImGuiCol_TitleBg], 0.80f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImLerp(colors[ImGuiCol_TabActive],    colors[ImGuiCol_TitleBg], 0.40f);
    colors[ImGuiCol_PlotLines]              = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.19f, 0.19f, 0.20f, 1.00f);
    colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.31f, 0.31f, 0.35f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableBorderLight]       = ImVec4(0.23f, 0.23f, 0.25f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_TableRowBgAlt]          = ImVec4(1.00f, 1.00f, 1.00f, 0.06f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
    colors[ImGuiCol_NavHighlight]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
}

void ImGui::StyleColorsClassic(ImGuiStyle* dst)
{
    ImGuiStyle* style = dst ? dst : &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    colors[ImGuiCol_Text]                   = ImVec4(0.90f, 0.90f, 0.90f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.00f, 0.00f, 0.00f, 0.85f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.11f, 0.11f, 0.14f, 0.92f);
    colors[ImGuiCol_Border]                 = ImVec4(0.50f, 0.50f, 0.50f, 0.50f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg]                = ImVec4(0.43f, 0.43f, 0.43f, 0.39f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.47f, 0.47f, 0.69f, 0.40f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.42f, 0.41f, 0.64f, 0.69f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.27f, 0.27f, 0.54f, 0.83f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0.32f, 0.32f, 0.63f, 0.87f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.40f, 0.40f, 0.80f, 0.20f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.40f, 0.40f, 0.55f, 0.80f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.20f, 0.25f, 0.30f, 0.60f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.40f, 0.40f, 0.80f, 0.30f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.40f, 0.40f, 0.80f, 0.40f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.41f, 0.39f, 0.80f, 0.60f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.0f, 0.0f, 1.0f, 1.0f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(1.00f, 1.00f, 1.00f, 0.30f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.41f, 0.39f, 0.80f, 0.60f);
    colors[ImGuiCol_Button]                 = ImVec4(0.35f, 0.40f, 0.61f, 0.62f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.40f, 0.48f, 0.71f, 0.79f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.46f, 0.54f, 0.80f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0.40f, 0.40f, 0.90f, 0.45f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.45f, 0.45f, 0.90f, 0.80f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.53f, 0.53f, 0.87f, 0.80f);
    colors[ImGuiCol_Separator]              = ImVec4(0.50f, 0.50f, 0.50f, 0.60f);
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.60f, 0.60f, 0.70f, 1.00f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.70f, 0.70f, 0.90f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(1.00f, 1.00f, 1.00f, 0.10f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.78f, 0.82f, 1.00f, 0.60f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.78f, 0.82f, 1.00f, 0.90f);
    colors[ImGuiCol_Tab]                    = ImLerp(colors[ImGuiCol_Header],       colors[ImGuiCol_TitleBgActive], 0.80f);
    colors[ImGuiCol_TabHovered]             = colors[ImGuiCol_HeaderHovered];
    colors[ImGuiCol_TabActive]              = ImLerp(colors[ImGuiCol_HeaderActive], colors[ImGuiCol_TitleBgActive], 0.60f);
    colors[ImGuiCol_TabUnfocused]           = ImLerp(colors[ImGuiCol_Tab],          colors[ImGuiCol_TitleBg], 0.80f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImLerp(colors[ImGuiCol_TabActive],    colors[ImGuiCol_TitleBg], 0.40f);
    colors[ImGuiCol_PlotLines]              = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.27f, 0.27f, 0.38f, 1.00f);
    colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.31f, 0.31f, 0.45f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableBorderLight]       = ImVec4(0.26f, 0.26f, 0.28f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_TableRowBgAlt]          = ImVec4(1.00f, 1.00f, 1.00f, 0.07f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.00f, 0.00f, 1.00f, 0.35f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
    colors[ImGuiCol_NavHighlight]           = colors[ImGuiCol_HeaderHovered];
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.20f, 0.20f, 0.20f, 0.35f);
}

// Those light colors are better suited with a thicker font than the default one + FrameBorder
void ImGui::StyleColorsLight(ImGuiStyle* dst)
{
    ImGuiStyle* style = dst ? dst : &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    colors[ImGuiCol_Text]                   = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.94f, 0.94f, 0.94f, 1.00f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(1.00f, 1.00f, 1.00f, 0.98f);
    colors[ImGuiCol_Border]                 = ImVec4(0.00f, 0.00f, 0.00f, 0.30f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg]                = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.96f, 0.96f, 0.96f, 1.00f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0.82f, 0.82f, 0.82f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(1.00f, 1.00f, 1.00f, 0.51f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.86f, 0.86f, 0.86f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.98f, 0.98f, 0.98f, 0.53f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.69f, 0.69f, 0.69f, 0.80f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.49f, 0.49f, 0.49f, 0.80f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.49f, 0.49f, 0.49f, 1.00f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.26f, 0.59f, 0.98f, 0.78f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.46f, 0.54f, 0.80f, 0.60f);
    colors[ImGuiCol_Button]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.06f, 0.53f, 0.98f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.31f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 0.80f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_Separator]              = ImVec4(0.39f, 0.39f, 0.39f, 0.62f);
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.14f, 0.44f, 0.80f, 0.78f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.14f, 0.44f, 0.80f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(0.35f, 0.35f, 0.35f, 0.17f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    colors[ImGuiCol_Tab]                    = ImLerp(colors[ImGuiCol_Header],       colors[ImGuiCol_TitleBgActive], 0.90f);
    colors[ImGuiCol_TabHovered]             = colors[ImGuiCol_HeaderHovered];
    colors[ImGuiCol_TabActive]              = ImLerp(colors[ImGuiCol_HeaderActive], colors[ImGuiCol_TitleBgActive], 0.60f);
    colors[ImGuiCol_TabUnfocused]           = ImLerp(colors[ImGuiCol_Tab],          colors[ImGuiCol_TitleBg], 0.80f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImLerp(colors[ImGuiCol_TabActive],    colors[ImGuiCol_TitleBg], 0.40f);
    colors[ImGuiCol_PlotLines]              = ImVec4(0.39f, 0.39f, 0.39f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.45f, 0.00f, 1.00f);
    colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.78f, 0.87f, 0.98f, 1.00f);
    colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.57f, 0.57f, 0.64f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableBorderLight]       = ImVec4(0.68f, 0.68f, 0.74f, 1.00f);   // Prefer using Alpha=1.0 here
    colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_TableRowBgAlt]          = ImVec4(0.30f, 0.30f, 0.30f, 0.09f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    colors[ImGuiCol_NavHighlight]           = colors[ImGuiCol_HeaderHovered];
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(0.70f, 0.70f, 0.70f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.20f, 0.20f, 0.20f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.20f, 0.20f, 0.20f, 0.35f);
}

//-----------------------------------------------------------------------------
// [SECTION] ImDrawList
//-----------------------------------------------------------------------------

ImDrawListSharedData::ImDrawListSharedData()
{
    memset(this, 0, sizeof(*this));
    for (int i = 0; i < IM_ARRAYSIZE(ArcFastVtx); i++)
    {
        const float a = ((float)i * 2 * IM_PI) / (float)IM_ARRAYSIZE(ArcFastVtx);
        ArcFastVtx[i] = ImVec2(ImCos(a), ImSin(a));
    }
    ArcFastRadiusCutoff = IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_CALC_R(IM_DRAWLIST_ARCFAST_SAMPLE_MAX, CircleSegmentMaxError);
}

void ImDrawListSharedData::SetCircleTessellationMaxError(float max_error)
{
    if (CircleSegmentMaxError == max_error)
        return;

    IM_ASSERT(max_error > 0.0f);
    CircleSegmentMaxError = max_error;
    for (int i = 0; i < IM_ARRAYSIZE(CircleSegmentCounts); i++)
    {
        const float radius = (float)i;
        CircleSegmentCounts[i] = (ImU8)((i > 0) ? IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_CALC(radius, CircleSegmentMaxError) : 0);
    }
    ArcFastRadiusCutoff = IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_CALC_R(IM_DRAWLIST_ARCFAST_SAMPLE_MAX, CircleSegmentMaxError);
}

// Initialize before use in a new frame. We always have a command ready in the buffer.
void ImDrawList::_ResetForNewFrame()
{
    // Verify that the ImDrawCmd fields we want to memcmp() are contiguous in memory.
    // (those should be IM_STATIC_ASSERT() in theory but with our pre C++11 setup the whole check doesn't compile with GCC)
    IM_ASSERT(IM_OFFSETOF(ImDrawCmd, ClipRect) == 0);
    IM_ASSERT(IM_OFFSETOF(ImDrawCmd, TextureId) == sizeof(ImVec4));
    IM_ASSERT(IM_OFFSETOF(ImDrawCmd, VtxOffset) == sizeof(ImVec4) + sizeof(ImTextureID));

    CmdBuffer.resize(0);
    IdxBuffer.resize(0);
    VtxBuffer.resize(0);
    Flags = _Data->InitialFlags;
    memset(&_CmdHeader, 0, sizeof(_CmdHeader));
    _VtxCurrentIdx = 0;
    _VtxWritePtr = nullptr;
    _IdxWritePtr = nullptr;
    _ClipRectStack.resize(0);
    _TextureIdStack.resize(0);
    _Path.resize(0);
    _Splitter.Clear();
    CmdBuffer.push_back(ImDrawCmd());
    _FringeScale = 1.0f;
}

void ImDrawList::_ClearFreeMemory()
{
    CmdBuffer.clear();
    IdxBuffer.clear();
    VtxBuffer.clear();
    Flags = ImDrawListFlags_None;
    _VtxCurrentIdx = 0;
    _VtxWritePtr = nullptr;
    _IdxWritePtr = nullptr;
    _ClipRectStack.clear();
    _TextureIdStack.clear();
    _Path.clear();
    _Splitter.ClearFreeMemory();
}

ImDrawList* ImDrawList::CloneOutput() const
{
    ImDrawList* dst = IM_NEW(ImDrawList(_Data));
    dst->CmdBuffer = CmdBuffer;
    dst->IdxBuffer = IdxBuffer;
    dst->VtxBuffer = VtxBuffer;
    dst->Flags = Flags;
    return dst;
}

void ImDrawList::AddDrawCmd()
{
    ImDrawCmd draw_cmd;
    draw_cmd.ClipRect = _CmdHeader.ClipRect;    // Same as calling ImDrawCmd_HeaderCopy()
    draw_cmd.TextureId = _CmdHeader.TextureId;
    draw_cmd.VtxOffset = _CmdHeader.VtxOffset;
    draw_cmd.IdxOffset = IdxBuffer.Size;

    IM_ASSERT(draw_cmd.ClipRect.x <= draw_cmd.ClipRect.z && draw_cmd.ClipRect.y <= draw_cmd.ClipRect.w);
    CmdBuffer.push_back(draw_cmd);
}

// Pop trailing draw command (used before merging or presenting to user)
// Note that this leaves the ImDrawList in a state unfit for further commands, as most code assume that CmdBuffer.Size > 0 && CmdBuffer.back().UserCallback == nullptr
void ImDrawList::_PopUnusedDrawCmd()
{
    if (CmdBuffer.Size == 0)
        return;
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    if (curr_cmd->ElemCount == 0 && curr_cmd->UserCallback == nullptr)
        CmdBuffer.pop_back();
}

void ImDrawList::AddCallback(ImDrawCallback callback, void* callback_data)
{
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    IM_ASSERT(curr_cmd->UserCallback == nullptr);
    if (curr_cmd->ElemCount != 0)
    {
        AddDrawCmd();
        curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    }
    curr_cmd->UserCallback = callback;
    curr_cmd->UserCallbackData = callback_data;

    AddDrawCmd(); // Force a new command after us (see comment below)
}

// Compare ClipRect, TextureId and VtxOffset with a single memcmp()
#define ImDrawCmd_HeaderSize                        (IM_OFFSETOF(ImDrawCmd, VtxOffset) + sizeof(unsigned int))
#define ImDrawCmd_HeaderCompare(CMD_LHS, CMD_RHS)   (memcmp(CMD_LHS, CMD_RHS, ImDrawCmd_HeaderSize))    // Compare ClipRect, TextureId, VtxOffset
#define ImDrawCmd_HeaderCopy(CMD_DST, CMD_SRC)      (memcpy(CMD_DST, CMD_SRC, ImDrawCmd_HeaderSize))    // Copy ClipRect, TextureId, VtxOffset

// Try to merge two last draw commands
void ImDrawList::_TryMergeDrawCmds()
{
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    ImDrawCmd* prev_cmd = curr_cmd - 1;
    if (ImDrawCmd_HeaderCompare(curr_cmd, prev_cmd) == 0 && curr_cmd->UserCallback == nullptr && prev_cmd->UserCallback == nullptr)
    {
        prev_cmd->ElemCount += curr_cmd->ElemCount;
        CmdBuffer.pop_back();
    }
}

// Our scheme may appears a bit unusual, basically we want the most-common calls AddLine AddRect etc. to not have to perform any check so we always have a command ready in the stack.
// The cost of figuring out if a new command has to be added or if we can merge is paid in those Update** functions only.
void ImDrawList::_OnChangedClipRect()
{
    // If current command is used with different settings we need to add a new command
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    if (curr_cmd->ElemCount != 0 && memcmp(&curr_cmd->ClipRect, &_CmdHeader.ClipRect, sizeof(ImVec4)) != 0)
    {
        AddDrawCmd();
        return;
    }
    IM_ASSERT(curr_cmd->UserCallback == nullptr);

    // Try to merge with previous command if it matches, else use current command
    ImDrawCmd* prev_cmd = curr_cmd - 1;
    if (curr_cmd->ElemCount == 0 && CmdBuffer.Size > 1 && ImDrawCmd_HeaderCompare(&_CmdHeader, prev_cmd) == 0 && prev_cmd->UserCallback == nullptr)
    {
        CmdBuffer.pop_back();
        return;
    }

    curr_cmd->ClipRect = _CmdHeader.ClipRect;
}

void ImDrawList::_OnChangedTextureID()
{
    // If current command is used with different settings we need to add a new command
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    if (curr_cmd->ElemCount != 0 && curr_cmd->TextureId != _CmdHeader.TextureId)
    {
        AddDrawCmd();
        return;
    }
    IM_ASSERT(curr_cmd->UserCallback == nullptr);

    // Try to merge with previous command if it matches, else use current command
    ImDrawCmd* prev_cmd = curr_cmd - 1;
    if (curr_cmd->ElemCount == 0 && CmdBuffer.Size > 1 && ImDrawCmd_HeaderCompare(&_CmdHeader, prev_cmd) == 0 && prev_cmd->UserCallback == nullptr)
    {
        CmdBuffer.pop_back();
        return;
    }

    curr_cmd->TextureId = _CmdHeader.TextureId;
}

void ImDrawList::_OnChangedVtxOffset()
{
    // We don't need to compare curr_cmd->VtxOffset != _CmdHeader.VtxOffset because we know it'll be different at the time we call this.
    _VtxCurrentIdx = 0;
    ImDrawCmd* curr_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    //IM_ASSERT(curr_cmd->VtxOffset != _CmdHeader.VtxOffset); // See #3349
    if (curr_cmd->ElemCount != 0)
    {
        AddDrawCmd();
        return;
    }
    IM_ASSERT(curr_cmd->UserCallback == nullptr);
    curr_cmd->VtxOffset = _CmdHeader.VtxOffset;
}

int ImDrawList::_CalcCircleAutoSegmentCount(float radius) const
{
    // Automatic segment count
    const int radius_idx = (int)(radius + 0.999999f); // ceil to never reduce accuracy
    if (radius_idx < IM_ARRAYSIZE(_Data->CircleSegmentCounts))
        return _Data->CircleSegmentCounts[radius_idx]; // Use cached value
    else
        return IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_CALC(radius, _Data->CircleSegmentMaxError);
}

// Render-level scissoring. This is passed down to your render function but not used for CPU-side coarse clipping. Prefer using higher-level ImGui::PushClipRect() to affect logic (hit-testing and widget culling)
void ImDrawList::PushClipRect(ImVec2 cr_min, ImVec2 cr_max, bool intersect_with_current_clip_rect)
{
    ImVec4 cr(cr_min.x, cr_min.y, cr_max.x, cr_max.y);
    if (intersect_with_current_clip_rect)
    {
        ImVec4 current = _CmdHeader.ClipRect;
        if (cr.x < current.x) cr.x = current.x;
        if (cr.y < current.y) cr.y = current.y;
        if (cr.z > current.z) cr.z = current.z;
        if (cr.w > current.w) cr.w = current.w;
    }
    cr.z = ImMax(cr.x, cr.z);
    cr.w = ImMax(cr.y, cr.w);

    _ClipRectStack.push_back(cr);
    _CmdHeader.ClipRect = cr;
    _OnChangedClipRect();
}

void ImDrawList::PushClipRectFullScreen()
{
    PushClipRect(ImVec2(_Data->ClipRectFullscreen.x, _Data->ClipRectFullscreen.y), ImVec2(_Data->ClipRectFullscreen.z, _Data->ClipRectFullscreen.w));
}

void ImDrawList::PopClipRect()
{
    _ClipRectStack.pop_back();
    _CmdHeader.ClipRect = (_ClipRectStack.Size == 0) ? _Data->ClipRectFullscreen : _ClipRectStack.Data[_ClipRectStack.Size - 1];
    _OnChangedClipRect();
}

void ImDrawList::PushTextureID(ImTextureID texture_id)
{
    _TextureIdStack.push_back(texture_id);
    _CmdHeader.TextureId = texture_id;
    _OnChangedTextureID();
}

void ImDrawList::PopTextureID()
{
    _TextureIdStack.pop_back();
    _CmdHeader.TextureId = (_TextureIdStack.Size == 0) ? (ImTextureID)nullptr : _TextureIdStack.Data[_TextureIdStack.Size - 1];
    _OnChangedTextureID();
}

// Reserve space for a number of vertices and indices.
// You must finish filling your reserved data before calling PrimReserve() again, as it may reallocate or
// submit the intermediate results. PrimUnreserve() can be used to release unused allocations.
void ImDrawList::PrimReserve(int idx_count, int vtx_count)
{
    // Large mesh support (when enabled)
    IM_ASSERT_PARANOID(idx_count >= 0 && vtx_count >= 0);
    if (sizeof(ImDrawIdx) == 2 && (_VtxCurrentIdx + vtx_count >= (1 << 16)) && (Flags & ImDrawListFlags_AllowVtxOffset))
    {
        // FIXME: In theory we should be testing that vtx_count <64k here.
        // In practice, RenderText() relies on reserving ahead for a worst case scenario so it is currently useful for us
        // to not make that check until we rework the text functions to handle clipping and large horizontal lines better.
        _CmdHeader.VtxOffset = VtxBuffer.Size;
        _OnChangedVtxOffset();
    }

    ImDrawCmd* draw_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    draw_cmd->ElemCount += idx_count;

    int vtx_buffer_old_size = VtxBuffer.Size;
    VtxBuffer.resize(vtx_buffer_old_size + vtx_count);
    _VtxWritePtr = VtxBuffer.Data + vtx_buffer_old_size;

    int idx_buffer_old_size = IdxBuffer.Size;
    IdxBuffer.resize(idx_buffer_old_size + idx_count);
    _IdxWritePtr = IdxBuffer.Data + idx_buffer_old_size;
}

// Release the a number of reserved vertices/indices from the end of the last reservation made with PrimReserve().
void ImDrawList::PrimUnreserve(int idx_count, int vtx_count)
{
    IM_ASSERT_PARANOID(idx_count >= 0 && vtx_count >= 0);

    ImDrawCmd* draw_cmd = &CmdBuffer.Data[CmdBuffer.Size - 1];
    draw_cmd->ElemCount -= idx_count;
    VtxBuffer.shrink(VtxBuffer.Size - vtx_count);
    IdxBuffer.shrink(IdxBuffer.Size - idx_count);
}

// Fully unrolled with inline call to keep our debug builds decently fast.
void ImDrawList::PrimRect(const ImVec2& a, const ImVec2& c, ImU32 col)
{
    ImVec2 b(c.x, a.y), d(a.x, c.y), uv(_Data->TexUvWhitePixel);
    ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
    _IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx+1); _IdxWritePtr[2] = (ImDrawIdx)(idx+2);
    _IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx+2); _IdxWritePtr[5] = (ImDrawIdx)(idx+3);
    _VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
    _VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col;
    _VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv; _VtxWritePtr[2].col = col;
    _VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv; _VtxWritePtr[3].col = col;
    _VtxWritePtr += 4;
    _VtxCurrentIdx += 4;
    _IdxWritePtr += 6;
}

void ImDrawList::PrimRectUV(const ImVec2& a, const ImVec2& c, const ImVec2& uv_a, const ImVec2& uv_c, ImU32 col)
{
    ImVec2 b(c.x, a.y), d(a.x, c.y), uv_b(uv_c.x, uv_a.y), uv_d(uv_a.x, uv_c.y);
    ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
    _IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx+1); _IdxWritePtr[2] = (ImDrawIdx)(idx+2);
    _IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx+2); _IdxWritePtr[5] = (ImDrawIdx)(idx+3);
    _VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv_a; _VtxWritePtr[0].col = col;
    _VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv_b; _VtxWritePtr[1].col = col;
    _VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv_c; _VtxWritePtr[2].col = col;
    _VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv_d; _VtxWritePtr[3].col = col;
    _VtxWritePtr += 4;
    _VtxCurrentIdx += 4;
    _IdxWritePtr += 6;
}

void ImDrawList::PrimQuadUV(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& d, const ImVec2& uv_a, const ImVec2& uv_b, const ImVec2& uv_c, const ImVec2& uv_d, ImU32 col)
{
    ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
    _IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx+1); _IdxWritePtr[2] = (ImDrawIdx)(idx+2);
    _IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx+2); _IdxWritePtr[5] = (ImDrawIdx)(idx+3);
    _VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv_a; _VtxWritePtr[0].col = col;
    _VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv_b; _VtxWritePtr[1].col = col;
    _VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv_c; _VtxWritePtr[2].col = col;
    _VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv_d; _VtxWritePtr[3].col = col;
    _VtxWritePtr += 4;
    _VtxCurrentIdx += 4;
    _IdxWritePtr += 6;
}

// On AddPolyline() and AddConvexPolyFilled() we intentionally avoid using ImVec2 and superfluous function calls to optimize debug/non-inlined builds.
// - Those macros expects l-values and need to be used as their own statement.
// - Those macros are intentionally not surrounded by the 'do {} while (0)' idiom because even that translates to runtime with debug compilers.
#define IM_NORMALIZE2F_OVER_ZERO(VX,VY)     { float d2 = VX*VX + VY*VY; if (d2 > 0.0f) { float inv_len = ImRsqrt(d2); VX *= inv_len; VY *= inv_len; } } (void)0
#define IM_FIXNORMAL2F_MAX_INVLEN2          100.0f // 500.0f (see #4053, #3366)
#define IM_FIXNORMAL2F(VX,VY)               { float d2 = VX*VX + VY*VY; if (d2 > 0.000001f) { float inv_len2 = 1.0f / d2; if (inv_len2 > IM_FIXNORMAL2F_MAX_INVLEN2) inv_len2 = IM_FIXNORMAL2F_MAX_INVLEN2; VX *= inv_len2; VY *= inv_len2; } } (void)0

// TODO: Thickness anti-aliased lines cap are missing their AA fringe.
// We avoid using the ImVec2 math operators here to reduce cost to a minimum for debug/non-inlined builds.
void ImDrawList::AddPolyline(const ImVec2* points, const int points_count, ImU32 col, ImDrawFlags flags, float thickness)
{
    if (points_count < 2)
        return;

    const bool closed = (flags & ImDrawFlags_Closed) != 0;
    const ImVec2 opaque_uv = _Data->TexUvWhitePixel;
    const int count = closed ? points_count : points_count - 1; // The number of line segments we need to draw
    const bool thick_line = (thickness > _FringeScale);

    if (Flags & ImDrawListFlags_AntiAliasedLines)
    {
        // Anti-aliased stroke
        const float AA_SIZE = _FringeScale;
        const ImU32 col_trans = col & ~IM_COL32_A_MASK;

        // Thicknesses <1.0 should behave like thickness 1.0
        thickness = ImMax(thickness, 1.0f);
        const int integer_thickness = (int)thickness;
        const float fractional_thickness = thickness - integer_thickness;

        // Do we want to draw this line using a texture?
        // - For now, only draw integer-width lines using textures to avoid issues with the way scaling occurs, could be improved.
        // - If AA_SIZE is not 1.0f we cannot use the texture path.
        const bool use_texture = (Flags & ImDrawListFlags_AntiAliasedLinesUseTex) && (integer_thickness < IM_DRAWLIST_TEX_LINES_WIDTH_MAX) && (fractional_thickness <= 0.00001f) && (AA_SIZE == 1.0f);

        // We should never hit this, because NewFrame() doesn't set ImDrawListFlags_AntiAliasedLinesUseTex unless ImFontAtlasFlags_NoBakedLines is off
        IM_ASSERT_PARANOID(!use_texture || !(_Data->Font->ContainerAtlas->Flags & ImFontAtlasFlags_NoBakedLines));

        const int idx_count = use_texture ? (count * 6) : (thick_line ? count * 18 : count * 12);
        const int vtx_count = use_texture ? (points_count * 2) : (thick_line ? points_count * 4 : points_count * 3);
        PrimReserve(idx_count, vtx_count);

        // Temporary buffer
        // The first <points_count> items are normals at each line point, then after that there are either 2 or 4 temp points for each line point
        ImVec2* temp_normals = (ImVec2*)alloca(points_count * ((use_texture || !thick_line) ? 3 : 5) * sizeof(ImVec2)); //-V630
        ImVec2* temp_points = temp_normals + points_count;

        // Calculate normals (tangents) for each line segment
        for (int i1 = 0; i1 < count; i1++)
        {
            const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
            float dx = points[i2].x - points[i1].x;
            float dy = points[i2].y - points[i1].y;
            IM_NORMALIZE2F_OVER_ZERO(dx, dy);
            temp_normals[i1].x = dy;
            temp_normals[i1].y = -dx;
        }
        if (!closed)
            temp_normals[points_count - 1] = temp_normals[points_count - 2];

        // If we are drawing a one-pixel-wide line without a texture, or a textured line of any width, we only need 2 or 3 vertices per point
        if (use_texture || !thick_line)
        {
            // [PATH 1] Texture-based lines (thick or non-thick)
            // [PATH 2] Non texture-based lines (non-thick)

            // The width of the geometry we need to draw - this is essentially <thickness> pixels for the line itself, plus "one pixel" for AA.
            // - In the texture-based path, we don't use AA_SIZE here because the +1 is tied to the generated texture
            //   (see ImFontAtlasBuildRenderLinesTexData() function), and so alternate values won't work without changes to that code.
            // - In the non texture-based paths, we would allow AA_SIZE to potentially be != 1.0f with a patch (e.g. fringe_scale patch to
            //   allow scaling geometry while preserving one-screen-pixel AA fringe).
            const float half_draw_size = use_texture ? ((thickness * 0.5f) + 1) : AA_SIZE;

            // If line is not closed, the first and last points need to be generated differently as there are no normals to blend
            if (!closed)
            {
                temp_points[0] = points[0] + temp_normals[0] * half_draw_size;
                temp_points[1] = points[0] - temp_normals[0] * half_draw_size;
                temp_points[(points_count-1)*2+0] = points[points_count-1] + temp_normals[points_count-1] * half_draw_size;
                temp_points[(points_count-1)*2+1] = points[points_count-1] - temp_normals[points_count-1] * half_draw_size;
            }

            // Generate the indices to form a number of triangles for each line segment, and the vertices for the line edges
            // This takes points n and n+1 and writes into n+1, with the first point in a closed line being generated from the final one (as n+1 wraps)
            // FIXME-OPT: Merge the different loops, possibly remove the temporary buffer.
            unsigned int idx1 = _VtxCurrentIdx; // Vertex index for start of line segment
            for (int i1 = 0; i1 < count; i1++) // i1 is the first point of the line segment
            {
                const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1; // i2 is the second point of the line segment
                const unsigned int idx2 = ((i1 + 1) == points_count) ? _VtxCurrentIdx : (idx1 + (use_texture ? 2 : 3)); // Vertex index for end of segment

                // Average normals
                float dm_x = (temp_normals[i1].x + temp_normals[i2].x) * 0.5f;
                float dm_y = (temp_normals[i1].y + temp_normals[i2].y) * 0.5f;
                IM_FIXNORMAL2F(dm_x, dm_y);
                dm_x *= half_draw_size; // dm_x, dm_y are offset to the outer edge of the AA area
                dm_y *= half_draw_size;

                // Add temporary vertexes for the outer edges
                ImVec2* out_vtx = &temp_points[i2 * 2];
                out_vtx[0].x = points[i2].x + dm_x;
                out_vtx[0].y = points[i2].y + dm_y;
                out_vtx[1].x = points[i2].x - dm_x;
                out_vtx[1].y = points[i2].y - dm_y;

                if (use_texture)
                {
                    // Add indices for two triangles
                    _IdxWritePtr[0] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[1] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[2] = (ImDrawIdx)(idx1 + 1); // Right tri
                    _IdxWritePtr[3] = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[4] = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[5] = (ImDrawIdx)(idx2 + 0); // Left tri
                    _IdxWritePtr += 6;
                }
                else
                {
                    // Add indexes for four triangles
                    _IdxWritePtr[0] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[1] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[2] = (ImDrawIdx)(idx1 + 2); // Right tri 1
                    _IdxWritePtr[3] = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[4] = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx2 + 0); // Right tri 2
                    _IdxWritePtr[6] = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[7] = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[8] = (ImDrawIdx)(idx1 + 0); // Left tri 1
                    _IdxWritePtr[9] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[10] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[11] = (ImDrawIdx)(idx2 + 1); // Left tri 2
                    _IdxWritePtr += 12;
                }

                idx1 = idx2;
            }

            // Add vertexes for each point on the line
            if (use_texture)
            {
                // If we're using textures we only need to emit the left/right edge vertices
                ImVec4 tex_uvs = _Data->TexUvLines[integer_thickness];
                /*if (fractional_thickness != 0.0f) // Currently always zero when use_texture==false!
                {
                    const ImVec4 tex_uvs_1 = _Data->TexUvLines[integer_thickness + 1];
                    tex_uvs.x = tex_uvs.x + (tex_uvs_1.x - tex_uvs.x) * fractional_thickness; // inlined ImLerp()
                    tex_uvs.y = tex_uvs.y + (tex_uvs_1.y - tex_uvs.y) * fractional_thickness;
                    tex_uvs.z = tex_uvs.z + (tex_uvs_1.z - tex_uvs.z) * fractional_thickness;
                    tex_uvs.w = tex_uvs.w + (tex_uvs_1.w - tex_uvs.w) * fractional_thickness;
                }*/
                ImVec2 tex_uv0(tex_uvs.x, tex_uvs.y);
                ImVec2 tex_uv1(tex_uvs.z, tex_uvs.w);
                for (int i = 0; i < points_count; i++)
                {
                    _VtxWritePtr[0].pos = temp_points[i * 2 + 0]; _VtxWritePtr[0].uv = tex_uv0; _VtxWritePtr[0].col = col; // Left-side outer edge
                    _VtxWritePtr[1].pos = temp_points[i * 2 + 1]; _VtxWritePtr[1].uv = tex_uv1; _VtxWritePtr[1].col = col; // Right-side outer edge
                    _VtxWritePtr += 2;
                }
            }
            else
            {
                // If we're not using a texture, we need the center vertex as well
                for (int i = 0; i < points_count; i++)
                {
                    _VtxWritePtr[0].pos = points[i];              _VtxWritePtr[0].uv = opaque_uv; _VtxWritePtr[0].col = col;       // Center of line
                    _VtxWritePtr[1].pos = temp_points[i * 2 + 0]; _VtxWritePtr[1].uv = opaque_uv; _VtxWritePtr[1].col = col_trans; // Left-side outer edge
                    _VtxWritePtr[2].pos = temp_points[i * 2 + 1]; _VtxWritePtr[2].uv = opaque_uv; _VtxWritePtr[2].col = col_trans; // Right-side outer edge
                    _VtxWritePtr += 3;
                }
            }
        }
        else
        {
            // [PATH 2] Non texture-based lines (thick): we need to draw the solid line core and thus require four vertices per point
            const float half_inner_thickness = (thickness - AA_SIZE) * 0.5f;

            // If line is not closed, the first and last points need to be generated differently as there are no normals to blend
            if (!closed)
            {
                const int points_last = points_count - 1;
                temp_points[0] = points[0] + temp_normals[0] * (half_inner_thickness + AA_SIZE);
                temp_points[1] = points[0] + temp_normals[0] * (half_inner_thickness);
                temp_points[2] = points[0] - temp_normals[0] * (half_inner_thickness);
                temp_points[3] = points[0] - temp_normals[0] * (half_inner_thickness + AA_SIZE);
                temp_points[points_last * 4 + 0] = points[points_last] + temp_normals[points_last] * (half_inner_thickness + AA_SIZE);
                temp_points[points_last * 4 + 1] = points[points_last] + temp_normals[points_last] * (half_inner_thickness);
                temp_points[points_last * 4 + 2] = points[points_last] - temp_normals[points_last] * (half_inner_thickness);
                temp_points[points_last * 4 + 3] = points[points_last] - temp_normals[points_last] * (half_inner_thickness + AA_SIZE);
            }

            // Generate the indices to form a number of triangles for each line segment, and the vertices for the line edges
            // This takes points n and n+1 and writes into n+1, with the first point in a closed line being generated from the final one (as n+1 wraps)
            // FIXME-OPT: Merge the different loops, possibly remove the temporary buffer.
            unsigned int idx1 = _VtxCurrentIdx; // Vertex index for start of line segment
            for (int i1 = 0; i1 < count; i1++) // i1 is the first point of the line segment
            {
                const int i2 = (i1 + 1) == points_count ? 0 : (i1 + 1); // i2 is the second point of the line segment
                const unsigned int idx2 = (i1 + 1) == points_count ? _VtxCurrentIdx : (idx1 + 4); // Vertex index for end of segment

                // Average normals
                float dm_x = (temp_normals[i1].x + temp_normals[i2].x) * 0.5f;
                float dm_y = (temp_normals[i1].y + temp_normals[i2].y) * 0.5f;
                IM_FIXNORMAL2F(dm_x, dm_y);
                float dm_out_x = dm_x * (half_inner_thickness + AA_SIZE);
                float dm_out_y = dm_y * (half_inner_thickness + AA_SIZE);
                float dm_in_x = dm_x * half_inner_thickness;
                float dm_in_y = dm_y * half_inner_thickness;

                // Add temporary vertices
                ImVec2* out_vtx = &temp_points[i2 * 4];
                out_vtx[0].x = points[i2].x + dm_out_x;
                out_vtx[0].y = points[i2].y + dm_out_y;
                out_vtx[1].x = points[i2].x + dm_in_x;
                out_vtx[1].y = points[i2].y + dm_in_y;
                out_vtx[2].x = points[i2].x - dm_in_x;
                out_vtx[2].y = points[i2].y - dm_in_y;
                out_vtx[3].x = points[i2].x - dm_out_x;
                out_vtx[3].y = points[i2].y - dm_out_y;

                // Add indexes
                _IdxWritePtr[0]  = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[1]  = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[2]  = (ImDrawIdx)(idx1 + 2);
                _IdxWritePtr[3]  = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[4]  = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[5]  = (ImDrawIdx)(idx2 + 1);
                _IdxWritePtr[6]  = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[7]  = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[8]  = (ImDrawIdx)(idx1 + 0);
                _IdxWritePtr[9]  = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[10] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[11] = (ImDrawIdx)(idx2 + 1);
                _IdxWritePtr[12] = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[13] = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[14] = (ImDrawIdx)(idx1 + 3);
                _IdxWritePtr[15] = (ImDrawIdx)(idx1 + 3); _IdxWritePtr[16] = (ImDrawIdx)(idx2 + 3); _IdxWritePtr[17] = (ImDrawIdx)(idx2 + 2);
                _IdxWritePtr += 18;

                idx1 = idx2;
            }

            // Add vertices
            for (int i = 0; i < points_count; i++)
            {
                _VtxWritePtr[0].pos = temp_points[i * 4 + 0]; _VtxWritePtr[0].uv = opaque_uv; _VtxWritePtr[0].col = col_trans;
                _VtxWritePtr[1].pos = temp_points[i * 4 + 1]; _VtxWritePtr[1].uv = opaque_uv; _VtxWritePtr[1].col = col;
                _VtxWritePtr[2].pos = temp_points[i * 4 + 2]; _VtxWritePtr[2].uv = opaque_uv; _VtxWritePtr[2].col = col;
                _VtxWritePtr[3].pos = temp_points[i * 4 + 3]; _VtxWritePtr[3].uv = opaque_uv; _VtxWritePtr[3].col = col_trans;
                _VtxWritePtr += 4;
            }
        }
        _VtxCurrentIdx += (ImDrawIdx)vtx_count;
    }
    else
    {
        // [PATH 4] Non texture-based, Non anti-aliased lines
        const int idx_count = count * 6;
        const int vtx_count = count * 4;    // FIXME-OPT: Not sharing edges
        PrimReserve(idx_count, vtx_count);

        for (int i1 = 0; i1 < count; i1++)
        {
            const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
            const ImVec2& p1 = points[i1];
            const ImVec2& p2 = points[i2];

            float dx = p2.x - p1.x;
            float dy = p2.y - p1.y;
            IM_NORMALIZE2F_OVER_ZERO(dx, dy);
            dx *= (thickness * 0.5f);
            dy *= (thickness * 0.5f);

            _VtxWritePtr[0].pos.x = p1.x + dy; _VtxWritePtr[0].pos.y = p1.y - dx; _VtxWritePtr[0].uv = opaque_uv; _VtxWritePtr[0].col = col;
            _VtxWritePtr[1].pos.x = p2.x + dy; _VtxWritePtr[1].pos.y = p2.y - dx; _VtxWritePtr[1].uv = opaque_uv; _VtxWritePtr[1].col = col;
            _VtxWritePtr[2].pos.x = p2.x - dy; _VtxWritePtr[2].pos.y = p2.y + dx; _VtxWritePtr[2].uv = opaque_uv; _VtxWritePtr[2].col = col;
            _VtxWritePtr[3].pos.x = p1.x - dy; _VtxWritePtr[3].pos.y = p1.y + dx; _VtxWritePtr[3].uv = opaque_uv; _VtxWritePtr[3].col = col;
            _VtxWritePtr += 4;

            _IdxWritePtr[0] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[1] = (ImDrawIdx)(_VtxCurrentIdx + 1); _IdxWritePtr[2] = (ImDrawIdx)(_VtxCurrentIdx + 2);
            _IdxWritePtr[3] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[4] = (ImDrawIdx)(_VtxCurrentIdx + 2); _IdxWritePtr[5] = (ImDrawIdx)(_VtxCurrentIdx + 3);
            _IdxWritePtr += 6;
            _VtxCurrentIdx += 4;
        }
    }
}

// We intentionally avoid using ImVec2 and its math operators here to reduce cost to a minimum for debug/non-inlined builds.
void ImDrawList::AddConvexPolyFilled(const ImVec2* points, const int points_count, ImU32 col)
{
    if (points_count < 3)
        return;

    const ImVec2 uv = _Data->TexUvWhitePixel;

    if (Flags & ImDrawListFlags_AntiAliasedFill)
    {
        // Anti-aliased Fill
        const float AA_SIZE = _FringeScale;
        const ImU32 col_trans = col & ~IM_COL32_A_MASK;
        const int idx_count = (points_count - 2)*3 + points_count * 6;
        const int vtx_count = (points_count * 2);
        PrimReserve(idx_count, vtx_count);

        // Add indexes for fill
        unsigned int vtx_inner_idx = _VtxCurrentIdx;
        unsigned int vtx_outer_idx = _VtxCurrentIdx + 1;
        for (int i = 2; i < points_count; i++)
        {
            _IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx); _IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + ((i - 1) << 1)); _IdxWritePtr[2] = (ImDrawIdx)(vtx_inner_idx + (i << 1));
            _IdxWritePtr += 3;
        }

        // Compute normals
        ImVec2* temp_normals = (ImVec2*)alloca(points_count * sizeof(ImVec2)); //-V630
        for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
        {
            const ImVec2& p0 = points[i0];
            const ImVec2& p1 = points[i1];
            float dx = p1.x - p0.x;
            float dy = p1.y - p0.y;
            IM_NORMALIZE2F_OVER_ZERO(dx, dy);
            temp_normals[i0].x = dy;
            temp_normals[i0].y = -dx;
        }

        for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
        {
            // Average normals
            const ImVec2& n0 = temp_normals[i0];
            const ImVec2& n1 = temp_normals[i1];
            float dm_x = (n0.x + n1.x) * 0.5f;
            float dm_y = (n0.y + n1.y) * 0.5f;
            IM_FIXNORMAL2F(dm_x, dm_y);
            dm_x *= AA_SIZE * 0.5f;
            dm_y *= AA_SIZE * 0.5f;

            // Add vertices
            _VtxWritePtr[0].pos.x = (points[i1].x - dm_x); _VtxWritePtr[0].pos.y = (points[i1].y - dm_y); _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;        // Inner
            _VtxWritePtr[1].pos.x = (points[i1].x + dm_x); _VtxWritePtr[1].pos.y = (points[i1].y + dm_y); _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col_trans;  // Outer
            _VtxWritePtr += 2;

            // Add indexes for fringes
            _IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1)); _IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + (i0 << 1)); _IdxWritePtr[2] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1));
            _IdxWritePtr[3] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1)); _IdxWritePtr[4] = (ImDrawIdx)(vtx_outer_idx + (i1 << 1)); _IdxWritePtr[5] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1));
            _IdxWritePtr += 6;
        }
        _VtxCurrentIdx += (ImDrawIdx)vtx_count;
    }
    else
    {
        // Non Anti-aliased Fill
        const int idx_count = (points_count - 2)*3;
        const int vtx_count = points_count;
        PrimReserve(idx_count, vtx_count);
        for (int i = 0; i < vtx_count; i++)
        {
            _VtxWritePtr[0].pos = points[i]; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
            _VtxWritePtr++;
        }
        for (int i = 2; i < points_count; i++)
        {
            _IdxWritePtr[0] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[1] = (ImDrawIdx)(_VtxCurrentIdx + i - 1); _IdxWritePtr[2] = (ImDrawIdx)(_VtxCurrentIdx + i);
            _IdxWritePtr += 3;
        }
        _VtxCurrentIdx += (ImDrawIdx)vtx_count;
    }
}

void ImDrawList::_PathArcToFastEx(const ImVec2& center, float radius, int a_min_sample, int a_max_sample, int a_step)
{
    if (radius <= 0.0f)
    {
        _Path.push_back(center);
        return;
    }

    // Calculate arc auto segment step size
    if (a_step <= 0)
        a_step = IM_DRAWLIST_ARCFAST_SAMPLE_MAX / _CalcCircleAutoSegmentCount(radius);

    // Make sure we never do steps larger than one quarter of the circle
    a_step = ImClamp(a_step, 1, IM_DRAWLIST_ARCFAST_TABLE_SIZE / 4);

    const int sample_range = ImAbs(a_max_sample - a_min_sample);
    const int a_next_step = a_step;

    int samples = sample_range + 1;
    bool extra_max_sample = false;
    if (a_step > 1)
    {
        samples            = sample_range / a_step + 1;
        const int overstep = sample_range % a_step;

        if (overstep > 0)
        {
            extra_max_sample = true;
            samples++;

            // When we have overstep to avoid awkwardly looking one long line and one tiny one at the end,
            // distribute first step range evenly between them by reducing first step size.
            if (sample_range > 0)
                a_step -= (a_step - overstep) / 2;
        }
    }

    _Path.resize(_Path.Size + samples);
    ImVec2* out_ptr = _Path.Data + (_Path.Size - samples);

    int sample_index = a_min_sample;
    if (sample_index < 0 || sample_index >= IM_DRAWLIST_ARCFAST_SAMPLE_MAX)
    {
        sample_index = sample_index % IM_DRAWLIST_ARCFAST_SAMPLE_MAX;
        if (sample_index < 0)
            sample_index += IM_DRAWLIST_ARCFAST_SAMPLE_MAX;
    }

    if (a_max_sample >= a_min_sample)
    {
        for (int a = a_min_sample; a <= a_max_sample; a += a_step, sample_index += a_step, a_step = a_next_step)
        {
            // a_step is clamped to IM_DRAWLIST_ARCFAST_SAMPLE_MAX, so we have guaranteed that it will not wrap over range twice or more
            if (sample_index >= IM_DRAWLIST_ARCFAST_SAMPLE_MAX)
                sample_index -= IM_DRAWLIST_ARCFAST_SAMPLE_MAX;

            const ImVec2 s = _Data->ArcFastVtx[sample_index];
            out_ptr->x = center.x + s.x * radius;
            out_ptr->y = center.y + s.y * radius;
            out_ptr++;
        }
    }
    else
    {
        for (int a = a_min_sample; a >= a_max_sample; a -= a_step, sample_index -= a_step, a_step = a_next_step)
        {
            // a_step is clamped to IM_DRAWLIST_ARCFAST_SAMPLE_MAX, so we have guaranteed that it will not wrap over range twice or more
            if (sample_index < 0)
                sample_index += IM_DRAWLIST_ARCFAST_SAMPLE_MAX;

            const ImVec2 s = _Data->ArcFastVtx[sample_index];
            out_ptr->x = center.x + s.x * radius;
            out_ptr->y = center.y + s.y * radius;
            out_ptr++;
        }
    }

    if (extra_max_sample)
    {
        int normalized_max_sample = a_max_sample % IM_DRAWLIST_ARCFAST_SAMPLE_MAX;
        if (normalized_max_sample < 0)
            normalized_max_sample += IM_DRAWLIST_ARCFAST_SAMPLE_MAX;

        const ImVec2 s = _Data->ArcFastVtx[normalized_max_sample];
        out_ptr->x = center.x + s.x * radius;
        out_ptr->y = center.y + s.y * radius;
        out_ptr++;
    }

    IM_ASSERT_PARANOID(_Path.Data + _Path.Size == out_ptr);
}

void ImDrawList::_PathArcToN(const ImVec2& center, float radius, float a_min, float a_max, int num_segments)
{
    if (radius <= 0.0f)
    {
        _Path.push_back(center);
        return;
    }

    // Note that we are adding a point at both a_min and a_max.
    // If you are trying to draw a full closed circle you don't want the overlapping points!
    _Path.reserve(_Path.Size + (num_segments + 1));
    for (int i = 0; i <= num_segments; i++)
    {
        const float a = a_min + ((float)i / (float)num_segments) * (a_max - a_min);
        _Path.push_back(ImVec2(center.x + ImCos(a) * radius, center.y + ImSin(a) * radius));
    }
}

// 0: East, 3: South, 6: West, 9: North, 12: East
void ImDrawList::PathArcToFast(const ImVec2& center, float radius, int a_min_of_12, int a_max_of_12)
{
    if (radius <= 0.0f)
    {
        _Path.push_back(center);
        return;
    }
    _PathArcToFastEx(center, radius, a_min_of_12 * IM_DRAWLIST_ARCFAST_SAMPLE_MAX / 12, a_max_of_12 * IM_DRAWLIST_ARCFAST_SAMPLE_MAX / 12, 0);
}

void ImDrawList::PathArcTo(const ImVec2& center, float radius, float a_min, float a_max, int num_segments)
{
    if (radius <= 0.0f)
    {
        _Path.push_back(center);
        return;
    }

    if (num_segments > 0)
    {
        _PathArcToN(center, radius, a_min, a_max, num_segments);
        return;
    }

    // Automatic segment count
    if (radius <= _Data->ArcFastRadiusCutoff)
    {
        const bool a_is_reverse = a_max < a_min;

        // We are going to use precomputed values for mid samples.
        // Determine first and last sample in lookup table that belong to the arc.
        const float a_min_sample_f = IM_DRAWLIST_ARCFAST_SAMPLE_MAX * a_min / (IM_PI * 2.0f);
        const float a_max_sample_f = IM_DRAWLIST_ARCFAST_SAMPLE_MAX * a_max / (IM_PI * 2.0f);

        const int a_min_sample = a_is_reverse ? (int)ImFloorSigned(a_min_sample_f) : (int)ImCeil(a_min_sample_f);
        const int a_max_sample = a_is_reverse ? (int)ImCeil(a_max_sample_f) : (int)ImFloorSigned(a_max_sample_f);
        const int a_mid_samples = a_is_reverse ? ImMax(a_min_sample - a_max_sample, 0) : ImMax(a_max_sample - a_min_sample, 0);

        const float a_min_segment_angle = a_min_sample * IM_PI * 2.0f / IM_DRAWLIST_ARCFAST_SAMPLE_MAX;
        const float a_max_segment_angle = a_max_sample * IM_PI * 2.0f / IM_DRAWLIST_ARCFAST_SAMPLE_MAX;
        const bool a_emit_start = (a_min_segment_angle - a_min) != 0.0f;
        const bool a_emit_end = (a_max - a_max_segment_angle) != 0.0f;

        _Path.reserve(_Path.Size + (a_mid_samples + 1 + (a_emit_start ? 1 : 0) + (a_emit_end ? 1 : 0)));
        if (a_emit_start)
            _Path.push_back(ImVec2(center.x + ImCos(a_min) * radius, center.y + ImSin(a_min) * radius));
        if (a_mid_samples > 0)
            _PathArcToFastEx(center, radius, a_min_sample, a_max_sample, 0);
        if (a_emit_end)
            _Path.push_back(ImVec2(center.x + ImCos(a_max) * radius, center.y + ImSin(a_max) * radius));
    }
    else
    {
        const float arc_length = ImAbs(a_max - a_min);
        const int circle_segment_count = _CalcCircleAutoSegmentCount(radius);
        const int arc_segment_count = ImMax((int)ImCeil(circle_segment_count * arc_length / (IM_PI * 2.0f)), (int)(2.0f * IM_PI / arc_length));
        _PathArcToN(center, radius, a_min, a_max, arc_segment_count);
    }
}

ImVec2 ImBezierCubicCalc(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, float t)
{
    float u = 1.0f - t;
    float w1 = u * u * u;
    float w2 = 3 * u * u * t;
    float w3 = 3 * u * t * t;
    float w4 = t * t * t;
    return ImVec2(w1 * p1.x + w2 * p2.x + w3 * p3.x + w4 * p4.x, w1 * p1.y + w2 * p2.y + w3 * p3.y + w4 * p4.y);
}

ImVec2 ImBezierQuadraticCalc(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, float t)
{
    float u = 1.0f - t;
    float w1 = u * u;
    float w2 = 2 * u * t;
    float w3 = t * t;
    return ImVec2(w1 * p1.x + w2 * p2.x + w3 * p3.x, w1 * p1.y + w2 * p2.y + w3 * p3.y);
}

// Closely mimics ImBezierCubicClosestPointCasteljau() in imgui.cpp
static void PathBezierCubicCurveToCasteljau(ImVector<ImVec2>* path, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float tess_tol, int level)
{
    float dx = x4 - x1;
    float dy = y4 - y1;
    float d2 = (x2 - x4) * dy - (y2 - y4) * dx;
    float d3 = (x3 - x4) * dy - (y3 - y4) * dx;
    d2 = (d2 >= 0) ? d2 : -d2;
    d3 = (d3 >= 0) ? d3 : -d3;
    if ((d2 + d3) * (d2 + d3) < tess_tol * (dx * dx + dy * dy))
    {
        path->push_back(ImVec2(x4, y4));
    }
    else if (level < 10)
    {
        float x12 = (x1 + x2) * 0.5f, y12 = (y1 + y2) * 0.5f;
        float x23 = (x2 + x3) * 0.5f, y23 = (y2 + y3) * 0.5f;
        float x34 = (x3 + x4) * 0.5f, y34 = (y3 + y4) * 0.5f;
        float x123 = (x12 + x23) * 0.5f, y123 = (y12 + y23) * 0.5f;
        float x234 = (x23 + x34) * 0.5f, y234 = (y23 + y34) * 0.5f;
        float x1234 = (x123 + x234) * 0.5f, y1234 = (y123 + y234) * 0.5f;
        PathBezierCubicCurveToCasteljau(path, x1, y1, x12, y12, x123, y123, x1234, y1234, tess_tol, level + 1);
        PathBezierCubicCurveToCasteljau(path, x1234, y1234, x234, y234, x34, y34, x4, y4, tess_tol, level + 1);
    }
}

static void PathBezierQuadraticCurveToCasteljau(ImVector<ImVec2>* path, float x1, float y1, float x2, float y2, float x3, float y3, float tess_tol, int level)
{
    float dx = x3 - x1, dy = y3 - y1;
    float det = (x2 - x3) * dy - (y2 - y3) * dx;
    if (det * det * 4.0f < tess_tol * (dx * dx + dy * dy))
    {
        path->push_back(ImVec2(x3, y3));
    }
    else if (level < 10)
    {
        float x12 = (x1 + x2) * 0.5f, y12 = (y1 + y2) * 0.5f;
        float x23 = (x2 + x3) * 0.5f, y23 = (y2 + y3) * 0.5f;
        float x123 = (x12 + x23) * 0.5f, y123 = (y12 + y23) * 0.5f;
        PathBezierQuadraticCurveToCasteljau(path, x1, y1, x12, y12, x123, y123, tess_tol, level + 1);
        PathBezierQuadraticCurveToCasteljau(path, x123, y123, x23, y23, x3, y3, tess_tol, level + 1);
    }
}

void ImDrawList::PathBezierCubicCurveTo(const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, int num_segments)
{
    ImVec2 p1 = _Path.back();
    if (num_segments == 0)
    {
        PathBezierCubicCurveToCasteljau(&_Path, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, _Data->CurveTessellationTol, 0); // Auto-tessellated
    }
    else
    {
        float t_step = 1.0f / (float)num_segments;
        for (int i_step = 1; i_step <= num_segments; i_step++)
            _Path.push_back(ImBezierCubicCalc(p1, p2, p3, p4, t_step * i_step));
    }
}

void ImDrawList::PathBezierQuadraticCurveTo(const ImVec2& p2, const ImVec2& p3, int num_segments)
{
    ImVec2 p1 = _Path.back();
    if (num_segments == 0)
    {
        PathBezierQuadraticCurveToCasteljau(&_Path, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, _Data->CurveTessellationTol, 0);// Auto-tessellated
    }
    else
    {
        float t_step = 1.0f / (float)num_segments;
        for (int i_step = 1; i_step <= num_segments; i_step++)
            _Path.push_back(ImBezierQuadraticCalc(p1, p2, p3, t_step * i_step));
    }
}

IM_STATIC_ASSERT(ImDrawFlags_RoundCornersTopLeft == (1 << 4));
static inline ImDrawFlags FixRectCornerFlags(ImDrawFlags flags)
{
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
    // Legacy Support for hard coded ~0 (used to be a suggested equivalent to ImDrawCornerFlags_All)
    //   ~0   --> ImDrawFlags_RoundCornersAll or 0
    if (flags == ~0)
        return ImDrawFlags_RoundCornersAll;

    // Legacy Support for hard coded 0x01 to 0x0F (matching 15 out of 16 old flags combinations)
    //   0x01 --> ImDrawFlags_RoundCornersTopLeft (VALUE 0x01 OVERLAPS ImDrawFlags_Closed but ImDrawFlags_Closed is never valid in this path!)
    //   0x02 --> ImDrawFlags_RoundCornersTopRight
    //   0x03 --> ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersTopRight
    //   0x04 --> ImDrawFlags_RoundCornersBotLeft
    //   0x05 --> ImDrawFlags_RoundCornersTopLeft | ImDrawFlags_RoundCornersBotLeft
    //   ...
    //   0x0F --> ImDrawFlags_RoundCornersAll or 0
    // (See all values in ImDrawCornerFlags_)
    if (flags >= 0x01 && flags <= 0x0F)
        return (flags << 4);

    // We cannot support hard coded 0x00 with 'float rounding > 0.0f' --> replace with ImDrawFlags_RoundCornersNone or use 'float rounding = 0.0f'
#endif

    // If this triggers, please update your code replacing hardcoded values with new ImDrawFlags_RoundCorners* values.
    // Note that ImDrawFlags_Closed (== 0x01) is an invalid flag for AddRect(), AddRectFilled(), PathRect() etc...
    IM_ASSERT((flags & 0x0F) == 0 && "Misuse of legacy hardcoded ImDrawCornerFlags values!");

    if ((flags & ImDrawFlags_RoundCornersMask_) == 0)
        flags |= ImDrawFlags_RoundCornersAll;

    return flags;
}

void ImDrawList::PathRect(const ImVec2& a, const ImVec2& b, float rounding, ImDrawFlags flags)
{
    flags = FixRectCornerFlags(flags);
    rounding = ImMin(rounding, ImFabs(b.x - a.x) * ( ((flags & ImDrawFlags_RoundCornersTop)  == ImDrawFlags_RoundCornersTop)  || ((flags & ImDrawFlags_RoundCornersBottom) == ImDrawFlags_RoundCornersBottom) ? 0.5f : 1.0f ) - 1.0f);
    rounding = ImMin(rounding, ImFabs(b.y - a.y) * ( ((flags & ImDrawFlags_RoundCornersLeft) == ImDrawFlags_RoundCornersLeft) || ((flags & ImDrawFlags_RoundCornersRight)  == ImDrawFlags_RoundCornersRight)  ? 0.5f : 1.0f ) - 1.0f);

    if (rounding <= 0.0f || (flags & ImDrawFlags_RoundCornersMask_) == ImDrawFlags_RoundCornersNone)
    {
        PathLineTo(a);
        PathLineTo(ImVec2(b.x, a.y));
        PathLineTo(b);
        PathLineTo(ImVec2(a.x, b.y));
    }
    else
    {
        const float rounding_tl = (flags & ImDrawFlags_RoundCornersTopLeft)     ? rounding : 0.0f;
        const float rounding_tr = (flags & ImDrawFlags_RoundCornersTopRight)    ? rounding : 0.0f;
        const float rounding_br = (flags & ImDrawFlags_RoundCornersBottomRight) ? rounding : 0.0f;
        const float rounding_bl = (flags & ImDrawFlags_RoundCornersBottomLeft)  ? rounding : 0.0f;
        PathArcToFast(ImVec2(a.x + rounding_tl, a.y + rounding_tl), rounding_tl, 6, 9);
        PathArcToFast(ImVec2(b.x - rounding_tr, a.y + rounding_tr), rounding_tr, 9, 12);
        PathArcToFast(ImVec2(b.x - rounding_br, b.y - rounding_br), rounding_br, 0, 3);
        PathArcToFast(ImVec2(a.x + rounding_bl, b.y - rounding_bl), rounding_bl, 3, 6);
    }
}

void ImDrawList::AddLine(const ImVec2& p1, const ImVec2& p2, ImU32 col, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;
    PathLineTo(p1 + ImVec2(0.5f, 0.5f));
    PathLineTo(p2 + ImVec2(0.5f, 0.5f));
    PathStroke(col, 0, thickness);
}

// p_min = upper-left, p_max = lower-right
// Note we don't render 1 pixels sized rectangles properly.
void ImDrawList::AddRect(const ImVec2& p_min, const ImVec2& p_max, ImU32 col, float rounding, ImDrawFlags flags, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;
    if (Flags & ImDrawListFlags_AntiAliasedLines)
        PathRect(p_min + ImVec2(0.50f, 0.50f), p_max - ImVec2(0.50f, 0.50f), rounding, flags);
    else
        PathRect(p_min + ImVec2(0.50f, 0.50f), p_max - ImVec2(0.49f, 0.49f), rounding, flags); // Better looking lower-right corner and rounded non-AA shapes.
    PathStroke(col, ImDrawFlags_Closed, thickness);
}

void ImDrawList::AddRectFilled(const ImVec2& p_min, const ImVec2& p_max, ImU32 col, float rounding, ImDrawFlags flags)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;
    if (rounding <= 0.0f || (flags & ImDrawFlags_RoundCornersMask_) == ImDrawFlags_RoundCornersNone)
    {
        PrimReserve(6, 4);
        PrimRect(p_min, p_max, col);
    }
    else
    {
        PathRect(p_min, p_max, rounding, flags);
        PathFillConvex(col);
    }
}

// p_min = upper-left, p_max = lower-right
void ImDrawList::AddRectFilledMultiColor(const ImVec2& p_min, const ImVec2& p_max, ImU32 col_upr_left, ImU32 col_upr_right, ImU32 col_bot_right, ImU32 col_bot_left)
{
    if (((col_upr_left | col_upr_right | col_bot_right | col_bot_left) & IM_COL32_A_MASK) == 0)
        return;

    const ImVec2 uv = _Data->TexUvWhitePixel;
    PrimReserve(6, 4);
    PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 1)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 2));
    PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 2)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 3));
    PrimWriteVtx(p_min, uv, col_upr_left);
    PrimWriteVtx(ImVec2(p_max.x, p_min.y), uv, col_upr_right);
    PrimWriteVtx(p_max, uv, col_bot_right);
    PrimWriteVtx(ImVec2(p_min.x, p_max.y), uv, col_bot_left);
}

void ImDrawList::AddQuad(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, ImU32 col, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathLineTo(p2);
    PathLineTo(p3);
    PathLineTo(p4);
    PathStroke(col, ImDrawFlags_Closed, thickness);
}

void ImDrawList::AddQuadFilled(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, ImU32 col)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathLineTo(p2);
    PathLineTo(p3);
    PathLineTo(p4);
    PathFillConvex(col);
}

void ImDrawList::AddTriangle(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, ImU32 col, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathLineTo(p2);
    PathLineTo(p3);
    PathStroke(col, ImDrawFlags_Closed, thickness);
}

void ImDrawList::AddTriangleFilled(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, ImU32 col)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathLineTo(p2);
    PathLineTo(p3);
    PathFillConvex(col);
}

void ImDrawList::AddCircle(const ImVec2& center, float radius, ImU32 col, int num_segments, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0 || radius <= 0.0f)
        return;

    if (num_segments <= 0)
    {
        // Use arc with automatic segment count
        _PathArcToFastEx(center, radius - 0.5f, 0, IM_DRAWLIST_ARCFAST_SAMPLE_MAX, 0);
        _Path.Size--;
    }
    else
    {
        // Explicit segment count (still clamp to avoid drawing insanely tessellated shapes)
        num_segments = ImClamp(num_segments, 3, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX);

        // Because we are filling a closed shape we remove 1 from the count of segments/points
        const float a_max = (IM_PI * 2.0f) * ((float)num_segments - 1.0f) / (float)num_segments;
        PathArcTo(center, radius - 0.5f, 0.0f, a_max, num_segments - 1);
    }

    PathStroke(col, ImDrawFlags_Closed, thickness);
}

void ImDrawList::AddCircleFilled(const ImVec2& center, float radius, ImU32 col, int num_segments)
{
    if ((col & IM_COL32_A_MASK) == 0 || radius <= 0.0f)
        return;

    if (num_segments <= 0)
    {
        // Use arc with automatic segment count
        _PathArcToFastEx(center, radius, 0, IM_DRAWLIST_ARCFAST_SAMPLE_MAX, 0);
        _Path.Size--;
    }
    else
    {
        // Explicit segment count (still clamp to avoid drawing insanely tessellated shapes)
        num_segments = ImClamp(num_segments, 3, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX);

        // Because we are filling a closed shape we remove 1 from the count of segments/points
        const float a_max = (IM_PI * 2.0f) * ((float)num_segments - 1.0f) / (float)num_segments;
        PathArcTo(center, radius, 0.0f, a_max, num_segments - 1);
    }

    PathFillConvex(col);
}

// Guaranteed to honor 'num_segments'
void ImDrawList::AddNgon(const ImVec2& center, float radius, ImU32 col, int num_segments, float thickness)
{
    if ((col & IM_COL32_A_MASK) == 0 || num_segments <= 2)
        return;

    // Because we are filling a closed shape we remove 1 from the count of segments/points
    const float a_max = (IM_PI * 2.0f) * ((float)num_segments - 1.0f) / (float)num_segments;
    PathArcTo(center, radius - 0.5f, 0.0f, a_max, num_segments - 1);
    PathStroke(col, ImDrawFlags_Closed, thickness);
}

// Guaranteed to honor 'num_segments'
void ImDrawList::AddNgonFilled(const ImVec2& center, float radius, ImU32 col, int num_segments)
{
    if ((col & IM_COL32_A_MASK) == 0 || num_segments <= 2)
        return;

    // Because we are filling a closed shape we remove 1 from the count of segments/points
    const float a_max = (IM_PI * 2.0f) * ((float)num_segments - 1.0f) / (float)num_segments;
    PathArcTo(center, radius, 0.0f, a_max, num_segments - 1);
    PathFillConvex(col);
}

// Cubic Bezier takes 4 controls points
void ImDrawList::AddBezierCubic(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, ImU32 col, float thickness, int num_segments)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathBezierCubicCurveTo(p2, p3, p4, num_segments);
    PathStroke(col, 0, thickness);
}

// Quadratic Bezier takes 3 controls points
void ImDrawList::AddBezierQuadratic(const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, ImU32 col, float thickness, int num_segments)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    PathLineTo(p1);
    PathBezierQuadraticCurveTo(p2, p3, num_segments);
    PathStroke(col, 0, thickness);
}

void ImDrawList::AddText(const ImFont* font, float font_size, const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end, float wrap_width, const ImVec4* cpu_fine_clip_rect)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    if (text_end == nullptr)
        text_end = text_begin + strlen(text_begin);
    if (text_begin == text_end)
        return;

    // Pull default font/size from the shared ImDrawListSharedData instance
    if (font == nullptr)
        font = _Data->Font;
    if (font_size == 0.0f)
        font_size = _Data->FontSize;

    IM_ASSERT(font->ContainerAtlas->TexID == _CmdHeader.TextureId);  // Use high-level ImGui::PushFont() or low-level ImDrawList::PushTextureId() to change font.

    ImVec4 clip_rect = _CmdHeader.ClipRect;
    if (cpu_fine_clip_rect)
    {
        clip_rect.x = ImMax(clip_rect.x, cpu_fine_clip_rect->x);
        clip_rect.y = ImMax(clip_rect.y, cpu_fine_clip_rect->y);
        clip_rect.z = ImMin(clip_rect.z, cpu_fine_clip_rect->z);
        clip_rect.w = ImMin(clip_rect.w, cpu_fine_clip_rect->w);
    }
    font->RenderText(this, font_size, pos, col, clip_rect, text_begin, text_end, wrap_width, cpu_fine_clip_rect != nullptr);
}

void ImDrawList::AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end)
{
    AddText(nullptr, 0.0f, pos, col, text_begin, text_end);
}

void ImDrawList::AddImage(ImTextureID user_texture_id, const ImVec2& p_min, const ImVec2& p_max, const ImVec2& uv_min, const ImVec2& uv_max, ImU32 col)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    const bool push_texture_id = user_texture_id != _CmdHeader.TextureId;
    if (push_texture_id)
        PushTextureID(user_texture_id);

    PrimReserve(6, 4);
    PrimRectUV(p_min, p_max, uv_min, uv_max, col);

    if (push_texture_id)
        PopTextureID();
}

void ImDrawList::AddImageQuad(ImTextureID user_texture_id, const ImVec2& p1, const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, const ImVec2& uv1, const ImVec2& uv2, const ImVec2& uv3, const ImVec2& uv4, ImU32 col)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    const bool push_texture_id = user_texture_id != _CmdHeader.TextureId;
    if (push_texture_id)
        PushTextureID(user_texture_id);

    PrimReserve(6, 4);
    PrimQuadUV(p1, p2, p3, p4, uv1, uv2, uv3, uv4, col);

    if (push_texture_id)
        PopTextureID();
}

void ImDrawList::AddImageRounded(ImTextureID user_texture_id, const ImVec2& p_min, const ImVec2& p_max, const ImVec2& uv_min, const ImVec2& uv_max, ImU32 col, float rounding, ImDrawFlags flags)
{
    if ((col & IM_COL32_A_MASK) == 0)
        return;

    flags = FixRectCornerFlags(flags);
    if (rounding <= 0.0f || (flags & ImDrawFlags_RoundCornersMask_) == ImDrawFlags_RoundCornersNone)
    {
        AddImage(user_texture_id, p_min, p_max, uv_min, uv_max, col);
        return;
    }

    const bool push_texture_id = user_texture_id != _CmdHeader.TextureId;
    if (push_texture_id)
        PushTextureID(user_texture_id);

    int vert_start_idx = VtxBuffer.Size;
    PathRect(p_min, p_max, rounding, flags);
    PathFillConvex(col);
    int vert_end_idx = VtxBuffer.Size;
    ImGui::ShadeVertsLinearUV(this, vert_start_idx, vert_end_idx, p_min, p_max, uv_min, uv_max, true);

    if (push_texture_id)
        PopTextureID();
}


//-----------------------------------------------------------------------------
// [SECTION] ImDrawListSplitter
//-----------------------------------------------------------------------------
// FIXME: This may be a little confusing, trying to be a little too low-level/optimal instead of just doing vector swap..
//-----------------------------------------------------------------------------

void ImDrawListSplitter::ClearFreeMemory()
{
    for (int i = 0; i < _Channels.Size; i++)
    {
        if (i == _Current)
            memset(&_Channels[i], 0, sizeof(_Channels[i]));  // Current channel is a copy of CmdBuffer/IdxBuffer, don't destruct again
        _Channels[i]._CmdBuffer.clear();
        _Channels[i]._IdxBuffer.clear();
    }
    _Current = 0;
    _Count = 1;
    _Channels.clear();
}

void ImDrawListSplitter::Split(ImDrawList* draw_list, int channels_count)
{
    IM_UNUSED(draw_list);
    IM_ASSERT(_Current == 0 && _Count <= 1 && "Nested channel splitting is not supported. Please use separate instances of ImDrawListSplitter.");
    int old_channels_count = _Channels.Size;
    if (old_channels_count < channels_count)
    {
        _Channels.reserve(channels_count); // Avoid over reserving since this is likely to stay stable
        _Channels.resize(channels_count);
    }
    _Count = channels_count;

    // Channels[] (24/32 bytes each) hold storage that we'll swap with draw_list->_CmdBuffer/_IdxBuffer
    // The content of Channels[0] at this point doesn't matter. We clear it to make state tidy in a debugger but we don't strictly need to.
    // When we switch to the next channel, we'll copy draw_list->_CmdBuffer/_IdxBuffer into Channels[0] and then Channels[1] into draw_list->CmdBuffer/_IdxBuffer
    memset(&_Channels[0], 0, sizeof(ImDrawChannel));
    for (int i = 1; i < channels_count; i++)
    {
        if (i >= old_channels_count)
        {
            IM_PLACEMENT_NEW(&_Channels[i]) ImDrawChannel();
        }
        else
        {
            _Channels[i]._CmdBuffer.resize(0);
            _Channels[i]._IdxBuffer.resize(0);
        }
    }
}

void ImDrawListSplitter::Merge(ImDrawList* draw_list)
{
    // Note that we never use or rely on _Channels.Size because it is merely a buffer that we never shrink back to 0 to keep all sub-buffers ready for use.
    if (_Count <= 1)
        return;

    SetCurrentChannel(draw_list, 0);
    draw_list->_PopUnusedDrawCmd();

    // Calculate our final buffer sizes. Also fix the incorrect IdxOffset values in each command.
    int new_cmd_buffer_count = 0;
    int new_idx_buffer_count = 0;
    ImDrawCmd* last_cmd = (_Count > 0 && draw_list->CmdBuffer.Size > 0) ? &draw_list->CmdBuffer.back() : nullptr;
    int idx_offset = last_cmd ? last_cmd->IdxOffset + last_cmd->ElemCount : 0;
    for (int i = 1; i < _Count; i++)
    {
        ImDrawChannel& ch = _Channels[i];

        // Equivalent of PopUnusedDrawCmd() for this channel's cmdbuffer and except we don't need to test for UserCallback.
        if (ch._CmdBuffer.Size > 0 && ch._CmdBuffer.back().ElemCount == 0)
            ch._CmdBuffer.pop_back();

        if (ch._CmdBuffer.Size > 0 && last_cmd != nullptr)
        {
            ImDrawCmd* next_cmd = &ch._CmdBuffer[0];
            if (ImDrawCmd_HeaderCompare(last_cmd, next_cmd) == 0 && last_cmd->UserCallback == nullptr && next_cmd->UserCallback == nullptr)
            {
                // Merge previous channel last draw command with current channel first draw command if matching.
                last_cmd->ElemCount += next_cmd->ElemCount;
                idx_offset += next_cmd->ElemCount;
                ch._CmdBuffer.erase(ch._CmdBuffer.Data); // FIXME-OPT: Improve for multiple merges.
            }
        }
        if (ch._CmdBuffer.Size > 0)
            last_cmd = &ch._CmdBuffer.back();
        new_cmd_buffer_count += ch._CmdBuffer.Size;
        new_idx_buffer_count += ch._IdxBuffer.Size;
        for (int cmd_n = 0; cmd_n < ch._CmdBuffer.Size; cmd_n++)
        {
            ch._CmdBuffer.Data[cmd_n].IdxOffset = idx_offset;
            idx_offset += ch._CmdBuffer.Data[cmd_n].ElemCount;
        }
    }
    draw_list->CmdBuffer.resize(draw_list->CmdBuffer.Size + new_cmd_buffer_count);
    draw_list->IdxBuffer.resize(draw_list->IdxBuffer.Size + new_idx_buffer_count);

    // Write commands and indices in order (they are fairly small structures, we don't copy vertices only indices)
    ImDrawCmd* cmd_write = draw_list->CmdBuffer.Data + draw_list->CmdBuffer.Size - new_cmd_buffer_count;
    ImDrawIdx* idx_write = draw_list->IdxBuffer.Data + draw_list->IdxBuffer.Size - new_idx_buffer_count;
    for (int i = 1; i < _Count; i++)
    {
        ImDrawChannel& ch = _Channels[i];
        if (int sz = ch._CmdBuffer.Size) { memcpy(cmd_write, ch._CmdBuffer.Data, sz * sizeof(ImDrawCmd)); cmd_write += sz; }
        if (int sz = ch._IdxBuffer.Size) { memcpy(idx_write, ch._IdxBuffer.Data, sz * sizeof(ImDrawIdx)); idx_write += sz; }
    }
    draw_list->_IdxWritePtr = idx_write;

    // Ensure there's always a non-callback draw command trailing the command-buffer
    if (draw_list->CmdBuffer.Size == 0 || draw_list->CmdBuffer.back().UserCallback != nullptr)
        draw_list->AddDrawCmd();

    // If current command is used with different settings we need to add a new command
    ImDrawCmd* curr_cmd = &draw_list->CmdBuffer.Data[draw_list->CmdBuffer.Size - 1];
    if (curr_cmd->ElemCount == 0)
        ImDrawCmd_HeaderCopy(curr_cmd, &draw_list->_CmdHeader); // Copy ClipRect, TextureId, VtxOffset
    else if (ImDrawCmd_HeaderCompare(curr_cmd, &draw_list->_CmdHeader) != 0)
        draw_list->AddDrawCmd();

    _Count = 1;
}

void ImDrawListSplitter::SetCurrentChannel(ImDrawList* draw_list, int idx)
{
    IM_ASSERT(idx >= 0 && idx < _Count);
    if (_Current == idx)
        return;

    // Overwrite ImVector (12/16 bytes), four times. This is merely a silly optimization instead of doing .swap()
    memcpy(&_Channels.Data[_Current]._CmdBuffer, &draw_list->CmdBuffer, sizeof(draw_list->CmdBuffer));
    memcpy(&_Channels.Data[_Current]._IdxBuffer, &draw_list->IdxBuffer, sizeof(draw_list->IdxBuffer));
    _Current = idx;
    memcpy(&draw_list->CmdBuffer, &_Channels.Data[idx]._CmdBuffer, sizeof(draw_list->CmdBuffer));
    memcpy(&draw_list->IdxBuffer, &_Channels.Data[idx]._IdxBuffer, sizeof(draw_list->IdxBuffer));
    draw_list->_IdxWritePtr = draw_list->IdxBuffer.Data + draw_list->IdxBuffer.Size;

    // If current command is used with different settings we need to add a new command
    ImDrawCmd* curr_cmd = (draw_list->CmdBuffer.Size == 0) ? nullptr : &draw_list->CmdBuffer.Data[draw_list->CmdBuffer.Size - 1];
    if (curr_cmd == nullptr)
        draw_list->AddDrawCmd();
    else if (curr_cmd->ElemCount == 0)
        ImDrawCmd_HeaderCopy(curr_cmd, &draw_list->_CmdHeader); // Copy ClipRect, TextureId, VtxOffset
    else if (ImDrawCmd_HeaderCompare(curr_cmd, &draw_list->_CmdHeader) != 0)
        draw_list->AddDrawCmd();
}

//-----------------------------------------------------------------------------
// [SECTION] ImDrawData
//-----------------------------------------------------------------------------

// For backward compatibility: convert all buffers from indexed to de-indexed, in case you cannot render indexed. Note: this is slow and most likely a waste of resources. Always prefer indexed rendering!
void ImDrawData::DeIndexAllBuffers()
{
    ImVector<ImDrawVert> new_vtx_buffer;
    TotalVtxCount = TotalIdxCount = 0;
    for (int i = 0; i < CmdListsCount; i++)
    {
        ImDrawList* cmd_list = CmdLists[i];
        if (cmd_list->IdxBuffer.empty())
            continue;
        new_vtx_buffer.resize(cmd_list->IdxBuffer.Size);
        for (int j = 0; j < cmd_list->IdxBuffer.Size; j++)
            new_vtx_buffer[j] = cmd_list->VtxBuffer[cmd_list->IdxBuffer[j]];
        cmd_list->VtxBuffer.swap(new_vtx_buffer);
        cmd_list->IdxBuffer.resize(0);
        TotalVtxCount += cmd_list->VtxBuffer.Size;
    }
}

// Helper to scale the ClipRect field of each ImDrawCmd.
// Use if your final output buffer is at a different scale than draw_data->DisplaySize,
// or if there is a difference between your window resolution and framebuffer resolution.
void ImDrawData::ScaleClipRects(const ImVec2& fb_scale)
{
    for (int i = 0; i < CmdListsCount; i++)
    {
        ImDrawList* cmd_list = CmdLists[i];
        for (int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
        {
            ImDrawCmd* cmd = &cmd_list->CmdBuffer[cmd_i];
            cmd->ClipRect = ImVec4(cmd->ClipRect.x * fb_scale.x, cmd->ClipRect.y * fb_scale.y, cmd->ClipRect.z * fb_scale.x, cmd->ClipRect.w * fb_scale.y);
        }
    }
}

//-----------------------------------------------------------------------------
// [SECTION] Helpers ShadeVertsXXX functions
//-----------------------------------------------------------------------------

// Generic linear color gradient, write to RGB fields, leave A untouched.
void ImGui::ShadeVertsLinearColorGradientKeepAlpha(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx, ImVec2 gradient_p0, ImVec2 gradient_p1, ImU32 col0, ImU32 col1)
{
    ImVec2 gradient_extent = gradient_p1 - gradient_p0;
    float gradient_inv_length2 = 1.0f / ImLengthSqr(gradient_extent);
    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    const int col0_r = (int)(col0 >> IM_COL32_R_SHIFT) & 0xFF;
    const int col0_g = (int)(col0 >> IM_COL32_G_SHIFT) & 0xFF;
    const int col0_b = (int)(col0 >> IM_COL32_B_SHIFT) & 0xFF;
    const int col_delta_r = ((int)(col1 >> IM_COL32_R_SHIFT) & 0xFF) - col0_r;
    const int col_delta_g = ((int)(col1 >> IM_COL32_G_SHIFT) & 0xFF) - col0_g;
    const int col_delta_b = ((int)(col1 >> IM_COL32_B_SHIFT) & 0xFF) - col0_b;
    for (ImDrawVert* vert = vert_start; vert < vert_end; vert++)
    {
        float d = ImDot(vert->pos - gradient_p0, gradient_extent);
        float t = ImClamp(d * gradient_inv_length2, 0.0f, 1.0f);
        int r = (int)(col0_r + col_delta_r * t);
        int g = (int)(col0_g + col_delta_g * t);
        int b = (int)(col0_b + col_delta_b * t);
        vert->col = (r << IM_COL32_R_SHIFT) | (g << IM_COL32_G_SHIFT) | (b << IM_COL32_B_SHIFT) | (vert->col & IM_COL32_A_MASK);
    }
}

// Distribute UV over (a, b) rectangle
void ImGui::ShadeVertsLinearUV(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx, const ImVec2& a, const ImVec2& b, const ImVec2& uv_a, const ImVec2& uv_b, bool clamp)
{
    const ImVec2 size = b - a;
    const ImVec2 uv_size = uv_b - uv_a;
    const ImVec2 scale = ImVec2(
        size.x != 0.0f ? (uv_size.x / size.x) : 0.0f,
        size.y != 0.0f ? (uv_size.y / size.y) : 0.0f);

    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    if (clamp)
    {
        const ImVec2 min = ImMin(uv_a, uv_b);
        const ImVec2 max = ImMax(uv_a, uv_b);
        for (ImDrawVert* vertex = vert_start; vertex < vert_end; ++vertex)
            vertex->uv = ImClamp(uv_a + ImMul(ImVec2(vertex->pos.x, vertex->pos.y) - a, scale), min, max);
    }
    else
    {
        for (ImDrawVert* vertex = vert_start; vertex < vert_end; ++vertex)
            vertex->uv = uv_a + ImMul(ImVec2(vertex->pos.x, vertex->pos.y) - a, scale);
    }
}

//-----------------------------------------------------------------------------
// [SECTION] ImFontConfig
//-----------------------------------------------------------------------------

ImFontConfig::ImFontConfig()
{
    memset(this, 0, sizeof(*this));
    FontDataOwnedByAtlas = true;
    OversampleH = 3; // FIXME: 2 may be a better default?
    OversampleV = 1;
    GlyphMaxAdvanceX = FLT_MAX;
    RasterizerMultiply = 1.0f;
    EllipsisChar = (ImWchar)-1;
}

//-----------------------------------------------------------------------------
// [SECTION] ImFontAtlas
//-----------------------------------------------------------------------------

// A work of art lies ahead! (. = white layer, X = black layer, others are blank)
// The 2x2 white texels on the top left are the ones we'll use everywhere in Dear ImGui to render filled shapes.
const int FONT_ATLAS_DEFAULT_TEX_DATA_W = 108; // Actual texture will be 2 times that + 1 spacing.
const int FONT_ATLAS_DEFAULT_TEX_DATA_H = 27;
static const char FONT_ATLAS_DEFAULT_TEX_DATA_PIXELS[FONT_ATLAS_DEFAULT_TEX_DATA_W * FONT_ATLAS_DEFAULT_TEX_DATA_H + 1] =
{
    "..-         -XXXXXXX-    X    -           X           -XXXXXXX          -          XXXXXXX-     XX          "
    "..-         -X.....X-   X.X   -          X.X          -X.....X          -          X.....X-    X..X         "
    "---         -XXX.XXX-  X...X  -         X...X         -X....X           -           X....X-    X..X         "
    "X           -  X.X  - X.....X -        X.....X        -X...X            -            X...X-    X..X         "
    "XX          -  X.X  -X.......X-       X.......X       -X..X.X           -           X.X..X-    X..X         "
    "X.X         -  X.X  -XXXX.XXXX-       XXXX.XXXX       -X.X X.X          -          X.X X.X-    X..XXX       "
    "X..X        -  X.X  -   X.X   -          X.X          -XX   X.X         -         X.X   XX-    X..X..XXX    "
    "X...X       -  X.X  -   X.X   -    XX    X.X    XX    -      X.X        -        X.X      -    X..X..X..XX  "
    "X....X      -  X.X  -   X.X   -   X.X    X.X    X.X   -       X.X       -       X.X       -    X..X..X..X.X "
    "X.....X     -  X.X  -   X.X   -  X..X    X.X    X..X  -        X.X      -      X.X        -XXX X..X..X..X..X"
    "X......X    -  X.X  -   X.X   - X...XXXXXX.XXXXXX...X -         X.X   XX-XX   X.X         -X..XX........X..X"
    "X.......X   -  X.X  -   X.X   -X.....................X-          X.X X.X-X.X X.X          -X...X...........X"
    "X........X  -  X.X  -   X.X   - X...XXXXXX.XXXXXX...X -           X.X..X-X..X.X           - X..............X"
    "X.........X -XXX.XXX-   X.X   -  X..X    X.X    X..X  -            X...X-X...X            -  X.............X"
    "X..........X-X.....X-   X.X   -   X.X    X.X    X.X   -           X....X-X....X           -  X.............X"
    "X......XXXXX-XXXXXXX-   X.X   -    XX    X.X    XX    -          X.....X-X.....X          -   X............X"
    "X...X..X    ---------   X.X   -          X.X          -          XXXXXXX-XXXXXXX          -   X...........X "
    "X..X X..X   -       -XXXX.XXXX-       XXXX.XXXX       -------------------------------------    X..........X "
    "X.X  X..X   -       -X.......X-       X.......X       -    XX           XX    -           -    X..........X "
    "XX    X..X  -       - X.....X -        X.....X        -   X.X           X.X   -           -     X........X  "
    "      X..X          -  X...X  -         X...X         -  X..X           X..X  -           -     X........X  "
    "       XX           -   X.X   -          X.X          - X...XXXXXXXXXXXXX...X -           -     XXXXXXXXXX  "
    "------------        -    X    -           X           -X.....................X-           ------------------"
    "                    ----------------------------------- X...XXXXXXXXXXXXX...X -                             "
    "                                                      -  X..X           X..X  -                             "
    "                                                      -   X.X           X.X   -                             "
    "                                                      -    XX           XX    -                             "
};

static const ImVec2 FONT_ATLAS_DEFAULT_TEX_CURSOR_DATA[ImGuiMouseCursor_COUNT][3] =
{
    // Pos ........ Size ......... Offset ......
    { ImVec2( 0,3), ImVec2(12,19), ImVec2( 0, 0) }, // ImGuiMouseCursor_Arrow
    { ImVec2(13,0), ImVec2( 7,16), ImVec2( 1, 8) }, // ImGuiMouseCursor_TextInput
    { ImVec2(31,0), ImVec2(23,23), ImVec2(11,11) }, // ImGuiMouseCursor_ResizeAll
    { ImVec2(21,0), ImVec2( 9,23), ImVec2( 4,11) }, // ImGuiMouseCursor_ResizeNS
    { ImVec2(55,18),ImVec2(23, 9), ImVec2(11, 4) }, // ImGuiMouseCursor_ResizeEW
    { ImVec2(73,0), ImVec2(17,17), ImVec2( 8, 8) }, // ImGuiMouseCursor_ResizeNESW
    { ImVec2(55,0), ImVec2(17,17), ImVec2( 8, 8) }, // ImGuiMouseCursor_ResizeNWSE
    { ImVec2(91,0), ImVec2(17,22), ImVec2( 5, 0) }, // ImGuiMouseCursor_Hand
};

ImFontAtlas::ImFontAtlas()
{
    memset(this, 0, sizeof(*this));
    TexGlyphPadding = 1;
    PackIdMouseCursors = PackIdLines = -1;
}

ImFontAtlas::~ImFontAtlas()
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    Clear();
}

void    ImFontAtlas::ClearInputData()
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    for (int i = 0; i < ConfigData.Size; i++)
        if (ConfigData[i].FontData && ConfigData[i].FontDataOwnedByAtlas)
        {
            IM_FREE(ConfigData[i].FontData);
            ConfigData[i].FontData = nullptr;
        }

    // When clearing this we lose access to the font name and other information used to build the font.
    for (int i = 0; i < Fonts.Size; i++)
        if (Fonts[i]->ConfigData >= ConfigData.Data && Fonts[i]->ConfigData < ConfigData.Data + ConfigData.Size)
        {
            Fonts[i]->ConfigData = nullptr;
            Fonts[i]->ConfigDataCount = 0;
        }
    ConfigData.clear();
    CustomRects.clear();
    PackIdMouseCursors = PackIdLines = -1;
    // Important: we leave TexReady untouched
}

void    ImFontAtlas::ClearTexData()
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    if (TexPixelsAlpha8)
        IM_FREE(TexPixelsAlpha8);
    if (TexPixelsRGBA32)
        IM_FREE(TexPixelsRGBA32);
    TexPixelsAlpha8 = nullptr;
    TexPixelsRGBA32 = nullptr;
    TexPixelsUseColors = false;
    // Important: we leave TexReady untouched
}

void    ImFontAtlas::ClearFonts()
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    Fonts.clear_delete();
    TexReady = false;
}

void    ImFontAtlas::Clear()
{
    ClearInputData();
    ClearTexData();
    ClearFonts();
}

void    ImFontAtlas::GetTexDataAsAlpha8(unsigned char** out_pixels, int* out_width, int* out_height, int* out_bytes_per_pixel)
{
    // Build atlas on demand
    if (TexPixelsAlpha8 == nullptr)
        Build();

    *out_pixels = TexPixelsAlpha8;
    if (out_width) *out_width = TexWidth;
    if (out_height) *out_height = TexHeight;
    if (out_bytes_per_pixel) *out_bytes_per_pixel = 1;
}

void    ImFontAtlas::GetTexDataAsRGBA32(unsigned char** out_pixels, int* out_width, int* out_height, int* out_bytes_per_pixel)
{
    // Convert to RGBA32 format on demand
    // Although it is likely to be the most commonly used format, our font rendering is 1 channel / 8 bpp
    if (!TexPixelsRGBA32)
    {
        unsigned char* pixels = nullptr;
        GetTexDataAsAlpha8(&pixels, nullptr, nullptr);
        if (pixels)
        {
            TexPixelsRGBA32 = (unsigned int*)IM_ALLOC((size_t)TexWidth * (size_t)TexHeight * 4);
            const unsigned char* src = pixels;
            unsigned int* dst = TexPixelsRGBA32;
            for (int n = TexWidth * TexHeight; n > 0; n--)
                *dst++ = IM_COL32(255, 255, 255, (unsigned int)(*src++));
        }
    }

    *out_pixels = (unsigned char*)TexPixelsRGBA32;
    if (out_width) *out_width = TexWidth;
    if (out_height) *out_height = TexHeight;
    if (out_bytes_per_pixel) *out_bytes_per_pixel = 4;
}

ImFont* ImFontAtlas::AddFont(const ImFontConfig* font_cfg)
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    IM_ASSERT(font_cfg->FontData != nullptr && font_cfg->FontDataSize > 0);
    IM_ASSERT(font_cfg->SizePixels > 0.0f);

    // Create new font
    if (!font_cfg->MergeMode)
        Fonts.push_back(IM_NEW(ImFont));
    else
        IM_ASSERT(!Fonts.empty() && "Cannot use MergeMode for the first font"); // When using MergeMode make sure that a font has already been added before. You can use ImGui::GetIO().Fonts->AddFontDefault() to add the default imgui font.

    ConfigData.push_back(*font_cfg);
    ImFontConfig& new_font_cfg = ConfigData.back();
    if (new_font_cfg.DstFont == nullptr)
        new_font_cfg.DstFont = Fonts.back();
    if (!new_font_cfg.FontDataOwnedByAtlas)
    {
        new_font_cfg.FontData = IM_ALLOC(new_font_cfg.FontDataSize);
        new_font_cfg.FontDataOwnedByAtlas = true;
        memcpy(new_font_cfg.FontData, font_cfg->FontData, (size_t)new_font_cfg.FontDataSize);
    }

    if (new_font_cfg.DstFont->EllipsisChar == (ImWchar)-1)
        new_font_cfg.DstFont->EllipsisChar = font_cfg->EllipsisChar;

    // Invalidate texture
    TexReady = false;
    ClearTexData();
    return new_font_cfg.DstFont;
}

// Default font TTF is compressed with stb_compress then base85 encoded (see misc/fonts/binary_to_compressed_c.cpp for encoder)
static unsigned int stb_decompress_length(const unsigned char* input);
static unsigned int stb_decompress(unsigned char* output, const unsigned char* input, unsigned int length);
static const char*  GetDefaultCompressedFontDataTTFBase85();
static unsigned int Decode85Byte(char c)                                    { return c >= '\\' ? c-36 : c-35; }
static void         Decode85(const unsigned char* src, unsigned char* dst)
{
    while (*src)
    {
        unsigned int tmp = Decode85Byte(src[0]) + 85 * (Decode85Byte(src[1]) + 85 * (Decode85Byte(src[2]) + 85 * (Decode85Byte(src[3]) + 85 * Decode85Byte(src[4]))));
        dst[0] = ((tmp >> 0) & 0xFF); dst[1] = ((tmp >> 8) & 0xFF); dst[2] = ((tmp >> 16) & 0xFF); dst[3] = ((tmp >> 24) & 0xFF);   // We can't assume little-endianness.
        src += 5;
        dst += 4;
    }
}

// Load embedded ProggyClean.ttf at size 13, disable oversampling
ImFont* ImFontAtlas::AddFontDefault(const ImFontConfig* font_cfg_template)
{
    ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
    if (!font_cfg_template)
    {
        font_cfg.OversampleH = font_cfg.OversampleV = 1;
        font_cfg.PixelSnapH = true;
    }
    if (font_cfg.SizePixels <= 0.0f)
        font_cfg.SizePixels = 13.0f * 1.0f;
    if (font_cfg.Name[0] == '\0')
        ImFormatString(font_cfg.Name, IM_ARRAYSIZE(font_cfg.Name), "ProggyClean.ttf, %dpx", (int)font_cfg.SizePixels);
    font_cfg.EllipsisChar = (ImWchar)0x0085;
    font_cfg.GlyphOffset.y = 1.0f * IM_FLOOR(font_cfg.SizePixels / 13.0f);  // Add +1 offset per 13 units

    const char* ttf_compressed_base85 = GetDefaultCompressedFontDataTTFBase85();
    const ImWchar* glyph_ranges = font_cfg.GlyphRanges != nullptr ? font_cfg.GlyphRanges : GetGlyphRangesDefault();
    ImFont* font = AddFontFromMemoryCompressedBase85TTF(ttf_compressed_base85, font_cfg.SizePixels, &font_cfg, glyph_ranges);
    return font;
}

ImFont* ImFontAtlas::AddFontFromFileTTF(const char* filename, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    size_t data_size = 0;
    void* data = ImFileLoadToMemory(filename, "rb", &data_size, 0);
    if (!data)
    {
        IM_ASSERT_USER_ERROR(0, "Could not load font file!");
        return nullptr;
    }
    ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
    if (font_cfg.Name[0] == '\0')
    {
        // Store a short copy of filename into into the font name for convenience
        const char* p;
        for (p = filename + strlen(filename); p > filename && p[-1] != '/' && p[-1] != '\\'; p--) {}
        ImFormatString(font_cfg.Name, IM_ARRAYSIZE(font_cfg.Name), "%s, %.0fpx", p, size_pixels);
    }
    return AddFontFromMemoryTTF(data, (int)data_size, size_pixels, &font_cfg, glyph_ranges);
}

// NB: Transfer ownership of 'ttf_data' to ImFontAtlas, unless font_cfg_template->FontDataOwnedByAtlas == false. Owned TTF buffer will be deleted after Build().
ImFont* ImFontAtlas::AddFontFromMemoryTTF(void* ttf_data, int ttf_size, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");
    ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
    IM_ASSERT(font_cfg.FontData == nullptr);
    font_cfg.FontData = ttf_data;
    font_cfg.FontDataSize = ttf_size;
    font_cfg.SizePixels = size_pixels > 0.0f ? size_pixels : font_cfg.SizePixels;
    if (glyph_ranges)
        font_cfg.GlyphRanges = glyph_ranges;
    return AddFont(&font_cfg);
}

ImFont* ImFontAtlas::AddFontFromMemoryCompressedTTF(const void* compressed_ttf_data, int compressed_ttf_size, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
    const unsigned int buf_decompressed_size = stb_decompress_length((const unsigned char*)compressed_ttf_data);
    unsigned char* buf_decompressed_data = (unsigned char*)IM_ALLOC(buf_decompressed_size);
    stb_decompress(buf_decompressed_data, (const unsigned char*)compressed_ttf_data, (unsigned int)compressed_ttf_size);

    ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
    IM_ASSERT(font_cfg.FontData == nullptr);
    font_cfg.FontDataOwnedByAtlas = true;
    return AddFontFromMemoryTTF(buf_decompressed_data, (int)buf_decompressed_size, size_pixels, &font_cfg, glyph_ranges);
}

ImFont* ImFontAtlas::AddFontFromMemoryCompressedBase85TTF(const char* compressed_ttf_data_base85, float size_pixels, const ImFontConfig* font_cfg, const ImWchar* glyph_ranges)
{
    int compressed_ttf_size = (((int)strlen(compressed_ttf_data_base85) + 4) / 5) * 4;
    void* compressed_ttf = IM_ALLOC((size_t)compressed_ttf_size);
    Decode85((const unsigned char*)compressed_ttf_data_base85, (unsigned char*)compressed_ttf);
    ImFont* font = AddFontFromMemoryCompressedTTF(compressed_ttf, compressed_ttf_size, size_pixels, font_cfg, glyph_ranges);
    IM_FREE(compressed_ttf);
    return font;
}

int ImFontAtlas::AddCustomRectRegular(int width, int height)
{
    IM_ASSERT(width > 0 && width <= 0xFFFF);
    IM_ASSERT(height > 0 && height <= 0xFFFF);
    ImFontAtlasCustomRect r;
    r.Width = (unsigned short)width;
    r.Height = (unsigned short)height;
    CustomRects.push_back(r);
    return CustomRects.Size - 1; // Return index
}

int ImFontAtlas::AddCustomRectFontGlyph(ImFont* font, ImWchar id, int width, int height, float advance_x, const ImVec2& offset)
{
#ifdef IMGUI_USE_WCHAR32
    IM_ASSERT(id <= IM_UNICODE_CODEPOINT_MAX);
#endif
    IM_ASSERT(font != nullptr);
    IM_ASSERT(width > 0 && width <= 0xFFFF);
    IM_ASSERT(height > 0 && height <= 0xFFFF);
    ImFontAtlasCustomRect r;
    r.Width = (unsigned short)width;
    r.Height = (unsigned short)height;
    r.GlyphID = id;
    r.GlyphAdvanceX = advance_x;
    r.GlyphOffset = offset;
    r.Font = font;
    CustomRects.push_back(r);
    return CustomRects.Size - 1; // Return index
}

void ImFontAtlas::CalcCustomRectUV(const ImFontAtlasCustomRect* rect, ImVec2* out_uv_min, ImVec2* out_uv_max) const
{
    IM_ASSERT(TexWidth > 0 && TexHeight > 0);   // Font atlas needs to be built before we can calculate UV coordinates
    IM_ASSERT(rect->IsPacked());                // Make sure the rectangle has been packed
    *out_uv_min = ImVec2((float)rect->X * TexUvScale.x, (float)rect->Y * TexUvScale.y);
    *out_uv_max = ImVec2((float)(rect->X + rect->Width) * TexUvScale.x, (float)(rect->Y + rect->Height) * TexUvScale.y);
}

bool ImFontAtlas::GetMouseCursorTexData(ImGuiMouseCursor cursor_type, ImVec2* out_offset, ImVec2* out_size, ImVec2 out_uv_border[2], ImVec2 out_uv_fill[2])
{
    if (cursor_type <= ImGuiMouseCursor_None || cursor_type >= ImGuiMouseCursor_COUNT)
        return false;
    if (Flags & ImFontAtlasFlags_NoMouseCursors)
        return false;

    IM_ASSERT(PackIdMouseCursors != -1);
    ImFontAtlasCustomRect* r = GetCustomRectByIndex(PackIdMouseCursors);
    ImVec2 pos = FONT_ATLAS_DEFAULT_TEX_CURSOR_DATA[cursor_type][0] + ImVec2((float)r->X, (float)r->Y);
    ImVec2 size = FONT_ATLAS_DEFAULT_TEX_CURSOR_DATA[cursor_type][1];
    *out_size = size;
    *out_offset = FONT_ATLAS_DEFAULT_TEX_CURSOR_DATA[cursor_type][2];
    out_uv_border[0] = (pos) * TexUvScale;
    out_uv_border[1] = (pos + size) * TexUvScale;
    pos.x += FONT_ATLAS_DEFAULT_TEX_DATA_W + 1;
    out_uv_fill[0] = (pos) * TexUvScale;
    out_uv_fill[1] = (pos + size) * TexUvScale;
    return true;
}

bool    ImFontAtlas::Build()
{
    IM_ASSERT(!Locked && "Cannot modify a locked ImFontAtlas between NewFrame() and EndFrame/Render()!");

    // Default font is none are specified
    if (ConfigData.Size == 0)
        AddFontDefault();

    // Select builder
    // - Note that we do not reassign to atlas->FontBuilderIO, since it is likely to point to static data which
    //   may mess with some hot-reloading schemes. If you need to assign to this (for dynamic selection) AND are
    //   using a hot-reloading scheme that messes up static data, store your own instance of ImFontBuilderIO somewhere
    //   and point to it instead of pointing directly to return value of the GetBuilderXXX functions.
    const ImFontBuilderIO* builder_io = FontBuilderIO;
    if (builder_io == nullptr)
    {
#ifdef IMGUI_ENABLE_FREETYPE
        builder_io = ImGuiFreeType::GetBuilderForFreeType();
#elif defined(IMGUI_ENABLE_STB_TRUETYPE)
        builder_io = ImFontAtlasGetBuilderForStbTruetype();
#else
        IM_ASSERT(0); // Invalid Build function
#endif
    }

    // Build
    return builder_io->FontBuilder_Build(this);
}

void    ImFontAtlasBuildMultiplyCalcLookupTable(unsigned char out_table[256], float in_brighten_factor)
{
    for (unsigned int i = 0; i < 256; i++)
    {
        unsigned int value = (unsigned int)(i * in_brighten_factor);
        out_table[i] = value > 255 ? 255 : (value & 0xFF);
    }
}

void    ImFontAtlasBuildMultiplyRectAlpha8(const unsigned char table[256], unsigned char* pixels, int x, int y, int w, int h, int stride)
{
    unsigned char* data = pixels + x + y * stride;
    for (int j = h; j > 0; j--, data += stride)
        for (int i = 0; i < w; i++)
            data[i] = table[data[i]];
}

#ifdef IMGUI_ENABLE_STB_TRUETYPE
// Temporary data for one source font (multiple source fonts can be merged into one destination ImFont)
// (C++03 doesn't allow instancing ImVector<> with function-local types so we declare the type here.)
struct ImFontBuildSrcData
{
    stbtt_fontinfo      FontInfo;
    stbtt_pack_range    PackRange;          // Hold the list of codepoints to pack (essentially points to Codepoints.Data)
    stbrp_rect*         Rects;              // Rectangle to pack. We first fill in their size and the packer will give us their position.
    stbtt_packedchar*   PackedChars;        // Output glyphs
    const ImWchar*      SrcRanges;          // Ranges as requested by user (user is allowed to request too much, e.g. 0x0020..0xFFFF)
    int                 DstIndex;           // Index into atlas->Fonts[] and dst_tmp_array[]
    int                 GlyphsHighest;      // Highest requested codepoint
    int                 GlyphsCount;        // Glyph count (excluding missing glyphs and glyphs already set by an earlier source font)
    ImBitVector         GlyphsSet;          // Glyph bit map (random access, 1-bit per codepoint. This will be a maximum of 8KB)
    ImVector<int>       GlyphsList;         // Glyph codepoints list (flattened version of GlyphsMap)
};

// Temporary data for one destination ImFont* (multiple source fonts can be merged into one destination ImFont)
struct ImFontBuildDstData
{
    int                 SrcCount;           // Number of source fonts targeting this destination font.
    int                 GlyphsHighest;
    int                 GlyphsCount;
    ImBitVector         GlyphsSet;          // This is used to resolve collision when multiple sources are merged into a same destination font.
};

static void UnpackBitVectorToFlatIndexList(const ImBitVector* in, ImVector<int>* out)
{
    IM_ASSERT(sizeof(in->Storage.Data[0]) == sizeof(int));
    const ImU32* it_begin = in->Storage.begin();
    const ImU32* it_end = in->Storage.end();
    for (const ImU32* it = it_begin; it < it_end; it++)
        if (ImU32 entries_32 = *it)
            for (ImU32 bit_n = 0; bit_n < 32; bit_n++)
                if (entries_32 & ((ImU32)1 << bit_n))
                    out->push_back((int)(((it - it_begin) << 5) + bit_n));
}

static bool ImFontAtlasBuildWithStbTruetype(ImFontAtlas* atlas)
{
    IM_ASSERT(atlas->ConfigData.Size > 0);

    ImFontAtlasBuildInit(atlas);

    // Clear atlas
    atlas->TexID = (ImTextureID)nullptr;
    atlas->TexWidth = atlas->TexHeight = 0;
    atlas->TexUvScale = ImVec2(0.0f, 0.0f);
    atlas->TexUvWhitePixel = ImVec2(0.0f, 0.0f);
    atlas->ClearTexData();

    // Temporary storage for building
    ImVector<ImFontBuildSrcData> src_tmp_array;
    ImVector<ImFontBuildDstData> dst_tmp_array;
    src_tmp_array.resize(atlas->ConfigData.Size);
    dst_tmp_array.resize(atlas->Fonts.Size);
    memset(src_tmp_array.Data, 0, (size_t)src_tmp_array.size_in_bytes());
    memset(dst_tmp_array.Data, 0, (size_t)dst_tmp_array.size_in_bytes());

    // 1. Initialize font loading structure, check font data validity
    for (int src_i = 0; src_i < atlas->ConfigData.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        IM_ASSERT(cfg.DstFont && (!cfg.DstFont->IsLoaded() || cfg.DstFont->ContainerAtlas == atlas));

        // Find index from cfg.DstFont (we allow the user to set cfg.DstFont. Also it makes casual debugging nicer than when storing indices)
        src_tmp.DstIndex = -1;
        for (int output_i = 0; output_i < atlas->Fonts.Size && src_tmp.DstIndex == -1; output_i++)
            if (cfg.DstFont == atlas->Fonts[output_i])
                src_tmp.DstIndex = output_i;
        if (src_tmp.DstIndex == -1)
        {
            IM_ASSERT(src_tmp.DstIndex != -1); // cfg.DstFont not pointing within atlas->Fonts[] array?
            return false;
        }
        // Initialize helper structure for font loading and verify that the TTF/OTF data is correct
        const int font_offset = stbtt_GetFontOffsetForIndex((unsigned char*)cfg.FontData, cfg.FontNo);
        IM_ASSERT(font_offset >= 0 && "FontData is incorrect, or FontNo cannot be found.");
        if (!stbtt_InitFont(&src_tmp.FontInfo, (unsigned char*)cfg.FontData, font_offset))
            return false;

        // Measure highest codepoints
        ImFontBuildDstData& dst_tmp = dst_tmp_array[src_tmp.DstIndex];
        src_tmp.SrcRanges = cfg.GlyphRanges ? cfg.GlyphRanges : atlas->GetGlyphRangesDefault();
        for (const ImWchar* src_range = src_tmp.SrcRanges; src_range[0] && src_range[1]; src_range += 2)
            src_tmp.GlyphsHighest = ImMax(src_tmp.GlyphsHighest, (int)src_range[1]);
        dst_tmp.SrcCount++;
        dst_tmp.GlyphsHighest = ImMax(dst_tmp.GlyphsHighest, src_tmp.GlyphsHighest);
    }

    // 2. For every requested codepoint, check for their presence in the font data, and handle redundancy or overlaps between source fonts to avoid unused glyphs.
    int total_glyphs_count = 0;
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        ImFontBuildDstData& dst_tmp = dst_tmp_array[src_tmp.DstIndex];
        src_tmp.GlyphsSet.Create(src_tmp.GlyphsHighest + 1);
        if (dst_tmp.GlyphsSet.Storage.empty())
            dst_tmp.GlyphsSet.Create(dst_tmp.GlyphsHighest + 1);

        for (const ImWchar* src_range = src_tmp.SrcRanges; src_range[0] && src_range[1]; src_range += 2)
            for (unsigned int codepoint = src_range[0]; codepoint <= src_range[1]; codepoint++)
            {
                if (dst_tmp.GlyphsSet.TestBit(codepoint))    // Don't overwrite existing glyphs. We could make this an option for MergeMode (e.g. MergeOverwrite==true)
                    continue;
                if (!stbtt_FindGlyphIndex(&src_tmp.FontInfo, codepoint))    // It is actually in the font?
                    continue;

                // Add to avail set/counters
                src_tmp.GlyphsCount++;
                dst_tmp.GlyphsCount++;
                src_tmp.GlyphsSet.SetBit(codepoint);
                dst_tmp.GlyphsSet.SetBit(codepoint);
                total_glyphs_count++;
            }
    }

    // 3. Unpack our bit map into a flat list (we now have all the Unicode points that we know are requested _and_ available _and_ not overlapping another)
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        src_tmp.GlyphsList.reserve(src_tmp.GlyphsCount);
        UnpackBitVectorToFlatIndexList(&src_tmp.GlyphsSet, &src_tmp.GlyphsList);
        src_tmp.GlyphsSet.Clear();
        IM_ASSERT(src_tmp.GlyphsList.Size == src_tmp.GlyphsCount);
    }
    for (int dst_i = 0; dst_i < dst_tmp_array.Size; dst_i++)
        dst_tmp_array[dst_i].GlyphsSet.Clear();
    dst_tmp_array.clear();

    // Allocate packing character data and flag packed characters buffer as non-packed (x0=y0=x1=y1=0)
    // (We technically don't need to zero-clear buf_rects, but let's do it for the sake of sanity)
    ImVector<stbrp_rect> buf_rects;
    ImVector<stbtt_packedchar> buf_packedchars;
    buf_rects.resize(total_glyphs_count);
    buf_packedchars.resize(total_glyphs_count);
    memset(buf_rects.Data, 0, (size_t)buf_rects.size_in_bytes());
    memset(buf_packedchars.Data, 0, (size_t)buf_packedchars.size_in_bytes());

    // 4. Gather glyphs sizes so we can pack them in our virtual canvas.
    int total_surface = 0;
    int buf_rects_out_n = 0;
    int buf_packedchars_out_n = 0;
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        src_tmp.Rects = &buf_rects[buf_rects_out_n];
        src_tmp.PackedChars = &buf_packedchars[buf_packedchars_out_n];
        buf_rects_out_n += src_tmp.GlyphsCount;
        buf_packedchars_out_n += src_tmp.GlyphsCount;

        // Convert our ranges in the format stb_truetype wants
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        src_tmp.PackRange.font_size = cfg.SizePixels;
        src_tmp.PackRange.first_unicode_codepoint_in_range = 0;
        src_tmp.PackRange.array_of_unicode_codepoints = src_tmp.GlyphsList.Data;
        src_tmp.PackRange.num_chars = src_tmp.GlyphsList.Size;
        src_tmp.PackRange.chardata_for_range = src_tmp.PackedChars;
        src_tmp.PackRange.h_oversample = (unsigned char)cfg.OversampleH;
        src_tmp.PackRange.v_oversample = (unsigned char)cfg.OversampleV;

        // Gather the sizes of all rectangles we will need to pack (this loop is based on stbtt_PackFontRangesGatherRects)
        const float scale = (cfg.SizePixels > 0) ? stbtt_ScaleForPixelHeight(&src_tmp.FontInfo, cfg.SizePixels) : stbtt_ScaleForMappingEmToPixels(&src_tmp.FontInfo, -cfg.SizePixels);
        const int padding = atlas->TexGlyphPadding;
        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsList.Size; glyph_i++)
        {
            int x0, y0, x1, y1;
            const int glyph_index_in_font = stbtt_FindGlyphIndex(&src_tmp.FontInfo, src_tmp.GlyphsList[glyph_i]);
            IM_ASSERT(glyph_index_in_font != 0);
            stbtt_GetGlyphBitmapBoxSubpixel(&src_tmp.FontInfo, glyph_index_in_font, scale * cfg.OversampleH, scale * cfg.OversampleV, 0, 0, &x0, &y0, &x1, &y1);
            src_tmp.Rects[glyph_i].w = (stbrp_coord)(x1 - x0 + padding + cfg.OversampleH - 1);
            src_tmp.Rects[glyph_i].h = (stbrp_coord)(y1 - y0 + padding + cfg.OversampleV - 1);
            total_surface += src_tmp.Rects[glyph_i].w * src_tmp.Rects[glyph_i].h;
        }
    }

    // We need a width for the skyline algorithm, any width!
    // The exact width doesn't really matter much, but some API/GPU have texture size limitations and increasing width can decrease height.
    // User can override TexDesiredWidth and TexGlyphPadding if they wish, otherwise we use a simple heuristic to select the width based on expected surface.
    const int surface_sqrt = (int)ImSqrt((float)total_surface) + 1;
    atlas->TexHeight = 0;
    if (atlas->TexDesiredWidth > 0)
        atlas->TexWidth = atlas->TexDesiredWidth;
    else
        atlas->TexWidth = (surface_sqrt >= 4096 * 0.7f) ? 4096 : (surface_sqrt >= 2048 * 0.7f) ? 2048 : (surface_sqrt >= 1024 * 0.7f) ? 1024 : 512;

    // 5. Start packing
    // Pack our extra data rectangles first, so it will be on the upper-left corner of our texture (UV will have small values).
    const int TEX_HEIGHT_MAX = 1024 * 32;
    stbtt_pack_context spc = {};
    stbtt_PackBegin(&spc, nullptr, atlas->TexWidth, TEX_HEIGHT_MAX, 0, atlas->TexGlyphPadding, nullptr);
    ImFontAtlasBuildPackCustomRects(atlas, spc.pack_info);

    // 6. Pack each source font. No rendering yet, we are working with rectangles in an infinitely tall texture at this point.
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        stbrp_pack_rects((stbrp_context*)spc.pack_info, src_tmp.Rects, src_tmp.GlyphsCount);

        // Extend texture height and mark missing glyphs as non-packed so we won't render them.
        // FIXME: We are not handling packing failure here (would happen if we got off TEX_HEIGHT_MAX or if a single if larger than TexWidth?)
        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsCount; glyph_i++)
            if (src_tmp.Rects[glyph_i].was_packed)
                atlas->TexHeight = ImMax(atlas->TexHeight, src_tmp.Rects[glyph_i].y + src_tmp.Rects[glyph_i].h);
    }

    // 7. Allocate texture
    atlas->TexHeight = (atlas->Flags & ImFontAtlasFlags_NoPowerOfTwoHeight) ? (atlas->TexHeight + 1) : ImUpperPowerOfTwo(atlas->TexHeight);
    atlas->TexUvScale = ImVec2(1.0f / atlas->TexWidth, 1.0f / atlas->TexHeight);
    atlas->TexPixelsAlpha8 = (unsigned char*)IM_ALLOC(atlas->TexWidth * atlas->TexHeight);
    memset(atlas->TexPixelsAlpha8, 0, atlas->TexWidth * atlas->TexHeight);
    spc.pixels = atlas->TexPixelsAlpha8;
    spc.height = atlas->TexHeight;

    // 8. Render/rasterize font characters into the texture
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        stbtt_PackFontRangesRenderIntoRects(&spc, &src_tmp.FontInfo, &src_tmp.PackRange, 1, src_tmp.Rects);

        // Apply multiply operator
        if (cfg.RasterizerMultiply != 1.0f)
        {
            unsigned char multiply_table[256];
            ImFontAtlasBuildMultiplyCalcLookupTable(multiply_table, cfg.RasterizerMultiply);
            stbrp_rect* r = &src_tmp.Rects[0];
            for (int glyph_i = 0; glyph_i < src_tmp.GlyphsCount; glyph_i++, r++)
                if (r->was_packed)
                    ImFontAtlasBuildMultiplyRectAlpha8(multiply_table, atlas->TexPixelsAlpha8, r->x, r->y, r->w, r->h, atlas->TexWidth * 1);
        }
        src_tmp.Rects = nullptr;
    }

    // End packing
    stbtt_PackEnd(&spc);
    buf_rects.clear();

    // 9. Setup ImFont and glyphs for runtime
    for (int src_i = 0; src_i < src_tmp_array.Size; src_i++)
    {
        ImFontBuildSrcData& src_tmp = src_tmp_array[src_i];
        if (src_tmp.GlyphsCount == 0)
            continue;

        // When merging fonts with MergeMode=true:
        // - We can have multiple input fonts writing into a same destination font.
        // - dst_font->ConfigData is != from cfg which is our source configuration.
        ImFontConfig& cfg = atlas->ConfigData[src_i];
        ImFont* dst_font = cfg.DstFont;

        const float font_scale = stbtt_ScaleForPixelHeight(&src_tmp.FontInfo, cfg.SizePixels);
        int unscaled_ascent, unscaled_descent, unscaled_line_gap;
        stbtt_GetFontVMetrics(&src_tmp.FontInfo, &unscaled_ascent, &unscaled_descent, &unscaled_line_gap);

        const float ascent = ImFloor(unscaled_ascent * font_scale + ((unscaled_ascent > 0.0f) ? +1 : -1));
        const float descent = ImFloor(unscaled_descent * font_scale + ((unscaled_descent > 0.0f) ? +1 : -1));
        ImFontAtlasBuildSetupFont(atlas, dst_font, &cfg, ascent, descent);
        const float font_off_x = cfg.GlyphOffset.x;
        const float font_off_y = cfg.GlyphOffset.y + IM_ROUND(dst_font->Ascent);

        for (int glyph_i = 0; glyph_i < src_tmp.GlyphsCount; glyph_i++)
        {
            // Register glyph
            const int codepoint = src_tmp.GlyphsList[glyph_i];
            const stbtt_packedchar& pc = src_tmp.PackedChars[glyph_i];
            stbtt_aligned_quad q;
            float unused_x = 0.0f, unused_y = 0.0f;
            stbtt_GetPackedQuad(src_tmp.PackedChars, atlas->TexWidth, atlas->TexHeight, glyph_i, &unused_x, &unused_y, &q, 0);
            dst_font->AddGlyph(&cfg, (ImWchar)codepoint, q.x0 + font_off_x, q.y0 + font_off_y, q.x1 + font_off_x, q.y1 + font_off_y, q.s0, q.t0, q.s1, q.t1, pc.xadvance);
        }
    }

    // Cleanup
    src_tmp_array.clear_destruct();

    ImFontAtlasBuildFinish(atlas);
    return true;
}

const ImFontBuilderIO* ImFontAtlasGetBuilderForStbTruetype()
{
    static ImFontBuilderIO io;
    io.FontBuilder_Build = ImFontAtlasBuildWithStbTruetype;
    return &io;
}

#endif // IMGUI_ENABLE_STB_TRUETYPE

void ImFontAtlasBuildSetupFont(ImFontAtlas* atlas, ImFont* font, ImFontConfig* font_config, float ascent, float descent)
{
    if (!font_config->MergeMode)
    {
        font->ClearOutputData();
        font->FontSize = font_config->SizePixels;
        font->ConfigData = font_config;
        font->ConfigDataCount = 0;
        font->ContainerAtlas = atlas;
        font->Ascent = ascent;
        font->Descent = descent;
    }
    font->ConfigDataCount++;
}

void ImFontAtlasBuildPackCustomRects(ImFontAtlas* atlas, void* stbrp_context_opaque)
{
    stbrp_context* pack_context = (stbrp_context*)stbrp_context_opaque;
    IM_ASSERT(pack_context != nullptr);

    ImVector<ImFontAtlasCustomRect>& user_rects = atlas->CustomRects;
    IM_ASSERT(user_rects.Size >= 1); // We expect at least the default custom rects to be registered, else something went wrong.

    ImVector<stbrp_rect> pack_rects;
    pack_rects.resize(user_rects.Size);
    memset(pack_rects.Data, 0, (size_t)pack_rects.size_in_bytes());
    for (int i = 0; i < user_rects.Size; i++)
    {
        pack_rects[i].w = user_rects[i].Width;
        pack_rects[i].h = user_rects[i].Height;
    }
    stbrp_pack_rects(pack_context, &pack_rects[0], pack_rects.Size);
    for (int i = 0; i < pack_rects.Size; i++)
        if (pack_rects[i].was_packed)
        {
            user_rects[i].X = pack_rects[i].x;
            user_rects[i].Y = pack_rects[i].y;
            IM_ASSERT(pack_rects[i].w == user_rects[i].Width && pack_rects[i].h == user_rects[i].Height);
            atlas->TexHeight = ImMax(atlas->TexHeight, pack_rects[i].y + pack_rects[i].h);
        }
}

void ImFontAtlasBuildRender8bppRectFromString(ImFontAtlas* atlas, int x, int y, int w, int h, const char* in_str, char in_marker_char, unsigned char in_marker_pixel_value)
{
    IM_ASSERT(x >= 0 && x + w <= atlas->TexWidth);
    IM_ASSERT(y >= 0 && y + h <= atlas->TexHeight);
    unsigned char* out_pixel = atlas->TexPixelsAlpha8 + x + (y * atlas->TexWidth);
    for (int off_y = 0; off_y < h; off_y++, out_pixel += atlas->TexWidth, in_str += w)
        for (int off_x = 0; off_x < w; off_x++)
            out_pixel[off_x] = (in_str[off_x] == in_marker_char) ? in_marker_pixel_value : 0x00;
}

void ImFontAtlasBuildRender32bppRectFromString(ImFontAtlas* atlas, int x, int y, int w, int h, const char* in_str, char in_marker_char, unsigned int in_marker_pixel_value)
{
    IM_ASSERT(x >= 0 && x + w <= atlas->TexWidth);
    IM_ASSERT(y >= 0 && y + h <= atlas->TexHeight);
    unsigned int* out_pixel = atlas->TexPixelsRGBA32 + x + (y * atlas->TexWidth);
    for (int off_y = 0; off_y < h; off_y++, out_pixel += atlas->TexWidth, in_str += w)
        for (int off_x = 0; off_x < w; off_x++)
            out_pixel[off_x] = (in_str[off_x] == in_marker_char) ? in_marker_pixel_value : IM_COL32_BLACK_TRANS;
}

static void ImFontAtlasBuildRenderDefaultTexData(ImFontAtlas* atlas)
{
    ImFontAtlasCustomRect* r = atlas->GetCustomRectByIndex(atlas->PackIdMouseCursors);
    IM_ASSERT(r->IsPacked());

    const int w = atlas->TexWidth;
    if (!(atlas->Flags & ImFontAtlasFlags_NoMouseCursors))
    {
        // Render/copy pixels
        IM_ASSERT(r->Width == FONT_ATLAS_DEFAULT_TEX_DATA_W * 2 + 1 && r->Height == FONT_ATLAS_DEFAULT_TEX_DATA_H);
        const int x_for_white = r->X;
        const int x_for_black = r->X + FONT_ATLAS_DEFAULT_TEX_DATA_W + 1;
        if (atlas->TexPixelsAlpha8 != nullptr)
        {
            ImFontAtlasBuildRender8bppRectFromString(atlas, x_for_white, r->Y, FONT_ATLAS_DEFAULT_TEX_DATA_W, FONT_ATLAS_DEFAULT_TEX_DATA_H, FONT_ATLAS_DEFAULT_TEX_DATA_PIXELS, '.', 0xFF);
            ImFontAtlasBuildRender8bppRectFromString(atlas, x_for_black, r->Y, FONT_ATLAS_DEFAULT_TEX_DATA_W, FONT_ATLAS_DEFAULT_TEX_DATA_H, FONT_ATLAS_DEFAULT_TEX_DATA_PIXELS, 'X', 0xFF);
        }
        else
        {
            ImFontAtlasBuildRender32bppRectFromString(atlas, x_for_white, r->Y, FONT_ATLAS_DEFAULT_TEX_DATA_W, FONT_ATLAS_DEFAULT_TEX_DATA_H, FONT_ATLAS_DEFAULT_TEX_DATA_PIXELS, '.', IM_COL32_WHITE);
            ImFontAtlasBuildRender32bppRectFromString(atlas, x_for_black, r->Y, FONT_ATLAS_DEFAULT_TEX_DATA_W, FONT_ATLAS_DEFAULT_TEX_DATA_H, FONT_ATLAS_DEFAULT_TEX_DATA_PIXELS, 'X', IM_COL32_WHITE);
        }
    }
    else
    {
        // Render 4 white pixels
        IM_ASSERT(r->Width == 2 && r->Height == 2);
        const int offset = (int)r->X + (int)r->Y * w;
        if (atlas->TexPixelsAlpha8 != nullptr)
        {
            atlas->TexPixelsAlpha8[offset] = atlas->TexPixelsAlpha8[offset + 1] = atlas->TexPixelsAlpha8[offset + w] = atlas->TexPixelsAlpha8[offset + w + 1] = 0xFF;
        }
        else
        {
            atlas->TexPixelsRGBA32[offset] = atlas->TexPixelsRGBA32[offset + 1] = atlas->TexPixelsRGBA32[offset + w] = atlas->TexPixelsRGBA32[offset + w + 1] = IM_COL32_WHITE;
        }
    }
    atlas->TexUvWhitePixel = ImVec2((r->X + 0.5f) * atlas->TexUvScale.x, (r->Y + 0.5f) * atlas->TexUvScale.y);
}

static void ImFontAtlasBuildRenderLinesTexData(ImFontAtlas* atlas)
{
    if (atlas->Flags & ImFontAtlasFlags_NoBakedLines)
        return;

    // This generates a triangular shape in the texture, with the various line widths stacked on top of each other to allow interpolation between them
    ImFontAtlasCustomRect* r = atlas->GetCustomRectByIndex(atlas->PackIdLines);
    IM_ASSERT(r->IsPacked());
    for (unsigned int n = 0; n < IM_DRAWLIST_TEX_LINES_WIDTH_MAX + 1; n++) // +1 because of the zero-width row
    {
        // Each line consists of at least two empty pixels at the ends, with a line of solid pixels in the middle
        unsigned int y = n;
        unsigned int line_width = n;
        unsigned int pad_left = (r->Width - line_width) / 2;
        unsigned int pad_right = r->Width - (pad_left + line_width);

        // Write each slice
        IM_ASSERT(pad_left + line_width + pad_right == r->Width && y < r->Height); // Make sure we're inside the texture bounds before we start writing pixels
        if (atlas->TexPixelsAlpha8 != nullptr)
        {
            unsigned char* write_ptr = &atlas->TexPixelsAlpha8[r->X + ((r->Y + y) * atlas->TexWidth)];
            for (unsigned int i = 0; i < pad_left; i++)
                *(write_ptr + i) = 0x00;

            for (unsigned int i = 0; i < line_width; i++)
                *(write_ptr + pad_left + i) = 0xFF;

            for (unsigned int i = 0; i < pad_right; i++)
                *(write_ptr + pad_left + line_width + i) = 0x00;
        }
        else
        {
            unsigned int* write_ptr = &atlas->TexPixelsRGBA32[r->X + ((r->Y + y) * atlas->TexWidth)];
            for (unsigned int i = 0; i < pad_left; i++)
                *(write_ptr + i) = IM_COL32_BLACK_TRANS;

            for (unsigned int i = 0; i < line_width; i++)
                *(write_ptr + pad_left + i) = IM_COL32_WHITE;

            for (unsigned int i = 0; i < pad_right; i++)
                *(write_ptr + pad_left + line_width + i) = IM_COL32_BLACK_TRANS;
        }

        // Calculate UVs for this line
        ImVec2 uv0 = ImVec2((float)(r->X + pad_left - 1), (float)(r->Y + y)) * atlas->TexUvScale;
        ImVec2 uv1 = ImVec2((float)(r->X + pad_left + line_width + 1), (float)(r->Y + y + 1)) * atlas->TexUvScale;
        float half_v = (uv0.y + uv1.y) * 0.5f; // Calculate a constant V in the middle of the row to avoid sampling artifacts
        atlas->TexUvLines[n] = ImVec4(uv0.x, half_v, uv1.x, half_v);
    }
}

// Note: this is called / shared by both the stb_truetype and the FreeType builder
void ImFontAtlasBuildInit(ImFontAtlas* atlas)
{
    // Register texture region for mouse cursors or standard white pixels
    if (atlas->PackIdMouseCursors < 0)
    {
        if (!(atlas->Flags & ImFontAtlasFlags_NoMouseCursors))
            atlas->PackIdMouseCursors = atlas->AddCustomRectRegular(FONT_ATLAS_DEFAULT_TEX_DATA_W * 2 + 1, FONT_ATLAS_DEFAULT_TEX_DATA_H);
        else
            atlas->PackIdMouseCursors = atlas->AddCustomRectRegular(2, 2);
    }

    // Register texture region for thick lines
    // The +2 here is to give space for the end caps, whilst height +1 is to accommodate the fact we have a zero-width row
    if (atlas->PackIdLines < 0)
    {
        if (!(atlas->Flags & ImFontAtlasFlags_NoBakedLines))
            atlas->PackIdLines = atlas->AddCustomRectRegular(IM_DRAWLIST_TEX_LINES_WIDTH_MAX + 2, IM_DRAWLIST_TEX_LINES_WIDTH_MAX + 1);
    }
}

// This is called/shared by both the stb_truetype and the FreeType builder.
void ImFontAtlasBuildFinish(ImFontAtlas* atlas)
{
    // Render into our custom data blocks
    IM_ASSERT(atlas->TexPixelsAlpha8 != nullptr || atlas->TexPixelsRGBA32 != nullptr);
    ImFontAtlasBuildRenderDefaultTexData(atlas);
    ImFontAtlasBuildRenderLinesTexData(atlas);

    // Register custom rectangle glyphs
    for (int i = 0; i < atlas->CustomRects.Size; i++)
    {
        const ImFontAtlasCustomRect* r = &atlas->CustomRects[i];
        if (r->Font == nullptr || r->GlyphID == 0)
            continue;

        // Will ignore ImFontConfig settings: GlyphMinAdvanceX, GlyphMinAdvanceY, GlyphExtraSpacing, PixelSnapH
        IM_ASSERT(r->Font->ContainerAtlas == atlas);
        ImVec2 uv0, uv1;
        atlas->CalcCustomRectUV(r, &uv0, &uv1);
        r->Font->AddGlyph(nullptr, (ImWchar)r->GlyphID, r->GlyphOffset.x, r->GlyphOffset.y, r->GlyphOffset.x + r->Width, r->GlyphOffset.y + r->Height, uv0.x, uv0.y, uv1.x, uv1.y, r->GlyphAdvanceX);
    }

    // Build all fonts lookup tables
    for (int i = 0; i < atlas->Fonts.Size; i++)
        if (atlas->Fonts[i]->DirtyLookupTables)
            atlas->Fonts[i]->BuildLookupTable();

    atlas->TexReady = true;
}

// Retrieve list of range (2 int per range, values are inclusive)
const ImWchar*   ImFontAtlas::GetGlyphRangesDefault()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0,
    };
    return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesKorean()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x3131, 0x3163, // Korean alphabets
        0xAC00, 0xD7A3, // Korean characters
        0xFFFD, 0xFFFD, // Invalid
        0,
    };
    return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesChineseFull()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x2000, 0x206F, // General Punctuation
        0x3000, 0x30FF, // CJK Symbols and Punctuations, Hiragana, Katakana
        0x31F0, 0x31FF, // Katakana Phonetic Extensions
        0xFF00, 0xFFEF, // Half-width characters
        0xFFFD, 0xFFFD, // Invalid
        0x4e00, 0x9FAF, // CJK Ideograms
        0,
    };
    return &ranges[0];
}

static void UnpackAccumulativeOffsetsIntoRanges(int base_codepoint, const short* accumulative_offsets, int accumulative_offsets_count, ImWchar* out_ranges)
{
    for (int n = 0; n < accumulative_offsets_count; n++, out_ranges += 2)
    {
        out_ranges[0] = out_ranges[1] = (ImWchar)(base_codepoint + accumulative_offsets[n]);
        base_codepoint += accumulative_offsets[n];
    }
    out_ranges[0] = 0;
}

//-------------------------------------------------------------------------
// [SECTION] ImFontAtlas glyph ranges helpers
//-------------------------------------------------------------------------

const ImWchar*  ImFontAtlas::GetGlyphRangesChineseSimplifiedCommon()
{
    // Store 2500 regularly used characters for Simplified Chinese.
    // Sourced from https://zh.wiktionary.org/wiki/%E9%99%84%E5%BD%95:%E7%8E%B0%E4%BB%A3%E6%B1%89%E8%AF%AD%E5%B8%B8%E7%94%A8%E5%AD%97%E8%A1%A8
    // This table covers 97.97% of all characters used during the month in July, 1987.
    // You can use ImFontGlyphRangesBuilder to create your own ranges derived from this, by merging existing ranges or adding new characters.
    // (Stored as accumulative offsets from the initial unicode codepoint 0x4E00. This encoding is designed to helps us compact the source code size.)
    static const short accumulative_offsets_from_0x4E00[] =
    {
        0,1,2,4,1,1,1,1,2,1,3,2,1,2,2,1,1,1,1,1,5,2,1,2,3,3,3,2,2,4,1,1,1,2,1,5,2,3,1,2,1,2,1,1,2,1,1,2,2,1,4,1,1,1,1,5,10,1,2,19,2,1,2,1,2,1,2,1,2,
        1,5,1,6,3,2,1,2,2,1,1,1,4,8,5,1,1,4,1,1,3,1,2,1,5,1,2,1,1,1,10,1,1,5,2,4,6,1,4,2,2,2,12,2,1,1,6,1,1,1,4,1,1,4,6,5,1,4,2,2,4,10,7,1,1,4,2,4,
        2,1,4,3,6,10,12,5,7,2,14,2,9,1,1,6,7,10,4,7,13,1,5,4,8,4,1,1,2,28,5,6,1,1,5,2,5,20,2,2,9,8,11,2,9,17,1,8,6,8,27,4,6,9,20,11,27,6,68,2,2,1,1,
        1,2,1,2,2,7,6,11,3,3,1,1,3,1,2,1,1,1,1,1,3,1,1,8,3,4,1,5,7,2,1,4,4,8,4,2,1,2,1,1,4,5,6,3,6,2,12,3,1,3,9,2,4,3,4,1,5,3,3,1,3,7,1,5,1,1,1,1,2,
        3,4,5,2,3,2,6,1,1,2,1,7,1,7,3,4,5,15,2,2,1,5,3,22,19,2,1,1,1,1,2,5,1,1,1,6,1,1,12,8,2,9,18,22,4,1,1,5,1,16,1,2,7,10,15,1,1,6,2,4,1,2,4,1,6,
        1,1,3,2,4,1,6,4,5,1,2,1,1,2,1,10,3,1,3,2,1,9,3,2,5,7,2,19,4,3,6,1,1,1,1,1,4,3,2,1,1,1,2,5,3,1,1,1,2,2,1,1,2,1,1,2,1,3,1,1,1,3,7,1,4,1,1,2,1,
        1,2,1,2,4,4,3,8,1,1,1,2,1,3,5,1,3,1,3,4,6,2,2,14,4,6,6,11,9,1,15,3,1,28,5,2,5,5,3,1,3,4,5,4,6,14,3,2,3,5,21,2,7,20,10,1,2,19,2,4,28,28,2,3,
        2,1,14,4,1,26,28,42,12,40,3,52,79,5,14,17,3,2,2,11,3,4,6,3,1,8,2,23,4,5,8,10,4,2,7,3,5,1,1,6,3,1,2,2,2,5,28,1,1,7,7,20,5,3,29,3,17,26,1,8,4,
        27,3,6,11,23,5,3,4,6,13,24,16,6,5,10,25,35,7,3,2,3,3,14,3,6,2,6,1,4,2,3,8,2,1,1,3,3,3,4,1,1,13,2,2,4,5,2,1,14,14,1,2,2,1,4,5,2,3,1,14,3,12,
        3,17,2,16,5,1,2,1,8,9,3,19,4,2,2,4,17,25,21,20,28,75,1,10,29,103,4,1,2,1,1,4,2,4,1,2,3,24,2,2,2,1,1,2,1,3,8,1,1,1,2,1,1,3,1,1,1,6,1,5,3,1,1,
        1,3,4,1,1,5,2,1,5,6,13,9,16,1,1,1,1,3,2,3,2,4,5,2,5,2,2,3,7,13,7,2,2,1,1,1,1,2,3,3,2,1,6,4,9,2,1,14,2,14,2,1,18,3,4,14,4,11,41,15,23,15,23,
        176,1,3,4,1,1,1,1,5,3,1,2,3,7,3,1,1,2,1,2,4,4,6,2,4,1,9,7,1,10,5,8,16,29,1,1,2,2,3,1,3,5,2,4,5,4,1,1,2,2,3,3,7,1,6,10,1,17,1,44,4,6,2,1,1,6,
        5,4,2,10,1,6,9,2,8,1,24,1,2,13,7,8,8,2,1,4,1,3,1,3,3,5,2,5,10,9,4,9,12,2,1,6,1,10,1,1,7,7,4,10,8,3,1,13,4,3,1,6,1,3,5,2,1,2,17,16,5,2,16,6,
        1,4,2,1,3,3,6,8,5,11,11,1,3,3,2,4,6,10,9,5,7,4,7,4,7,1,1,4,2,1,3,6,8,7,1,6,11,5,5,3,24,9,4,2,7,13,5,1,8,82,16,61,1,1,1,4,2,2,16,10,3,8,1,1,
        6,4,2,1,3,1,1,1,4,3,8,4,2,2,1,1,1,1,1,6,3,5,1,1,4,6,9,2,1,1,1,2,1,7,2,1,6,1,5,4,4,3,1,8,1,3,3,1,3,2,2,2,2,3,1,6,1,2,1,2,1,3,7,1,8,2,1,2,1,5,
        2,5,3,5,10,1,2,1,1,3,2,5,11,3,9,3,5,1,1,5,9,1,2,1,5,7,9,9,8,1,3,3,3,6,8,2,3,2,1,1,32,6,1,2,15,9,3,7,13,1,3,10,13,2,14,1,13,10,2,1,3,10,4,15,
        2,15,15,10,1,3,9,6,9,32,25,26,47,7,3,2,3,1,6,3,4,3,2,8,5,4,1,9,4,2,2,19,10,6,2,3,8,1,2,2,4,2,1,9,4,4,4,6,4,8,9,2,3,1,1,1,1,3,5,5,1,3,8,4,6,
        2,1,4,12,1,5,3,7,13,2,5,8,1,6,1,2,5,14,6,1,5,2,4,8,15,5,1,23,6,62,2,10,1,1,8,1,2,2,10,4,2,2,9,2,1,1,3,2,3,1,5,3,3,2,1,3,8,1,1,1,11,3,1,1,4,
        3,7,1,14,1,2,3,12,5,2,5,1,6,7,5,7,14,11,1,3,1,8,9,12,2,1,11,8,4,4,2,6,10,9,13,1,1,3,1,5,1,3,2,4,4,1,18,2,3,14,11,4,29,4,2,7,1,3,13,9,2,2,5,
        3,5,20,7,16,8,5,72,34,6,4,22,12,12,28,45,36,9,7,39,9,191,1,1,1,4,11,8,4,9,2,3,22,1,1,1,1,4,17,1,7,7,1,11,31,10,2,4,8,2,3,2,1,4,2,16,4,32,2,
        3,19,13,4,9,1,5,2,14,8,1,1,3,6,19,6,5,1,16,6,2,10,8,5,1,2,3,1,5,5,1,11,6,6,1,3,3,2,6,3,8,1,1,4,10,7,5,7,7,5,8,9,2,1,3,4,1,1,3,1,3,3,2,6,16,
        1,4,6,3,1,10,6,1,3,15,2,9,2,10,25,13,9,16,6,2,2,10,11,4,3,9,1,2,6,6,5,4,30,40,1,10,7,12,14,33,6,3,6,7,3,1,3,1,11,14,4,9,5,12,11,49,18,51,31,
        140,31,2,2,1,5,1,8,1,10,1,4,4,3,24,1,10,1,3,6,6,16,3,4,5,2,1,4,2,57,10,6,22,2,22,3,7,22,6,10,11,36,18,16,33,36,2,5,5,1,1,1,4,10,1,4,13,2,7,
        5,2,9,3,4,1,7,43,3,7,3,9,14,7,9,1,11,1,1,3,7,4,18,13,1,14,1,3,6,10,73,2,2,30,6,1,11,18,19,13,22,3,46,42,37,89,7,3,16,34,2,2,3,9,1,7,1,1,1,2,
        2,4,10,7,3,10,3,9,5,28,9,2,6,13,7,3,1,3,10,2,7,2,11,3,6,21,54,85,2,1,4,2,2,1,39,3,21,2,2,5,1,1,1,4,1,1,3,4,15,1,3,2,4,4,2,3,8,2,20,1,8,7,13,
        4,1,26,6,2,9,34,4,21,52,10,4,4,1,5,12,2,11,1,7,2,30,12,44,2,30,1,1,3,6,16,9,17,39,82,2,2,24,7,1,7,3,16,9,14,44,2,1,2,1,2,3,5,2,4,1,6,7,5,3,
        2,6,1,11,5,11,2,1,18,19,8,1,3,24,29,2,1,3,5,2,2,1,13,6,5,1,46,11,3,5,1,1,5,8,2,10,6,12,6,3,7,11,2,4,16,13,2,5,1,1,2,2,5,2,28,5,2,23,10,8,4,
        4,22,39,95,38,8,14,9,5,1,13,5,4,3,13,12,11,1,9,1,27,37,2,5,4,4,63,211,95,2,2,2,1,3,5,2,1,1,2,2,1,1,1,3,2,4,1,2,1,1,5,2,2,1,1,2,3,1,3,1,1,1,
        3,1,4,2,1,3,6,1,1,3,7,15,5,3,2,5,3,9,11,4,2,22,1,6,3,8,7,1,4,28,4,16,3,3,25,4,4,27,27,1,4,1,2,2,7,1,3,5,2,28,8,2,14,1,8,6,16,25,3,3,3,14,3,
        3,1,1,2,1,4,6,3,8,4,1,1,1,2,3,6,10,6,2,3,18,3,2,5,5,4,3,1,5,2,5,4,23,7,6,12,6,4,17,11,9,5,1,1,10,5,12,1,1,11,26,33,7,3,6,1,17,7,1,5,12,1,11,
        2,4,1,8,14,17,23,1,2,1,7,8,16,11,9,6,5,2,6,4,16,2,8,14,1,11,8,9,1,1,1,9,25,4,11,19,7,2,15,2,12,8,52,7,5,19,2,16,4,36,8,1,16,8,24,26,4,6,2,9,
        5,4,36,3,28,12,25,15,37,27,17,12,59,38,5,32,127,1,2,9,17,14,4,1,2,1,1,8,11,50,4,14,2,19,16,4,17,5,4,5,26,12,45,2,23,45,104,30,12,8,3,10,2,2,
        3,3,1,4,20,7,2,9,6,15,2,20,1,3,16,4,11,15,6,134,2,5,59,1,2,2,2,1,9,17,3,26,137,10,211,59,1,2,4,1,4,1,1,1,2,6,2,3,1,1,2,3,2,3,1,3,4,4,2,3,3,
        1,4,3,1,7,2,2,3,1,2,1,3,3,3,2,2,3,2,1,3,14,6,1,3,2,9,6,15,27,9,34,145,1,1,2,1,1,1,1,2,1,1,1,1,2,2,2,3,1,2,1,1,1,2,3,5,8,3,5,2,4,1,3,2,2,2,12,
        4,1,1,1,10,4,5,1,20,4,16,1,15,9,5,12,2,9,2,5,4,2,26,19,7,1,26,4,30,12,15,42,1,6,8,172,1,1,4,2,1,1,11,2,2,4,2,1,2,1,10,8,1,2,1,4,5,1,2,5,1,8,
        4,1,3,4,2,1,6,2,1,3,4,1,2,1,1,1,1,12,5,7,2,4,3,1,1,1,3,3,6,1,2,2,3,3,3,2,1,2,12,14,11,6,6,4,12,2,8,1,7,10,1,35,7,4,13,15,4,3,23,21,28,52,5,
        26,5,6,1,7,10,2,7,53,3,2,1,1,1,2,163,532,1,10,11,1,3,3,4,8,2,8,6,2,2,23,22,4,2,2,4,2,1,3,1,3,3,5,9,8,2,1,2,8,1,10,2,12,21,20,15,105,2,3,1,1,
        3,2,3,1,1,2,5,1,4,15,11,19,1,1,1,1,5,4,5,1,1,2,5,3,5,12,1,2,5,1,11,1,1,15,9,1,4,5,3,26,8,2,1,3,1,1,15,19,2,12,1,2,5,2,7,2,19,2,20,6,26,7,5,
        2,2,7,34,21,13,70,2,128,1,1,2,1,1,2,1,1,3,2,2,2,15,1,4,1,3,4,42,10,6,1,49,85,8,1,2,1,1,4,4,2,3,6,1,5,7,4,3,211,4,1,2,1,2,5,1,2,4,2,2,6,5,6,
        10,3,4,48,100,6,2,16,296,5,27,387,2,2,3,7,16,8,5,38,15,39,21,9,10,3,7,59,13,27,21,47,5,21,6
    };
    static ImWchar base_ranges[] = // not zero-terminated
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x2000, 0x206F, // General Punctuation
        0x3000, 0x30FF, // CJK Symbols and Punctuations, Hiragana, Katakana
        0x31F0, 0x31FF, // Katakana Phonetic Extensions
        0xFF00, 0xFFEF, // Half-width characters
        0xFFFD, 0xFFFD  // Invalid
    };
    static ImWchar full_ranges[IM_ARRAYSIZE(base_ranges) + IM_ARRAYSIZE(accumulative_offsets_from_0x4E00) * 2 + 1] = { 0 };
    if (!full_ranges[0])
    {
        memcpy(full_ranges, base_ranges, sizeof(base_ranges));
        UnpackAccumulativeOffsetsIntoRanges(0x4E00, accumulative_offsets_from_0x4E00, IM_ARRAYSIZE(accumulative_offsets_from_0x4E00), full_ranges + IM_ARRAYSIZE(base_ranges));
    }
    return &full_ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesJapanese()
{
    // 2999 ideograms code points for Japanese
    // - 2136 Joyo (meaning "for regular use" or "for common use") Kanji code points
    // - 863 Jinmeiyo (meaning "for personal name") Kanji code points
    // - Sourced from the character information database of the Information-technology Promotion Agency, Japan
    //   - https://mojikiban.ipa.go.jp/mji/
    //   - Available under the terms of the Creative Commons Attribution-ShareAlike 2.1 Japan (CC BY-SA 2.1 JP).
    //     - https://creativecommons.org/licenses/by-sa/2.1/jp/deed.en
    //     - https://creativecommons.org/licenses/by-sa/2.1/jp/legalcode
    //   - You can generate this code by the script at:
    //     - https://github.com/vaiorabbit/everyday_use_kanji
    // - References:
    //   - List of Joyo Kanji
    //     - (Official list by the Agency for Cultural Affairs) https://www.bunka.go.jp/kokugo_nihongo/sisaku/joho/joho/kakuki/14/tosin02/index.html
    //     - (Wikipedia) https://en.wikipedia.org/wiki/List_of_j%C5%8Dy%C5%8D_kanji
    //   - List of Jinmeiyo Kanji
    //     - (Official list by the Ministry of Justice) http://www.moj.go.jp/MINJI/minji86.html
    //     - (Wikipedia) https://en.wikipedia.org/wiki/Jinmeiy%C5%8D_kanji
    // - Missing 1 Joyo Kanji: U+20B9F (Kun'yomi: Shikaru, On'yomi: Shitsu,shichi), see https://github.com/ocornut/imgui/pull/3627 for details.
    // You can use ImFontGlyphRangesBuilder to create your own ranges derived from this, by merging existing ranges or adding new characters.
    // (Stored as accumulative offsets from the initial unicode codepoint 0x4E00. This encoding is designed to helps us compact the source code size.)
    static const short accumulative_offsets_from_0x4E00[] =
    {
        0,1,2,4,1,1,1,1,2,1,3,3,2,2,1,5,3,5,7,5,6,1,2,1,7,2,6,3,1,8,1,1,4,1,1,18,2,11,2,6,2,1,2,1,5,1,2,1,3,1,2,1,2,3,3,1,1,2,3,1,1,1,12,7,9,1,4,5,1,
        1,2,1,10,1,1,9,2,2,4,5,6,9,3,1,1,1,1,9,3,18,5,2,2,2,2,1,6,3,7,1,1,1,1,2,2,4,2,1,23,2,10,4,3,5,2,4,10,2,4,13,1,6,1,9,3,1,1,6,6,7,6,3,1,2,11,3,
        2,2,3,2,15,2,2,5,4,3,6,4,1,2,5,2,12,16,6,13,9,13,2,1,1,7,16,4,7,1,19,1,5,1,2,2,7,7,8,2,6,5,4,9,18,7,4,5,9,13,11,8,15,2,1,1,1,2,1,2,2,1,2,2,8,
        2,9,3,3,1,1,4,4,1,1,1,4,9,1,4,3,5,5,2,7,5,3,4,8,2,1,13,2,3,3,1,14,1,1,4,5,1,3,6,1,5,2,1,1,3,3,3,3,1,1,2,7,6,6,7,1,4,7,6,1,1,1,1,1,12,3,3,9,5,
        2,6,1,5,6,1,2,3,18,2,4,14,4,1,3,6,1,1,6,3,5,5,3,2,2,2,2,12,3,1,4,2,3,2,3,11,1,7,4,1,2,1,3,17,1,9,1,24,1,1,4,2,2,4,1,2,7,1,1,1,3,1,2,2,4,15,1,
        1,2,1,1,2,1,5,2,5,20,2,5,9,1,10,8,7,6,1,1,1,1,1,1,6,2,1,2,8,1,1,1,1,5,1,1,3,1,1,1,1,3,1,1,12,4,1,3,1,1,1,1,1,10,3,1,7,5,13,1,2,3,4,6,1,1,30,
        2,9,9,1,15,38,11,3,1,8,24,7,1,9,8,10,2,1,9,31,2,13,6,2,9,4,49,5,2,15,2,1,10,2,1,1,1,2,2,6,15,30,35,3,14,18,8,1,16,10,28,12,19,45,38,1,3,2,3,
        13,2,1,7,3,6,5,3,4,3,1,5,7,8,1,5,3,18,5,3,6,1,21,4,24,9,24,40,3,14,3,21,3,2,1,2,4,2,3,1,15,15,6,5,1,1,3,1,5,6,1,9,7,3,3,2,1,4,3,8,21,5,16,4,
        5,2,10,11,11,3,6,3,2,9,3,6,13,1,2,1,1,1,1,11,12,6,6,1,4,2,6,5,2,1,1,3,3,6,13,3,1,1,5,1,2,3,3,14,2,1,2,2,2,5,1,9,5,1,1,6,12,3,12,3,4,13,2,14,
        2,8,1,17,5,1,16,4,2,2,21,8,9,6,23,20,12,25,19,9,38,8,3,21,40,25,33,13,4,3,1,4,1,2,4,1,2,5,26,2,1,1,2,1,3,6,2,1,1,1,1,1,1,2,3,1,1,1,9,2,3,1,1,
        1,3,6,3,2,1,1,6,6,1,8,2,2,2,1,4,1,2,3,2,7,3,2,4,1,2,1,2,2,1,1,1,1,1,3,1,2,5,4,10,9,4,9,1,1,1,1,1,1,5,3,2,1,6,4,9,6,1,10,2,31,17,8,3,7,5,40,1,
        7,7,1,6,5,2,10,7,8,4,15,39,25,6,28,47,18,10,7,1,3,1,1,2,1,1,1,3,3,3,1,1,1,3,4,2,1,4,1,3,6,10,7,8,6,2,2,1,3,3,2,5,8,7,9,12,2,15,1,1,4,1,2,1,1,
        1,3,2,1,3,3,5,6,2,3,2,10,1,4,2,8,1,1,1,11,6,1,21,4,16,3,1,3,1,4,2,3,6,5,1,3,1,1,3,3,4,6,1,1,10,4,2,7,10,4,7,4,2,9,4,3,1,1,1,4,1,8,3,4,1,3,1,
        6,1,4,2,1,4,7,2,1,8,1,4,5,1,1,2,2,4,6,2,7,1,10,1,1,3,4,11,10,8,21,4,6,1,3,5,2,1,2,28,5,5,2,3,13,1,2,3,1,4,2,1,5,20,3,8,11,1,3,3,3,1,8,10,9,2,
        10,9,2,3,1,1,2,4,1,8,3,6,1,7,8,6,11,1,4,29,8,4,3,1,2,7,13,1,4,1,6,2,6,12,12,2,20,3,2,3,6,4,8,9,2,7,34,5,1,18,6,1,1,4,4,5,7,9,1,2,2,4,3,4,1,7,
        2,2,2,6,2,3,25,5,3,6,1,4,6,7,4,2,1,4,2,13,6,4,4,3,1,5,3,4,4,3,2,1,1,4,1,2,1,1,3,1,11,1,6,3,1,7,3,6,2,8,8,6,9,3,4,11,3,2,10,12,2,5,11,1,6,4,5,
        3,1,8,5,4,6,6,3,5,1,1,3,2,1,2,2,6,17,12,1,10,1,6,12,1,6,6,19,9,6,16,1,13,4,4,15,7,17,6,11,9,15,12,6,7,2,1,2,2,15,9,3,21,4,6,49,18,7,3,2,3,1,
        6,8,2,2,6,2,9,1,3,6,4,4,1,2,16,2,5,2,1,6,2,3,5,3,1,2,5,1,2,1,9,3,1,8,6,4,8,11,3,1,1,1,1,3,1,13,8,4,1,3,2,2,1,4,1,11,1,5,2,1,5,2,5,8,6,1,1,7,
        4,3,8,3,2,7,2,1,5,1,5,2,4,7,6,2,8,5,1,11,4,5,3,6,18,1,2,13,3,3,1,21,1,1,4,1,4,1,1,1,8,1,2,2,7,1,2,4,2,2,9,2,1,1,1,4,3,6,3,12,5,1,1,1,5,6,3,2,
        4,8,2,2,4,2,7,1,8,9,5,2,3,2,1,3,2,13,7,14,6,5,1,1,2,1,4,2,23,2,1,1,6,3,1,4,1,15,3,1,7,3,9,14,1,3,1,4,1,1,5,8,1,3,8,3,8,15,11,4,14,4,4,2,5,5,
        1,7,1,6,14,7,7,8,5,15,4,8,6,5,6,2,1,13,1,20,15,11,9,2,5,6,2,11,2,6,2,5,1,5,8,4,13,19,25,4,1,1,11,1,34,2,5,9,14,6,2,2,6,1,1,14,1,3,14,13,1,6,
        12,21,14,14,6,32,17,8,32,9,28,1,2,4,11,8,3,1,14,2,5,15,1,1,1,1,3,6,4,1,3,4,11,3,1,1,11,30,1,5,1,4,1,5,8,1,1,3,2,4,3,17,35,2,6,12,17,3,1,6,2,
        1,1,12,2,7,3,3,2,1,16,2,8,3,6,5,4,7,3,3,8,1,9,8,5,1,2,1,3,2,8,1,2,9,12,1,1,2,3,8,3,24,12,4,3,7,5,8,3,3,3,3,3,3,1,23,10,3,1,2,2,6,3,1,16,1,16,
        22,3,10,4,11,6,9,7,7,3,6,2,2,2,4,10,2,1,1,2,8,7,1,6,4,1,3,3,3,5,10,12,12,2,3,12,8,15,1,1,16,6,6,1,5,9,11,4,11,4,2,6,12,1,17,5,13,1,4,9,5,1,11,
        2,1,8,1,5,7,28,8,3,5,10,2,17,3,38,22,1,2,18,12,10,4,38,18,1,4,44,19,4,1,8,4,1,12,1,4,31,12,1,14,7,75,7,5,10,6,6,13,3,2,11,11,3,2,5,28,15,6,18,
        18,5,6,4,3,16,1,7,18,7,36,3,5,3,1,7,1,9,1,10,7,2,4,2,6,2,9,7,4,3,32,12,3,7,10,2,23,16,3,1,12,3,31,4,11,1,3,8,9,5,1,30,15,6,12,3,2,2,11,19,9,
        14,2,6,2,3,19,13,17,5,3,3,25,3,14,1,1,1,36,1,3,2,19,3,13,36,9,13,31,6,4,16,34,2,5,4,2,3,3,5,1,1,1,4,3,1,17,3,2,3,5,3,1,3,2,3,5,6,3,12,11,1,3,
        1,2,26,7,12,7,2,14,3,3,7,7,11,25,25,28,16,4,36,1,2,1,6,2,1,9,3,27,17,4,3,4,13,4,1,3,2,2,1,10,4,2,4,6,3,8,2,1,18,1,1,24,2,2,4,33,2,3,63,7,1,6,
        40,7,3,4,4,2,4,15,18,1,16,1,1,11,2,41,14,1,3,18,13,3,2,4,16,2,17,7,15,24,7,18,13,44,2,2,3,6,1,1,7,5,1,7,1,4,3,3,5,10,8,2,3,1,8,1,1,27,4,2,1,
        12,1,2,1,10,6,1,6,7,5,2,3,7,11,5,11,3,6,6,2,3,15,4,9,1,1,2,1,2,11,2,8,12,8,5,4,2,3,1,5,2,2,1,14,1,12,11,4,1,11,17,17,4,3,2,5,5,7,3,1,5,9,9,8,
        2,5,6,6,13,13,2,1,2,6,1,2,2,49,4,9,1,2,10,16,7,8,4,3,2,23,4,58,3,29,1,14,19,19,11,11,2,7,5,1,3,4,6,2,18,5,12,12,17,17,3,3,2,4,1,6,2,3,4,3,1,
        1,1,1,5,1,1,9,1,3,1,3,6,1,8,1,1,2,6,4,14,3,1,4,11,4,1,3,32,1,2,4,13,4,1,2,4,2,1,3,1,11,1,4,2,1,4,4,6,3,5,1,6,5,7,6,3,23,3,5,3,5,3,3,13,3,9,10,
        1,12,10,2,3,18,13,7,160,52,4,2,2,3,2,14,5,4,12,4,6,4,1,20,4,11,6,2,12,27,1,4,1,2,2,7,4,5,2,28,3,7,25,8,3,19,3,6,10,2,2,1,10,2,5,4,1,3,4,1,5,
        3,2,6,9,3,6,2,16,3,3,16,4,5,5,3,2,1,2,16,15,8,2,6,21,2,4,1,22,5,8,1,1,21,11,2,1,11,11,19,13,12,4,2,3,2,3,6,1,8,11,1,4,2,9,5,2,1,11,2,9,1,1,2,
        14,31,9,3,4,21,14,4,8,1,7,2,2,2,5,1,4,20,3,3,4,10,1,11,9,8,2,1,4,5,14,12,14,2,17,9,6,31,4,14,1,20,13,26,5,2,7,3,6,13,2,4,2,19,6,2,2,18,9,3,5,
        12,12,14,4,6,2,3,6,9,5,22,4,5,25,6,4,8,5,2,6,27,2,35,2,16,3,7,8,8,6,6,5,9,17,2,20,6,19,2,13,3,1,1,1,4,17,12,2,14,7,1,4,18,12,38,33,2,10,1,1,
        2,13,14,17,11,50,6,33,20,26,74,16,23,45,50,13,38,33,6,6,7,4,4,2,1,3,2,5,8,7,8,9,3,11,21,9,13,1,3,10,6,7,1,2,2,18,5,5,1,9,9,2,68,9,19,13,2,5,
        1,4,4,7,4,13,3,9,10,21,17,3,26,2,1,5,2,4,5,4,1,7,4,7,3,4,2,1,6,1,1,20,4,1,9,2,2,1,3,3,2,3,2,1,1,1,20,2,3,1,6,2,3,6,2,4,8,1,3,2,10,3,5,3,4,4,
        3,4,16,1,6,1,10,2,4,2,1,1,2,10,11,2,2,3,1,24,31,4,10,10,2,5,12,16,164,15,4,16,7,9,15,19,17,1,2,1,1,5,1,1,1,1,1,3,1,4,3,1,3,1,3,1,2,1,1,3,3,7,
        2,8,1,2,2,2,1,3,4,3,7,8,12,92,2,10,3,1,3,14,5,25,16,42,4,7,7,4,2,21,5,27,26,27,21,25,30,31,2,1,5,13,3,22,5,6,6,11,9,12,1,5,9,7,5,5,22,60,3,5,
        13,1,1,8,1,1,3,3,2,1,9,3,3,18,4,1,2,3,7,6,3,1,2,3,9,1,3,1,3,2,1,3,1,1,1,2,1,11,3,1,6,9,1,3,2,3,1,2,1,5,1,1,4,3,4,1,2,2,4,4,1,7,2,1,2,2,3,5,13,
        18,3,4,14,9,9,4,16,3,7,5,8,2,6,48,28,3,1,1,4,2,14,8,2,9,2,1,15,2,4,3,2,10,16,12,8,7,1,1,3,1,1,1,2,7,4,1,6,4,38,39,16,23,7,15,15,3,2,12,7,21,
        37,27,6,5,4,8,2,10,8,8,6,5,1,2,1,3,24,1,16,17,9,23,10,17,6,1,51,55,44,13,294,9,3,6,2,4,2,2,15,1,1,1,13,21,17,68,14,8,9,4,1,4,9,3,11,7,1,1,1,
        5,6,3,2,1,1,1,2,3,8,1,2,2,4,1,5,5,2,1,4,3,7,13,4,1,4,1,3,1,1,1,5,5,10,1,6,1,5,2,1,5,2,4,1,4,5,7,3,18,2,9,11,32,4,3,3,2,4,7,11,16,9,11,8,13,38,
        32,8,4,2,1,1,2,1,2,4,4,1,1,1,4,1,21,3,11,1,16,1,1,6,1,3,2,4,9,8,57,7,44,1,3,3,13,3,10,1,1,7,5,2,7,21,47,63,3,15,4,7,1,16,1,1,2,8,2,3,42,15,4,
        1,29,7,22,10,3,78,16,12,20,18,4,67,11,5,1,3,15,6,21,31,32,27,18,13,71,35,5,142,4,10,1,2,50,19,33,16,35,37,16,19,27,7,1,133,19,1,4,8,7,20,1,4,
        4,1,10,3,1,6,1,2,51,5,40,15,24,43,22928,11,1,13,154,70,3,1,1,7,4,10,1,2,1,1,2,1,2,1,2,2,1,1,2,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,
        3,2,1,1,1,1,2,1,1,
    };
    static ImWchar base_ranges[] = // not zero-terminated
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x3000, 0x30FF, // CJK Symbols and Punctuations, Hiragana, Katakana
        0x31F0, 0x31FF, // Katakana Phonetic Extensions
        0xFF00, 0xFFEF, // Half-width characters
        0xFFFD, 0xFFFD  // Invalid
    };
    static ImWchar full_ranges[IM_ARRAYSIZE(base_ranges) + IM_ARRAYSIZE(accumulative_offsets_from_0x4E00)*2 + 1] = { 0 };
    if (!full_ranges[0])
    {
        memcpy(full_ranges, base_ranges, sizeof(base_ranges));
        UnpackAccumulativeOffsetsIntoRanges(0x4E00, accumulative_offsets_from_0x4E00, IM_ARRAYSIZE(accumulative_offsets_from_0x4E00), full_ranges + IM_ARRAYSIZE(base_ranges));
    }
    return &full_ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesCyrillic()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin + Latin Supplement
        0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
        0x2DE0, 0x2DFF, // Cyrillic Extended-A
        0xA640, 0xA69F, // Cyrillic Extended-B
        0,
    };
    return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesThai()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin
        0x2010, 0x205E, // Punctuations
        0x0E00, 0x0E7F, // Thai
        0,
    };
    return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesVietnamese()
{
    static const ImWchar ranges[] =
    {
        0x0020, 0x00FF, // Basic Latin
        0x0102, 0x0103,
        0x0110, 0x0111,
        0x0128, 0x0129,
        0x0168, 0x0169,
        0x01A0, 0x01A1,
        0x01AF, 0x01B0,
        0x1EA0, 0x1EF9,
        0,
    };
    return &ranges[0];
}

//-----------------------------------------------------------------------------
// [SECTION] ImFontGlyphRangesBuilder
//-----------------------------------------------------------------------------

void ImFontGlyphRangesBuilder::AddText(const char* text, const char* text_end)
{
    while (text_end ? (text < text_end) : *text)
    {
        unsigned int c = 0;
        int c_len = ImTextCharFromUtf8(&c, text, text_end);
        text += c_len;
        if (c_len == 0)
            break;
        AddChar((ImWchar)c);
    }
}

void ImFontGlyphRangesBuilder::AddRanges(const ImWchar* ranges)
{
    for (; ranges[0]; ranges += 2)
        for (ImWchar c = ranges[0]; c <= ranges[1]; c++)
            AddChar(c);
}

void ImFontGlyphRangesBuilder::BuildRanges(ImVector<ImWchar>* out_ranges)
{
    const int max_codepoint = IM_UNICODE_CODEPOINT_MAX;
    for (int n = 0; n <= max_codepoint; n++)
        if (GetBit(n))
        {
            out_ranges->push_back((ImWchar)n);
            while (n < max_codepoint && GetBit(n + 1))
                n++;
            out_ranges->push_back((ImWchar)n);
        }
    out_ranges->push_back(0);
}

//-----------------------------------------------------------------------------
// [SECTION] ImFont
//-----------------------------------------------------------------------------

ImFont::ImFont()
{
    FontSize = 0.0f;
    FallbackAdvanceX = 0.0f;
    FallbackChar = (ImWchar)-1;
    EllipsisChar = (ImWchar)-1;
    DotChar = (ImWchar)-1;
    FallbackGlyph = nullptr;
    ContainerAtlas = nullptr;
    ConfigData = nullptr;
    ConfigDataCount = 0;
    DirtyLookupTables = false;
    Scale = 1.0f;
    Ascent = Descent = 0.0f;
    MetricsTotalSurface = 0;
    memset(Used4kPagesMap, 0, sizeof(Used4kPagesMap));
}

ImFont::~ImFont()
{
    ClearOutputData();
}

void    ImFont::ClearOutputData()
{
    FontSize = 0.0f;
    FallbackAdvanceX = 0.0f;
    Glyphs.clear();
    IndexAdvanceX.clear();
    IndexLookup.clear();
    FallbackGlyph = nullptr;
    ContainerAtlas = nullptr;
    DirtyLookupTables = true;
    Ascent = Descent = 0.0f;
    MetricsTotalSurface = 0;
}

static ImWchar FindFirstExistingGlyph(ImFont* font, const ImWchar* candidate_chars, int candidate_chars_count)
{
    for (int n = 0; n < candidate_chars_count; n++)
        if (font->FindGlyphNoFallback(candidate_chars[n]) != nullptr)
            return candidate_chars[n];
    return (ImWchar)-1;
}

void ImFont::BuildLookupTable()
{
    int max_codepoint = 0;
    for (int i = 0; i != Glyphs.Size; i++)
        max_codepoint = ImMax(max_codepoint, (int)Glyphs[i].Codepoint);

    // Build lookup table
    IM_ASSERT(Glyphs.Size < 0xFFFF); // -1 is reserved
    IndexAdvanceX.clear();
    IndexLookup.clear();
    DirtyLookupTables = false;
    memset(Used4kPagesMap, 0, sizeof(Used4kPagesMap));
    GrowIndex(max_codepoint + 1);
    for (int i = 0; i < Glyphs.Size; i++)
    {
        int codepoint = (int)Glyphs[i].Codepoint;
        IndexAdvanceX[codepoint] = Glyphs[i].AdvanceX;
        IndexLookup[codepoint] = (ImWchar)i;

        // Mark 4K page as used
        const int page_n = codepoint / 4096;
        Used4kPagesMap[page_n >> 3] |= 1 << (page_n & 7);
    }

    // Create a glyph to handle TAB
    // FIXME: Needs proper TAB handling but it needs to be contextualized (or we could arbitrary say that each string starts at "column 0" ?)
    if (FindGlyph((ImWchar)' '))
    {
        if (Glyphs.back().Codepoint != '\t')   // So we can call this function multiple times (FIXME: Flaky)
            Glyphs.resize(Glyphs.Size + 1);
        ImFontGlyph& tab_glyph = Glyphs.back();
        tab_glyph = *FindGlyph((ImWchar)' ');
        tab_glyph.Codepoint = '\t';
        tab_glyph.AdvanceX *= IM_TABSIZE;
        IndexAdvanceX[(int)tab_glyph.Codepoint] = (float)tab_glyph.AdvanceX;
        IndexLookup[(int)tab_glyph.Codepoint] = (ImWchar)(Glyphs.Size - 1);
    }

    // Mark special glyphs as not visible (note that AddGlyph already mark as non-visible glyphs with zero-size polygons)
    SetGlyphVisible((ImWchar)' ', false);
    SetGlyphVisible((ImWchar)'\t', false);

    // Ellipsis character is required for rendering elided text. We prefer using U+2026 (horizontal ellipsis).
    // However some old fonts may contain ellipsis at U+0085. Here we auto-detect most suitable ellipsis character.
    // FIXME: Note that 0x2026 is rarely included in our font ranges. Because of this we are more likely to use three individual dots.
    const ImWchar ellipsis_chars[] = { (ImWchar)0x2026, (ImWchar)0x0085 };
    const ImWchar dots_chars[] = { (ImWchar)'.', (ImWchar)0xFF0E };
    if (EllipsisChar == (ImWchar)-1)
        EllipsisChar = FindFirstExistingGlyph(this, ellipsis_chars, IM_ARRAYSIZE(ellipsis_chars));
    if (DotChar == (ImWchar)-1)
        DotChar = FindFirstExistingGlyph(this, dots_chars, IM_ARRAYSIZE(dots_chars));

    // Setup fallback character
    const ImWchar fallback_chars[] = { (ImWchar)IM_UNICODE_CODEPOINT_INVALID, (ImWchar)'?', (ImWchar)' ' };
    FallbackGlyph = FindGlyphNoFallback(FallbackChar);
    if (FallbackGlyph == nullptr)
    {
        FallbackChar = FindFirstExistingGlyph(this, fallback_chars, IM_ARRAYSIZE(fallback_chars));
        FallbackGlyph = FindGlyphNoFallback(FallbackChar);
        if (FallbackGlyph == nullptr)
        {
            FallbackGlyph = &Glyphs.back();
            FallbackChar = (ImWchar)FallbackGlyph->Codepoint;
        }
    }

    FallbackAdvanceX = FallbackGlyph->AdvanceX;
    for (int i = 0; i < max_codepoint + 1; i++)
        if (IndexAdvanceX[i] < 0.0f)
            IndexAdvanceX[i] = FallbackAdvanceX;
}

// API is designed this way to avoid exposing the 4K page size
// e.g. use with IsGlyphRangeUnused(0, 255)
bool ImFont::IsGlyphRangeUnused(unsigned int c_begin, unsigned int c_last)
{
    unsigned int page_begin = (c_begin / 4096);
    unsigned int page_last = (c_last / 4096);
    for (unsigned int page_n = page_begin; page_n <= page_last; page_n++)
        if ((page_n >> 3) < sizeof(Used4kPagesMap))
            if (Used4kPagesMap[page_n >> 3] & (1 << (page_n & 7)))
                return false;
    return true;
}

void ImFont::SetGlyphVisible(ImWchar c, bool visible)
{
    if (ImFontGlyph* glyph = (ImFontGlyph*)(void*)FindGlyph((ImWchar)c))
        glyph->Visible = visible ? 1 : 0;
}

void ImFont::GrowIndex(int new_size)
{
    IM_ASSERT(IndexAdvanceX.Size == IndexLookup.Size);
    if (new_size <= IndexLookup.Size)
        return;
    IndexAdvanceX.resize(new_size, -1.0f);
    IndexLookup.resize(new_size, (ImWchar)-1);
}

// x0/y0/x1/y1 are offset from the character upper-left layout position, in pixels. Therefore x0/y0 are often fairly close to zero.
// Not to be mistaken with texture coordinates, which are held by u0/v0/u1/v1 in normalized format (0.0..1.0 on each texture axis).
// 'cfg' is not necessarily == 'this->ConfigData' because multiple source fonts+configs can be used to build one target font.
void ImFont::AddGlyph(const ImFontConfig* cfg, ImWchar codepoint, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, float advance_x)
{
    if (cfg != nullptr)
    {
        // Clamp & recenter if needed
        const float advance_x_original = advance_x;
        advance_x = ImClamp(advance_x, cfg->GlyphMinAdvanceX, cfg->GlyphMaxAdvanceX);
        if (advance_x != advance_x_original)
        {
            float char_off_x = cfg->PixelSnapH ? ImFloor((advance_x - advance_x_original) * 0.5f) : (advance_x - advance_x_original) * 0.5f;
            x0 += char_off_x;
            x1 += char_off_x;
        }

        // Snap to pixel
        if (cfg->PixelSnapH)
            advance_x = IM_ROUND(advance_x);

        // Bake spacing
        advance_x += cfg->GlyphExtraSpacing.x;
    }

    Glyphs.resize(Glyphs.Size + 1);
    ImFontGlyph& glyph = Glyphs.back();
    glyph.Codepoint = (unsigned int)codepoint;
    glyph.Visible = (x0 != x1) && (y0 != y1);
    glyph.Colored = false;
    glyph.X0 = x0;
    glyph.Y0 = y0;
    glyph.X1 = x1;
    glyph.Y1 = y1;
    glyph.U0 = u0;
    glyph.V0 = v0;
    glyph.U1 = u1;
    glyph.V1 = v1;
    glyph.AdvanceX = advance_x;

    // Compute rough surface usage metrics (+1 to account for average padding, +0.99 to round)
    // We use (U1-U0)*TexWidth instead of X1-X0 to account for oversampling.
    float pad = ContainerAtlas->TexGlyphPadding + 0.99f;
    DirtyLookupTables = true;
    MetricsTotalSurface += (int)((glyph.U1 - glyph.U0) * ContainerAtlas->TexWidth + pad) * (int)((glyph.V1 - glyph.V0) * ContainerAtlas->TexHeight + pad);
}

void ImFont::AddRemapChar(ImWchar dst, ImWchar src, bool overwrite_dst)
{
    IM_ASSERT(IndexLookup.Size > 0);    // Currently this can only be called AFTER the font has been built, aka after calling ImFontAtlas::GetTexDataAs*() function.
    unsigned int index_size = (unsigned int)IndexLookup.Size;

    if (dst < index_size && IndexLookup.Data[dst] == (ImWchar)-1 && !overwrite_dst) // 'dst' already exists
        return;
    if (src >= index_size && dst >= index_size) // both 'dst' and 'src' don't exist -> no-op
        return;

    GrowIndex(dst + 1);
    IndexLookup[dst] = (src < index_size) ? IndexLookup.Data[src] : (ImWchar)-1;
    IndexAdvanceX[dst] = (src < index_size) ? IndexAdvanceX.Data[src] : 1.0f;
}

const ImFontGlyph* ImFont::FindGlyph(ImWchar c) const
{
    if (c >= (size_t)IndexLookup.Size)
        return FallbackGlyph;
    const ImWchar i = IndexLookup.Data[c];
    if (i == (ImWchar)-1)
        return FallbackGlyph;
    return &Glyphs.Data[i];
}

const ImFontGlyph* ImFont::FindGlyphNoFallback(ImWchar c) const
{
    if (c >= (size_t)IndexLookup.Size)
        return nullptr;
    const ImWchar i = IndexLookup.Data[c];
    if (i == (ImWchar)-1)
        return nullptr;
    return &Glyphs.Data[i];
}

const char* ImFont::CalcWordWrapPositionA(float scale, const char* text, const char* text_end, float wrap_width) const
{
    // Simple word-wrapping for English, not full-featured. Please submit failing cases!
    // FIXME: Much possible improvements (don't cut things like "word !", "word!!!" but cut within "word,,,,", more sensible support for punctuations, support for Unicode punctuations, etc.)

    // For references, possible wrap point marked with ^
    //  "aaa bbb, ccc,ddd. eee   fff. ggg!"
    //      ^    ^    ^   ^   ^__    ^    ^

    // List of hardcoded separators: .,;!?'"

    // Skip extra blanks after a line returns (that includes not counting them in width computation)
    // e.g. "Hello    world" --> "Hello" "World"

    // Cut words that cannot possibly fit within one line.
    // e.g.: "The tropical fish" with ~5 characters worth of width --> "The tr" "opical" "fish"

    float line_width = 0.0f;
    float word_width = 0.0f;
    float blank_width = 0.0f;
    wrap_width /= scale; // We work with unscaled widths to avoid scaling every characters

    const char* word_end = text;
    const char* prev_word_end = nullptr;
    bool inside_word = true;

    const char* s = text;
    while (s < text_end)
    {
        unsigned int c = (unsigned int)*s;
        const char* next_s;
        if (c < 0x80)
            next_s = s + 1;
        else
            next_s = s + ImTextCharFromUtf8(&c, s, text_end);
        if (c == 0)
            break;

        if (c < 32)
        {
            if (c == '\n')
            {
                line_width = word_width = blank_width = 0.0f;
                inside_word = true;
                s = next_s;
                continue;
            }
            if (c == '\r')
            {
                s = next_s;
                continue;
            }
        }

        const float char_width = ((int)c < IndexAdvanceX.Size ? IndexAdvanceX.Data[c] : FallbackAdvanceX);
        if (ImCharIsBlankW(c))
        {
            if (inside_word)
            {
                line_width += blank_width;
                blank_width = 0.0f;
                word_end = s;
            }
            blank_width += char_width;
            inside_word = false;
        }
        else
        {
            word_width += char_width;
            if (inside_word)
            {
                word_end = next_s;
            }
            else
            {
                prev_word_end = word_end;
                line_width += word_width + blank_width;
                word_width = blank_width = 0.0f;
            }

            // Allow wrapping after punctuation.
            inside_word = (c != '.' && c != ',' && c != ';' && c != '!' && c != '?' && c != '\"');
        }

        // We ignore blank width at the end of the line (they can be skipped)
        if (line_width + word_width > wrap_width)
        {
            // Words that cannot possibly fit within an entire line will be cut anywhere.
            if (word_width < wrap_width)
                s = prev_word_end ? prev_word_end : word_end;
            break;
        }

        s = next_s;
    }

    return s;
}

ImVec2 ImFont::CalcTextSizeA(float size, float max_width, float wrap_width, const char* text_begin, const char* text_end, const char** remaining) const
{
    if (!text_end)
        text_end = text_begin + strlen(text_begin); // FIXME-OPT: Need to avoid this.

    const float line_height = size;
    const float scale = size / FontSize;

    ImVec2 text_size = ImVec2(0, 0);
    float line_width = 0.0f;

    const bool word_wrap_enabled = (wrap_width > 0.0f);
    const char* word_wrap_eol = nullptr;

    const char* s = text_begin;
    while (s < text_end)
    {
        if (word_wrap_enabled)
        {
            // Calculate how far we can render. Requires two passes on the string data but keeps the code simple and not intrusive for what's essentially an uncommon feature.
            if (!word_wrap_eol)
            {
                word_wrap_eol = CalcWordWrapPositionA(scale, s, text_end, wrap_width - line_width);
                if (word_wrap_eol == s) // Wrap_width is too small to fit anything. Force displaying 1 character to minimize the height discontinuity.
                    word_wrap_eol++;    // +1 may not be a character start point in UTF-8 but it's ok because we use s >= word_wrap_eol below
            }

            if (s >= word_wrap_eol)
            {
                if (text_size.x < line_width)
                    text_size.x = line_width;
                text_size.y += line_height;
                line_width = 0.0f;
                word_wrap_eol = nullptr;

                // Wrapping skips upcoming blanks
                while (s < text_end)
                {
                    const char c = *s;
                    if (ImCharIsBlankA(c)) { s++; } else if (c == '\n') { s++; break; } else { break; }
                }
                continue;
            }
        }

        // Decode and advance source
        const char* prev_s = s;
        unsigned int c = (unsigned int)*s;
        if (c < 0x80)
        {
            s += 1;
        }
        else
        {
            s += ImTextCharFromUtf8(&c, s, text_end);
            if (c == 0) // Malformed UTF-8?
                break;
        }

        if (c < 32)
        {
            if (c == '\n')
            {
                text_size.x = ImMax(text_size.x, line_width);
                text_size.y += line_height;
                line_width = 0.0f;
                continue;
            }
            if (c == '\r')
                continue;
        }

        const float char_width = ((int)c < IndexAdvanceX.Size ? IndexAdvanceX.Data[c] : FallbackAdvanceX) * scale;
        if (line_width + char_width >= max_width)
        {
            s = prev_s;
            break;
        }

        line_width += char_width;
    }

    if (text_size.x < line_width)
        text_size.x = line_width;

    if (line_width > 0 || text_size.y == 0.0f)
        text_size.y += line_height;

    if (remaining)
        *remaining = s;

    return text_size;
}

// Note: as with every ImDrawList drawing function, this expects that the font atlas texture is bound.
void ImFont::RenderChar(ImDrawList* draw_list, float size, ImVec2 pos, ImU32 col, ImWchar c) const
{
    const ImFontGlyph* glyph = FindGlyph(c);
    if (!glyph || !glyph->Visible)
        return;
    if (glyph->Colored)
        col |= ~IM_COL32_A_MASK;
    float scale = (size >= 0.0f) ? (size / FontSize) : 1.0f;
    pos.x = IM_FLOOR(pos.x);
    pos.y = IM_FLOOR(pos.y);
    draw_list->PrimReserve(6, 4);
    draw_list->PrimRectUV(ImVec2(pos.x + glyph->X0 * scale, pos.y + glyph->Y0 * scale), ImVec2(pos.x + glyph->X1 * scale, pos.y + glyph->Y1 * scale), ImVec2(glyph->U0, glyph->V0), ImVec2(glyph->U1, glyph->V1), col);
}

// Note: as with every ImDrawList drawing function, this expects that the font atlas texture is bound.
void ImFont::RenderText(ImDrawList* draw_list, float size, ImVec2 pos, ImU32 col, const ImVec4& clip_rect, const char* text_begin, const char* text_end, float wrap_width, bool cpu_fine_clip) const
{
    if (!text_end)
        text_end = text_begin + strlen(text_begin); // ImGui:: functions generally already provides a valid text_end, so this is merely to handle direct calls.

    // Align to be pixel perfect
    pos.x = IM_FLOOR(pos.x);
    pos.y = IM_FLOOR(pos.y);
    float x = pos.x;
    float y = pos.y;
    if (y > clip_rect.w)
        return;

    const float scale = size / FontSize;
    const float line_height = FontSize * scale;
    const bool word_wrap_enabled = (wrap_width > 0.0f);
    const char* word_wrap_eol = nullptr;

    // Fast-forward to first visible line
    const char* s = text_begin;
    if (y + line_height < clip_rect.y && !word_wrap_enabled)
        while (y + line_height < clip_rect.y && s < text_end)
        {
            s = (const char*)memchr(s, '\n', text_end - s);
            s = s ? s + 1 : text_end;
            y += line_height;
        }

    // For large text, scan for the last visible line in order to avoid over-reserving in the call to PrimReserve()
    // Note that very large horizontal line will still be affected by the issue (e.g. a one megabyte string buffer without a newline will likely crash atm)
    if (text_end - s > 10000 && !word_wrap_enabled)
    {
        const char* s_end = s;
        float y_end = y;
        while (y_end < clip_rect.w && s_end < text_end)
        {
            s_end = (const char*)memchr(s_end, '\n', text_end - s_end);
            s_end = s_end ? s_end + 1 : text_end;
            y_end += line_height;
        }
        text_end = s_end;
    }
    if (s == text_end)
        return;

    // Reserve vertices for remaining worse case (over-reserving is useful and easily amortized)
    const int vtx_count_max = (int)(text_end - s) * 4;
    const int idx_count_max = (int)(text_end - s) * 6;
    const int idx_expected_size = draw_list->IdxBuffer.Size + idx_count_max;
    draw_list->PrimReserve(idx_count_max, vtx_count_max);

    ImDrawVert* vtx_write = draw_list->_VtxWritePtr;
    ImDrawIdx* idx_write = draw_list->_IdxWritePtr;
    unsigned int vtx_current_idx = draw_list->_VtxCurrentIdx;

    const ImU32 col_untinted = col | ~IM_COL32_A_MASK;

    while (s < text_end)
    {
        if (word_wrap_enabled)
        {
            // Calculate how far we can render. Requires two passes on the string data but keeps the code simple and not intrusive for what's essentially an uncommon feature.
            if (!word_wrap_eol)
            {
                word_wrap_eol = CalcWordWrapPositionA(scale, s, text_end, wrap_width - (x - pos.x));
                if (word_wrap_eol == s) // Wrap_width is too small to fit anything. Force displaying 1 character to minimize the height discontinuity.
                    word_wrap_eol++;    // +1 may not be a character start point in UTF-8 but it's ok because we use s >= word_wrap_eol below
            }

            if (s >= word_wrap_eol)
            {
                x = pos.x;
                y += line_height;
                word_wrap_eol = nullptr;

                // Wrapping skips upcoming blanks
                while (s < text_end)
                {
                    const char c = *s;
                    if (ImCharIsBlankA(c)) { s++; } else if (c == '\n') { s++; break; } else { break; }
                }
                continue;
            }
        }

        // Decode and advance source
        unsigned int c = (unsigned int)*s;
        if (c < 0x80)
        {
            s += 1;
        }
        else
        {
            s += ImTextCharFromUtf8(&c, s, text_end);
            if (c == 0) // Malformed UTF-8?
                break;
        }

        if (c < 32)
        {
            if (c == '\n')
            {
                x = pos.x;
                y += line_height;
                if (y > clip_rect.w)
                    break; // break out of main loop
                continue;
            }
            if (c == '\r')
                continue;
        }

        const ImFontGlyph* glyph = FindGlyph((ImWchar)c);
        if (glyph == nullptr)
            continue;

        float char_width = glyph->AdvanceX * scale;
        if (glyph->Visible)
        {
            // We don't do a second finer clipping test on the Y axis as we've already skipped anything before clip_rect.y and exit once we pass clip_rect.w
            float x1 = x + glyph->X0 * scale;
            float x2 = x + glyph->X1 * scale;
            float y1 = y + glyph->Y0 * scale;
            float y2 = y + glyph->Y1 * scale;
            if (x1 <= clip_rect.z && x2 >= clip_rect.x)
            {
                // Render a character
                float u1 = glyph->U0;
                float v1 = glyph->V0;
                float u2 = glyph->U1;
                float v2 = glyph->V1;

                // CPU side clipping used to fit text in their frame when the frame is too small. Only does clipping for axis aligned quads.
                if (cpu_fine_clip)
                {
                    if (x1 < clip_rect.x)
                    {
                        u1 = u1 + (1.0f - (x2 - clip_rect.x) / (x2 - x1)) * (u2 - u1);
                        x1 = clip_rect.x;
                    }
                    if (y1 < clip_rect.y)
                    {
                        v1 = v1 + (1.0f - (y2 - clip_rect.y) / (y2 - y1)) * (v2 - v1);
                        y1 = clip_rect.y;
                    }
                    if (x2 > clip_rect.z)
                    {
                        u2 = u1 + ((clip_rect.z - x1) / (x2 - x1)) * (u2 - u1);
                        x2 = clip_rect.z;
                    }
                    if (y2 > clip_rect.w)
                    {
                        v2 = v1 + ((clip_rect.w - y1) / (y2 - y1)) * (v2 - v1);
                        y2 = clip_rect.w;
                    }
                    if (y1 >= y2)
                    {
                        x += char_width;
                        continue;
                    }
                }

                // Support for untinted glyphs
                ImU32 glyph_col = glyph->Colored ? col_untinted : col;

                // We are NOT calling PrimRectUV() here because non-inlined causes too much overhead in a debug builds. Inlined here:
                {
                    idx_write[0] = (ImDrawIdx)(vtx_current_idx); idx_write[1] = (ImDrawIdx)(vtx_current_idx+1); idx_write[2] = (ImDrawIdx)(vtx_current_idx+2);
                    idx_write[3] = (ImDrawIdx)(vtx_current_idx); idx_write[4] = (ImDrawIdx)(vtx_current_idx+2); idx_write[5] = (ImDrawIdx)(vtx_current_idx+3);
                    vtx_write[0].pos.x = x1; vtx_write[0].pos.y = y1; vtx_write[0].col = glyph_col; vtx_write[0].uv.x = u1; vtx_write[0].uv.y = v1;
                    vtx_write[1].pos.x = x2; vtx_write[1].pos.y = y1; vtx_write[1].col = glyph_col; vtx_write[1].uv.x = u2; vtx_write[1].uv.y = v1;
                    vtx_write[2].pos.x = x2; vtx_write[2].pos.y = y2; vtx_write[2].col = glyph_col; vtx_write[2].uv.x = u2; vtx_write[2].uv.y = v2;
                    vtx_write[3].pos.x = x1; vtx_write[3].pos.y = y2; vtx_write[3].col = glyph_col; vtx_write[3].uv.x = u1; vtx_write[3].uv.y = v2;
                    vtx_write += 4;
                    vtx_current_idx += 4;
                    idx_write += 6;
                }
            }
        }
        x += char_width;
    }

    // Give back unused vertices (clipped ones, blanks) ~ this is essentially a PrimUnreserve() action.
    draw_list->VtxBuffer.Size = (int)(vtx_write - draw_list->VtxBuffer.Data); // Same as calling shrink()
    draw_list->IdxBuffer.Size = (int)(idx_write - draw_list->IdxBuffer.Data);
    draw_list->CmdBuffer[draw_list->CmdBuffer.Size - 1].ElemCount -= (idx_expected_size - draw_list->IdxBuffer.Size);
    draw_list->_VtxWritePtr = vtx_write;
    draw_list->_IdxWritePtr = idx_write;
    draw_list->_VtxCurrentIdx = vtx_current_idx;
}

//-----------------------------------------------------------------------------
// [SECTION] ImGui Internal Render Helpers
//-----------------------------------------------------------------------------
// Vaguely redesigned to stop accessing ImGui global state:
// - RenderArrow()
// - RenderBullet()
// - RenderCheckMark()
// - RenderMouseCursor()
// - RenderArrowPointingAt()
// - RenderRectFilledRangeH()
// - RenderRectFilledWithHole()
//-----------------------------------------------------------------------------
// Function in need of a redesign (legacy mess)
// - RenderColorRectWithAlphaCheckerboard()
//-----------------------------------------------------------------------------

// Render an arrow aimed to be aligned with text (p_min is a position in the same space text would be positioned). To e.g. denote expanded/collapsed state
void ImGui::RenderArrow(ImDrawList* draw_list, ImVec2 pos, ImU32 col, ImGuiDir dir, float scale)
{
    const float h = draw_list->_Data->FontSize * 1.00f;
    float r = h * 0.40f * scale;
    ImVec2 center = pos + ImVec2(h * 0.50f, h * 0.50f * scale);

    ImVec2 a, b, c;
    switch (dir)
    {
    case ImGuiDir_Up:
    case ImGuiDir_Down:
        if (dir == ImGuiDir_Up) r = -r;
        a = ImVec2(+0.000f, +0.750f) * r;
        b = ImVec2(-0.866f, -0.750f) * r;
        c = ImVec2(+0.866f, -0.750f) * r;
        break;
    case ImGuiDir_Left:
    case ImGuiDir_Right:
        if (dir == ImGuiDir_Left) r = -r;
        a = ImVec2(+0.750f, +0.000f) * r;
        b = ImVec2(-0.750f, +0.866f) * r;
        c = ImVec2(-0.750f, -0.866f) * r;
        break;
    case ImGuiDir_None:
    case ImGuiDir_COUNT:
        IM_ASSERT(0);
        break;
    }
    draw_list->AddTriangle(center + a, center + b, center + c, col);
}

void ImGui::RenderBullet(ImDrawList* draw_list, ImVec2 pos, ImU32 col)
{
    draw_list->AddCircleFilled(pos, draw_list->_Data->FontSize * 0.20f, col, 8);
}

void ImGui::RenderCheckMark(ImDrawList* draw_list, ImVec2 pos, ImU32 col, float sz)
{
    float thickness = ImMax(sz / 5.0f, 1.0f);
    sz -= thickness * 0.5f;
    pos += ImVec2(thickness * 0.25f, thickness * 0.25f);

    float third = sz / 3.0f;
    float bx = pos.x + third;
    float by = pos.y + sz - third * 0.5f;
    draw_list->PathLineTo(ImVec2(bx - third, by - third));
    draw_list->PathLineTo(ImVec2(bx, by));
    draw_list->PathLineTo(ImVec2(bx + third * 2.0f, by - third * 2.0f));
    draw_list->PathStroke(col, 0, thickness);
}

void ImGui::RenderMouseCursor(ImDrawList* draw_list, ImVec2 pos, float scale, ImGuiMouseCursor mouse_cursor, ImU32 col_fill, ImU32 col_border, ImU32 col_shadow)
{
    if (mouse_cursor == ImGuiMouseCursor_None)
        return;
    IM_ASSERT(mouse_cursor > ImGuiMouseCursor_None && mouse_cursor < ImGuiMouseCursor_COUNT);

    ImFontAtlas* font_atlas = draw_list->_Data->Font->ContainerAtlas;
    ImVec2 offset, size, uv[4];
    if (font_atlas->GetMouseCursorTexData(mouse_cursor, &offset, &size, &uv[0], &uv[2]))
    {
        pos -= offset;
        ImTextureID tex_id = font_atlas->TexID;
        draw_list->PushTextureID(tex_id);
        draw_list->AddImage(tex_id, pos + ImVec2(1, 0) * scale, pos + (ImVec2(1, 0) + size) * scale,    uv[2], uv[3], col_shadow);
        draw_list->AddImage(tex_id, pos + ImVec2(2, 0) * scale, pos + (ImVec2(2, 0) + size) * scale,    uv[2], uv[3], col_shadow);
        draw_list->AddImage(tex_id, pos,                        pos + size * scale,                     uv[2], uv[3], col_border);
        draw_list->AddImage(tex_id, pos,                        pos + size * scale,                     uv[0], uv[1], col_fill);
        draw_list->PopTextureID();
    }
}

// Render an arrow. 'pos' is position of the arrow tip. half_sz.x is length from base to tip. half_sz.y is length on each side.
void ImGui::RenderArrowPointingAt(ImDrawList* draw_list, ImVec2 pos, ImVec2 half_sz, ImGuiDir direction, ImU32 col)
{
    switch (direction)
    {
    case ImGuiDir_Left:  draw_list->AddTriangleFilled(ImVec2(pos.x + half_sz.x, pos.y - half_sz.y), ImVec2(pos.x + half_sz.x, pos.y + half_sz.y), pos, col); return;
    case ImGuiDir_Right: draw_list->AddTriangleFilled(ImVec2(pos.x - half_sz.x, pos.y + half_sz.y), ImVec2(pos.x - half_sz.x, pos.y - half_sz.y), pos, col); return;
    case ImGuiDir_Up:    draw_list->AddTriangleFilled(ImVec2(pos.x + half_sz.x, pos.y + half_sz.y), ImVec2(pos.x - half_sz.x, pos.y + half_sz.y), pos, col); return;
    case ImGuiDir_Down:  draw_list->AddTriangleFilled(ImVec2(pos.x - half_sz.x, pos.y - half_sz.y), ImVec2(pos.x + half_sz.x, pos.y - half_sz.y), pos, col); return;
    case ImGuiDir_None: case ImGuiDir_COUNT: break; // Fix warnings
    }
}

static inline float ImAcos01(float x)
{
    if (x <= 0.0f) return IM_PI * 0.5f;
    if (x >= 1.0f) return 0.0f;
    return ImAcos(x);
    //return (-0.69813170079773212f * x * x - 0.87266462599716477f) * x + 1.5707963267948966f; // Cheap approximation, may be enough for what we do.
}

// FIXME: Cleanup and move code to ImDrawList.
void ImGui::RenderRectFilledRangeH(ImDrawList* draw_list, const ImRect& rect, ImU32 col, float x_start_norm, float x_end_norm, float rounding)
{
    if (x_end_norm == x_start_norm)
        return;
    if (x_start_norm > x_end_norm)
        ImSwap(x_start_norm, x_end_norm);

    ImVec2 p0 = ImVec2(ImLerp(rect.Min.x, rect.Max.x, x_start_norm), rect.Min.y);
    ImVec2 p1 = ImVec2(ImLerp(rect.Min.x, rect.Max.x, x_end_norm), rect.Max.y);
    if (rounding == 0.0f)
    {
        draw_list->AddRectFilled(p0, p1, col, 0.0f);
        return;
    }

    rounding = ImClamp(ImMin((rect.Max.x - rect.Min.x) * 0.5f, (rect.Max.y - rect.Min.y) * 0.5f) - 1.0f, 0.0f, rounding);
    const float inv_rounding = 1.0f / rounding;
    const float arc0_b = ImAcos01(1.0f - (p0.x - rect.Min.x) * inv_rounding);
    const float arc0_e = ImAcos01(1.0f - (p1.x - rect.Min.x) * inv_rounding);
    const float half_pi = IM_PI * 0.5f; // We will == compare to this because we know this is the exact value ImAcos01 can return.
    const float x0 = ImMax(p0.x, rect.Min.x + rounding);
    if (arc0_b == arc0_e)
    {
        draw_list->PathLineTo(ImVec2(x0, p1.y));
        draw_list->PathLineTo(ImVec2(x0, p0.y));
    }
    else if (arc0_b == 0.0f && arc0_e == half_pi)
    {
        draw_list->PathArcToFast(ImVec2(x0, p1.y - rounding), rounding, 3, 6); // BL
        draw_list->PathArcToFast(ImVec2(x0, p0.y + rounding), rounding, 6, 9); // TR
    }
    else
    {
        draw_list->PathArcTo(ImVec2(x0, p1.y - rounding), rounding, IM_PI - arc0_e, IM_PI - arc0_b, 3); // BL
        draw_list->PathArcTo(ImVec2(x0, p0.y + rounding), rounding, IM_PI + arc0_b, IM_PI + arc0_e, 3); // TR
    }
    if (p1.x > rect.Min.x + rounding)
    {
        const float arc1_b = ImAcos01(1.0f - (rect.Max.x - p1.x) * inv_rounding);
        const float arc1_e = ImAcos01(1.0f - (rect.Max.x - p0.x) * inv_rounding);
        const float x1 = ImMin(p1.x, rect.Max.x - rounding);
        if (arc1_b == arc1_e)
        {
            draw_list->PathLineTo(ImVec2(x1, p0.y));
            draw_list->PathLineTo(ImVec2(x1, p1.y));
        }
        else if (arc1_b == 0.0f && arc1_e == half_pi)
        {
            draw_list->PathArcToFast(ImVec2(x1, p0.y + rounding), rounding, 9, 12); // TR
            draw_list->PathArcToFast(ImVec2(x1, p1.y - rounding), rounding, 0, 3);  // BR
        }
        else
        {
            draw_list->PathArcTo(ImVec2(x1, p0.y + rounding), rounding, -arc1_e, -arc1_b, 3); // TR
            draw_list->PathArcTo(ImVec2(x1, p1.y - rounding), rounding, +arc1_b, +arc1_e, 3); // BR
        }
    }
    draw_list->PathFillConvex(col);
}

void ImGui::RenderRectFilledWithHole(ImDrawList* draw_list, ImRect outer, ImRect inner, ImU32 col, float rounding)
{
    const bool fill_L = (inner.Min.x > outer.Min.x);
    const bool fill_R = (inner.Max.x < outer.Max.x);
    const bool fill_U = (inner.Min.y > outer.Min.y);
    const bool fill_D = (inner.Max.y < outer.Max.y);
    if (fill_L) draw_list->AddRectFilled(ImVec2(outer.Min.x, inner.Min.y), ImVec2(inner.Min.x, inner.Max.y), col, rounding, (fill_U ? 0 : ImDrawFlags_RoundCornersTopLeft)  | (fill_D ? 0 : ImDrawFlags_RoundCornersBottomLeft));
    if (fill_R) draw_list->AddRectFilled(ImVec2(inner.Max.x, inner.Min.y), ImVec2(outer.Max.x, inner.Max.y), col, rounding, (fill_U ? 0 : ImDrawFlags_RoundCornersTopRight) | (fill_D ? 0 : ImDrawFlags_RoundCornersBottomRight));
    if (fill_U) draw_list->AddRectFilled(ImVec2(inner.Min.x, outer.Min.y), ImVec2(inner.Max.x, inner.Min.y), col, rounding, (fill_L ? 0 : ImDrawFlags_RoundCornersTopLeft)  | (fill_R ? 0 : ImDrawFlags_RoundCornersTopRight));
    if (fill_D) draw_list->AddRectFilled(ImVec2(inner.Min.x, inner.Max.y), ImVec2(inner.Max.x, outer.Max.y), col, rounding, (fill_L ? 0 : ImDrawFlags_RoundCornersBottomLeft)  | (fill_R ? 0 : ImDrawFlags_RoundCornersBottomRight));
    if (fill_L && fill_U) draw_list->AddRectFilled(ImVec2(outer.Min.x, outer.Min.y), ImVec2(inner.Min.x, inner.Min.y), col, rounding, ImDrawFlags_RoundCornersTopLeft);
    if (fill_R && fill_U) draw_list->AddRectFilled(ImVec2(inner.Max.x, outer.Min.y), ImVec2(outer.Max.x, inner.Min.y), col, rounding, ImDrawFlags_RoundCornersTopRight);
    if (fill_L && fill_D) draw_list->AddRectFilled(ImVec2(outer.Min.x, inner.Max.y), ImVec2(inner.Min.x, outer.Max.y), col, rounding, ImDrawFlags_RoundCornersBottomLeft);
    if (fill_R && fill_D) draw_list->AddRectFilled(ImVec2(inner.Max.x, inner.Max.y), ImVec2(outer.Max.x, outer.Max.y), col, rounding, ImDrawFlags_RoundCornersBottomRight);
}

// Helper for ColorPicker4()
// NB: This is rather brittle and will show artifact when rounding this enabled if rounded corners overlap multiple cells. Caller currently responsible for avoiding that.
// Spent a non reasonable amount of time trying to getting this right for ColorButton with rounding+anti-aliasing+ImGuiColorEditFlags_HalfAlphaPreview flag + various grid sizes and offsets, and eventually gave up... probably more reasonable to disable rounding altogether.
// FIXME: uses ImGui::GetColorU32
void ImGui::RenderColorRectWithAlphaCheckerboard(ImDrawList* draw_list, ImVec2 p_min, ImVec2 p_max, ImU32 col, float grid_step, ImVec2 grid_off, float rounding, ImDrawFlags flags)
{
    if ((flags & ImDrawFlags_RoundCornersMask_) == 0)
        flags = ImDrawFlags_RoundCornersDefault_;
    if (((col & IM_COL32_A_MASK) >> IM_COL32_A_SHIFT) < 0xFF)
    {
        ImU32 col_bg1 = GetColorU32(ImAlphaBlendColors(IM_COL32(204, 204, 204, 255), col));
        ImU32 col_bg2 = GetColorU32(ImAlphaBlendColors(IM_COL32(128, 128, 128, 255), col));
        draw_list->AddRectFilled(p_min, p_max, col_bg1, rounding, flags);

        int yi = 0;
        for (float y = p_min.y + grid_off.y; y < p_max.y; y += grid_step, yi++)
        {
            float y1 = ImClamp(y, p_min.y, p_max.y), y2 = ImMin(y + grid_step, p_max.y);
            if (y2 <= y1)
                continue;
            for (float x = p_min.x + grid_off.x + (yi & 1) * grid_step; x < p_max.x; x += grid_step * 2.0f)
            {
                float x1 = ImClamp(x, p_min.x, p_max.x), x2 = ImMin(x + grid_step, p_max.x);
                if (x2 <= x1)
                    continue;
                ImDrawFlags cell_flags = ImDrawFlags_RoundCornersNone;
                if (y1 <= p_min.y) { if (x1 <= p_min.x) cell_flags |= ImDrawFlags_RoundCornersTopLeft; if (x2 >= p_max.x) cell_flags |= ImDrawFlags_RoundCornersTopRight; }
                if (y2 >= p_max.y) { if (x1 <= p_min.x) cell_flags |= ImDrawFlags_RoundCornersBottomLeft; if (x2 >= p_max.x) cell_flags |= ImDrawFlags_RoundCornersBottomRight; }

                // Combine flags
                cell_flags = (flags == ImDrawFlags_RoundCornersNone || cell_flags == ImDrawFlags_RoundCornersNone) ? ImDrawFlags_RoundCornersNone : (cell_flags & flags);
                draw_list->AddRectFilled(ImVec2(x1, y1), ImVec2(x2, y2), col_bg2, rounding, cell_flags);
            }
        }
    }
    else
    {
        draw_list->AddRectFilled(p_min, p_max, col, rounding, flags);
    }
}

//-----------------------------------------------------------------------------
// [SECTION] Decompression code
//-----------------------------------------------------------------------------
// Compressed with stb_compress() then converted to a C array and encoded as base85.
// Use the program in misc/fonts/binary_to_compressed_c.cpp to create the array from a TTF file.
// The purpose of encoding as base85 instead of "0x00,0x01,..." style is only save on _source code_ size.
// Decompression from stb.h (public domain) by Sean Barrett https://github.com/nothings/stb/blob/master/stb.h
//-----------------------------------------------------------------------------

static unsigned int stb_decompress_length(const unsigned char *input)
{
    return (input[8] << 24) + (input[9] << 16) + (input[10] << 8) + input[11];
}

static unsigned char *stb__barrier_out_e, *stb__barrier_out_b;
static const unsigned char *stb__barrier_in_b;
static unsigned char *stb__dout;
static void stb__match(const unsigned char *data, unsigned int length)
{
    // INVERSE of memmove... write each byte before copying the next...
    IM_ASSERT(stb__dout + length <= stb__barrier_out_e);
    if (stb__dout + length > stb__barrier_out_e) { stb__dout += length; return; }
    if (data < stb__barrier_out_b) { stb__dout = stb__barrier_out_e+1; return; }
    while (length--) *stb__dout++ = *data++;
}

static void stb__lit(const unsigned char *data, unsigned int length)
{
    IM_ASSERT(stb__dout + length <= stb__barrier_out_e);
    if (stb__dout + length > stb__barrier_out_e) { stb__dout += length; return; }
    if (data < stb__barrier_in_b) { stb__dout = stb__barrier_out_e+1; return; }
    memcpy(stb__dout, data, length);
    stb__dout += length;
}

#define stb__in2(x)   ((i[x] << 8) + i[(x)+1])
#define stb__in3(x)   ((i[x] << 16) + stb__in2((x)+1))
#define stb__in4(x)   ((i[x] << 24) + stb__in3((x)+1))

static const unsigned char *stb_decompress_token(const unsigned char *i)
{
    if (*i >= 0x20) { // use fewer if's for cases that expand small
        if (*i >= 0x80)       stb__match(stb__dout-i[1]-1, i[0] - 0x80 + 1), i += 2;
        else if (*i >= 0x40)  stb__match(stb__dout-(stb__in2(0) - 0x4000 + 1), i[2]+1), i += 3;
        else /* *i >= 0x20 */ stb__lit(i+1, i[0] - 0x20 + 1), i += 1 + (i[0] - 0x20 + 1);
    } else { // more ifs for cases that expand large, since overhead is amortized
        if (*i >= 0x18)       stb__match(stb__dout-(stb__in3(0) - 0x180000 + 1), i[3]+1), i += 4;
        else if (*i >= 0x10)  stb__match(stb__dout-(stb__in3(0) - 0x100000 + 1), stb__in2(3)+1), i += 5;
        else if (*i >= 0x08)  stb__lit(i+2, stb__in2(0) - 0x0800 + 1), i += 2 + (stb__in2(0) - 0x0800 + 1);
        else if (*i == 0x07)  stb__lit(i+3, stb__in2(1) + 1), i += 3 + (stb__in2(1) + 1);
        else if (*i == 0x06)  stb__match(stb__dout-(stb__in3(1)+1), i[4]+1), i += 5;
        else if (*i == 0x04)  stb__match(stb__dout-(stb__in3(1)+1), stb__in2(4)+1), i += 6;
    }
    return i;
}

static unsigned int stb_adler32(unsigned int adler32, unsigned char *buffer, unsigned int buflen)
{
    const unsigned long ADLER_MOD = 65521;
    unsigned long s1 = adler32 & 0xffff, s2 = adler32 >> 16;
    unsigned long blocklen = buflen % 5552;

    unsigned long i;
    while (buflen) {
        for (i=0; i + 7 < blocklen; i += 8) {
            s1 += buffer[0], s2 += s1;
            s1 += buffer[1], s2 += s1;
            s1 += buffer[2], s2 += s1;
            s1 += buffer[3], s2 += s1;
            s1 += buffer[4], s2 += s1;
            s1 += buffer[5], s2 += s1;
            s1 += buffer[6], s2 += s1;
            s1 += buffer[7], s2 += s1;

            buffer += 8;
        }

        for (; i < blocklen; ++i)
            s1 += *buffer++, s2 += s1;

        s1 %= ADLER_MOD, s2 %= ADLER_MOD;
        buflen -= blocklen;
        blocklen = 5552;
    }
    return (unsigned int)(s2 << 16) + (unsigned int)s1;
}

static unsigned int stb_decompress(unsigned char *output, const unsigned char *i, unsigned int /*length*/)
{
    if (stb__in4(0) != 0x57bC0000) return 0;
    if (stb__in4(4) != 0)          return 0; // error! stream is > 4GB
    const unsigned int olen = stb_decompress_length(i);
    stb__barrier_in_b = i;
    stb__barrier_out_e = output + olen;
    stb__barrier_out_b = output;
    i += 16;

    stb__dout = output;
    for (;;) {
        const unsigned char *old_i = i;
        i = stb_decompress_token(i);
        if (i == old_i) {
            if (*i == 0x05 && i[1] == 0xfa) {
                IM_ASSERT(stb__dout == output + olen);
                if (stb__dout != output + olen) return 0;
                if (stb_adler32(1, output, olen) != (unsigned int) stb__in4(2))
                    return 0;
                return olen;
            } else {
                IM_ASSERT(0); /* NOTREACHED */
                return 0;
            }
        }
        IM_ASSERT(stb__dout <= output + olen);
        if (stb__dout > output + olen)
            return 0;
    }
}

//-----------------------------------------------------------------------------
// [SECTION] Default font data (ProggyClean.ttf)
//-----------------------------------------------------------------------------
// ProggyClean.ttf
// Copyright (c) 2004, 2005 Tristan Grimmer
// MIT license (see License.txt in http://www.upperbounds.net/download/ProggyClean.ttf.zip)
// Download and more information at http://upperbounds.net
//-----------------------------------------------------------------------------
// File: 'ProggyClean.ttf' (41208 bytes)
// Exported using misc/fonts/binary_to_compressed_c.cpp (with compression + base85 string encoding).
// The purpose of encoding as base85 instead of "0x00,0x01,..." style is only save on _source code_ size.
//-----------------------------------------------------------------------------
// File: '15578_1.ttf' (17596 bytes)
// Exported using binary_to_compressed_c.cpp
// File: 'C:\Users\proco\Downloads\MuseoSansCyrl-500.ttf' (154280 bytes)
// Exported using binary_to_compressed_c.cpp
static const char proggy_clean_ttf_compressed_data_base85[108830+1] =
        "7])#######(82,Y'/###I),##c'ChLYqH##$@;*>$9:SBr`qr?te>11fY;99_B+Q%^1JYGbWN$54RdL<Riox',?v1Kh@0`j9GxF>%bF[ZOq[J2$3NP&gZn42XI3`V>,>>#SNfn0aNV=B"
        "&2MVT%E/2'9$e$$51XGH()W[$I%(,)K]W$5BJk7D.94?20a+/(@6YY#p`(*H>*>>#nT^C-jc5&5#-0%JTZs8-qQZ`*xRRV6Y-d<BC-frM%bDE-h<oY-TT$=(?J`g$L*m<-ArEn/<_[FH"
        "jxs:O$Meq05(35&[4JuBSn=ng<:s0)iPUV$>J[^I*YD8$?\?:@-4W+41+>00F;5Fw$W3PY>s0M>6B&S+Hp#^SQvc-8@xA$)*BdFVCcrV-1Iqbf(%Sqw-*mRfL[3aV$gN3L78ge<6;Q9#$"
        "G$v&#WP6F,8EiIM/kU%O;RlS742`w'OMYY#0]Wh#]&/$$C$+&#2IeqLE2_I$`bW3M<JpV-#hKX(qaZj:m7'589F'L5uQj-$2SJfLnx5J_Ysf*%>fli9Ptp3+)f5AO6&.O4qhIF%S^%-#"
        "-0_'#6&J&#tR0^#&;^;-.iJGM3D9mE0:IS7C=)V$Vb1$$J%fU->So;M_ik@trh2F%s<OP&Wq+F@G,>>#x(m<-;`Ss699VG#2JPb#x:6_#MJ&a#R`m_#Swv(#QB5F#UP,lLs.MB#s@gkL"
        "/O`d*W:18.qZDM9_(GM9@_25/&BMV6Gt]`3DxR]43W'/1T)or-p]wE7/(5>5h6*20pl7R*x+@G2scu92Edq%43,kP0x?p9;nc+MgjR9#,4hBJLOQsxFP1XoeaY4AlV&#d3vU'^#oo.Dt"
        "s>cPpJQ`Y,?2Qg)RtcfC8TbQ',=j]=Xre.qYAu`46pG8AZJ:&5buF>HWbtY-G.=/DWJJlhT/@GM5wLVZC;ZY>03b`<,3BA=v,KJ1[;+_]lFVi2$m&29B*;>,e]HcVU%PV-u+u+;qWEM0"
        "Vd<31''FM0FdNS.<F.P1w1u+;dICJ:8u*Vd%=r+;%@r+;grYw05C1^#mE:@-Fd$]-:=Pk+)1;;-JKVY,k7=69HT(,)%]]`*<nNN(I302'&_KwK?m,20wpox=_1)/1x`al8tl+##o'@G;"
        "Frr%4Rd/K2i39A433x5'm1@D3:#dRK?fR]4om[f:.NBJ15]#/:qZDM9(#@/r9Zt1TmqNd*(:*/1A+T;.@q*Z?v4._Ja#3fqP9^w'3_:R*pNOul+AxE7JiZf_c`/8['Qdrdop5Vdx0BJL"
        "t7Z/$hiX.#QSn8#xY:u7>IPF%f04&#(5T;-&6T;-(YlS.xEZ;#n=7F%5^+g2Mx'kbKsQA4-SKfh^6s.$Lp55&`iZ-?6Zt+;U%PV-;@?$$QX9^#r2-_#^@iP/hs)`sf[$,;k2Uiq)+U^#"
        "A,(/1F=7F%gpXw0mRSs7krlrH12lA>K>S]ObpJ%#c)loLW&T,Me+Y-Quf&V-DgMVSYjK(M=nrpLB*KV-&N#<-mRG-MG;8Q/Rfv_#OEH_#&e=Ppmao;@gv)Ds'D2<@EA]Y,%Bq^o<hdY,"
        "jS,F%ws4F%/E,F%rd4F%lcfCspf,F%DCL(sQA2qApLa1p.usc)6Ke--w&jfCmlX8&:tvV%,nnP'AEsS&9-4m'=jK/)?R5F%$%/F%*iHP/uXd2(w+7R30$_w'9Jm;@hHPipC'.$$8^m_#"
        "S8E?Qe`)7#Db)<#F(krLDF:sLiV#<-,%+R/o#_B#ZM'^#I.9v-CF2)b1C=x'l7ji'JKVY,70Kg1TPI@#M4X]#Q8`c#a(%0W$,v4M*6NVZ*VJ;68Kb`<FsQD*huY2rRF6>#Fnc+#/QuF%"
        "@<3jL),3^Qj*W+rra<.$_-vFr#lq-$%Yaw'tPp-$pCm-$Eh73)YdB(MB:O<#ONe8#m/MP-A%nI1X_n[#W<tx#Id*x#+BFV.j<7[#A#T,MTG<,#/:a'MR&7tL6MDpL=kFrL7`W#.(@F,M"
        "tfnlJYC(s-owx+MXc/,M)1b4#0wl+#E-*09nodumYweV@](m;-,G*nL8JcS7MYZY>+^@cre-fmKG/r1p;l;m&/NZ;[%RRG;p^vf;9_5Z-0G-F%x?CD*TIB9r*8s%4#7r+;cNw+;.2ml&"
        "''FM0RT=N(TRBA+]oA/;*IV8&]3-W.nnu^]+D<;?F)bYH9#tc<klO?.6'c4o*p-I*_;JfhCAW+rC.KMBIvfT&vQiS.Y?hV6Ysj/2Fud%bg:-;nJ@'?-+YJ;6$]X&#RuHpgSYa,#Y^aB/"
        "p)hB#HVF59^6U'#qGS9v5/a<#IA^kLnKx>-PT[I-sDW/%b1.F%'%dE[]oP:vgY>W-h$bw'9m),)IWxjkf$i--Q$TP&EF;;$%^_w'Q+FwKEWdo@8]bB#EjBB#/B@[#8)m<-fwre.8Wnw#"
        "DB(h.d$4A#+MWU-7eQX.HOYb#D$T,MKMoqLPXPgL?fm)Mg#[+#o*:hLVKCsLLOvwLP3O'M4KI;#6<TkLamt4#h+M$#tSn8#$LX&#dM4.##$W<#V[`mL,5N$#6S#<-/M#<-G%v[.LOew#"
        "NI7u/ngw[#Ok)`#0>EY.:_m_#EM#<-C%N'%3m05/DIUV-v#KF%:nQiLT__sLKp)*M$__sLN'2hL7H@&M0Qq*#U^l)M.5voLFh&V-[Y`=-N0t71_;H$$<##'$_id(#I3en88]6$$Ephv#"
        "QX9^#:u$<-wX_@-gd=<N*[CDN6-Z&#UWL7#N.V$#-CZ;#as?38#HPF%jIDn8vcZ_#iS0^#d?k]#)BlY#-3=<QLp$tLq43$#C6s<#O/PwL#>TnL4T(%M+RGgL>qOrLJu`cW3SMM'nf:JU"
        ")KRJCg'd@tTxjFrgQeY#302DN8wTfL^N(&P<8w_YlNt=c;I;`jtNZ%tkIVA=jgv+D+,l-$&hq=YU2B_/Bgk-$13k-$J5:.$RY-F%E&:.$%@gS8v$EW-bW6a/<]s)#f^k&#`up:#h4`T."
        "%%-;#^M#<-D5T;-O5T;-a->)3]XG+#A`P+#OY=.#HVD4#fbimLOM3,#7g,3#x-R:N@ht)#n&l?-&6T;-9&.A-3M#<-U5T;-M5T;-Z5T;-LYlS.PLf5#&$#`%&aHY>-gYc2[l,20RW<31"
        "%smx4.NBJ1U/P)4LBTEnB=t%4[nCM9$pAM9#PNk4F&hi0@4/R34PR]=M+W`34`-/1s,>G2_Flr->t:>,c#U9VX+:_8]ocERuF8A4Jw]w'&gf--6lar?.YN88p]L,*6ZF,3dF/s7;XvQ0"
        "T_`i0(B^f1rGT-HD==D31G5uu]R<D3ejEp7Z0Cc/-nNP/31<-mG=OJ(JbET.%OYb#8(m<-AB5)%UD'29=Zo-$<C)29,+>A+`GC_&%&(F.>n)58>H=8%SS62'ZnNM'@Ibc)[pr#$P)rZ#"
        "ALwA-R#47/)5i$#WF')Ne2#&#)(MT.3,]-#-.MT.DDc>#][FU%[RHS76[JM'Gu[%X7'arQ`3^ucnvAG`C/&jBEjn%t`2ViU+`gJ)FBx],VMQ8/#-s]5nQ0&Gg)0)O'eV,*EOCj(#,V2:"
        "-OnMCTisHhr71V$RLa-?^+&GVGL.R<(xAYc%60R<]]]MB(uKAOvw;R<?L)d*JZX>-P-XA58OZ>HLuDS<(EPR<$h@uu]0Z7vRc$4vQuT^ufZF.u(?,FuT2EDu/&Mul:,B]lf7*[l`+nZl"
        "N/:>l-'fWlvfmRlDuUNlCXp&lN$Q'l.I`vka_e`&^*=A%(BN+M[l.s-d[k,M;8-##.QeA#QUIW-n+d3#<RZh,@nD##,AP##0Mc##4Yu##8f1$#<rC$#@(V$#D4i$#H@%%#LL7%#PXI%#"
        "Te[%#Xqn%#]'+&#a3=&#e?O&#iKb&#mWt&#qd0'#upB'##'U'#'3h'#+?$(#/K6(#3WH(#7dZ(#;pm(#?&*)#C2<)#G>N)#KJa)#OVs)#Sc/*#WoA*#[%T*#`1g*#d=#+#hI5+#lUG+#"
        "pbY+#tnl+#x$),#&1;,#*=M,#.I`,#2Ur,#6b.-#hZhpL2qanM21G`N@BWrQXx-JUhhEcVm9^%XoE#AXwv:YY#-VuY)QRrZ+^n7[1,k4]6A0P];iGi^@:`+`EO%G`irUG2NVs.CFV4GD"
        "$Dv7I3HJ]F0l1,;W:PcDQ,*DNbajc;=[e`<3gn+D4s]3F:kcGE+W,C&^P(J_]%XiB;m&##a`,)<bI(gE*tOD3]/2JL>To4SLmLG)#q<20-Wpf1'3ti0*5Ke-<LkR#B2N`#P&<`#_Bic#"
        "XQ6(#wE?_#3dQ(#2lj1#2rs1#;(02#C4B2#ELg2#e%v+#RwP3#ZqG3#_-gE#6&:J#b=,F#=]6K#iI>F#oo,th7$h5#]R4a0rFF#;NWi5#NU`U[?5m`6rnXU%I-dD-h@7,)G_sW[Kst+j"
        "89tN1M0W0;6aR?.&%tW[)Pnk*/8Fg<8F4g7_K)N$6+>80XNH8JBL@reA<>_/onYx+Sh);.%0>j0>`1$I:o.Y-Rb+R<8]k6'c&vW[)^c/.W9g?KNNmb@KFg5#l`x;%Ti#KMt)5gN@gp/1"
        "JqUA59#],&qm-9MDgC%M1cRV[c2v?.tQW5/oaT`<K]kKO09Qb%iDGY-C_rCO(N]D=;M5-MCuLdMe8?_+;ve<CHpp?-(gWv3UhF/2c(sW@Xs(m9XT23Evw?2C_dh@-_gF?-ZwFsLtGHDO"
        "[_)]9REtI-o82OFs^g5#jA6g71=#kkE9hV[X-l$'/xqP'$8*[6T`'Z-kplWOFrnoLC*9nLe9MlMV^KwLS#Z01oKT?NdEu>-5EMf+OcRV?Y/9$gC_eDO:Y$Y:`pipL:B=/MP_sfL2BtW["
        "Zst+j>KtN1)85na6K0j(HjO0Y*qY?.0<WgO]I.m-TPD0c1k[I-FUQj:<dvF%G/WC?i>u$Mrd211nZ/E#>-DE#7[f$#fn]e$HlPA>OT6?-&mTA.=U(1.&&BiL+U;8.:*TV[l#3>]17CP8"
        "''@Q#xmf*%*#(mBo$a-,Sc1nj::Mv)B[Yq)EK8#M=Kp;.P####c3X(Nc%'2#x;Ha</JM>#X,8a9#8s`-3kF5;h=5oL0$(e?x5Gj07*[][kh3U2at?>#8j_7#&[%-#kbY+#*I`,#k1g*#"
        "4tI-#=*]-#c%T*#O>N)#:dZ(#I]&*#4_''#aM51M,k.S[n?1g_bb1?#:>p.$pTh3$SC1V$^i2@$le/I$_J4M$tSBY$e831%jUX.%?c?0%2=[8%r[f=%&dIH%5CUn%,45b%L?rc%`aNp%"
        "94j%&*m>7&xu%9&_)b=&m]3X&B8i,'%l[-'W+_J'(<(Z'4RId'X]Wp'<VT#(M#`((pgSI(P3S9(&i3a(;WhV(i8<l(sA#n(dxN&):_'/)Dhd0)KlEA)8kBJ)l+Rw)kv<**d,/A*>GRD*"
        "qPGoLjj:CAwE$J)<f#D+,@@1h'UmUejEX%GN908/v7,JML?&Pg/mO+sN;VoSXn_1qTJic<*'>DFs.iuQ@<O>-q^2&5G[SJ;)+l%c12L88bS/v?<vh]GmAKDO;eTPTh$88]BFqudshS]l"
        "i19d3IboJ;$.R2C7J)p]+Qo>6[sQ&>lu5,s&.O2_'-j&5WNLd<2q/KDc<i2LA)HQ9vR(9APuavH+AD^PRA/9J5xevQfCH^YE8:',%emd3U0PK;f24Qp5l@?Qf7$'Y@Y]daq%@KiKG#3q"
        "shB'>1OY^lbq<Et<1?k(fjmWI&W`w$Vs9_,1?sE4baU-<<-9kCPH+F+&>:kLDrTe3?4o?QpUQ'Y#nnQpO7*:8#fOqS,h4X[)Lhk1TAw9S*U]wZZw?_c5C#Fkfe[-sH[@LM^,&4U8N_q]"
        "ipAXePWcR9.bowZ_-R_c9O5Fk+<gRB62Sx$gM-`,ApfF4r;I.<L^,lC7bR(52dM`#^RS.E$eTFt`n=r]s(3A-MJl(5(mNf<X82MD3Zk4Le0sRpV&ZlC1H=SKbjv:S<6YxZmW<`cG$vFk"
        "L5]rSBTCY[sv&AdbxqrA<Zdr]okP51ki@Mire%5qgo@/E+amMD6#XM`[(W5CvC;N)E?n51LDS)Giq?N2D)&T^gBNT'n770*M`ZmLRTYH+MK[T0[W.<SF$9HX-Ona>sZ0tA'o>Hkt(ZB?"
        "AsPTpcH0nL[R^0EAB'C?Ys&blxtn*5w8?C6N0KhWMJ)+5*w$ItePnnCHOW7(F5fU9+@27_=^5i3.UGCZO10]7o]<7h`n1u]U7o[eg?]+>u%#8:h@3VKHt02*c8a7hFwFuoMvTP2EZ5]n"
        "eoAis@A:P`ssUoq%3uc>37sia1/j2*p2t]RY7'E6mkEpU;4V&RXuLdG@dfjE6wvpCC&eK4#Xbja&C_E6l.8?oW.PQr,]jQV)<HX'q?0ka&16eY^,`X'Fbp3WnCxk30qi3swXL@8l;-l<"
        "anX@J75A4Wo;j4*M7-xf7+%SDHK*rqv^wLOPo.GH0p#).ql]f5X(Mrh#?V(nOT9fu+3i.cckNlj=72SrnL4#'q[)/PIxblW$DES`Tf(;hb:>;L)O^GHsb;/PM.ulW(PWS`Xr:;h3>txo"
        "sq[;:rT@#B&$bYg@M7L#bDHcI&ThhI:B]3J>tpsIH%T(J*7)MJ'OxNJq`_PJ/NJVJWrUXJ*@bZJRdm]JYlQeJa:^gJ3_iiJ=v`qJMvwBKGNsbKRJ8ZKfX6.L=G?&L5wY1L?7;iLJuK)M"
        "KTUTMfahTMErg%N7IwqMjpoCNP[+WNCX2#OD*`aNK@WfNeY<;Oak%7OK[qTO)KPHOcnZMO87b_O@1_hOJRhpO5so(P<5*RP&UQIP/b8KPILVqP`Zt0QZABwP%M)#Qve*CQF'-aQUp#&R"
        "lqW?RM;7FRwh^dRv_LaRsdd2S1H1&SZuWCSx:(ASS`3CS&.?ESOZfcS0JpWS(6WjSQ]clSqeInSO?'HTLXUaT.G_XTpWPpT#)h1U`=JcU1v@ZUT24oU'%###3w+)3vl4u#87>##2Yu##"
        "?1r?#hBI#MEo<n0`Y#j[pl`/%;#nD3N[3T#oS/X[`*(H&5F<*3J:0q[^b`W[hPd2$6;@hLeb)G+0d#gj9(uk0AZvG&b0Cj$gmG'+0TZ,&*9muaIZN[$j33@$Rgs-]C%2r$%E1o*hK_/%"
        "F9Fs$qK&t[gX=gL[EDN$q)ck0/L]h,F'*i,oSgQ]wj;^O-mD0(QccN'ffBp&iCeA-&+%mLNWwaNw=eA-sEuS0;Nb8%I3TQ&HxY-NYoKi^9@n8%'nmaNW#5g7o-=G2eNAX-ltQX-`-/@#"
        "st@T%RSl>#hk7luB(6lu]7fl,%5il##q]E#Xw4uuM(5Yu$/>uuLN%fh%it&#%/5##`i.T%t?0Ab-l68%bff4]RR`i0YSYJ]QX`i0bfq,2`uuj[du%K%(ECGMY2C'#-3eoe`vii00neV$"
        "L*g5#J#gb4ddS8%S0rq@GpHp@L%<##H8:(C5*o>/-J7@#FY)^M)g@(#[3@k=0aHD3V>#j[=RA@'HurYN/[.peG10q[,DYHN[hdh2,n,D-GlL5/o6c$<w`O$Mom,D-PbJN-ui4g._<XA#"
        "`NTW$-L2c*-jaI3mY1_Ae>23'MA*$5VU`i0KA#n&K=bF3[`uf]x&+#-EHcq]aviM/iVDN$Hsn.M26Voe]9>(+S<Or.$LK/2b4.90[uo8'2E_c)_hf5#:jhg1@r/q[AC_n[M&e,&dD>tN"
        "Y%8i1lG&X[jO6W*Hv4Q'uvqgL`&-/(6$no%HDDQM'LYGM)UY,MraEp+cwl^+CM'kL72t)'(NGb%#sgQ]/UugL[E%IM5K.IM7T..MDNx>-gs7jLlmR.MIh&6,#I^A,=/WS][6A>-mF#]5"
        ")vT%#5@*T%ME#n&`J@h(&u,c*8hi%,k8B88R&;,%WO3H+cSNI3:7<iM.U^=%iJl-$xJv;%UYlS.R1x;%RvY11cj.@'SQ`$'=_i@.#Au`3TlHh,T1W*.RY)h-R0$2Uu<@]:FFNfLvlrHa"
        "V`bS%x$###a:a%vsdLv#wvK'#>v(E0T_`W[1^)N$&[a?$LvOg7SW^j0kN]fLP.=F3n:ZJ]:C^q)4b^q%+'M&1<l_gho1$j[)?Z)0f[pA(PbVsenCKe$dj-K%Pbp;.f<Mt7;-B@m7-e*#"
        "&aQN'J4kT[hMPm,G[*N-LJ>-2J,'q%00Bm,$at],4UA9]JR^?-&XpF.ZVRh(XKn0,(x0'#L5TQ&m80s7_QbA#P+,Y[0eRo[pSRh(klOu[@PSh(+wk@58M&<%<#:dMll9D5GJ$>$PB56#"
        "kaN:.HN5Y[`:Lv)Rl?=7wPCD3J29f3iB7f3N,tI3m/_:%B-Tv-q?`[,Vg'u$BkY)43OF]-1ioR9)BSt94W`QC`X#&>UO)L3K'OL3N-bWJbR9m0Dg+$6h,$)6D^<6An?[,=u,7p0lIaP0"
        "$g7i;TX0^@]3n0#CCXc2;@'8eQ/YS%DZ_c)j6IP/O1l4]WR`i0qr4:]Eu:T.'%Ud&/Ci9.o%s/%CGZk(;i4*+*_+k0(x;,^j>u'&(mepe,'?02_ruj[j[b,&1I%U[mj7Z)KN+@#*Q<pe"
        "H40q[@:.6/95Dj-7]KjL;x9reZekT[XiD60ae'H&1dWpe%@nAQ8XP-33(-%#qQ&w#/O3H+[[RL(Bbr>#V1qA(Ce`##(X2H*9L[W-hkds*c`OjL0pU,/r,x@,GgJo[po:[0/[q+*YIZ#)"
        "[c^6]oPM>5LWeh2KNv)4+gB.*ugBD3JsRF4PDRv$9$i-M0xXI)RW;E4;7KU)u,B8%&aVVK_xPr#,EcUmokX31T6x/rW4s`?s+dU0K/Cw6`P$&7426>J?l)AbQc[.q:wc31#N:lSNi*&7"
        "kxmx@37R51%/5##RNft#tZw8#s2h'#,#4N-T_`W[)r9H&bt@T%QqYJ]gU`i084h?-#1aW[7LMv)B?^+32Kv02[iuj[wI+K%1I%U[,G%K.e:eB#G+B+3p4$j[=H9Q,5C]T]NjZr%0`EC#"
        "@He-Md6pfLnenD0S>vm&O?3H*9*V&1sP'U[x^Mv)/E[k+$+_&(fc^6]-f+@5LWeh2QM>c4h>%&4HjE.35Z5<.uiWI)Uf%&4_T/i)vg'u$qaVa4^^D.3p$UfL#i;+5SKnH3T0wj1R_PD4"
        "p#L3MpeOpLF1eXCFD'k;b;MFc0,V[#lwP`>9X@%%Tx)U8CJ3>AH5B#BAeD.=kI@>#,]wf(6?v4fC28>,Z9u+Mi&Doe^NUGM[G`oeVD>/]T)U'#4(a5/$gwf(uJPfLYt-##OG;4#Yng:#"
        "NEX&#dr--2^ouj[sV-30i1],&.rQ)3K,6I6f-v)4D@rkL27B@Y(-0GGS^h$r=p8efN?Rt:F)>>#LGYh3[SpF(9Ax-#]+,##K=,F#Qi_7#.2^V-H'dERbDO#)FW3IMfkD1)3k,V/wwGH3"
        "*>`:%(I3Q/?bR$@U6db%(Yqk+GPU0<N`Bh3d`'B>PC083c0=AF`wh<CwTZ`*NL;20k5PP&vLg4]XR`i0_#/X[eA-Q#3C::]Y9fj0q]*v#_88S[o1xG&1ECGM?oC)3msk,Mta49%j14H&"
        "4:rp.b3]j0H[b0P:,tI3-:+N0u>$%l2C&Y=8*(FM9=AZ$``Z.UT2ScD&Rb?K6;fA#;-+<-o-HA%$-/J3GH0mC(#aJfOkkG2^6/X#<kf6(75f-#;+,##xRV=-ejEB-@-bV$_Jr3)@3#x7"
        "?tpHQ`vVnDJJ^-6F)K+i4(8Sn5lwv6.q'N$LbvP8F&n>69Nl:9Ta?(#P[E`a-u&&tA]L7#/=cY#,jo0#+WC(&j:a/1.VE%$H$;cu`+;$uThE;2cPIV6K$tc2USql&xX'58$dgQ'Y2]Z#"
        "fe5^(x>l0)4;lfhei#j[[]]&('+v;?mp@Z)fX^&(`YBq[I)9D5Iu@O'SdUj$OJ9D5n_k[$T;i`3twC.33N'?-vXkM(YA16Cs_Y%5q%`tuih9^uQ6NlC)CjWCCEpiu%?4,)$q>.q#)>>#"
        "?08j/tNhC([BC5i*xt&#]5YY#co#-.NRo?Ns,UreXgM'SiID'SS00X[ij;^(G+Zre_w0q[w6tv1'<FW*lB]T]Mv2s%OJ0jLUr(G+?jwhe42/Z$uvjT[e;p5,Drl8+T=`/(?H*T%rr@K%"
        "-Q2W[swDT+>S@['<dTe$=97O+if19.r1l:]QrHO(96+T+oK-k$QJj&+i]:M:Y9^Y(P*8g7dbIm,OYBq[PY9D5K@9q[bf9D5HD:&#N<Gm#+vnK(d60F*T/FM28-w)4%2J&4nGUv-@Tsv6"
        "J]B.*_-f<$G$D=6+N-m:pL&3:@FSL*M?4s:*p<1;QFgC#fxJ,*(_&E5;U'^-H*-r/K:c*GP&Na6UT2w.%->>#DJ&cr@c)Ab1,l4S[NQ&4i2+<*V_`W[cx=S[-m%K%@'QreY2k&-9[<LD"
        "'-k&-%JE0(Ups-]?C_n[dO^)'UP;n&$_]T]/Dg;-O<up7sUXQ't)/*'VJ:i:vYbA#@c*hu@=5gLtSrhLX>P=$N6#6#^IfZpuUkL(KtSBH]$gm0lkZx6Dr%&455%&4)G>Z,1V)Y$ocsE4"
        "a$<@6MFiN2JM/**lj]R/&1tqa$,r/NFfj/>Z%xN:iX2-4W`Bu$.EcY>q]$N0QxAmMmN`m$j4$##685-vd9cf(Un;w@SvYm#/A=K1Ad&q%d0aW[a8h5#/xZ)3mR*.2e.vj[p(Ag%,f?)3"
        "F#06&JaIZ%f6A9]mV1C&^:no%2W-)3Tf?T00+pG3HMh4#rZA<$^kM[$O0ub';Ft%tP4M7#O1Rh(Yx7C#d1>F%dO3H+<ggp%[YAa'O',)#H]UK(w#%hLGcKd4HImO(NIHg)+'IH3?(]v$"
        "PWtA#FtpvA]17T$g,i<d=DUuc,`0l`78fY#Oq][un+P:vIY&crCl)AbBDjlA&.m<-f:Mt-EGH&MsER?&$),##N5YY#d,E6.rv5Y8(mR5'L87g1Vt3T#mM/X[cE$E'7J*eM6jbo9E,sj2"
        "j:tD'[HTaa7W#m&DZde$23i&#a-JfL)<#gL,qeC#hn/T%i3H)4bSIS@TG@H)awvT.lt(GihV#j0eEx8%mAmu8'Pj+MCj?lL,:=JMPSa<'[paJ2E]%a+Nd?4C/5YY#jK%##w[p@t-l68%"
        "ET8G;_x0B#Tvg5#Bw*<-3hc-&E?AN9gtv$$<aTO9Wt7I#/o%eu8kh6Mw(x$vlsr>Ni);'#S@Bx9swlZ$,3eoe:[,1M>'m2$Conm-U&V*#7Mn]4.MF:CO%sQ;v%5W%2cc?TwLDM0M@Lxt"
        "S?tWUPM0S[fc`/%)JC,2IZn?Tr9Ym/4M,i_IFa4Qnkf9&m#CR'D.*l$4@K&tRtj`a/h[V$4^4P]5@n8%kMfo7?kK#$J3E#0jVeh2ua[g)/Rjf1viEpuxq.-u'^bYSCG$pLrcZY#Bf1PS"
        "-fe(Wx-J'JiN.S[bYDj$PP8C%hMct7.Dv[->G2]-I:V%k$fU%kkd61<W<IOMC,:*#DtDFN.;#,2([;#N9q7S[wkAw^P^*+N)$TfL**^fLWjrr$/Na;%*w-^#:i<w^$'5F%&x?hMVTd>#"
        ".EEv$hn.*4BJ8d)Pv6qLP`IE1Oirof0VH65K,>>#Gh39#Y'+&#JB;T+T_`W[#Im&(.R3N0Wx=S[;n*T+I#AJ:O5ZV[K;6X$-q>/]mk[f$OMbmfHm[f$%qjT[[Zw;*>D9Z)R1M/(8qqV$"
        "(=i;*h0?+*(UA9]#p)6L,NJ#M/YSh(k-:3$Uije)Av+1#3>*A'Xpiu[(&Sh('Lf?5nT)H&jc^6]%c+@5U(U&(w/RHMCe?x6aT^:/Ak3Q/rJGd$;bU>,>ErI3%.c,3?&Tj2i<c4:*QPa."
        "h`g5BN[LR0OZJ'5'wLS0a)c0=NjVO1iY8Eb?O&##[#vx4EB-JqElC[#$=VrQC,:n'B6SYGO5G[#&u#.-2*_w'k-pw'cE&##V?t(3s0LVZ`X+)*[Sf4],0gEYNUvY#HPCv%et,W*/s=fh"
        "``>/]h)U'#S4%L(DbV##sgNU.>n]N-*c'`$x*9T%x^D.3X5Du$hE*=eJoA33iK)YIIgS,6h0D(GV*lS#Ps_/AUQVQT6iut2/i9ugL%K&#^,MZZEaXS%i,U`3jRm;-hPr]$36@hLWF%IM"
        "Ow@peI70q[cb`W[fg%?)asxM(4G2:%mND.3ig'u$maG$KDU^:/CPmYoEpdXW4+sJPXVIh#CrWRXCT#YLI3*_o?1?s%BO2T&f)t4F&b:,^1D>>#98J'.iDEENQ-D)3>E35&Kjev%k,Te$"
        "%w]e$?Q>'ZBjnO(:=6g)g#4jLcF9H#/x-SunHGb#qi&r>_2A>#SAsA#p*c(.DFriMD'qW$;%-W%9`fF-^-US-`<:1Oo`Up$J3XN([C3huu%r*M>l<s>LAsJao:sn#g5=&#m&?W*Vq@9]"
        "SQ*G''lKI)&U+k0*7#RESi5RE4U#j[Wo=^(mE.W*?Pgqe+)..MYqo-)*QGj-hk>^(Zc^6]H9$X/flr/%`x9D5s,]&(eYBq[Ax(t-H.:I;s2Jt%MvPm&Igd2$-UZ584`=W6=wZ)4k_Y)4"
        "7@j?#l3$-399.wCtcd141D8mF,jS%fM,$p.4uq+eIXH^g^l[S/J6`;U7Y5cu2kZS/MW,?78pJVQH&UP&5E'?7WD%K%4N[^$:nkq]15>>#l%xG&ncj>['mRped;JX[@RBk$.@JX[?0r-="
        "<^nO(aawiLAD4jLeFNsBX8dWB##4;0$xEA4A%AA4GBSK*hb7`aO5G[#bppw'Xp%crwZtw'jWad4&5;PMRL0@8B_kA#b4H-..25-N$BC58`(LB#e5/X[-i>#Meq?##LvOg7`B]j0^pii0"
        "_0@LMeF`hL`i0a#P7AvLMG-##i>uu#s$kB-=hvA%p2ZQ&*jaI3/75##`6bS%4=%q.swa.20JOdXh]k]dL1fc)_hf5#'D-W*>Xf5#_7Jo&'Unm/1=^&tXm0vmt5J>-F;vl0V?%?)@2X#)"
        "b/c+k;b6Z$vs4R*uUs-]<U_n[q=0ta]1/CMF8^S[l%],&s`@0(2(k%tPS.0(4.k%t:HX8%c]Rh(OH0UBKPt5()M1v#[Q[GMrOaC=EMes]TX6##RZ:N$bf9D5Q&GO/>UCF*FU@lLv.`#$"
        "%Fo8%cq7T%xU`v#UXxNWk,.1(u*CSB`Q6)*P(+,PQYL;$_a_nueKIV/4si776tp$8cj-S#6fKp0q7Y&dC17j#L6i$#ZeMd&T_`W[C0Y[$353E3N[6-4*24qedSd&m#^IpeeQd&6]q]G9"
        ",'Y?p-dGS'Rgs-]);1r$DxH4$9d5m&4^4P]a[XgLR<Uk1Fe5t[W,Rh()O]?5uaB9%*1q>$?mp?7V/2N$olC66*>JD*np*P(63(B#C%(f)J?iH#Kk/s$V<vXcEoF3b%o+C7D,$&MR6%&M"
        ",m?]4:s*(#VMQ$v#f:Z#Qb($#qNYm:gI)W[`1&3$8s:P-K;Y`%%R#j[oAqh$-L>/]ok%t[cMRh(?9rv#2Xne-Y(-eQ#,f+Mh&Xb3l[Ds-j39H<q#Wm/+87<.KOr9fPubJfwS_&D.Y3`R"
        ".]<`RICCafU.cZhYvfSVJhcuTN-r=1-6YY#%h_7#>:r$#Tv`b&16;,^q6VjVTI&.2[iuj[`e'H&uS.0(e/ji0XJ>/]d)U'#29hp7J@pK2eNAX-0k'u$fMiC=TWb;/Xa7H#+>`#KJQOG7"
        "2Gx]Q*YeGdFn4Y#Hkt>7i.fBJ5TZ$vtkCZ#V*V$#jf<9#8L###SKjq7rQ[A,la<02S)Aw#^88S[N<#N0mEvA(Qsb@#Gp<iLHI%peeoHC>(GJX[ldRo[H@$[dW9dF*#vXo[pcL_&Eqbg1"
        "Ck-G+/f-Vg9'uk0[RX1(To>r%dZb5/bM.-)Ea*.M8[`=-K[`=-ON6j92LmV[DDK#M;YSh(Q(G?5?)HQ&i]G_d/rPW-cxO*I<m.L(LmP2'GgJo[%sRh(BB`$#VU+s%4DXI)pH3Q/9QaB%"
        "2Qaa4UgsJW=w(.3OG<*fUcBG=oC)*f>aiC@@St+=wm*MFeOoWT8AssMj%-d=XusgH31H%7<N'EHR5n)3Dh_7#Qww%#f3f&(Uh%t[TFI79uHo/1'_DB(Tw82'2,0qew90/2[iuj[rar>)"
        "(5+1(nJji0YG#j[:):b(bf>/]H>dX$,<Yfli&uk0Rxe0(^Zub'M=kT[LJ4S[gJSo[G_Tk1s,CH*_P'U[^$Uo-)dYb%:%LM(DDDM2wF+F36'PA#Ynn8%#GO.)XKJs7p_Tp7GMrB#:_wV0"
        "h'SE5>qa2GoR`i5TEE]5qid@)w:es8XoE5&(tiW#$I)W#iMgc=KJ>uuLv^#vdDJt#ZkP>#_mdw'RMJ^#mT0%MxEv.#$),##pNft#G<Y4/h]Q(#a,;3t@w`29rJ)W[gP8S[CKa^%C];m/"
        "k^`#)_oIg%3vD^1E,?G2%S+F3;S<+3oo6F%V<Tv-d<P<B$Q)wS^k4Qt%+BY5(BpJ=xq&>5=*ouLR;C`.15YY#Z)c(.BnU^8m1ZV[0-Wb$>e;29J<oT&0#GfhT8#j[ARLD.c'h)'C;7g1"
        "iJWm%nkf9&@ljT[uS%hLr)d2$MsaD,R`_R'G+kT[KibS[L)wG&CpHo[o^*r$Y[s5&HCn8.+@2##2T<?$4]e[-YSn>%mUSM'<3Q_[[HY3'<Y/uuI5?M'<pDB#+12mLPH-##C>uu#bVS/."
        "rLtcMf^G^(nIM:8ut7T]S)`0(-leR9`?;)br%YhM(&DR'k)1hLR.m2$Wu*gL]sp5#sHEk6(xMRMmgLx$9%,gL=EhbaI6gjpua`=-g.w=.`LKd&BKss%kxv%mb,MR*DI&X[x[T&(V]Vn&"
        "Bf4^(TPDn&Ouq@-)fvE2J2KQ&&+2Z)dhKI)&UA9]ndf#I,NJ#M1`Sh(PL_v%;_s5&duEI)ku_p.OKSm(hRo6*-`FgL(#a0(:hh0,=`h68Vck&#f[F%$/56N9ueB#$Kc7T%31JZD`;.s$"
        "E`@JOB=<p%9erQGmx<p%q(.Ab6$U[.*;+gL@i)9/w^Yx62fQ041jm(#$),##55YY#/h_7#+MTp7bpIp&6j,'ZYB4p%n6fT%_V0Z)1)PfhU;#j[+):b(fl#j[F&e,&`%xG&g[70(xjAU)"
        "-X#j[rCX)'OfA78b$rE4s[L<#(uDg_BXuL&_MuD4Q@VjL^V=T[p*c,2;NNT%D4gQ]F#I-)-B?M[E$r#$CtIv#NQ3_O57n##qBaW[ZDWd&)9ck0rITe$7X>U)T#SgLW/Sn$b)a*7@U1'#"
        ":3wS%Gf^0M$k-AOM0$_[0eRo[R5Rh(rT*)#=pFJ(P5Dj'LWeh2J<UD3WB[F4DvD%$4]@C#]Cr?#TR>TG+nVG)E<2Ygvck<1&n11L=$TY>6>:U/6w7luco-V0$eW:v-A###03,Abe&xFi"
        "*,>>#.(]w'71+AbgL/JL?6+W-pn15Mut4T#xuJt[[*P[$6jTRj@Bni$jjjT[R$)B(8Z%E'a']0(ldQT-0Dg;-Z]bA=(6:B#O&;k'_X'4.>TYpO/VNj$ZFL<hGR1@5J7tT[i,fTi74YIF"
        "v0UR'Ijhc)nB7g)R2^u&^^_,)YWhR#wJ;)'[WLg(4-6>8Au5=-5VlY#$Nj(*dK=T%$VF&#Z;(`>mIGxtbY>8%S//S[eYDj$*PL,2d3o8.[iuj[w%#gL:fcs-ZeFs<s12H*J#G:.)5q^>"
        "w^vXAV2MEu>^>YJ=a,V+%>3N0:$g5#H)4s$&MM>>:3[Z$n8B@#n0auJN=Q:v)Y/kXpEF]kK@_cD],F>#aXgCsSF*AbTe`i0/[rY#(Lp+M:,uG/X@f/%FF0p@jfv5/_k%t[P>Rh(g4;>5"
        "iUch2_<N1)Bf,29LbGP?<[bX#$o)D#P,YwLeTGxuf'w(#&5>##ksqt%9vW-?ER$gL3Sw[-#Hc]#qGFA<tJ/R36We+rA4`YGA8%30Ox=S[^5-Q#ELN>89<SP/oo,##6)Kb#lNV0#DSXV-"
        "91Xrd=R@[#jmV$9A%r+;FL@/1QkWg)N7=PAME$b5R>#P9;ci8]WU`i0$d9e?G30X[q8_-*dR[G)NRi;*WBL]>#1T;.&m?.*Nc^6].r+@5cHb5,IN0T%?$BK1c,A)+Uphj$U5@L(_>'U'"
        "hJL:%%Kq(6$Ri8.ai?<.KkDJ:Ruk,2+t+Z#.Z,lC`(o33BA2v#I&($7EqX#7'W>Io:?_wQ+a/s2GNP404E:=B3]s^@jI7wg_A)kbIiBwg+fGwgV@]w'V@Uwg%HBe4fh(?)DDY%M(9aZ#"
        "YGv2$1i)Cfa/v2'YFQp&Os?wg7AfL(RMI,)TCvp&Z%f0(@C6_f_#2/(b*?1/D+9q[s)(a6a;E.3TIS:/'6Uwek2F$3gnIn2>5mY#:_xY#1pGPCW'xZg%-1$7)k/dQCM]-)+gwJ39j?xQ"
        "lMTK/=@1=BV:b(N4VDG)N[5JC=Tx$#<AGp&`hf?2)6xv)N6K2'7J^qev3'/2(XqA4$2],&Qsb@#(E*pet]ji0Z7DK(<,6&=GBdv$RADN'>5X(#YO@L(.@l?5I4tT[0_Mv)Bqwr$fd#i)"
        "(e*^,l1pb4m::8.obE]-7o7T%iIE?Qr;_G$pq'jB)v/90_'?xH3Bsi'-1dC5'nA)R:OA$,Nmvo9Y3[/ZENV*#n%ni$?:5b#WZI%#bx#&%)>]fL?7+qe2:5##@/wE0-3eoep?[C#1S>na"
        "?@JX[vWV#)usO%#LvOg7.t]j0qP6.MURZY#x^n8+BR&Z$%g[)4S.@x6Mf^I*NGUv-4n.i)O;[B74bra46,x-)t`9CI<1qU<-m%X/CB,#>GQKF<'6&##R5-$v]fCZ#F'+&#qX$0#@h,##"
        ";$rgL3ArG/A0t.2T8#j[-W>j-wllD0:`LghY0c/1%l%t[IN;.3i%?/]87fT%?ZVK(Y@>>,k;;g.F3F8%#3BV.9_Mv)^44L(GgJo[d(Sh(0c5Y[C'g5#@L?j(or4Y[m;Ed&iEHI3`foA("
        "*WTI*4(7]6/(]v$+dfF4WEPT%Dr.[#Mw60)^^D.3;:b=.a-i#9fUxY#kNk)I+@PM*]7Ys0Q+d[?\?Z.u8%]$)80x[59]FTD=K%BD/60q)3+xcY@H#iB#0FPK=.?S,#pwq+;+Tlg)QxIG)"
        "2jJpK_r<d&bUiY#oh(W%xZW2()jhh)/s=fhgo#j[r?2Z)46aQ8-hG,*nZxJ),4B0%koeK(8N)qi@iN=(2TNI3g,4R8''Zg)GuEb3+Xuf%g'&,;JOqc)1wFDB,?GtA7@q[t/6SHbdYlf1"
        "aVUL=j+P:vmT%##@k/Ab0PE`W-Ci9.tI7D3*FADXHgpE[rfR+MaJE$#m[2H&Uh%t[e_T9TXDr/%2g/[$pj#Q&l^+k0[w=81:T1L.LWLj$:,9w$wA@<-p%[,&Rr'?5w[%IKnkf9&DxjT["
        "QI_T[Fd$K%xE=D_YqeqgfY20(xso6*s,kT[HSOo[9FTk18Bb8%8$0UB9mOr$Tlvb40d<.)P*Ig)L(F-Oh1(RGlp;-md9$qkOJ?JpsJPO-3jUL.i^U+r?PYp&<K4D<cP6XJSv7S[J[eqp"
        "a7Ba'VYQnCurE.3Coh8.dOOH,d&@d)DmOi#[[?I0GH.)$x%0$vo?#+#u^cb#=rlY#;Q5hLR>$##BO.s$caf<-$0h,9DSGp7,#s8AIqUkB.L`m$4&^L9Wglw7l-sG<]@#29^H?/;i*qA#"
        "hS.U.S5a`#X.m<-[VS/.)p/kL8qugLci8%#Pm@-#pUWj0/0gj07$44'j14H&2*.-OmKs?#%ou#,qo5<-b<0`&A%d29>Dxp]@Bc/(QtY@5Tb8V8ul^.=W3K['EKui*9dGvA=YI@>1+0@'"
        "`02n'Grf77?dHH3wt&01p<#+#484e#44i$#=Ze^$IM_8.kXtD'$&%6/`rMm#GERhLIJ3R8pZX&#S+jm1*Uv&%_EWR8/%Wm/D::,)wD30(0J=L<J5W#/b$mlArLnUg#)P:v8&&cro-3s$"
        "/G*DWP2P<1=`9xtEZZcM5*Sc;SR2e$Ga?Q/?;<E3U;#j[h]v2$dB]T]vLNp%q@Dp+/s=fhfAJX[^@f/%i*8$#GgST&i6A9]h#ZQ:T,'88[;Y)4dRdUARc#K)ja#EP:Xpk1c:es82[1<("
        "7XvC+gxEE*$vYB,U:ICQXnDV,#:f<$0#U8%UQh*#jq]&v%rC?#J$of$SJ###xibo$*UYJ]PU`i0h*eC#'^da$xqM*l/t1-MP,r;*o1+:0BX5@5)eYB?Y-&s$]c]&(I>w.<Z)pG3w4K0<"
        "iA>9B(ha$@=k+Z#8_J^Ztg8au:_f)Gf#-8%[@Fk:U,OJ-2;^;-*%38<t<oNOB'l;.ju#dL1iit-jl(BM>9p=1W:5B4td4@DfYeS%uDS6`tkFuYYQ>A#V54gL]n[`*J%hS.6%Ad*HZKLN"
        ".CsM-0H9.<Mbr`b)G53<ABW%$?b+Q#H^,m&62M/(0:^&t4A36p1[B%'u,_hN&xR/p;T'`&)AffL*@4aaQG>0p/o#]'%?_hNQFU&t[r144rBjqKv[FI)cj_t%V3C3$M:Y_H;(PS7.q3R%"
        "h+^bG%ve^$^kFJ(Ka#Q&`TSXJ&AuWWXm([#NP?(@O/iV$H)L3W4Q+hLrwGI#Fm)R4hCBMBJPu*%f,(8%iE/D,M6(7#$),##2M>s-P$RC<*7(B#OCo;<7R*e3)qq<#(uDg_GImb%EsJ#k"
        "b5IN+Tck*Ni=`a%S:SXJ%2'-<x9Z;%Q`@T%q-IVWX^C[#W[GgFM1W4EDF<T%4Fn(sO[v3'[FS=uX=Hn&x$###1u_vuWDY>#4U@%#)8q/%Vh%t[IN`I3$QZqT@xI.2b%vj[N4nWK_Ea?#"
        "0vspeecNUK%<F])5l#*5nfd/(JHWh[Hm?g%Mw&&HIDrq)/<kT[[Ug)'._0N$K8=W$E5V/(Ad8m&lVFl]J*wDE1VbA#B>&X[0eRo[S>Rh(xE+@59bJe$+Q'U[),a/%D6to%LWeh2a^D.3"
        ",Hqwei.<%$x,Tv-V&))3e[E&-S^5uKIUap%cpIB*PixI2f264*I#tFr7BG#.37gEuV*Y5(U@T9r8evms>ZI9rv^&>G%>Hs-NKoG9I`D<%cbKv)JsjeMo*KeahChXAhhR`a-%<*euUWh["
        "?Hcm#f#ck0K*uP86.Jp]3@N5&4UM13U_UQ8mF9j(;;iP-+r'`$8S`^@eFOX<kY9T7(*8X-_LM0vNkRs$W@H>#wQi22^n`+5[-_E*4]1v#x)P:v@7W+V?tw=lLI$)E],F>#.<2MB=c&a*"
        ";?_c)IfC5)TG*F3(lh4V$'8f:[LwA-1JwA-APwA-4w=d42Bwo#f=L/#3O>+#mM/X[ij7Z))3eoe(CBT%Aw#j[]8Ed&b7X)'h1(A#xLTE*PKl2$N',)#Q+rK(N,MJ(;+;D5TUtT[xfd2$"
        "Np5Q&^3<k9,`Y#>SwC.3+WkL)Dfn$$.m@d)m&@?.kj]*+AGeeOVsSA,HE=^,d9o(-p*,;/pc%&,?Y;#vpHG'vbR+Q#2%vY#:L]9v[####Yfv$v'+iZ#e)+&#v5<j$Ks0H;p53D#Ntx2'"
        "#'Roe#[[C#')0X[m&s>)x0m'FYiV<%F%QrelYft[L?Pk-)%N9`C$..M?Qc**^cAE'gkP(+HN5Y[Jm-K%%/FM2hh>l1^O6)%w0;GDe?(%.iLJ=%Mof2B[H&t98Wn=?\?RhK<?OR818^*$8"
        "/TLKUVGtB'';s&=TR_NEChCXB5xGA%,C(h.U5YY#@0G0.-]jnM*9/J.)G4H&iJ$T.6OP##>#@I/t])N$9PehLS3f.2^ouj[Jq+W%,@fj0GSI(+R6G<%6U6.MV=6##CQ<`#c-&t[k)U'#"
        "O`uJ(,4Y?5J7tT[GG[i.I,B+4*g@5A<%$eO%a(h$Q^R513*CZAho_w6ag?B_T6Nxn_AxIFgu([6[?jvnwF/j-5P1I$Q$,AbWuSY,(`u?^;.1a3q4sm#<$,3'Dr8F3T8#j[/=Z^(Iee6/"
        "u'6^()E(gLf&>/2]r:0]>-;.3j(?/]ZZ;.3p^f+M&'cI)`,$6#$9hH%l^X,*Cj_h.ac>/]W#Ml-LsU0c+:[hM,2OIAJ4@m0%'9q`eo:E4TMrB#i^p0#JYaDDQ6)qL$ux`7hR_>IUs#h<"
        "*X4%At%bT9AG%(8%A@>#%d?-dm.A-dZ?6ipF5u%#_uRg%+@nM0))wE3>Q66#u<>gLaKXF3R2#j[)8JK%6ee6/xx%K%58@hLt,,/2d+vj[_[b,&>U`>#LIp+3hr#j[6U`v)Bl&G0/'^j0"
        "v(,:]wC.@'uoIfL-:#gL(,1q[U&l?-=tdx%.kw1&O`d8.D?c2$sx_5/5gJq4,$209q[Zo'^TgaaM(o0(Yn*l$JFgQ]ENC,)7bU,Mj$Mv)ceTe)9xc<-<.%Q/2w'3$)mqh1#oKB#Cas5&"
        ".hUhL>Th]4..h%#FAlJ(S>)n&LWeh2M,B+4+EsI35SMT.@vv;%rb%T%#lY)4a/P(OnAd(I&p8+*mDm[CaVu9W_EDZ.gQol/vEg12mw7O7*q<&dB7YY#oE+]b,tu4fW=18.DjN`Eh3:V&"
        "HZ^/2cB4T#-;0X[gN?a'kt[0(g/?6s:B?/]L(i5/EQE9bFaj@99E_'#Scbw#Jj,baAn+GrvdH&4oe)T+lmkl'V]Dca1UD>#$=D`+k8uA@O*?hLJ%To[W5Rh(&D5Y[aGWd&/v,W.Cd^2-"
        "(r4?5bA0u-O`-k()j[K(Kf$-)^dg40Is?g%J#gb4Os^woS*tM*5Ko.*I5^+4`#VD3vCXI)Sh7#Q,RO*?_b>R0sBq]$kbKn0uN?#%U;+_$LX2fF.u^_+BhoX7kPth)/rRBJJNj.3u]CSI"
        "u1]i(%F&##Q6E-$TXH,$:kmB7^D)N$6Z?D3WA#j[3MLe$dL&>-0,d,%l+8H<&JM2'Gw2;6&>uu#Ol&crM$q4f?\?(,)$u3MK3nr##b@tD'mW<Y$;6;,^(1jv#7PN&105+],F]`H*&DI#2"
        "0#Gfhd%H[$5@ji0t@$j[5:wd$.j%pe0>ki0matM(WG)3'j$dC+]N3H*2@Bg.#ZBq[F)9D5C)7U7U,`0(x3d_+fKMk+;f9i(j=;>5IpJF4$jE.3s_h8.ri/+*H,Bf3<vU#$hbw]FWmx6*"
        "sa>T%=^VDSFXvGR?&A&J`&sDIcM_M34Xe8'K:]r8Heqc35-ZX?=,[bdU@]ahuS.U#dAFMZL]+fhOf0P1%V3K;V#3@.o5o^5F?uu#xY#p%O%=Se[=PV-m.VoI;N4[#^r[,&HZ^/2vF$j["
        "qZIs*C<0/2Y5RKuX?0X[%Y`/.H1dre`$1q[1):-1KN;.3df#j[RG@d/I.F#-8./v$3uBM(B/GN'*a6Y[b=Lv)&)Qs*6t@Y-1Vw<()ptT[pLf,&;$f:.&u9a'8?>m/_Nv)4tf%&4Wd(H%"
        "6i:8.5@j?#8'UZ$:_YI)AM2]-^LMt7T8q809.44:>?ra#;<s<-=Afi+FG7@#r[pEFaEYf2;sX]dk'`]5fM*B48@vP544n0#6l@J1oNMxthc^V$LUf:d6dV)'7M1gh:[,1MgaYgLoR1q["
        "Vb`W[cGHm#-lH)31N*9B:^*l(gE?B?5'DR'J:eO$*el)tW<Baa6ZVGiAEOr.fo.K%)U$1,S/t%tEmNT%3lhL5U:'L5T7'L5#5xfLa*[]OaT5g13tZS%>&8>-ks)/36<wS['ULS72;cY#"
        "5.Is$.Rr/:]lq;]U84P]8X^,&*.=G2'w.J3nuqB#O+i5/q*ajWwO'&MABiqW1?^JfDhq-$ueK'#m*^*#7i9B#.(sR7WIf5#''Roe60<5&Bnp)#]JqB#e5/X[]@j2$UsIv#6Rq>$#sQB7"
        "Obt'4X_Y)4F9F==qFAbu,kV:v$bRI''Fgp9xil&#gueg8v8Hw-bnJ2'DC)seLhk/M:(%K))H,N-^Ddq]XT)4+JrP^?`97se1PKX[2HvD0oWe8+8xg>-1KxM-S.,S8pA(<-4M,i_D+VuX"
        "nkf9&awkT[pI_T[#=]2-_d[2-#le2-@Z(h$ZxrW.W/[g%j[hS.Ev>j-u;+&,GgJo[?oSq)Wx1$#@OM=-fm>11qd_6]:1l@5[_Mv)0@Dn+-WV)3uT7x,<`?<.(gE.3>U^:/u%7V8X<3%$"
        "Vt@T0?O7K:24fA6GBA&,Ka%$(Av$5JJ<3*4A0lJ(ENficKN=>-K<#N0^A%@#L:;,#.n`r7eaDW[Nx=S[^2q5#Ub8#G_.oUJ'h@k9m/5##Vo%P#YZw8#>@%%#SGt$%,_#j[c(],&oh@K)"
        "2/Yfh<-oi$ka7_86R>/]lk%t[d`Rh(8'Is$BtY@5B;Qq%J?>=-lcg@3uiWI)o1ANKWT2*@4mX31(Rl^GeTbQ'ex@21er.m0Ixp`#:g#>>5caY5=wfi'&`g4]XR`i0nP/X[w0-]]1/H$G"
        "+?lM(W.E#G[._#$@u7&G+n:pf$+x.(Lj_k$=9qu;fjI%vP8$C#w1`($I#vY#m->>#v'>uuGW'B#wA;=-5A;=-_NJX?4*XCnU_T_4G:/@:8>c+rVJ9b@Rtfx=v_o`*;j%#,Deh4]Xdm@E"
        "hR4:&s6&8&LvOg7v?]j0_'SfLq,wS'%S%Q,4;lfhYG#j[VI+K%H<f?#Bcj*3ci>/]uk%t[N;Rh(*'1A5xs^9%gk)T+-,+L(50>@5nT)H&K*AY-qNst(<#gb4%i:8.7.5I)n7Lh&+XV8."
        "m^le%8vXa42o&$A2+eS%*BiW/p`*+3=].Abt]>v7%N>suBOJZ$>9<)+fX_=3K+-5/l)/s-H&UP&#u>M9G&X)EhKD8]#n4na^=no%=D<*3P'5/%(eYJ]t_=R*/c=gL)s;0(V>#j[h:=d&"
        "7<Ks-H]_,8IXvZ$]Nv)47%x[-GYph6&_1,)T3/]B7&h17pR;8.K[HNN1-4e#xsY3#pFQ-H;SXuY)Exu#hgH&mY^g5#1IWS)nrf+4mE^QCi(%7Mdm-##VXZC#-YI%#o%*)#iA/X[Xq=j$"
        "HEvj[X.jm#oaSj0S5#j[[>Hm#ciO@#t@&e%LZBq[NG9D5CDm6&XAW)'*WTI*8'L:%lYWI)@f)T/)_D.3VdPR,Ss1p/lBW`+^p%+4RJI9%N-t#-d.Kv5i3%##g1KP8o&FG;@`_w#f9%##"
        "#IQ0PGP>M9vrl.UR>:5&SP<A+23M^H.;4qevi/X[eE@I-q=Z-.?XG/It;mK)IBo?#+WEpeb>A$T3`ffLl`-c*Tu9a'=FD>#C1e'&jABq[/54hY81YgLm-sv#&kKT._R(f)`[@f$Q9-T%"
        "TM2]-X?#AQ%;pQ:?$XB5>K]B5]$$#5MxJT:oQ`s9GtQP1Ca.51ql,$M:5c[2R[lb#v.mG(dxt.#mW-D($M#<-R;X7/^>uu#S[9%MK%Rj#kpC*M9k0&vGt_xLf64D#7`9DMMe6lLivHTM"
        "`UEk#(#+GM>C6tPVb%Y-pc=F.j8i]4]j8jU:kSM'FY*&P+lP)#KaB#vIirO#6h[%#@%/5#I--##>uGrenP/X[.Ga]$GHvj[ZI+K%WACA#I7T+3n.$j[uk[8FZ$EL)f/Zba0+0&tK^Se]"
        ";]82BE'Zg)6^ck0XJ+a<2J28]fHmL4I'j%,Nq'30[P'U[6Hb5,;CkF6Zsdh2[YVO'31VM3,,6J*?]d8/#RU&$X0Si)]S%&4PbJX-VUN.5qtQ:v2P###c?aYG`7+5A5@@[#*/_%#Iu6^O"
        "EcLGHG@uA#Rd3S*00+x9t8d*P6&;;(XLp[OJ?WmN89^3Mv[ZY#,>###-',Abw@%1)i&j4]ZR`i0mLmE37MAl*fRK/),f?)3F&^m&c0aW[pfDj$9_a*3nX3.2[iuj[k<Z&(5j0W-p0Oq2"
        "6jH)3J8K6&Kjev%b,Te$)-^e$/U]j03S/K1J8]YOnkf9&?ijT[NA*I6't>ba]U[-)%o5B().q#$KcU0(r5)x$SUch2a6CUqB0vM(:m;F30x;?#MAPYu>xFY#m5i(ZNAf:2'Ri>5$$:uc"
        "<hu:#$),##3av_#L[w8#aM=.#/kgWhEF#G3NES,9<:46'FNK/2HLpSU%2^fh*^Mp$E$ki0;]<vS3o[U/d:;k^81D$#=g9v-HN5Y[q_d8+3I^,/mP'U[0T-Q#&&?;.Tr'E'du>n]P2***"
        "Ym'<.lr*^4^r%BF[E=m'1#(='jtWQ)$3LDU#%=t-t4Vm8o,W,<WGuPF*+H,Eti:HOYU?uu+Wr,#1%rv#Je*jL>&-/(w5WT'JY$T*[RGePN_HM91B:@-xc::R1v@F6PlR62`O7`a1JkB#"
        "2`+/(jeJ&vBK;:29$abN`C6##h@9:2M5###0bGR*OtUvLkDhLM`E`hL>ecgL`IQ>#2fe6/N5YY#tU0%MKsE^MOlaf/<uB;(ge;UKS<Q&#MB.u/#)>>#LW+:$Xk'S-/C(tLWi,t$Eeq#$"
        "i*(PfW(RX.8xJ*#StbkLN[,[.v0(B#<O]:.swX&#/7#kkM(:L,G),##2o.F/.23)#0H$o@:)cu%9HC,2cqdC#kG/X[W7Nm#dh%?#Sm0H;5IJX[ldRo[&S#[d5HTP&#vXo[hYL_&-I4g1"
        "Ck-G+>_L#$0@DX-tH6L,.fX,Ma^bp%bZ3l_hQlH0ot+U&D4gQ]Ba$-)aB0p%_$PfLWeVV$_D4i,e5gQ]`I=gLn6oS%?e_>$N*[;%OmJT&N#?Q&kta>.H;<H&SZKh,DhQh,PeFQ#AAlV$"
        "+WC(&hO3H+0Uch2mX_a4:>`:%pcD<%mq%95$50MMlT6xm_+Y7m4[6(#WMQ$vle:Z#kN7%#ga9B#:BI&%ep>NDnE`)+;b<.2dh?C#/A0X[YI/N$1I%U[utKd&$d(K.eRT&(Lk^jL=@Sv$"
        ">X]f1IQo5#1ufS#n&u,Mp8=EE&,#H3DQHL?(#/9&t.x,&&x_5/WngQ]'=YgL>Hr-MRag5#+g3.M&:IW*[Lx],`66s.,QM8]u-DN9nnMW[:q.W*Or4?5s@/,40?5Y[PDV,/R.P?5:N'p%"
        "q_^F*)1Q_H$P7C#QcAX[0eRo[0,Sh('U+@5'2m8+LIRQ/S59D5p<(E#<):W-kR`?@6P<^4V=2W$le@l)Bl'WJMu%TgOIfo1VtfV8O(he>or[]4U:.xS@#^-F]h]m8+:`:T1jT#.$k(2>"
        "eO5V8^M^,/x0q`I0cr`Ir)P:v]b9g1veUt-[w$###2BP8MC7VQbL?##p.jNPN_HM9udOkL.k7+NgT8IG6vKW-Ni<_A%uu3%mFlYHG6M.2-sZo@cV[V6H&UP&+I;J:f#%H2QX`i0C6;$#"
        "c0aW[^=83$=%29.Px=S[`qAm/ZxVm#DvKX[<LTk$*O>/]f)U'#[C`K(=?o6%jF+F3RA@@fsk^w%V9XQV5PPZB[39N%k$cGd[qn(;@?`*#p?>'vQ`d_#v:q'#(O>@0dR`i0o=ZJ]^#,F%"
        "mjG$KbZ0X[.qP#255*4(#mji0(/'f$aapj0]cuf]wl`W%48Bqe1Aki0R9CkLg%rF*RcX)']FgA+b+wW.AQ'Q,[4kd)@Kj<%-@l?5D,l%#$n7#MLBrN(]*Tb*T/FM2xOFb3vf?p.]]WI)"
        ",wl6:ji]+4hD.&4q`l-$k'8<.rM[L(DGLJ=I*u#-,OKu.^Qlf4O-2K2Lb4A-sEL41VJwf(,CZv8un&Q0;v>W.KC&N:ZE))-ghg(4vfg&,o8pe*6D,,4B_ChF$hrC(ptH0##2Hs-<:=%R"
        "'LM/#(R]:.uP55&_Tx&cNBAG;*$'A=^`1R<I;G##6KvJ1X#x%#tvK'#Nii4#f,>kiKehreYa6##ZKVH3(`$j[>ug&(/RR6/_Ooj$;;V<HW78^H;4Lre^t0q[gv=t7SKM=.]]i/%LvKX["
        "6CTa06BTj0iC<b7OS3a0aD,W-uX;f4+VS#2I3br$9JU6]?7g?5rx<a0[-fu-&Cbo9(TM8])9..M',x>%9$l@7bYJf3IIO%7RCIX$`/TmA@/3Z6,3<d*p*BT%(LK2D6A3`FMM)$-5]GQD"
        "E_QD*]E:6Cv>u?6]$hM[E'ZIO*=Cp&krqn9&VNwA>^:r/)r#P;l7/b6[1FUC_q%ht[OW/8<2s20#^55&x5xu#:,&crcW/s$5PR]4oCGl]YRw'#$pU,/f/cue-P,:]pV$@'LRXF3^S#j["
        "F8JK%Z5w3'MR5G3YG#j[8N8S[E-h5#[uFue#q1q[>c`W[*3b5,?,wV[3Dk;3L+A*+</QE#87')#1vd[$_G,Q(vLLh1*a6Y[oFLZ)V.nW.Vec;3r/=x,Zwwq.r*Wp+GAd'&3f_26^Opk$"
        "LIrQ]F`Y_/n2'U[1Y=d&]7O-)>iE/%mWDM2S4@x6mwlX&&GM:8D't^eR+@<.$3Tv-iO4j1p:Rv$`Bx+%>?Xv-&gX(55nN)+INaW/^d34LWs@>IS39Yub?]s9ZoI<.+)c*G`mmD*fT,O:"
        "2&8P#N/xj2YA9o[`d62;kX[`/OvZ7&(KKo2UbqY?v:w<'$>%d5Iv>98if<j1oCxT6Y#+5.XC$T'$),##+av_#.MY##[hHV:cibf*<8Bqe3@,##.jape(,0X[rx=S[/Q)N$NUN/%<%EB#"
        ">uGre*,ki0q6&L(J<F8%Zro'+I03H*:%LM(%q*)#)<cM(@WeA5B%9q[);:D5SU'U[/cX)'JZ^5&Xh]w'j2'U[rVeh2'IE3&ElNbP^5E.3X5Du$J-V'4oC2XKG,2Z9*r#P;fRdU0Y>im9"
        ".L'to4eUb*0LVM<FH3IG/Vfa59;OODP2jN;.GcWo_a$l$=ZXt-QKtJsL@?>#4Je*ZC*Au-1vKARObHM9PG&T*ZG4.#h<X7/qf+##U-(,MXA8'NO?Zu>F2f/;&;cY#]YtYH2U/:2BelA#"
        "BTT408%g&v^Kl7(dx;X([kP^#sDE%t6=c&#C_7RNv6[Y#DJ&crdp6PflNEM0uKm4]kR`i0wUZJ]>@Mo0f.;,^%+,2(e;d2$w,2$,p<]T]x8Ke$4'M&1;fUghvvZih'1drekAji0$:M_&"
        "EK$j[?R.W*m&b3:K]=U&'lJ8#p+lg1^Ut>)<rcW-Hq*XAUdSIir>cc)k#<d&Q5ZQ&&CaW[UV8E'+Tck0rITe$H>-g);v28]#>5_-EO,@5[?AR00?5Y[%#,P]Q:Xt?#dC(&TO3H+JJC&#"
        "#s%K1hEU6].=1A5GgJo[YO9U)Hm2>5w8iJ(sn%?5m(g&4G]R:/Zk_a4iVp.*:>`:%qYVO'P8T497n*H;+87<.Lg3nKUw[8'JSDG<B*+05WY@g>O,cDQx0Y$8jG5q:L:hk;=+EXo+OhR&"
        "X(4f<rhPM(U,q[6#E7)eCpBM3g?_sAbEDP:3@Sq$_en[#xGc5/nJl7(2Q1oC+U%ab8-exOw20W->4[d+D^Zb#[YtYH57>S*]bHM9/+Zw9M0xZ]LhGaQ+:kB-ocf70JrKS.oeK>,jYc'&"
        "bFNP&S//S[j(],&imp8r#<cg$/4JX[YrMm#>[ujKpwo]$>3lX$=l,LqW20U#Ox_KA9GhA@Hae$e]$MfL-&j#vN^cb#R@%%#cT'B#F;+B(T_`W[ml)6#,QD8]dM_$'33ZJ]0lu8.cD8S["
        "cuJ&4+K0T+E*J?#,R[<-2T=j-GTT/2Fx#ZAG-l@$u_ec)_hf5#rY70(B6Z'tGs1/(LTZ't0p.T]@Z$-)9c%tKL*A>-N-A>-<%`5/UhgQ]41PgLlMO/M(NJ#McQx?&F_>@5(J5Y[)Od#)"
        "dJRh(c97A56u5Y[RhGS7@eAQ&r=ke)6#V-O+c7C#pM>>#/e:8*=8e/1,&Sh($Fo?5%v5W*P*KK1P29D5(4$`4>;gF4:5JdF#Li8.U`<^4s,HA'G6i?/3C<;:6oJU/,7nu9)@E9f%N6nC"
        "qf@N:EQ@&4OK'AS)*nD4JK^xStWbO#c9e3<A>h-D@u/(#4ok+Da%U^#oxX&#hZD'',A'cr&R(S*ng(8@.Zc:2@lfvR[NA[#ci7#:mF:jB/'bw9.]F_AUsIS7w,]Y#`aBZ$wxIG)XH.DE"
        "pCbm$>6ZJ](-gj0$5F$#vI.WEf.O^,npwM-dY`h$kYwc)L@2Z)pt@`FKmi]-k0;Z)MYBq[UY9D5_0qQ]o?.],Bl*)#'TlgL%,/L(TXX^,Ldg5&uRSq)tVTI*.&M:%t]DD3DvP_FqtK#$"
        "d]xn$Q+rv--b$e#qQa+5=rL<Cnl$]#e^K=8,mYUK#tEAO3'cj1c?V#1[Q1xlI=jRC:8fRCQiqjt-Co+2As,.m.')?RR3gZ$N5&r^g&bxFN)$K:C:x%YKY?T.IjLvu/nbS(pv>*P1BIY%"
        "L.^*#)ec+#4+rvuv@hf#QT@%#T+9A;]fA&$^g`I3c[rY#U)-Q#7=ZF*^Q+k0%/TX[vj7Z)ZGd5/lAo;*Xe?.;u(-Z$<]hH%XJK;o[Cl[$_-,Q#?,*I-,ZDca=WwwM*/^S[m;Hm#%;41("
        "2=T&tI)D/(H*U&t_E2(+LM'kL>:iv)?sck0wXTe$w_k1(4T>R*_nHo[a0Uk1p)F?#OSEI)@E@.M7>):%]O3H+P..L(1R1@5ClWD*>DiD+3sYV$>CBd)n)YA#(fn$$<I'>.0^i,)TI;8."
        "=.;?u<Km),ZW'Y$=9<)+k[TauD+XphIb#j'GWCRuw<MN(34.,;k^jq.x>==eBd4`kCpv&#69a`#vDl(3Ls4s$./r%4n5j4]xR`i0.([J]6V>W-*r9I$PSCW-/8LU'lPe12[iuj[OCpA1"
        "nqaC#)Fn8.QLO,2/%pX%B7mre)/0X[DWNp4bmI21^^r>5d?qQ]>4B02IWPu[8oSh(Cn)9/*a6Y[^$42*XjQ121.Y&#lA8@%J>.3'l&/h,<%&r%_w4k0FHvN'wQJn/VsnW&3_=-;B.K,3"
        "j6Ct%Umh1;'Wq'#UB')3s0LVZveUt-@(8W]f+&8##%0'd2EauP;S_>?.Zc:2]bHM9W6q3+U1Ok4H?o;-0BWb$t)q#v`Vx+MmAaa-&Kq34uQ:v-L$8R*^]J`A+4?aAwL9`AM<&##<a[B#"
        ",v./(Ld0'#,ac;-wFk3.dU0%M:v&nLMsvY#BK*p#x15##&2jq/Fi_7#He[%#ks3_$3pjpe2@5##7J^qe2=>##CVLW$r6#j[':Ne$wlN)3osRv)k6J$#LvOg7''^j0FHujBmtR5'Z)-W-"
        "4qS9LSevY#V,e,&VlPd$bc^a*6gNZ5N#G:.<*0VoEpdXW6.sJPCBdBSE`-G=0dXt*&D?W-M6B-dxop;-%DsM-OsQ*0$k^v)Vq@9]>`uS.vRZJ]+l,k%Hv;,^pXXQ'?uQj(i+J?>o(%Q0"
        "?'tW_M6$j[b&e,&eL0E'l,<.3<>Kqesu+:]*OsT`AbChL(l%-)F5cu%j-&t[,l%t[n1Sh(Q=s]+QB3H*lP$.;3*VT/pc^6]reI=HP>,i=TcT)(#-;d29#:C>l%o+MJlCO;DXQD*T6.lN"
        "XXjT/5ghA7V-HDuo^Am0Fv>W-T*pr'P<EG>QM7&G>@R78?:x%YWd+<-]]AZ$oVLt-3JZcO)fRb%.*V3;4+f4VGwDJ:R^`M:VaV'#,W7)vbrUZ#Bmi78Emis%Y,8$#6*ml$P/>o8o]1uT"
        "'g@pehS+:]8shv>i5ZV[eWKZ$H-M$%ap'q%UrU7'b-&t[sk%t[luRh('w*)#%p,f*VTfm8/EAt@2[tUdjhLJ:GKvN'^(d;-(O3'%/jgW-ig80uhw`qKvlc&#%4n0#'b'eZ&dWpepO,F%"
        "dMv2$U_`W[Gieg.]dK2'FO;se/9Z02[iuj[#P@g.tM%0(t]ji0ei#j[r#_,/-IZv$Q36kLc*[V%.51u%0>FL(Z3(w,RE3H*Dedj(--%Q/K)IK%eua**/+c&#.PwiLhU^?5H1tT[>;;g."
        "13x+;rf,g)@l-<-&#)Q&?(=;LJ>.Y8'g442IX)n8'**Z6K^./P'_TH<_2g<&H2ho8xa(*4HuY/ZHhI'?F?(m9+,nd;]ukA#uVDu$+^&crY%dYG*[EM06I[w#U:QoR#)P:vhen;-KZ`=-"
        "+f`=-RLPh%HaV2:(ek;2x@QoRR4Y<SDa1hNW14`#:w%ZN*+CA=a(lTi]cp-QuaXS%%QYc2A]k4]UX`i0wpSfL5KihLhKJX[JP@g.1dWpeqY/X[xx=S[I72Z)JdVseh<1q[Xb`W[]RFg%"
        "`'r;-lVCj$+VU,2n3*=(0S3C#)1D$,VEBm,X^vkL:6RK)V,e,&tHG[$8FChLhV;g(gGjU.b(MT.nS;a0Ur:T.B0p5#/`Ys-]m1^:5:Ia-<T]T.s,qG/0>FL(r%5Y[u]S&(MBNO()mLhL"
        "P@li(-`Pu[7KEe-e-DM2IQl8/L/0J3bGurHP5MB#:.d&+h3e1IQ/%_#[j5o/rkoCuLv6*,LoEA[?1I/$t*uA#L.0/(P&U'#xhK#vm8&=#kZZeMcAn9M(6KnLDCMX-wi0I$:61AbM,@D*"
        "+Zwd=9`nE3AH'L5N;<E3.1,###PK**=Td2$`u>Q&PXVZ)EUJ2'6DTqe(5/30gFo/%N2-:](cpa>,l/1(g5ji0$+3+38&'qenf+:]7hq0,.2[TII=pG3IM/YgC&#:.p&#A#TiG2CcO$I#"
        "r&`v7wscN#%')k#ixisL=3lDuXid_uGKS+I$),##+tfN-?0G0.=XG5N<VIeMhK,B(2oSW[l=83$OT^2'>.w`%lR%Q,Xc,U'<pIiL)ZPgLe1#&#%i&',i6A9],6OX_'p0q[jb`W[cs(^,"
        "XjU',LP'U[.U2Z)[2=hCdm@p&HLfV%fa4/PUf[6:<@oh#7%T<9<0('5WoND3B2[@73vrQ9qe4b$I)d3r49rxu(][2.U%brL*a8%#qb<N&GAe-2gGSX[jar>),E*pej-[C#)qWt(:9Sv)"
        "$=)(FUq4MXpig^F(qcG*(0['#cYBq[Yc9D5hKffLiV20(,Die$=?gw#0Pr_,4<0.c$ac8/0Rqq@8u5I,CV4I)]ND_.QZh^#$UAa#1QOv-(-8$9.`EwT72DwT2:bxb_RmbZhN<Z#a7X)'"
        "=>Kqe-.,##qVij'c^+k0&?Js%J0IL-vU)..=bsPPuo(-MSFdj'2>M,*Ep8j1kU)..+QdBMemp<Mr<MB#%]CZ#Y+emL.CLv-e)>>#/XB[1HuC8(Ewu+#5`5##Yt&WounS+MNCQu#SxX&#"
        "+<X7/Au9+v%S4oLWklgL6t+x#h?:@-dVkV&lG.+McRZY#q1(B#.0p$&M),##+N?(#+V0%M9)f(#RQums]58S[l,h5#&5eoe4F>##m[pA(6Ce-2XJ>/]kk%t[K,Rh(%A5Y[G)e,&)I>e9"
        "V8xlBYi1<-xxnj'dnf(#kK$iL>CSYM'oA%#.aBZ)s+,KESs7S[^$rd-lP`<L=%9+3oJ-d*uUu#$A82.;+Xf[9v3(69B-n@t_==[Ro1Yc4JacWB'>'w%#n9;(&+Ow77Nh'#p<#+#&:]P#"
        "w7>##AoSK%uU`i0^NUGM3YNY&kF+F3eE06M(sJfL/r8)vYUOgL1$*$#F4ViM?#=d&+'RoePOVBo=M%E3i:[-2g4vj[i3?a'Ah%?#+WEpeDs/6&HNi#%_-&t[`)U'#j`I&4vu.&44XsJ)"
        "]j?#5/>Dl0xr]du8@1s?iVj22#2Qf15o)Ab.[(`$$s2D37L/AbSq'AXp`+##*Z%^fj:tx+-pg(a@PsP9jOM=-R>%'M[G#VdJtG&#v/8<%udZxOr%[I%-bLgLAX5^(<PgqeWZ:0%$F#j["
        "IsHg%%ZXT&hb@0(e=c'&tB>/]C(i5/cUHt3<oWrDn[6(#^b+Q#KG-K%BKaT[qK[Ke`GT%5_8uf1FhW`aT(tD*+'(N$Fp=6#5.Is$MrYd$ShFQ#;f8mAHVbA#rk>$$s/Y:.2di,)%0,K)"
        "?eM0=H,^w6?^B>AYk>`#23VH,tS'I*[9'U%;*w,*hi)wKwYgO]t&.(s0mkd*+0Mc#6lkL<Z+9)v]Bic#o+uA#@73b$6?T2##)>>#NjvC#3h%Y-aD7R*HqAA=a4n0#Fxq+;q/R(s,782'"
        "hD-^o]qv>#V/6Q#k+.anwEE?#6pQ)3[M#j[rn^&(S.%T.d^0[WqE#m7^D]UJ6:RR94Fqc]p7(F#D)9foO&gWl_3l?%h9fYG/3#,2t[vs9EW?'vR:FGM/jlkM9HA#M[Lco.ajvC#sLco."
        "Enc+#w72iLcJ)Y$fvC*M(TY&#P<;^#w/D:2xFB`Ne+[j#aXx+MaWqw-?*=gNM.gfLQ`Ye#b>Uh$A8i-Qpj9SIkd0;?Q:M>?v=6R*YJ.;?K1HP/&8P>#J862'DbPQ1o<@q$h_Hv5Vx=S["
        "h5-Q#6lH)3]P#j[nF4H&cB]T].79q%/eis%a5?Q#GvCe2[<]j0f2ji0>)QQ&O?>Q#neadt_eDW[pVeh2NaZ&4_H/i)2'2K(N,`E6GcG1F9vKJ1utwA#J]d8BT18t>RkS-QS59xtBfK-Q"
        "`Ks$#23f&(T_`W[]1&3$Xq@9]UU`i0mR*.2nIvj[f(Ag%(SK,.tJ_-M$M+9%`#>j(/lYW-?HV6Nb2a6NRWV6NY$oV$qW2H*ZmO/)VpCT.b/xb4.<Tv-fqwK:`H#J446<bNnwcW0et2E2"
        ",_.F:dO:;QEn_a%?aP/$swX&#e_+/(F:L/#/^Gl$J5YY#+Z9%M2)D1Nshc*vA?xn$2W5j#kk6=.DP*SeN'mxu)?:@-coOkL@g7[BGw__A;]ci9eX8m%MSs;.mXIY>Bdkxu<OuG-48`90"
        "RVXxt,pZo@QatEI`e[%#.*u4%XhmY#]i@g%E;[-2^34T##s/X[o]k8+vak1(^pii0_cYJ]jWfj0-CRj'-s_8.4M,i_%(Im%CiBR'IKs-];F_n[T]k4]&vhh14^4P]A>*?5]O3H+D&c%#"
        "cCUv)^iQu[WARh(g3*)#m9at(v1pb*9A%R/k@C8.MG>c40$^K'^S&k;(djC$Q$4f;h:#^?b7D.*NRlD#aBOs/Xt$##pwq+;j(sc)Mikr-.Y1RjpJ;MKLs<^,%R7[Gv0T;.)J=w-+`6)3"
        "c-1q[vg`i/'VIg.#Zc/.:xxg%$p9q[YetX?sH)s[[Jn0YPAVj0lFL8.tkXF3vu.&4GqCi%p^oY#;$,_Z$0.51s5-3';*w,*,9#=A27AF,Y7bnucJ37%la6H)_]8;6^55o;wZGl$pY&cr"
        "1Z(v>HPds-31HR=*aZ/;6Fk<?w^R&Gar(A='wNjBmo'B#fa7L?c?5R*Gah;2T3T%biO-i;*%*A=WBt(3ZB[VQ]O+)*v6,GMMQGp.coYJ]^[u,GQh;Z#+L;s%UY;j0xe;,^Q3+x#l%xG&"
        "-R>j0mJ4W*tTX1(u`ji0c[kW[ukKa'*C]T]-%bp%-b7p&M%3p'.v_,/u5Km,eYBq[W29D5R$mB+k9Am,%B;3'3@('#_iQu[6><X(+6EM2'*fF4'cXF3&8rs-t6Hv?`;=W6E:s6/KsU)3"
        "R$oC=D2odu@+PY#Y;Nx'S-=BgN?2s(x7lv,TZ0N#N+.0&<xZ(mDHFdT?/.Z#GW,V%g9F5;Fr#:$AOY##)-E6.jmUhH._DW[DD7d/9_a*3rZf8.<%0^1eujA#la/tq5i#_+,sdA,(mZ20"
        "%l@g.+N$3(uA(tq*X#j[0VtD',_@T&UKZkL#xvW._T,a+bE1W[Og_j$qvtY$55_6]51P@5QY=d&Z(+h(:u19.moka+xs]/)(qbZ-72Y_/()Cq[oV^'/9]U6]]@xfL%tdh2L)'J3]G7.%"
        "H]`m/;f)T/<<Tv-,]Eb&9(:f3F*'N0d'_>:_N[VD(8`:Q%3nd=s4[,E9Iua#tFHJ#h8.[#%Hs+=XWd9:t(lEQ;/Q2SWXwtC0A@)6.wDTJv;i#7wC7m<9ewL<h.XdObCg)$swX&#i_+/("
        "s'trL`f%8@we'B#&[9%M2sPoL`F?##uZJ3%0lj%4Fv,AbUQi#$h6/MT`(^j:gH_iB0J;:2GqAA=;bpw%0pwA#'^5WodT7DENf8<.S&qRnqrL'JiNk8.bECfqXOpA#V6OJ-=H:@-RX`=-"
        "9Rqw-qe-:N@]8wuu)>>#+sqw-nsoURlnHM9^n.A=+5m92mJ<fqeWP?pS[m4]OR`i03YTX[im.?)e0]T%0'$j[cFc;3.7#T4?(%hho1$j[5VKs3*G3a01sZ3(kOc'&>N?/]iZ&c$Pa9dc"
        "_2Xi%3fs-]EF_n[ob>a'WcrN'tBaW[$Ox2-K)dk0*uTe$.]I_&:Css-]DK#MAYSh(u/8*'&q*#-Ie6qT#P7C#Aj$9./7-A#ht.L(#S]>5&K3k^>9(,)kQh02HN5Y[6-qG/;ix8&%Am8."
        "4TdO10(R12u,VJ(it=C5.gv:%S^13$qjN:.a.i/)UB?:@pZuS/ooN$8`)E.3A@h8'(aBt6=.;N=d*SQ2K)`QCaAp<C4)E_,wwk4:FwZP;'LTvAr#;j;A`R_-4eYn0g#S_>nDO::?72a4"
        "t@[%-SkI.4Vf_)EaS$C#vDl(3p03s$Cj:lorCi5/1p`/%Zw2F<j]Zp.4P0X[(#>S[F`T&(>q>re[n0q[2c`W[GuW)0N)QQ&C=vre,7;dO>c1j&ru9dO.iN0(Qds-]IU_n[lX#E'USM3'"
        "sBaW[xE]m,H#dk0In=p7/K28]OSUN($5c1^`o&b*sb.<-9qR6//7-A#@s?q7nt[/3G-xr$t8Br.bT3H*Gw)k(7x5Y[q7:Z)U',)#^Q(kL;2#C5B%9q[A`:D5G1'U[($Js*P5;j'bFw92"
        "qS'U[T%iE%q^D.3FH7l1gL>o$hjdh%r`WI)J6@b327rE6dOlY/w@BO;w$pnC;K#l9O@rT.Kll@?YFJ#'9c[;8f3WD+t;Bs7rj++5bke=-IN]a+g7e>67dk;Je1Yl(Z*ad499uW8Uw)p'"
        "X.wu>VO'&+?Uh4]SX`i0T8#j[phT&(`;11:)Vid*0K3pe-#9a<R<]T]H+RS%.jape&p-.MiQoW$DD.T%pjF%#Y>*-&wwG(+HN5Y[Ip?g%xY9Z)[P'U[v]Hm#Y%+h(LWeh2X_Y)48%1N("
        "Xm9g'683D#dC:/:G'HNBB)$k(Tjte>>ck83=ILa3'-&##B0OxuF(pa#'rB'#/0Zs*.T_H/,5Dj-V`TjLBS0X[oo`/%3:**3eK=,MTxOp%_88S[0Hd2$9(e)3-K9W-'O:O+.%3t_tr[0("
        "))ki0sIZJ]VhBU)r7A<?,]tQ'T(Z3^i&^;.re>$g:;uT[FZBm,i3db*2kRlLgCUZ-x@X<.6c'M(g,I],is'<.P3,Q#C>(W-j'S49Q'mS/dDkPTH(V49WCBv-=fLl/^p%+48lY9J(aVB'"
        "j`1u7SQF&#b$pV%*n9;(r+dE56iP>#m:w0#]h6##>p4Y#@h_7#PQk&#ton2-T_`W[jl)6#Z-xp][W=&#uwl>)7pjpeu%,:]`RgTr*RTq%%FT,/9YCghp`JX[rEvA('mM7&Qldg)s6A9]"
        "%)2C&h00q%cx2+<&vKd2wh*H/_oIg%cYBq[F;9D5GF5n]`w_%,btY@57Z52'QWCj$&3=1)@DXI)d]]+4d6oO9A1G&u8n9i:&3r#%M(jL1Nac]#@l5o/rv8A,)tP^$r1+E*T@]En_0CG)"
        ",pQS@j3Nm'mg-L<(F5gL<V`/%24w)32=>##davP.jJHm#XJ(W-3hkUg-2xpenf+:]>?5VBA^Og7LT9-m@(Z68sY8W7^E]j0TF/T.X_Y)4G^Rh%QBF:.N#G:..)M/USE:/:[6SO#<BGs>"
        "ZV4buD+,##<p4Y#FL31#R#S-#=pZ20c`m5#E`sE3-gKwK*NL,2Wl*J-j4H-.cB4,M*:,T%_88S[EN#N-_)4s$I%6^(b.dm&K1H^(d,?50tT]j0rr+:]:8.@'@4pfL6du(3$pji0B2=1)"
        "%kYGHgr5H.m&l]#3V*T%n=gV6u#Y<8fpuAJIY3r.$arO'_vnB5mC)v#Q6DCQQclv8xdah)1K.)$]=IN:_v/DE<,O#HM?AG;65:3Bhw%h=#M7$vN4KV%>r'crUv,v>QH0<-W8f.%Kd#&Y"
        "cKVs?5[2:2.;`s-cSDoMH?3^'=]C$@eX2:2'dO-QlxFlEWf2:2Mof_Ar,Q*P^>]^.uK5+#4;:-)<S,.<v#A>#U:n(3k7.AbJ]DV?R?TZ$>RQX&S<R:TN_SR&x;-IOvJ5s.t,0Q,OP'U["
        "$CQ#)&vpY-N>Ag%R82N'6h2H*j0h/%V/(W-I[>x>uWm;%ddvek2hi8.$jHVBB)]WBPYLQ(0ZeijQ8&8'8aXQt%+BY5(?^/=xq&>59H<02fXOX?wdU&5aaDuL$jjmLj&E?#6S<f/i4k/."
        "T_`W[@J>p&+K;8];>^;-.jB*YNi.Q-QqHu3-D=d&iO)R&fw`W[)Bk8+4vspeN-xQ-nQI'26^hA5%6Hq%j*Wp+rqQlL@rVK(3'5@5N>8B#SYBq[r@s6jq]C#PG`&TAg=169/:h1;)-LsA"
        "muO59rH:-k3Im9'Cn>N1n)P:v@%$##0QbYG:ANY5r/5W-Jb=R*JL5R*/+F]b7Y-v?2XscWSEPP*hvGS&fm.n1(wiMBmukA#T1I6%OA###`$kW-mr3:2Vq5R*iE'FIcG3_AiK=VHKu%Y-"
        "OY-FI=73eXRI-LM$nU[-I6D*[UAK-QxYj:2;4g*#_u:@-TJRX.n8YuuA*6rBfdA%#%*6rBvb9b*UK+<-wN7Q2-dC)3]P)Q/T8#j[taRs*=h`U'G?B7/$OJw#AG8o:..09&xNRx,E4'AX"
        "6.qw%qDE**^/+%tN]nG2-N5j#iYw8#&RE1#?h5##Rm`a-Z#<_A;:/X[1G=d&EQ#,3+w502J'<$[JtYJac?=$[w.n/(Rgs-]O__n[`ibS[K)[g%u>ck0k4Te$*4U2(./&a+H(=#-+:-$$"
        "?,Zm&e1CkLYoKi^I?#n&S2FJM@wNn/]O3H+KxrR&;0E'%w^D.3Xwr1);>#c4tllhMYi.d#&n.i)ZFIw#`cZ8/?a,s.TM`C=WAU8.x]0I*,]YM(0Kcx#6Jsm*)F.*5MV2u$=cvw-8^lnC"
        ".aOH*7s3A%=f2=.jv%ip4_q5'))>>#,jvC#LB*E(B>ni$Mt&YAZoW>-w7gSSpk4R*Pf(##4qAA=V####2[oi'[7wu>,N;R*MV8R*ItAA=EOKR*i7n92kZZcMWGdu>o#n92sUn92PC?>#"
        "3kc+rtvaYGE-axFX5(,290[8%n)UX[OrMm#e?\?g%&v?SIlHH?$X;d2$W'JZ>xIZV[V;*m$j&kT[qK[KesQ2w7'0W@$Ttj`aA/M/(DxH4$59Os$=Xso(-?>G2$SVS(terF?lg#/4Oca+r"
        "nZ+i<.pfYHhY@W[fJHm#,a$dM[tjfkZRkPAOip-QI-d)3I)D/(F.eO$6[5'tDU<`aXV:ONC=Z/(spOn*8RhhL:F5gL:%HQ#C7`BS`[K&#i'U/>@/LR/-9xb4([<P?9W.&4BKC$Th(2rK"
        "nKtM07+jW#l21/#Fu(MMbR@peoxEd2b$aW[jM8S[nGd2$)G*peK',2t2Dxpej>ji0M](K(u:8>5<(#w-fYDD3f$x;Uiq>g)pa5x4J^b)+IM8k;5^8d4%ee],%EdN'D=@>#[7N/(;:;kF"
        "=[U50_`0i)]wI/(iLL0YNSW%X]O))<WI75&*4?M9+aFT&7In-2an#B#g7HqV8n#j[]SAa'^i@g%=f*iL?xJO9F&xP'CSBl5I7'U[jfJo[cMRh(oRM>5&3=1)*W8f3$-jhLRD--3>U^:/"
        "qZ1T%@Yf,3T84.3$m*.)e`[h(WTxZ-eu6w-TBI0)hr*.)Tk%%#E:+_YJ^af:O&`c)AN.S[ww]O4o,h5#.fWpenJji0FVTI*,%?87Tw,nA>9U^Y'2<8&7Iu&+xfp_%V<cL1htRs$*5jb3"
        "vuJgL_d<c#gk71$S;r$#5cV)'gZ52'N%0$p-pQ)3NNFn',-[oei(q)3c.hJ@:'JH>)RGgLr`IpeTe?pg(@w.iMb`&#to4T[lVDj$wxe0(;tP'tE+0q[N&p*`>%;Q6DT/T&WlaID7Qkm'"
        "Yr@k'oDbIDJds9)Zr+@5<&vM'6pk1^<n]2']bC@IFj4g7NNd,&`YBq[NM9D5vjS/)5K1q.B-Tv-j:bPiCx.211-NW@EATv-_*LfLVn6##qB8X#731/#-Mc##xn'N$b:c;%d@PZ$T#+s$"
        "[7LW%4;lfh%WIT]=F*T%&9noeD5[V[,+#h%<?&:lJU4VhZ?o8%$M)9.c$s8.oP$3qqv9^n_A8b#oar0#P=JX-e<Zsg,[el/5@@[#FDBlLi_?>#'H%crUN0AbixUoIcUIp.`R`i0<Vmbu"
        "&KVoekibq]_Nfw#m.=d&-4%m%J?$j[/mPj-bB]T]=LFp%xhUV-:'R(#`$aW[ubm8+dI9a'rn-B#wVU&#Kb[v%7i0M(ZXn-)$(,)#nBfL(kZe<-QY=d&&l+?5ZN$i;2e5g)6,d,%T7n58"
        "m+h)3k;/nf1Q9Tn/ws=A38>?Bx%]h(6)<t8n96.)>%Zc>RP$wHol--$[[cm:r+J7&0.]vNxH3YlveUt-SPW9r.(ajMALhkLF#6m#n`''#LFKg.x/lG*wQNQ'va9I),[?T-oaZp-D=b[A"
        "dO5^(Ka<IMbw4.)1;[)0V;Jo[@gC0cWs[iL5R8L(i`4Y[S,e,&1La@e&)m]##FFg1q:Rv$,0fX-RtC.3H_+T%`6Tv-9cl%Vho851sk4u%Qo`.E.G/>GJgw#P0juK3=TZa3QPK%6tTsde"
        "IFLafxx28&Cqu&+5OwK=;a9C+@:v29$<=B,[qbHd)?F@nBV*//g5I8#DXI-d1OU8G5gG,*V,Ws.hC4w>Z;t>-q]:E=w17W&X69aaC[k%td>Xh[Q;<H&v5ck0^*hQ]6+:/)M;t.M(NJ#M"
        "Qt+s%M?@A5Sh`m0*]*)#M5TQ&@6]],dF)W-E]sx'^O3H+QFo4'M3,Q#%Q7K(L[>D%l8Ph:,6S.*Tu>n]DvH-)ctY@5PItT[%Weh22]GG',DMt-9hPE=K($WIe;lI=q@u]>.VEr$).j*%"
        "wN0Ab,_6=&D]t5;t7NsB/'c5/;L7%#twYQ8th.T&'Sop0xwSfL9N@g%J95g$.pQ)3JTD%%'Uuf]9uQS%*Q<peHa8T&-ZUGM'E.pen`Dm/V$nO(N`0i)Fc1p.6,RD<W02UD])]j%m#sx+"
        "-pg(aOfif(iqZlV)a%peLM#7&HNi#%b>S9Al_%T&[?J;%4l9w%+nYJ]9g+C/v''q%kgO@#b6xv#^lxA(Q',)#>F@lL5oVL)*)TF4m_Y)4pZ'u$?a8PBW(7=7gNARJ:InM.UW9_6[KMk>"
        "XBmkE=05##4vX:$Dxsb.Z9F&#q:/+%96ZJ]NR`i0NY(H,ke5^(x;%<-aZ+k0CbgHQN00X[lsV#)eO7g(gsw@$^$aW[[]]&(nNIs*/xZ)3Xe0q[EpTW$0'uWUualJ(3_C@5KYhA#HS_V&"
        "*WTI**cTV64f*F3?DXI)gDQJ((ZVO'.[D$^eQ^:/gf3=?#qe3O2/K^AU/oW-HHPulq/Fn:?Z.T@=HI'`))R]AcY_`E]?+pNJ#s]7[NXmLLN6##.?uu#fOei.Pqn%#C6MP-:B7a$=^;*e"
        "6nkq]Ger?#Zj1F+-3eoedqZC#%#0X[<D72.:tCIN=lC)3/`:kbqS0q[Z1pC1m)U'#`eIL(_LTE*k^CL.V$nO(SBvq`Tg3bNm(&t@3V&UB^$2^J*rR._6EdH6p3WSKo0@%k%]U@ko#>dG"
        "$%iI_+8v(5m<:H/3(V$#X<7#MefA%#'b`t%`#19.Kd%%#h+c2BbgG,*s4+9]o9fj02CvX$';B8'>Us;-f8r]$5S4<Sr=/L(nH*)#xlfQac$PU%7i:8.'sUv-#fc;bps;s#BHu8ChQ$-?"
        ".kte>:1uM1RILIgY3'fh?FM[&Rc/)$t*uA#AR&c$JINg4e'ZfC#:pS8<1xU.rMft#EE:@-R(xU.&tl+#F_Jn.LJ-g#9Fj6.N$x/N#>%E3WMYJ])lT<hk^+?Ght)9`pQ<r$+xii0[M#j["
        "U[3Y$mveW6D$nO(_kY)4?.lr?rX?d#%]Pj#X4B)P]6YY#d/0I$R#>kF]bJM'%h<LGUt[;$*JSU&Tfl##m[,o$$C#j[bM8S[IV6U(Goc^?,okn'd&kT[/8st%aB(N$9p'-;uU]X[Kd_j$"
        "p&ck0ICgQ]Q8R-)gZ09%Ep=R*<%>R*[nHo[BXTk14eiY#?bap%bO10E?T4g7FbOm#M9lw$kR=F3oN,O'tu9G$J2ln%OsZo@='J,3q<ep&.e7G;xD.X[]uDQ#V_`W[YOoj$jJu_F%e,g)"
        "iwv5'i+9&Fv+_#$vOR8F,B)-*V;Jo[MmV6NeHDM2skstK=5#f*H6HT%x*gm0$HLcV5tqaAe_xPVx0299]c.AbkT%;C94:>82J%##:V^-Q>RM-Qpv?D*OFt1Btu-d*w.7H*+sw<-j,T2("
        "AQ^5/nSOs*KVJn8I&Sp&uh^eDEG]t[#l%t[wiRh(ut%?5.r*N-,rw#1)1qA(Lggp%^q.W*BUe;-L^oZnt]PA#vkh8.m(TF4>Pu6*4[eLMZifHsI^.70(g/[BfX8C5kxE;VlhVd4=x=+B"
        "f_8l)&^La62%t1TJ3hCuiw,G4(RZ`*g1ns-CDhQ9j)_>$+BWv$8=`B](RYJ]^9fj0uuNv#qBFc%SGoO(6otM([C3huss-o>cL_Y#HQ4VH<X/Ab<<CG)1+h4]aR`i0S;>/]E<;.3?ijT["
        "p<Z&(k<oZ#pEfjO:IDhhfl#j[p'ae$v8ioeD(0q[Vb`W[mW;B(e0Sj0ci>/]mk%t[niRh(pu4Y[[%ItfReE]-'GA1(]MqmCl-Zg)]H7g)>Cqo75>&-:1>3JU38Oc)CP9)*m*iFT<#`fQ"
        "%,j:P2*15%n%*Ab^=dl/wom*MScIDE9(&H*9x'Rsu+f0(3h2H*9=lfLNCDN$o$cgLv4jj$IUJ2'Cl/F3WA#j[gM8S[tGd2$40vE[.9b=-7+d)/&8(,20P>naE9,naUY,1MPN>gLb+1q["
        "FKNp$SvF_/Y9K)+Ldb8.p?tho`vqG2:-,Q#[*-W*f/ZbaD/N-l/xR:.>6Gm#<wH?$Ttj`a4pdsMv.=d&Y<BaaSfI0(:@q<1icVLfRaRZ$OCkT[Ma,l0VM8a'CgFQ#o>1h1%%_B#8bhV$"
        "Y8rK(T7xE&*.=G2%ft'4JR=F35rql/,8&d)*1M8.Hsvu5qCgYaId.WBQ`MOap6C,A>j.Q#<P<D<$):20.ZVs[`5^M#Q9'@MTX$##?t3xub88t#n`''#]i@+%#OYJ]iX`i0+pep]wKMd*"
        "n7X)'/eL&4(PDj-'gw<-,tDp+$?D_+LvOg7kJQ*PjpJ<$N6#6#c7:D5*peK(=u[iLtOfh(2J@iLwbxL(53Q'?MLfm0@c3n:9#1s1joId)*Y*T%ld]a+V@M52;<Y'6@')P:?otr9,p.'A"
        "(eLV8&=4WJZ+kP0oUn=7o#xh23,4R:*/jO3$Zq]7+bL(#S26t@cWerQN]MJ(EWnp'^l*H&4X/r8`srW%pDO#)/s=fh#C<j$,%ji0^Y>/]KEVm$l;iWju(uk0kh&AA[Il%tUg,ba49-K%"
        ";x7C#KPu/($@I6%Ze>2BpN2s[stxNK'UX&#oNJU)n'E6Li@8=%pq4D#Fo0N(5Fo8%@sN'%c,#A#&$F'%`p][uWc_nu)A4</*Ul77A6L_7q73S9^L_#$oot+;@8Q9iI&K9i1x^%OE>Q<-"
        "<6jf-U$xjk'e9W(5gpNkQ^sY(<4RwkmNb^In%ra%wG*nDD]mYj=obqLPT:U#Mqt/EVq5L/0oUvuA9oNMG^F)#2:###;$rgLUmg5#Tj.Z#e]#^C5%3%$-`NpeBp86&E3m&$^$aW[b?'Z$"
        "'L>/]_)U'#UkSr87O4K1:=Hg)HkSm&c7o.Ucc#/P@]LXk_TAa#+dtbrs4:vuf_&*#8I@[#Mb5##bu;e+aCTVMUu'kL8g6##LW+:$OYw8#?@%%#/[tXA`&8S[m,h5#8r1XLc7TY[h#]v)"
        "fX^&(Yl#R]7%MZ#Bl*)#ZCiK(AXV##F>7T%Jr'f).NP8/bS<+3>U^:/Ot3RgO`vGg*#%'DqGAaSS<_fCK5d,T`:]EUSWn-Ijo`B9_1h^#rh_7#C,c98T3ZV[r4E/%lN@s=WT1'#t/oO("
        "Pm3jLW1Td#Lh8iThc+ktrcpA9PtmY68neG3Q&P-3s0LVZ[YG[#oaZQsb*j;-9s+G-qu+G-Jx[/&Ng;9]`9fj0#>BW$@j0K4a`e,&Md,_J/>)+48%1N(rJSt##5d`EcY6oR%a*^#*@?,<"
        "6[a/)]QaE53v`oe4F5##mADN'wiaI3nX3.2c(vj[]RFg%6=*W-ch7i:.cn]cUMg693K)<%U$t`aHS<W[95c36mA7*B/hk6'_$f0(`oh$`@JB`V;3sS&Nu/T]Q#.-)3&Qe$kkEQ/<dTp%"
        "#KCh1sCbA#KuxX[0eRo[UARh(i`4Y[J65Q#R',)#pM?eM.X1?%u@A>5p<(E#*)TF4L[M1)0J>c4sZ8s$6;BR1`#:;.4&b>F_1$j'UlpHl&gV#.68sp/@(3fU3prB#*WnnPXIVS%38HP/"
        "5Z`A+%7OJ(Z.pu,8@h4]]R`i0nP/X[/6b5,;ks*3&&0X[xSd2$/xZ)3U7;8&E3m&$]JqB#H)H_$&loJ1ek%t[Qj;.3ac>/]pY5F%->Uv)_r[,&pbqA#sU.Q,jYBq[KOkc6aAsI3$:Rq$"
        "tkY)4M#M)3>U^:/vr/+*:ZQv$L=?#CH*6I$J,GA^_LVwJl@J+`@+TwJnZKqVA9=XMXbB&@DI[YB)3VdB]klOG$),##^p+_F@m1t.(#TF*8O#`F59@G=4jDnu;M+siJ9Cgi,pZo@i-u4f"
        "H&UP&s<l&HXo4o$bkgM1Yb`W[awBH&b9Sj086KU^/FuM(<:^L;A8J)=oaw0<wwnilZ$###WVH(#t2wiL#f&%#-3f&(>AU69mG=q&j?to%oW+k0@X@%>UKPcG/w(hLBB.*3I6S,9EIAx$"
        "M0p5#R',)#D/GJ(0L(@51sQY>XGu`4LZ(9.]4&>.HtvDE#N3T977U9C.W%H#<,camXE_N24rf77>LkJ2TAGdk1QsuPTG?#6)fTB#Wh%t['K+f*h+Vj939BtqeGr/([sk0jnU'b*i%o)<"
        ")TDs@e2xfL/CONNTm[`EQ'IREiRH,$ph=(.b/$iNlQ.K%)4*u7m#oP'b3I)NMAl_$c)ET]LhET%/pjpep/mD<7^OvIWKII-EkrM%7dwQNQ)j:P%/5##-5YY#rY>ek:H&(%rlwG)_T+k0"
        "Rh3T#aZ?i&L9HI;VV^;.CwtG%0(FK;[iXfa8eDrR$K<&Aq8&s8.m(i#1,UCs2>e^I1,ms:;O-?5,j_7#4xL$#2O>+#/1###2Z?D3drYJ]98BHQh%f)*gl[>%>h/X[FYSk+:vZ)3OI0q["
        "ib`W[cnBd&H;7Q/oMji0OF4l'I)4gL#LY@&%ES`#*0HxFEUJ^Ii-f8NxN4'6kXCRu^Y@7P,Go(<+5eM1p,+9&t4fr6VT9<-`ip,.ZtSb*mH_v>]UV6NQM,1M_x(hLYL.peKO]3O94YgL"
        "hms>5t/oO(X&0aN=QNsB^CK)I6OiI6%:kcNe<%D#9)&cr<Kv4f;Z0A=D)c%#XD)N$#.Uc$/';,^a(b.)ljkg$Vw/X[g*(H&?PgqeRoP7&IW.?%g-&t[x4WN4R8Rh(e.;>5'^IK()M5Y["
        "Xc]&(Ouo(>$uha4t*5j1qCn;%WSQG%0ni8.l3-d3i_sMDKS`:Q/hDZP:jCm2s'[3VQe%U<)HkW/<UwK=Q**o:AY,dT&Y:)##r^^#v3(crN/N-Zw`8>,MRFW/c`R^$`t>B#Xq@9]5nJ,2"
        "rR;,^KeW9%se5^(l^@m,9w4q.fb`W[TRE_ZV]1i:i,k#-j'v>)JGCW$/j9q[T>9D5>;iJ(X;3H&'b^l:Ht]G3s?Kn&[Tx0:G>Ha3wL=p@(5gvc6S=/fm>d((4BY]gullnD$c_nuWw$*g"
        "<*9*_$FwS#Dgx9WCUH?U%/5##>.7m/Ng_7#Oqn%#CXei.&+*F3R1L`$6?;,^PhNP&@cU2(O6c&,`f.Z>85ZV[.5<+&+e#j[sJ7^$?nJX[xl5Q,Vke8.5Wkql0uw20FibS[Z`oA(;GD7*"
        "_kf5#=F2##lTA9]ut`61a/6Q#-x7C#>p=/(9B]7;$.L'+OEc2$vGX#)s*JT%[PbL(CADM2'xT_4h>%&4PP,G4>uv9.nJD,)W^Tv-YiWI)Y5St)o%_J3;&n*CvXNqN)CEA5:&:W-F*VU:"
        "F'R.)$u+&+#lu%FSR$=-H3V*#FBkxu;S3p#Eww%#-p7m*O)0b*w^Va*O7]j0*-h5#@'Qre^t0q[33TO&6Zxd*,+Kj0WM9D5f?U6]9Fu@58ZBj(JrQ.;KxxU7_1L.;a#wU7C3^G3cJ=0&"
        "@g^*46g7#,mn/,)-pOoR6.n;-PAnI/2japeO-w3:#_V,>a6n>#._n<-+k)T+@*k.2ci>/]-B(hNgQ&W$xoOo[$`#[d4M,i_FEk_q/i8d2@?c2$T=`/(EiL7#bG=g11q]e$?K4g7Y]9Z)"
        "Nc^6]x(8?5a6+T+XreK(GgJo[%sRh(E5PN'2FKoMeffF4,F^:%-Ft1sf;(u$S0H4KMK=W6HgF?^H4,4;3s@>I@q8RE);wK=De%J=H84G#`cFS46;k@.OD.sKpDT=;_Rcr9q@P,#r<#+#"
        "XepU#k4tL<Z>KL=Kt'B#Q[tS=2_.s&_wh;-%41Z):[3.2XJ>/]#l%t[h+Sh(8Y,B=WbZ)4+<:A=dX4K1?TG@@wdm-3`N%^A1^u]@)6gF4d6n@t[,g#6+i5685m@F#0G2Q9Tr?t.h]%hc"
        "romcNq6T(?&xSfL^Tk`-+Ec-;?jiU#uBOr?%/5##em8i#H=K$.+Tv>8Xdk&#`xPm&MK^5/n3?a'@qq,M>x;/:OW^/)xVDgF4$3#&-quf]G@[S%JJWJ%-gIL(&fx>5eTFgLfoH(#iUch2"
        "max9.1W$E3dbZV-J#G:.]BF:.6OsDo^xRY>MZj@O+S08@AcKlEcESu>J=Nm*sDcp.;`5##8&K9r2J#b[R9M-Z^#FhLqQ6]@@R#Gk5-Mi%J<09.([@=XSs,:.l1fhfcD6f=7CVoc<x7f="
        "+LHH3+vsI3EOVZ5P+x;%*7i;D7`h8:?CiSWfV2[@K5H;$m(Z&M>c^t#%%W'MqqJfL]'.##3EJX#mNY##_lk.#K0$##%3eoeoWSfLCu+qeaE1<-w0aW[Wx=S[+d`/%@'Qre-H[ihESU1:"
        "`V$9.h-&t[$l%t[e>Rh(Cp(A5gkk2$mP'U[lF],&YFG>,PPxG&A/*W[^%Y#)ECi9.d+l>)XH>N0dxrB#Hv8+4dBEd*@/JT%5)9+*vkh8.q/xB5@kKMD'eSQ2B9hY.*,[tA6o@i=J+xA6"
        "`;RU97V+31%tGw7a>K>,KS3lMgc$+#2%V?#a?q-MY&FR/u1XH)=N?Q#M`Ks%e_GL%'xd;-U:2>Ta_;W[bL-X3=Pj.#to4T[o:YT[[?%?)1kdS[P$E##tO_h1dQZg%Pf;C=LJdV[IMm@7"
        "`5Z/(CJ@T%OW$E3,`=F3GuEb3cx[v$+:[w@U[;m/i>%*$-<GHjF*2igV>/$5W6&8%>%fE3hUs`u2YEi%Z.rZ#p+uA#5wo3%s9+A=QiIfLk<Huua84Y8RvEjIV%.Y8Kb*lC+7/Y8+F$N%"
        ";l2Y8SUV-'?tjOF@mM]S5Abne8Y=Yul1318Am5K)O#Fcii'x]5<S29.TC]j$J6)Y[Wx=S[kP)N$.fWpeD#B6&F<2B$pp7e*oIw;-lue>%dpCT%H0x9.g8%H)?pU]=+^#b$2C)6NqQ(?#"
        "#Q3/[$),##[5YY#,h=(.Uthr=gn'^#;%6W%k`(BS:obqeoMji04M,i_^:(g'%aRX[h:YT[W?%?)7)=^(He?171O5?%:^'X[j.xG&N)QQ&9j?g%P5dQ&cvvI3F)D/(5_L;$%xl>)bX'.)"
        "%UA9]H]%kV,NJ#M/YSh(k-:3$UMRh(>v+1#AX$<&47wS%'uAu(@>wG2AjF%#M3,Q#fbOm#WYBq[rO0`$L<N1)'L@lL6u.>.1(]v$0Ma/2b2Gx#tn]UL7'*JM.R(3*F#I-)2k&H-=_[@#"
        "D6q.90+4]uYHQ$?ixB=uCGG.hn:%Q/q5YY#,a]=#Jh;H'xU`i0lokq],>.[[6/;-2[iuj[X;ds+[_G)4-JS,2&O/##;L8>#h9fJf1VA$j>1U_#BD&cr#H0s$@HCG)Z.U4V:JJF-oV[Y%"
        "$O#j[glXQ`gs]@#=37hLJ]7K%K29D54a#k([c^6][xIfLe&eh2M)'J30k'u$Z;DT%o77<.jsmjUF$<wUqBkTC,UHqCo[hduR/fJmlkFP<KQ5wCZO(]$#5xfLiU/C'uIW4VPk1N(6LfEB"
        "m]]tuoBJ%:I]d/;4j9/1`3x/)YQI`Eq6#K1t?Qa'#C]T]%Jno%t1)Q<AvRiLxtmX$4k#j[sPd2$p<41(eUw;-+nmp-+rxQ_(oJL(-bo?59xTi(P>'U%=$3H*+N#9.R/`0(N5C9(%h'u$"
        "P3e,*Qp,f;x#AZ5eTS,;Ehm`*?s1_IS@_`#eQ9=8EAn[7+@$p#g)GN1->%aI7+8C+mLeC:@$'J=8:&##N#h#vJ+ffL4;K%#%j^v)T_`W[`1&3$#M#<-_ANQ1-vRpepPji0ML9e)6l2k("
        "&W@K(B8(K(ZUof.CWCj$;X'-%fK-H&&86J*x,Tv-%mxp*0Z:q.fW;>I%L.`=GiPs.i+OfLE7-##G.GB#Kc]=#R=8rgEpw9DPpk&#*M3peTJ-88V$m<.VP2Q#?)H]Xx@Or?g1K+<=q0B#"
        "0c5##u'?(#Q)q#vaCol#E0`$#X-4&#EVP1%D[SX[#O;^(112_+LvOg7sZ]j0F+sM0)6b5,@3K+3HqI`=W&O#-Ml8Z8++^1(d,ji0%@j+35japeo;U-Md+1q[$uLp$Eeji0b,]`+V)Rg%"
        ":wCi%e`f+45wOA#YsHd)U78C#Go%&4TYeZ$v4oL(ME_QTa$Y>TKd%T%X<S]F3pgN<rtlN<GPMuG(Qo&_1i05RQLbk$fII/C+:wa$?J<b$PVN2BjEAN(]%2Yl]vO;@oU^B#L,W%Oh'm@t"
        "/<GS8=LTNEVsc2$&oxA=9B^G3ZW_,2$o#hBkbm@t$p)AXmB)jI42J&#h)e&#hDt$MIApG&5ZQV[+fSA-g@pG&aAsI3oi4c4uvnW=@PqB5Vr<<BhpFY[[OgbS$[jPgSB+n,rl91&D5tQs"
        "]k$hL;+;x$@YeA=<fmr[Y_-HMYcf3/;MvHA_4[wplUPv$e>&n.OwS.$+U3L=;&XIH)S.INb*0i)-v@XL@@Y&HB]U&&U.35&6tXJ([KNp&ue3NN?I_P8;]%p]78$fXeO-d$bkbA=qf;H*"
        "V;Jo[(n=(&(EsI3Rk4NN6=P)4TMrB#<7R)D>i3^@Ds=.35)XG#'MD9=].PV90b6h2R:de4milrH/U(fXr`^,._6CT=+oB(SuAS`#nquehK(p7C?5VH>BaWI3sZ]tuVrECNn`r13q$r+;"
        "DLOrdjjn8&,dbLWgPK,.4p@O9R_gJ)g3YB=])Zg)V;Jo[6MWF&XRRt-dHCqL/Bj8C^O_DN#85n0U),##7EJX#wOY##cn6&IumK#$LG0f$-$;,^]o<i(^C#E3#d`/%;4w)3j.ZJ]t#gj0"
        "$Jp8%AUf8.E%'a*CiJH2I7'U[.cX)',:c?5SU'U[oo3Z%+'[)4cOu%(AP?8/mi)qBsc,O&]sd%7gM).5?[-HIe'-w7DQ2t8nQ?\?.pVp+H<5n0#A%r+;-h0g(1G?N([paxF;%*T.7I###"
        "5vP)/PU`i0do/I$=o>reLPPn&i0aW[$;we%1e#j[o$6^(F%jB=i&X-t^OaC=jx@e*`YBq[S>9D5OXKe)Ki#9&]NXG;iK7a+C`Jgt<#0i)Mk=j0-<Tv-S*Ig)c]WF3>S*T%vTS,;*PI<Q"
        ")ok&TA<w]'5cPW9mE2<9ptm@tp=>BS.p2wBZPC4D9/onC605##<,>>#>p?La%2[I%@mmE3@kh,M?IFqeKZ`$#9NYO-c4(p$N.<'MAqLv)Ghpk$t0#j[h_T&(O9;X-$#,na9hJX[DVvP/"
        "4M,i_dCdb1IIjT.VM8a')(RC=m##Q'M)@.%*a[L(xLS>5Ho7O',<ZV[2)@.%,#;A=Xck,2>uv9.eS<^4&vUv-%i#c*tm>X7ZLOGBr/20>n`h(YJ?TE<NMobuBAVmuAU8L264Ht&X.3U%"
        "kIX=?PuK#$n1eeOssMcDH)(A=0=jl&i%sc)jP,/1&3S8pgK3Z#nWe8+C%Qred:('#g0aW[d=83$(`5<-pI5k%nT0X[YI/N$U*/tem7$*34Ge'#LvOg77O]j0nKiHEK<'41^f$B#5>Kqe"
        "/;ki0.BKfL%FT?5d3:q[_bQlL;YOjLs3Rs*9fCc*`dYT%4d``3?;Rv$NBFA#Nw]8Bp]sY#8bS^ZtgLo0*)N0(4[-K)j@1A?ge;20V7Gr9cvrQ9_BeB3k;IV%/&-p%9sK)tv-&e4i=fv;"
        "hmQC#,TqC(s0e0#6f>##NjLvu(<Qt$Ur-s$Jc`r?Bmt;-A;Qt$5$;,^h5C#$qRT&(q5tJ.5Zpj(8XW*3hMiNt%h^q%%s6B#kcTv):iI;59CQ#)7'r@5PL'U[obX)'&l+?5D('U[TZ:=%"
        "JJt3jJD0i)CQCD3wK(E#@O`J:GK)B48e-.)dgB.;RK]?&vkt/CO(3o(jakP&6E;w.M:+YGXBAL(L%@=-AaiT9h;AL(=df^+cxJvLj7@i.9EJX##o(P-``i%%$LYJ]_U`i0(g3X_:6vj["
        "'9Os*Ah%?#@+Zre0SsV[U6E*KJIf9&W00aaGwB&tmE%%DN/8X%,b*T+r#8D+0UA9](gtKjo>16&2r+@5?sgp%)hi%,K)9;-CvcH2/7-A#`O`K(v@A>5IFpQ]^d10%',Cq[<X&B5NwqV-"
        "#)<g1SBGQ#.T^V.3(U&(;ZSn8LiV&fK;Uv-:`1@)nmJI4$LC#Kk/Av7$05##m####@i_7#-Mc##]$:N$Vq@9]QX`i0]_r'QV,8S[eP)N$^;cOTN@*P(kB^6CIemlA1@(cV$J-8%#)>>#"
        "vM%>/GUqC(svlk*,>?<-E)n9M;oXC.e&U'#C'?W[x$Q#)Qt0j?w3lnE&O;c*0k/<-ib$I4VTS;1$0.51g,d7&1j5s.a9.I-HqJn1d_$##?n*xuM:'U#2I.%#RQT^@?2ZV[wwMA&aJeZp"
        "03;,^&g++H*V?GE@idg)/xZ)3B='`R$dRpeoLQ6WqGLA#X>Ed&N/41F=rVu$1EQJ(vg'u$O_KT%/&1)5_PK->[R/gbxJ.,2gHnh2ab=v>x^0UVv2Y7:q6_u;Ib+n1ACfn9MlK#$AB(h."
        "Ne[%#_2d<';$bDEeK?$$0(e)3BrjT[>#[W%+h#j[*NL=-mu+o$0@uqC_:3(=Zg5g):i?m%S5%&4=%;$^7-;o0iPYvoLC1PD*8.<-ctU_?FiGG#e*QUb]kV*>CP='?$*,##15YY#Rg_7#"
        "Xp4R%E(KF32@5##,1d'+]uI+<[)$?$kcC59WWT$-bB]T]?_kp%vUuu,tt)<-)'?[$3w>/]xk%t[q&rx$wVtT[tfJo[(.Ec+.)]L(BGF61[E<,>N7h5'vWxsAp@UBst$sd4Q7xR&elM]b"
        "4_L`NV:e5/Wh((vF-JnLP,LD&4c/*#K_`=-C/G5VU8_]=/4*A=t2eA4j2s@tsU^l86*8$#[`%K%-3eoehN+,M<&C6&^'fDE-(wH3Fax9.1tT1;u^UgXOYq8.pbl/#bhT&#3.7m/4n<9#"
        "Pqn%#L7)m$,>KqetL%Q/NLVV$m.=d&dgOX-&WXacHBeq7@TT/)hCQh-bBT9VC7dq7xVSLX'vwpe2==m/ufRh(L]DM223XJ-0/Vo%Y?(U%j<0d]a]#gS//K^AuibP:3p(i#]#n6Dd8N]A"
        "?Lqu8^NXmLRKQ:vtJN%txJ=w^PNbx^C_:HMRK@uQqW_:[sF>A#p:2T+?9(g3C>DSItd?KX@5g7CI1k'@CaWI3>/t`:Re6hN)9g8.Tf$##XQI]%)@*E(i?$IMv-%6%=jK/)$ded+oHmwL"
        "G-hb*=>.<-cwsY$_RiY#Hc9a'cbKv)0#Gfhg.Pv*]LMa*D49u-H1<t=FriL)#vk>)OYBT%A30aa6<X8%D`BkLQJk1^&c><-*V,k%NhHo[;6f`]VD,x6vCjc)#F/[#<[SM'<0?C[[HY3'"
        "'`Ib4L#A1(kwoYcI5?M'<pDB#o%dx>Y+kI)9[X-dE,]^#@a]=#P;MP-L;.2..S:*OPi*FNtKs$>ZH7&c8,F<Mi/Is*YT:t-URAwMJ5DhLI/;hLBmh`NPoN'O/=Sh(0=WH3.UCF*xK(E#"
        "G@+9.YNZlf*8qs(6mc#>,VcC5.Mso&J[]tuX?\?',%^DB>AZ]7R@8X_#JX7VHE?fYGb$el/8eRK*a=^&(N-.x%PlN.2uOZJ]:*gj0RF'a+,g:g.0klD0nQ=<-GG-k@`NvV[CcwG/M=*T."
        "cq9H&g=Nu.nW]j0>N&:L'HP=$>xg;*CpHo[)c%:Luw9+*wY5dDT?)=.jP'U[/V+H&_c^6]BI;MkJ7-##-:q>$bcT/bgd7dDc55H3DR:a4FN,g$tsC%.qX6]6+FYI)>+xe%UU^6:jA>Z#"
        "#csXcqV22<[MMP078^$]tfwM5o2ZcDra/a#A7,p'A;q;.EfFw5k/5##Nn8i#Qnh7#h&U'#VSCx$TcsF3)Zq]#&,7d/BEq/1lO(B#*1aW[hx=S[sE1x$spAQ,Y-Sj0s=$j[No=^(a.=d&"
        "kq[K(LvOg7pZ]j0r'WK(hvM9/Ls,02'c?/]wT:]$vCAk0CJ1r$[hI4$JCTa*bW+W-v+l,4+7PM(%`o>5T4h6Cc+Fd&wYBq[)s/A?&TM8]6kvq73nSVKNK:x$FvFp7VXqxRDSV&7@&^)$"
        "-<GHj&`qX%L4<9.l/*dIKuHW-%(m,4S:$##^RXgL.2(i#$=r$#@Vx<91a;W[);=d&gts`*-U#:.^JqB#1)Ms-OPhD91m/E3$ZMCB<a-bAmeJpU+0Fn:(9eY57,Un;>4$wAq6GB6NI%##"
        "#)>>#(,>>#LOhC(0t9j$46V&#+auS.%h_7#F)MP-Xi1`&D<vf]5rZS%(l,b*]N+k0cuuf]M$`ENKLope#&KX[W]]&(_oIg%ZMDj$Tfh;-Cic4%F^FE+JxRk'xoOo[:.$[d<dTT%R,1k&"
        "D#T&j'(uk0T(o0(K89U%wRT&(UYrj'9uAgLBZnENHs[.M4NJ#M_nn'&7fx>5ElG110?5Y[px+P]aFG_+I#9;-i<ST%TO3H+;5xA(eP'U[7q.W*#Yf>5t/oO(LR(f)]W^:%'BqB#@#5J*"
        "[h0T%uND.3g^+v#(6h&6Ps3I3v/&89_w9ZRH1>]#+=S6D0d<b=2m4Y#3'Y#/8Nrau;ZI1CvWvv$r)#,2.SJS:UZ3tex##:&W+Vj)`6A9]`R`i0J(+T%hJ,##IbVseSo_c)+^Yj-bNSj0"
        "4W212[iuj[@19a0,3eoe`$1q[wk%t[gb`W[8&;g.Jgp/2?6a$'RFrU[ldRo[]_$[dl%$Z-Y&R,2QO9O%nkf9&_3U2(buh$`BWoT&d<hQ]#Do-)at[:.rm0j(A<<X(SRkX(]bFX(1xE['"
        ".nss-LDK#M3]Sh(YX:@5OLk-)%`CkLQDOl]+2MC&Au=v>9[)&-s/o%,k;;g._@td)^T3H*/%Fj-%ZBq[GCTq)7]6n]_UqS.=)&I,1m_D3_xv20C]R_#7lc,*RSk;JY2&a$7fF.3X@U)$"
        "KYx>,dL;jCDa,G4CXX&-FTCY$mjwrQ^nk(=IRv1<xi4>d;*#:/nBD)+`],gGtOet71(Z(+b@5C+W,08262l)>5U7T:JZ###%F'Q/55T8._dT`3h,(q.UuDQ#NDbXZmI>QsWUQ>#'?woe"
        "v_Z[$eNAX-mgfX-xNYY5NATq#ll#tEoG?/;X4A)O^(W.?,3j]XPPqkL/i1N(6Jp-k)c<&[TNH-Z?@Ak=Jp1AbCL1GDZhv5/2@5##*Q<pe2=>##g0aW[hJHm#4@3*3h4R-2[iuj[mUtD'"
        "t-r;Hbg%T&Mx33.XGWa*:%E<-p5nd$Xax9.6*#T5L(OF3%tDkB#76GMB23XVN/.F#KX`d:?'>+6.0exO*0HxKkoV(L%QDwK]H7g)#WU92XaF#7mMcbLKZ,Znu#HsfMfQs@X*cY5-K>g)"
        "T76)%th%T.]w^)'3Rml.FQr$#Wmlw$p6/W-2Dugudg=%#tcxN/p<]j0'gL-MBc[,&g@Qq%[R3p'k-&t[nk%t[klRh(j<*)#MJGJ(TMij'M5&K%*`ET%K=6g)%0fO(@=Y)4:U^:/+N2K("
        "]I<hu'-+nq`,WW;BXLa#>:WV,CjC_T&Uu$A`Gn8#(7$C#Jom(3M3r@t?S[o@&w%NBZ]%p]jMwKYCY_]n9Q7IM0S7IM/Jr-M1]ReMs_IpeciBtU-jRh(KMG3'fDR6W%'Z6W)Ti7W7^Z6W"
        "4DXI)hi]+4dJ^h6tsil8-6s7BX`7LDGmiB#+*N7+jM`aBnw;1Pn]v9V)w4VH14/AbJ3XP&.JMK)gv`I3-(0)@q2g%#e0aW[e>4^%Aw/X[q9FW--o*)@D@:reD(0q[nb`W[#[.W*,WCgL"
        "b+1q[LduH2m3$*'$eSj0^S#j[pCX)'/6e6%)*D>B,lx1(oG>>BL&S%`W-GdkCurh1Vxe0(U[0q[4;1r$4v`s[8)P:$0[iY#EaoC%;X$<&.wb8.vtPC+Aq?,MDd4g7_:2T+LP'U[Z'x%J"
        "J)0i)n?9>KWUL'Bc3quK#BOrlY4^'&N,>>#h'U%O'dj@tAGPkBFuf2DfLX;(4N/jBLWP2CL8l2DJhqp7gZrS&ep9oBOVMH*okY)4jcO/M(s$a&i_%a?bD3^'<D,jINPGg$O=-##_@hJ#"
        ":]w8#.w&2#RE$##V32H3XPYJ].Ffj0e)=9/fr)>p7Ead*a2i20R/rG/HWDseAsfuKUk+(*T-ki01jLN(T)C=$<+;D5Pts4sPsIo[ac]B-ebd5I-`mGEk-B)I&KI(>R_m9M3,>>#qBU%O"
        "n*3s$tt/JLp,,G%v8Y/.)3eoeh>/X[Wx=S[JaY/.D?vre#Xa8&eKc#.g$aW['5>o$ToQW-jKj^o`A+jLD^]w#aj$HClvo6*n[:;-Q#(f7OB@-Y=HG@783VHY=vM/<pt;]&l%7t@t:AGM"
        "N]MJ(f)wAR*Z:D3pZkJ,po)O'h0aW[>K)<)wq5^(G6]?#-dWpeI;#n&(jJ1CO>mr[*X:sH/fZV[6Z10%F:CR'H.kT[QsHg%Su*gLr[Ba'$&G##Cgap%Yx7C#h4Gb%S^[J&b,]&(ZP'U["
        "+vMFZ?(=F3,M<F3#2<sH3K=&YEX.$I5n;61'm_d%]Pk@tc1&n`*)3GCAeK;e>&ic8f%-.mds^-m0@>1mV6xP8[0<0;ptjOFU;s`?Q4;P%@M,jI2IIqBUv`rZR+fc)/9rJad0/t[AK`I3"
        "7O5##`<'p%FDfg%WT53'ExAF3ZJ#j[ptg&(jB]T]8egq%nJ`j'3kMW%^JqB#Q[Xk%+:JX[7[Za$0@JX[d@f/%AA?4(`vii0]P#j[9):b(ac>/]FX[6/eh)U4aO*<ML%],&W00aaQY70("
        "Z`h$`(d-9.VVS&(NS:7'[HTaaA>)n&4^4P]Qj(k'Wr1W-5QtVfaGsI3N*u6JYF]i)Z02N(vC5n:Ad)%f^FF[2$7,Ab@m0aI52%9.(=G(ak3LY%77m@t&;kA#ZqFd3$H>bQSvo(q]Y$au"
        "v`:u>5RCa40d<.)EWvD3q7VK4$8iOF=dD]SfE,D#c;MqC-CJs-Rvm'MDU?>#3S###Cm,Abu8.p]eee$'7Y^&(O;6:]VIYQs=<HE3&pRK(xp+k0au:,^_gm'&7;%E3S5#j[bM8S[-72Z)"
        "4`6)3gu>/]>-;.3]1?7&Uou2)g6A9]-#2C&f[no%9bYnJ$l,mqH<^'J3)OgP[+`o%e@bN0t@1h1fd;H&;UQq7S[K/)+:ep7WkTN(c56b<k%*?JiMbmB=/[HF9X.&8Aab]usgkgLB:-##"
        "xXkA#r:>o.JOb#)d/<q-^ErjtZ>5##fEo?#b@tD'*8F-)pWngu-$;,^;X*X$0Jngur6#j[QX)G;o^,g)DY;g:mI;s%q@X&#gR`a%)Z0q[cb`W[mWV#)1I%U[q6<n%1oCoiQ)uk0PlR0("
        "YNub'M=kT[#C@0ei2'u7SUKj($BRhL->s0(O1M7#xSL-Ma`)k'%ppPqes>G,=aNZS$:E#7ZY(;:cM1F%qv$-FjX@?aIw&loJ8+##54i$#0L&(MOEW$#$oi)'v3%T&&L2%$Wh%t[C<`I3"
        "X]:,^EX7w#hOcv$Yg`DBWFbm'-lH)3t(%ijc4T&()Dd8.aw^)'W:?T&LV8R8aO2mheGm/(sf+nae)kT[Ddwf&i5kT[AnR:.N)wG&RrKs%VR0O.IE53'wJ.Z-G<ii%t:'Ghx:+@]V]1:G"
        "dB_`EIX7t&q3n0#W+35&m[li9Y$`uP3-t=c9Yde%S_VUCi8%wEq8g<Rju]HOkOq3HWCD]XtwCWSl/%+:2G-/r6U^Ee(qO3r[i<d&D5+_$6nkq]55>>#m)Kp7>xB^#]j=k9WfSA$0K3pe"
        "G10q[`b`W[hTD^(V;Jo[T,Rh(QCNa*H`,t6__j=.o6Lq@Y;+YBIX@eu#c_nu#`HCu(&AM#j`wc9F,oPB)B%RNZ9iRNhe%<-joL=1`?Qa'eB]T]/1tp%qHh9&r`wS]HtjT%.gCg)<5Gs:"
        "WZZ)4[?t9B0nIH>CKb(E2;Qv?rXE$j1x%Q/,%/Ab%=Vf:_0@s%UR&Q/d>SX[e9-*'Fqe;-%bje$%huj[1M>#MA'N0(Zgii0=_gkL#ZRg%w6/J.gH]j0CE>Q/DctM(6otM(Gu)Q/O=*hu"
        "hqX7[BDCs-M?X)8]st&#?v-S#;ZM<Cl$pE@bm5m&BLYNBD/aqgP3iH-PwhH-L*iH-aW.e-7eC9rI0x9.Mk;3ti4nf1='6W#e_Ps=JJA6s=[*W-b2aQs@&PJGdOP#)A5l;-qSI#%d>Dj'"
        "3Ajf%3<^o%YVvP3/Rh[%VWvTM$XYJ];3-XLl>1q%wTRs*c=b)'_P'U[ifJo[U,Rh(w0J?5#E%K(@8DM2eNAX-%jE.37G=1<GD4jLhQ;s@BO=m:Pt[W;Mn=TBnM1AbeC2]ujQu:=T&Z-,"
        "QM'&F@F$_]uom(332k@tCl<PADCL,MRE-##7J^qeMgX5''?/W%8RQL-%x.+/E)TQ&o1BOX;'&$P&;]r'/U1N(N$?F#.GJSBe`7LDa8Q6BmGr*i;,10bXR)tSRjXT##>V,#/ev_#K`&cr"
        "gqt4f$NYc2[Ti4]k95qV(hYJ]BP#<-qIdd$dsk[#log02*ia;3/s=fh[M#j[J7*Y$CN$j[7drA1>X4I*,$kC#pGdq%R^Lj$mI2e.nDa)'P[Nj0)GLZ);j9V.;q.W*?-d)3r4Sh(5xPu["
        "<,Sh(MiqK(E,00M9hML)$`o>5wUXb3]E4J*[YWI)+2pb4g<7f3*^B.*Ynn8%5Djc)@V*w$_ims.Mw6u6p3$B=?;Rv$&uq*>+/o-FA(8G4r2UTE#s(N<KT@L2l2gKF,)p+V[K0@@[q8sA"
        "]_m6Lj7^W?Qgo'I[KpLVLan?U@XX.73)JH3[lZcPeglP=C'*%8BrNn0NA,AkL`OV-r+ZrH#p5X$/bYJ]jR`i0m7ZJ]jv+F%1CSX[##>S[_0?b#gTj?#DC)sec-1q[bmq&4;eu>2eOBa'"
        "TYBq[G59D5d3:q[+&-F%7]$R]th,,*&Id(#a*=M(<?@A5)'#M(EbM##XZB:%]-+V.wUXb3UdYp%[Tm#%2+pD*p`_EF`ObO:D6In0)%1?AbKMm02L./=TJn[TOW3d4l[)H4O*bV$ugqF<"
        ")Rq,=('n.OrpUc?`;@d;T[GTWV(eY-GnlS9r,>>#u+6VHN,w4f<jgx=`_tG2.lT&(sE+l'LvOg7.$^j0'KS^hQZQl$)U#j[^O6W*'El,*A(OiLjB_F*W2n,&OGlr$sO71_^U3<%jm?l1"
        ":4m&qI0$hO]l3P#W;e=1nHn?&^L`9eLAtQ0[=6v#Dmv%+^AbV_n<.W*8vspe&W:-Mls0+*^j'<-BQ*^%(R#j[[Fq;*0YMg)@xEiLm#:+*w,/W%*%Ei-#;8i+bvF7%6r*U.1=TVB14vo&"
        "S]49'M=AwP$,>>#Pj4VH@d,AbmoIV61h.Z#W;d2$/xZ)3g.I-2]luj[WuDQ#8ZU-/[<]j0WbOk2$aIpeo&u,Ms7S9&e-&t[^)U'#2q)a4XL3]-Jl*F3<+xC#pGSt#r*9'@=^be>EL/sl"
        "vi2u0mdsL#Kc]=#v$T*#jSvP/S7Jj$ce7v#pPW^#cJqB#30p^$m$mRAJK]9&^-Sj0^`YJ]7mb$0*JxfLZ.`@%sjXCcHK&.]%tD]Xw8=rZjCB>#'/###qitQjQjOppSvYm#@axeV1@XKl"
        "M*S49:ZbA#ijLd;1%qWhai-G+9@3pk/)uk09hFm#P[E`aJ/M/(SJh$`DN77*_1rk)DTxc;f)_^#93wS%4jo0#Rw0N$%0^f$NbOm#(&/T%CTNI34#?%-x<n=7lidJ(K.NrL&p8+*ZlZW#"
        "%>+dnj4CWna<)fh$),##o+ED#rc]=#QF_/#sU:a*XKPp75c0^#x+Xf-`*YB]IY?&MxQIg%9_e;-gC1p$[hqKn9<%HA^$@#6)FkR/OM%0(J:eO$<DG9&Dd+6#h'LdMV/S8%Yi#K2Us(3*"
        "[+u1)<=E:.M93[JKhAQ&+c]+Bt$6ruq0?B,%+CY,tZ%,8mSBj(S$eV_r+w2$Xq@9]pPHE3PIv#)F3K2'>MWE3ei#j[kM8S[>v,5&49@hL5R+qeVl#7&RS#6(n6A9]'p1C&cRno%X,(L:"
        "*d.T&TefGutAHf]',=thl/M/(O0ub'CujT[0gJq4EAg[5QY70(MI*l$J4kT[H$E##g`Xg1^qbm#<))$>O=$$$NP'U[nYB3kCC3u7gSPH3>HF:.0:t%ox_7Q/eHPZB=u';Qv@)T.[f32o"
        "S?X,%@Hs@t8w1VZ3.=j0qfSX[Zw^)'rgX[#:]?j(XG44%M'#eoVICKnPM<Q.EA#8v^OdYY;[61M_-CF*,jt1)aq-_ou(b#]po`[#ldHsCbt.#BaUj,8nq;g;)%o%MI^&wugS-g#Sde@#"
        "ZgL]$vk,F*_q<B6DoR.2X1%^$BuZihuUpqeMT:DH-2opeSu:k'fr[,&D/1W-rKo;SYj-P11e@q`tM]V=c0Fhc`mjT[Jsh05#uj`a5$[S%B.gQ]@Z$-)'dOS>5f@x>)_0j_ZVkL/_O&F."
        "G9/F.%SX1(X+Z7&+O.<*)?28]-aK/F,NJ#M-SSh(Q(G?57qqV$A[:'#8n$W$%j$i1tCbA#>j2W[0eRo[TiUDd)@0nJn`Q_#Nc^6]3l4@5LWeh27):H4t>(h$CI;8.cu7O'YS?'@DGl#)"
        "*s'slZo-V0QKQfLPX-##jm8i#u`]=#BkVr7ml^N(S;6:]QU`i0MxYp7t=<W[Q)wG&m]Xq7Re2(XGhvV[Li4^(B=Is-nMTt*m$$n/@Z$-)_6to%OJ)Q0@#YJ(=4VKeP@#38wm7p&uh2(X"
        "5GW&Hdn$q7#b2W%D5W&HY2dQ#$)+b*leZp7ibdT0V;Vj$Oj+<-pH1=%ms?].1Q8c$ipMCXt<0ZHq#;.EHQY2'ND,jIX=Hn&#+,##VRH,$Mh_7#)^v#8o+&X[_nBd&e'=8%LvOg7WxtK3"
        "1KTX[`G`]$N5V;HPa8o8(^2W[SSAa'aG9o8TdkgN1Ro]Gg9^[m.;]/hC$OB@Akte>eb`s#ZEvilA'mD/psAi#dO.+M7^7F%[uH^8./Fp*FHk?P+D?&U]X.O#p9^q9s#CB#DqHAe[gcER"
        "J/6VHm=.Ab.R;J:ESd5/i8h5#%Q,BFk4$$$)G*pe56,R_6G.*3a]#j[Bd&c$6k>/]pk%t[`>Rh($XO@5GYD:%bmoO9IL#H3SP>f*]I@t-c@5l*d'tQ/(&AM#=S.(#6Kjm0qPr`*9r:FR"
        "0$wcVeRpj0v(G/HBIvERl;qW-F3=fu$4]]ekZYV$27Xc2U6OG2VO'&+K$i4]bR`i0B$:j03*os*UE^2'<AEE3<#YZ5i$aW[G-,Q#]f>2'LvOg7X3]j0t'k.2Tf@w<PKF&#EAd5/rw^)'"
        "apJr7a8Om'cAUh:h0Q0)fP'U[$gJo[(pGb%*nDM2&]Nx-fYDD3$`^F*,%LC4xpcNDlRS=%dv=$GqHYY7E@s3CjXKD36_24E'X$08*K=oN#L320,hZV-4vcZGOU`i0S)=ciisKkbFQ1kb"
        "3J8U)<YjE3`CVK(?P<f/%Ui;*pH9**0j+T&DP<f/D$g5#YMTP&-rO&#sPqI8s*)d*BJ^W%@Vpqef+Ke$J`_8.#rpA(I(%N(B0,O-IpCl-$jGb%GQ(kbq+5dMZ=w[H'jv5/BkY)4i^8ZA"
        "hL+=.?hoY#oRA<]YLgbStVvDIkUFpuld?/)&3wh<f$U^#&h_7#C5)d%qG5W-C+71EuG.pe(L5dP.^1)3_P3uJeon^$Q;:L:0EvV[Mg$K%eEi;%lV9K-k[I^0V$nO(r%'J3KCdc*-0?T%"
        "bN7e#BQ:9CjZ?H?-b_nu36>bFHkZ>Oc<17#o$%,;:Bqc)O5G[#@N<)#KaB#vU=W`#kMb&#/qs1#H'$##8PgqeiH]fLTE[se,a;@,p0aW[K);g.3:**3MH5h;jb^?-a.=d&<>Kqe*%Le$"
        ",$_,/B,UN(%O*C#5[U,MI?O>5a$uT[7J`,/bc^6]Hn:A5W:6^(i?;C+Bu19.St,+*/TLs-Ne=jLTq78%L2GQ'BnIv#;bRb1UE(E##q?d)4(XD#qw<0l.c:W-H@Rm/[B4J*?]d8/-]rS%"
        "v%,d3?;Rv$_DRs?.D760i<?)KJdCYuplSuCQA=R'LeJLQ7T3)<;M@@#-Ze&@#>OG2f.*t.2_NiM?u1<2s-,$-Qat)d&21<?C-NfLTh6##;Nft#SNY##i^''#PD%4Vk$$k(Y/J?##g:g."
        "*9:m'+k+k0+ATX[tI+K%.X5d//s=fhWA#j[^9Jm,(LD<%8&'qe&oKe$(UFj-3WCW--%b)0[SMj$LP'U[-ZBm,wLS>5PL'U[Kv>j-Xrng(D*`TrpV^6]63rhLV#Jo[PDY$0TWa*.#Dh;*"
        "R5-?-Y*_-6Kj&9&@_%Z#P+@p.SJAd)MG#3)%$gK430rO';]d8/pUE]-B-Tv-QMha<XcO'Oa,:,$pwB/CCSdn(0@mv,sih%SDEIW#XJtg353n(N^J6s.G`l,G4qVH<cZ;k'^6>o/OE;$7"
        "YL%##KaB#v*<W`#n`''#iacOGpY9C,@PgqeleQ7&c9,B-dAY98TrNn052<0)3w+k00PTX[fexZ$e3J<-e*uW%STKX[mBf2-K4=^,edJG<0:kM(;t[58_SV=.xR]>5#*cM(b@oO'O+;D5"
        ";7bjLbo+P(.;698=4N4)q#1>.>.#,@b8;E5vRL>&R>xEa6=I#%vSOV-+8.2KMikr-DX](WHK(]$MQ$j[2%Q#)5=[-2.JTX[nW:]$:fu,4[JT88T^5<.%#f0(.k[w'90$j[%qBg.uwd;-"
        "/ms;&;O/?7d2WA5^qtT[9Hb5,YY27&K+;D5mj9N(2956/kYBq[)+/;8gauS/Qu4U0*l_58fVaW%xkp$?03O58fPN<%&0+&F7lPb@1Xe;-uJBW$]a$o#:'Pp/13-Ab`9@uu5=r$#?xB+$"
        "t*uA#B`+/(''2G#,`=R*ZV###wcL]bb*OJM8=c&#t]O4MQR+D<Ybc9D7xb(NeRP5A:oMW[tU9a'ihnG)n1J>%0<,9.tQi;*ZKdA4]@f/%vY70(WA#j[efVj$lB]T]u#2$>:X;W[eh)U4"
        "=W,p*jEk6/_VLg1(jB)<:gVs[Z,Rh(^-Kb*eu;N054qY,Sg'u$lHOLDTD_s-Vr>[]ku/wAV.%d=Im/b#i?BU#*U+;+EAP7W_M0SDUktBC;pxSo4*hc)W:K_fv12<-;p0/A2JO2(jYTAO"
        ",07W*kNf8.=uBF:aeGt[alRh(N`lN'$(,)#7IN*exY9D5D%tT[FYYd$t2xb43)9+*IJk;%4&7N7+t_W9WL-_TT[FhDVCBC#Hm@5md)],AH)%e4)h3liR=2q&PT<M^Ofif(]'R^%p0#j["
        "0Y&Y%0O]j0NuZ`*xa&<-?])Y$*quj[a1&3$6dhx7&gU-%#UYJ]xhAU)ibap%kgO@#hvPm&V/wG&#XU&#C(^,MijZx6.bZV-BK]6%Pj8$&F_#R:&K`@>HJsVRUH[o*kv7gLIT?>#k0U%O"
        "S@l@ts,LU_v2Moek]+:]n1_0G&MOgL%p(-MH^m>#JcYV$@[/X[javA(c=V/(2>jf%nJ0q[`HpZ$1(1-M6F5gLTQxF/ZSRh(X`aaEL?dV[2gnRA_%Z[f8<Ig)5]=@5`@7`?&Wo;@X#oj%"
        "qb+YR>.CY;R[rQWJDLc;'o.AbRSTfb`ooN%rss;-o+pn$484T#s`/X[i&s>)+`6)3XUTfb8][*3`e&eZ&p8eZ6[]j0lDji0&-]q$^f*F3[$Jw#<&9+4($u5/N)x^59,rb?KEbBGXUEC,"
        "f.S(QIUO7eJ:&Q//)k@tx_BP8[AdT.il23$Z^i[%`)NqM_&NqMoM0q[Xm)m$.O>/]jk%t[f`Rh(#4A?5=a1=1m>sI3Unn8%rbTV6I^dl$A_cn:mrt[?PgLE4kWCn90.&bYApuM0LJ-g#"
        "=j_7#hDqlM,tW)'W&d9%I?Eq7d=Xm'_=4^(ZTS2(`vBmU/pC)3[YYJ]0i?<-kMp(/ZSRh(W'i%eY=]s?FYm;%qH4;p]g%V:@it$8NCjVRQh48qRL-##Nn8i#^N.+Mh5bJO^leQ%7Wk;-"
        "URhD8n^,vAf`0K-3_7q$35OSq<8VA7(WI#8':?Z?Ac(pir+Sn$J/6VHan*Ab6Ek%=hL0D=44ZV[s+b;&o/(A#m,ht$M0p5#HN6s[Mab-;>MDs%aq$6%C3Ar'`kY)4LC'`=iDD)Fh2)(6"
        "wP:)PvPqJ2CssQ0r_[xb53-)*Uo?w7G:+F3e5/X[[x=S[#)],&s:vf+a*I>#A]a*3i1vf]TU[S%8Pgqeuf/X[xOPo$>FcgLYL-N'GT-Q#xR]>5f&%hLX+d2$8+'u.#%c;.&@of$qfE.3"
        ")<oO(*?(B#33J>#^HAF>^nEH4)`pY8:]l&>Wsj`Aog+8%G->>#/]6VHbo-AblVsIhS$Js-T?8D=XEqB#E?`I3&]@m,ifC59:.N;7s(RQ&+[=X$@r/q[L__n[5#tqe*$jd*E`5W*F9rf*"
        "3mxN0AU_n[v=0ta9GehA0s25(wc4^(NGF<$1WZ,&'rES7@[s5&wb^F*?3H$E1r7C#u]>>#7I<T%wT-eM=bdc*Z%Hb<^m.T]_@p'+D8tqe=_PH3DR:a4>T><.(.G-)3-W::p%>'.cMsqe"
        "SksVRUH[o*H:n*39n8i#nc]=#Xmq7#:R###Qs5A=5o`W[fP8S[u,h5#0Fd+ERWO1:6G2d*q,'W$@?/%FFC4g1u:YT[Y:k,&3kdS[-1[<N@Jka*_Mhp.l[HW*],P1:8gs9)Ur+@56*];$"
        "jR^F*AA)u$AX$<&47wS%.=g:)gU,H2b,Rh(d**)#Lu$L(Yo[K(1ik$%RUCF*)`=F3Qk=w$e'p8)`MrA7KLo1*i?>9)lb+YR&G3qKYEm:Zx/hZ-0'1L*dQW$#EI-,$t*uA#%708%;A(##"
        "DSXV-91Xrd?rnlbSA_]=2=*A=X@b(N+.88%CEcf(I2Gvek9[s*i2NM1r]/X[*C2Z)9_a*3L:Pn1vJ.pe8b6-+9obqeV_0q[eb`W[qWV#)@6b8.i>Xs*9<3a*:NGb._`0i)EYlS.B5xHu"
        "p,LNaL7pK<0T,AbL,GMe1N$cCE3QJ(LNfo7=':^#]esw'Y;###,$,AbhC'DN#,P:vB8jK%'O]`XNt/t@.+*p%veUt-j>#KN?<2o*R@xW-_J[R*#%+A=XK9D3e]$,V^FJG)I.XlAI-vD3"
        "s-q)'V_`W[k5xv)OmG3'7J^qe?I=T%Aq#j[ktMp+W2Hm#8&'qet]ji0PSGJ(G?'p%.+;D5_0qQ]Is$h(Bl*)#Q@[L(.@l?5WtJb*qaY)<o.4Q'Zmis@i5T;.fW1=%pu/J3.]_V$SHvLD"
        "_dVXIgg`g[Ep$@CnSuDHU4h13T@/B,P&Z>f=[3d^p,f;LKU5*nVXoV%1GPV-;Ih4]s1u^];HZJ]#:j9`&^*&+?65O-G65O-kM=4%`O/G<t3N9`1'?/]O65O-G65O-585O-69Cd/eBqQ]"
        "mXb.)Kh+a+D@W,*kaUh.r%5Y[O9``$(T#)<9kBn'lkZx6O]B.**r+gLK$Ea,k(TF43iZ>#9bv>8p<6.)h3gm&DmKv-aKDiOdZfVC1I;`5;KGd1ARLP'-E9W$OKpm&9qS/Hclxh>F5AU9"
        "@^rxuJ_If$*n9;(I55##5`5##IekXQU(1^#;9X7/:G4.#%jwO;Y85R*81OeOEX`=-$kQX.4EJX#no`a-S<Rw97R3j(BEcD+$Gp8SqYXt-93Q_AAr>7vv),##<Q]X#ri_7#pqH0#M6$##"
        "%3eoeN-klARQ@a+PZ*r7)tlW.5AufhsC?/]O?jb$eL<AhF'uk0M5W)']N^aa@Ob%tWIM7#hw?9ItQbA#?>/X[0eRo[l>Rh($n*)#'>*jL_)sA5J=9q[`1:D52J@iLVn[T(J#gb4RtC.3"
        ">U^:/tHZ)4.u5875mBj0:H7g)_l8+*$DXI)b1mp8_BXQ9Q)C2),N'**maau-lUa2c6Q-PT^)rYJ.:3b5BeNZ#Ll4-)0PlY#W+=<+IM]#,'1[G6E@4g1[D?C#KHfI(2iCvu2.IV87%KwQ"
        "ZiTt-5W&##Qw`xFEOKR*?[%##1CgxXNW[w'p.v)4uvR:vpr7R*MKbYGSBD^#$88n*._xt-hiIcMg/pe*#gM<-5X`=-f?jf%Cp?1U<:ZgDbu(A=>ZZ`*g]<H2HR@%#1IQg%T_`W[]1&3$"
        ".R3N0t#A?)InJ2'*.db*e2)6/nar>)`2L-;cBvK).?woeoMji0^$0b*kdF<-<%vW-S2M4BoxZp.rF>c4:bnt-*J3j1'RPT#Mq1pupxfV$7q-?u2io*D#T*p%Y7qkgXH76K*:SI#maJqC"
        "PftC0DNft#wMY##Wv6kX'b$lX=LvnX%WnkXT>5`%(*VK(%`o>5SRtT[s0qA(JxmI;D9v,*0Zc8/Uxb84'mp+H:V+DV?-%@&p2RvY.EG?#P?H+<uD&h;ed%F#';E99R4n0#6#^&?jJ^YG"
        "BO4E+w^$AOcK)G3vi/X[:hIs*EQ#,3#FB/2[iuj[PA?Q/mb`W[+K0T+79_A=ZjR5'v>1WJ#NK?-nK7W*[YBq[J/9D5ZhtT[2?Fp+/Fu?5_ttT[%ltD'F*fv#GgJo[<?(W.s`0i)s`+p7"
        "04MAl]V3x77#^SS-6pr-j(bo7Z.V`bNb0&P:;Ie*V_`W[:_.W*DKp+30tW58-E1urvK>/]-gqD+)BEU-tYAR.gixA(['cV[%X?T-40m28N)Rqr%mY=--l+O/mWxDS%($*8)pDGW=TYQ/"
        "6gbYG'>@PJD1xJ1p####A8]Y,ea?cr-Q;R*#.:R*a7LcD#e&A=:b_^#i*3)<m`7R*i>-:2U-/f*Twsp.U^Wt-3T,:2snff(k$<_Ac/%gDB&PkLXK:@-t5rw-g4K^RoK]c;>AE_AG%5^#"
        "STYO-4-BSN'?V'#jVT[Ms^#WM?^5.#Gn)YJrd`J#vi_7#[>$(#p](T.Qx=S[)30O&3rii0[YYJ]hQfj0w+bv#wTRs*.7IK1J#G:.<KRcMiB8'@xTxpLTR?>#L,W%OSDo@tVEXA5`NBp."
        "XPYJ]DE@_8[[ap%_Vx^.9[P##F]WE-S]kZ/4^[fjw_m@trdf;-a+O$%I9lEni`A_fWUC?IFK_SMK3)9NGUkNNp81Pofe6T&%nB%>]'Fwp@1*+jUx.T&Xn9wpv9#j[Cah/%__]5/])U'#"
        "D*5JCEn/K2eNAX-*7Y;.;Uot@d%2'@*-2k#[FvilrQ4IuZwAr-SxtjtE7Vf:H1:C#_%xG&Y/J?#LvOg7q4[QM'aRpeQPa>0=<nS%bMDj$]O`gH&Ec-;8&P`?vBs@tmB)jI<s.H2&0;,#"
        "HX6g#dl9'#gFF^(9:C`.o0Q#)tnBc$Im;,^ZN+=$kr[,&>eQ60/s=fh%V$j[sCRX$*kYJ]ckI$T+Zdr%^Z[s&-rvSj?(uk0RIDp+..Am,OV09%?'t`aAKes$Dewu-Yu_N(%>(M^S]J^+"
        ",6?8&54bw'TQ=W6/7-A#$H_N(WcIK(D+;D5M@tT[ifJo[rcRh(v15Y[N5<d&C_Zj(^:EM2xOFb3nB7g)`uSF*lYWI),JC+Ev=Gb%lrMT%am@d)WQBG?S>a4+a@DZJ&cKS3-,G@?hRtX$"
        ">O&WR5`l@tP:a#eMf$s$YBB]Ix2xh2kOHY)Mc1Z#?U/_u(,>>#cXK(sk;jl8;?_c)X5(,2%@?&MbV8S[c`Mj$*W>G2744]-:)D2'b=A+#Y?):2Z--JV&X,wNbh'a#K/[o#HcDE-O/5)%"
        "D<QUnIu)1)&]p;6/i8_#_Uf7#<=;mL9YHYW967T0)7UR3#OLxXEZRcDEK,d*e,S0c%s=fh*hV>NRSrhL`C(o0EAwoLV;$##PlRfL?C:A=&,u9.2Hw=P5@@[#$]X&#(hKwKv,:PMxcd##"
        "?:-^R4)DD3V>#j[]M8S[eP)N$5=rt%X8Qm#QYBq[F;9D5^'%1MYF4jLM7;d0r05'Mq7kvL[>6##dtpA#`O9w1Rj9'#c//X[bfDj$>eViT%f;>M'/g'1m-Y#NBFs^1P_%/1rdBMKH&UP&"
        "=c;XUrE=#G:+sgt87CP8%[Z?$4dWpejY+:]f(SoumEa?#ZUch2r_SxAgAI'XEx<ZJ[Dr@kQN<><,IxctZ$[lLtd<uL-l&%#?@6K%Xq@9]:-.&%u<#j[QAA.Mu0EfO5<`-McZ..2,8@.M"
        "w`Zk(LvOg7xa]j0nf+:],8.@'3M#b[,jH)340t;-OSK*[[EZ)4rJ-aI2x6TJL`0;<m3QH.6l*=k#H8%vxvu+#7lsL#KtlY#_kh7#mtJ*#pWj,8ug.T&wh?\?e[)q5#>)UX[Wo;Q#,0uk:"
        "wQbA#KSCs-L7R)9>%q>$QE`m;?R$m8op8K23?sI3=r1p.-nqduO#Rh#1(.1#QpCT.^Z9D3L'kG2SA:5&Hs?D*paai0<(ku5wQm4]YR`i0sx4:]MU3N0`7g>2`Cf.3hE]fL(ZBBFG&sL)"
        "In-c++[+k01STX[emAm5oH]$#;E4m'[EG@62/Yfhiu#j[6):b(a]#j[poOb$%I#j[e^b/.[O%*4<`j4(D3e'&DQ$j[nDsD'Pv8p&Ys/gLu?n8+iDFN14/w3(<qd'&9?\?/]Jwkg$)r'$j"
        ">^WpD%DEO'Tj_j$kdWU.1ib)'`1M9.8PC`5KLcY[D'_,/qiQu[O`Sh(I,)A5As/W3+)Z3^:h2)+fpEe-(;xk'PHYm#KA9D5&3=1)NN:Ce[qZ>#G^v*3+/rv-S9A%#LSHK)>SHs.]x'r0"
        ".n6K)Q3J>-h*AT%vw)^?T17^?b(q]+9INJ0.5Lw6$Z?>>T4I#@ORY`uCKmd?ThdG#iR[51VJ-VH7h>n0a#J1?4ae`6gRk7@$@l77oGJ0MASV^uSoMD?q%M,7Mt+^6P@VD%#r<U2:Y>K3"
        "0oi'#O^ZC#vtlY#Wq64v0S,lLg6<MM+bv.#>.GuuW->>#`g_7#d=N)#+N&qB*[?a$4gdC#c//X[V%n5#]u1/(Wjje`$b;W[h-&R5>wB'8W?U'#[orB#%tb0;AlCnLgrJfL/02B##%x)$"
        "I#vY#6c*f-S<&:)ZIB]XCa_S@ocsrR]32p/Do1#?rl88SB%aSAECUSSe&bJ2`?F8A9B2Q9j@pl8:gV;.^-fV@[[2_Ah=hpN5M`PM'Z(hN?s1#v2h@H#x&Ff-M&Ck=>/BP8)]CG;J?KM'"
        "O==3;veX)'_C2##LvOg7cQ]j0i:[-2^ouj[g-q)'8*=7/r^]j0hj'-Me$7##ob#B(c=b)'OYBq[OG9D5FVTI*(b@s6<X_a4ZH/i)xZoY#0f3N1vPqSU-Xcr%@U*1Dw^3NM@'1kL@tlOM"
        "H&6wL:.]QMQD4jL<.*G#,PZL-(T;=-UdF?-Hc7:.ctxXu+$.#v#ZajLF;DPM$U[2P:l7QMZrPsM]F?>#b6h.C>(Xf*)tj%=_Y_,2Tn3T#jD/X[`*(H&G8aQ8HUU&5w9ZC:kfH(#g',Q#"
        "Nc)H&;KaT[Kf0P]Bqd)E)^kA#%%Q4%_Ebs$N<Gm#@[Qp-H:feOGFK;6s/?C+#9rTf4f.32H5FK3#;NfLaK6>#LN%H#&=3jL/egvL[*doL1(^fLq:kG#KIX&#[EX&#FRm,&T_`W[#n.?)"
        "AD)h))3eoe&&0X[40$A12DX)'C9mrea'1q[UCDJ7.VIg.wG,N-YYBq[A)9D5_66n]SV<e)HtY@5B`*d)r&W(#'^IK(jc4Y[Xa_/%;+UM(,RJ?5^hwa4*)TF4QCi8.3.3a%^Mu`4TU5;&"
        "gkv++%#Uw6(AWJ2HG3]79R#@A]Q?/2nfvS/1Bx5(g_0)=h'DfF]w96kv4.n9v$Ug2>g;A+9,4v,o5oo.[W-Y/8(Lree<]fLN4xpeP_tr-Cn`Qj09h5#B?^+3hTXGMWXFF3XD#j[oM8S["
        "N&V,/9(e)3+hew'Ji^jLe+Ur.dI_v)5g5W-c[lZgWj5Y[Y?]2-#wTt$5-S5'lGH2)>?Wa4B(7x6Kf^I*@GUv-X>d;%-@wX-C/]iL:/V-%h#[%5Q.7V8TO&63g%4j1c:&A#/iI7n;X82'"
        "cRkOK:bR0)vg8<_-m<87vCkAH%ng>&+IGa,=)2uA13BqRu4n0#aK(;?pvh+rQxIG)lBel/'AT+i9<S$#N,N&#4k'Q/r+lq]1_/[#.%$60=.L^,N_>W.;@Do/Xwkf*%;.^1/s=fhgo#j["
        "X/*H&c@tD'jnR0(vqc'&dbe;-Mu19.A[Y#2S./T%?5]Ljb(uk0p+7h1]Zpaa4Ig&tFbN`a0kk2$:x7C#?gfM'T^Nj1]O3H+1*c5/b]9D5c__sH[C)s[;pc'&.K]B5DbQN(8S%iL,=Yi("
        "f_oB57nuD0SjFZ-PGd'&L6`hL7fxL(QEb9@P0UB#c?XA#np*P(0OYg%#X?(>-?YD4+[9T%8B2]-I0iH#:Hvr%Ax4jB-%Oo5I>/#,A,gc=A,^G=L[YV/DUQI#Ea_nuZ*wO(G1WB#+L&E#"
        "hBOs/0`Bfh>vU(6_8L%@EjX?69=A`9l/5##o(%w#)i_7#Sww%#x0Zs*Xq@9]PL0T%2Vpqe(A,:]2-gj0C/2f)`,$6#G6;.3$S%Q,DFRhhqCZJ]HnUk+RW7iL;X2%,6O=T.]q0q[Gbxi$"
        "Oo^&?S23fS[[T4BMgd$$hjp**Id#baO*__mJIsm$C%CR'MWs-]Bn_n[o=0ta=:HeMZfmg1g8&X[O/*H&6KaT[OAa)'.-/M^GTcN'V+o<?mk7p&9-k;-SEDIM(.Is*QDTv5d**)#Cj2,)"
        "TTCD3x`DD3>;n]4Bm1T/,PlV-G/<T%^+>O.6m1[#4%GX9Q8U@#wi0sA:I7[uB[`lJsmC?#XNhH*dc0J:tkh1heIO@tvwRW8Y(C>#8/J(s;8:eX.Ql]##>Ef%.h:]X5v$g(>U'L5(6(,2"
        ")L?&MU28S[gGd2$+S<pe'?2s[3m&kLpSOo9A#1H27VSOE:H/4E7[l8E:A0LE%/5##mR6g#Yv$8#Q3=&#E>Dp+<Pgqe&Nv_+pwl>)=,2x.dEZa'p(@['r`3T#*8Kt[TRw+5ug=M(/Fu?5"
        "We9q[ku9D5TX'U[4%Ca'47^k$f29q[pbSq)m&'U[qVeh2rV&J3&_D.3`</W-QaGD6?9b303v+h<&f_>6`M?F%8q3iMquof3fx-oL])Oc4?2MP:%nUP:5>&p9%h:5:k,>>#&nIP/IdUG)"
        "*GDfUlR*.2`&/X[s])N$8XW*3d2/X[s+Ag%fUm,3ce?C#^OEp.a#ji0K4lL:RQm0)qkJ8#l7_h1SPd,&:e<30.o#[d)=DY$q^N7M^JDN$k5ck0f(^e$)*Te$s:41(Ti57&=KoP'1'4m'"
        "4B0j(.LH$$:n$W$Sv:k'?,>1#cO3H+ok?=7ZDsI3)M3]-Va$E36dk-$D_rGDjttq<;Fx)=EI/7V@n]@kXC61<vH&).1_hA4>$###UGH$v(HlY#8Mc##/*2,#<Xg0MY4d,2XD#j[^>Hm#"
        "YfV)'@3RHM:mNt*Zh-a5*0fX-&jEpu$.fdu$d<pucZKsfXNGPS-1bnL1l*J-:k*J-H1e7<v*$?$?H8#PUNw7&2,dc)`q+Q#h0Gm#S%eb2Rv3kO6`tQNcsIig_X>kO(Gg3OXv-auams73"
        "FI$,v2JT6vFUl##Q*_/%0%PfLbHv,2d+vj[Zk0H&YAm2$UYBq[9B/'dPfK.*wqq8.beSK>K.v3)f#Z40MtnlLwN-##s6QV#Aail*9&g_-qA+c<IAdF<TcQ?$g2=]Fs?#p@oKv=.LW<J:"
        ":54S[%LsM6rZ_03NIu32oY+naMjY/.EC'jLr[1q[Wt@9]`gK)3J.Q#)8rT>-XB>H2Q):b(3+%j[r#_,/(5R)0^4M9.1Gq;*aFwG*Sjj*.,nYJ]s9LHMf+1q[aMv50+MX)'4@3*38qfp0"
        "3fV>$[G_c)c<RS[i:YT[Llto[et&i'l=i$`rwpc'9C(^#Cd4m'Ve9v-Pidg)Loe]5wG64+9%l3+:(l3+TZ.iL[jHca#)19dcor=-4er=-Eer=-Ghr=-([,%.nrRdMU%Ai1p*eV%;8i0,"
        "oLv't=K3T%UPh$`AQ'#*]Fjd*(S'.)rARhLFecgLx)HJ(p5@hLNUeEN=j%i1jRhU%58e--m[)(tC#0U%4TJ'J%0BFRCwAt[@@>gLnLoo[G<%4]ebX,MDO9n$GHck0E7gQ]E^q,)5T+Ot"
        "ag?K%b*l$0m>gQ]N#7-)fm;H&.T2W[ZV8E'C2Uw0A8l;-o*'_-S^3[9kVLh,L0eh,f:Iq`*IX/.sA'u-P`^KM&;MhL&(_b*+IfG*.T2W[uwDT+*8Hq;=BD<doG]j/f9_2(1AJ&,_]H']"
        "VF]A,>e_>$RIX>-9?m6<8fm6<VF=Z.NTu`&tjlN'f]Rh(xbpb*Yd39.T;h;.aaP9RC1PS7DR<T%Nn@e64HAdM4@8X[0eRo[LGSh(Z67Y[+sia0:a/+49B4H*4J+P''/o>2q',)#^-cP("
        ":Fxp/Y9#<8,=jM2s_+V/qWKu.6P8d)h>Id)($4Q/kE$`4Ak,V/a=%q.[JId)&EC_&P85R*H0rhL1F5gLKblH39:k=.)^B.*T9@+4m>:Z-='.`K2p^)N.kMmJqKRbMIZ)3JnUWfG/RFsL"
        "hC0(.0D(XF.:Z9C3[v@&5=o7d/0fE+DK>.8`T(F#Q8GjP-T?`SG3&H:-S:q9,0/<8hm;,tWOqa7W*WC8@Ri$JL-NVJ)B]`GL@1S6.=b`5);UdaK9`E4/g:'#Gc08.i8^lSnVgi0Ea@A%"
        "]gHH38R5##MR5G3cc#j[+QM]$p$v>)^)UX[u_e,/]F]C#5S0X[YI/N$T$&tev(,:].ggj0oM[Y#3PN&1c2/a$VA7d/KvY,3S-(0MgIws.6i8^1);[)0#ZBq[XP9D5lp1PikL?x6TJZ[l"
        "+1>)4I,?g)1w<L#1Wl>7w#r41hWtT%p>I?OMe[DI$m';ZOPen9lX`v#G.4:(-E&-<$>x:ZNgLfL56ho-23B-m(v8>,H9BempM?em,tYJ]&qmp-?qK+P4Bi-MG*.W*sM)^,svK)+qvK)+"
        ".,3++Qsb@#KCg+3hr#j[BTg2-a?X,*&1>R-`PRM._`0i)TC%N(VuW//@]/QiY2:lbx=O,MWV]=D,A2#vaX/a#sxX&#'`+/(w^cF#?5+n-wA3wgPgYc2[XPwgF7+60c-e'('0kQj(9'Rj"
        "R*fs-*lhkL2$EIN+I6hM.e2eNd/r3(EgRYoH*ese.GKX[4-$H/g]Tk1NUDse=%ht[4l%t[FFPwpF=460@P.a+#wqj.?G$T.6o0N(*]wj'.q@p7r,f5BNP03Cw_-q7qgFZ.E*1t%2g08."
        "]<%vPnVgi0<a@]Oc3t(#U&q5#b)UX[6%Ud&*ulW-O(a$'oJl=-LA1?3FJbmK+Za/2uD=;82U)s[tfBQ(7cM:8`:Mt.7.5I)+2pb4.<Tv-,%%q7?0d<IE`Dt#48GD+TmcR&#rec*KBr>5"
        ";hQCuFfYA#)?YY##T1D3@1fucx)'/1SB)32e4Od&V_`W[3=Ka0LnL50CoD6/G*Fp+q[&g;E5$?$q(D98A^1p/_=)<-lu(e$gZKX[7:T&16Y<C#M.fp/ZJWd&7jTV.vTk%*<M4I)$3Tv-"
        "Cxj^oiu.&4VQ3R8>jtB,sMtH*[dpm&;3<H*ZlBb*p25$5SqOmu<9MWB0*>>#ANft#u?*E(#0Z6o]?OY$Gm4u#I$M$#Fq4k/S5#j[tF4H&$m<U]=RWT%e)S&(8S:ghXaii0-sWf2*HrU["
        "ldRo[,o#[d;dTT%Y-CX(k2?wQLW?&%n,kT[WI_T[Hd$K%`)cj$Fkbg1]O3H+5T)H&TP'U[mVeh2%<oO(+BhA=fJ$SBv&eS%fM>DYo^RG#@BqB+DX4OuH[9w^/x$##O-q4f[][`*kff3/"
        "t?NZ6&BqwuZ#8$vSJH$vw[1Z#Mb5###OTCeLuBKM`=^kp$),##+g@/2Gg_7#n9w0#Et###%3eoebC+T%)qYJ]t^fj00Fi6&j+fg%ZTG3'*Q<pew90/2b%vj[_01W<#E_s-Yx<CWnkf9&"
        "r2CR'OO*l$77k%t^a#baEc@0(4^4P]w9(hLlN<r$,QHu$ZP&E'N',)#F>cJ(>FD>#;+;D5TUtT[sbD&&x77<.1%60)4]=m'IPpkVGTeb47SA^7a,I<8bY)B#4drH(2Fld3k;HSEug28:"
        ";IXN=ff*5AH(Vg)N'3kNX/5##1[.+1dYw8#d^''#V/Zs*o8Qa+Vv@Z#hwZT&.2OX-A]kZgU+lZgwNb8.?P@g.t3f;-XB;`$SF:N(Pg0t$*[wT.9_Mv)LdTT%LB-Z-PpCl-r6rZ^#NtT["
        "&Y=d&(r4?5QuV@]M#^k943K:^nX6x6J]B.*vkh8.uf4^%OqSv$<8@.2x7jKEcHcA-Pn(jEJl*x>^l*<L;eBN#P4B0<T#mx@bxDcF(;EC,('+]BO>=XC%V@-AJcYd=JLi8K$,>>#`-%##"
        "SF*Ab.9K]=W3o8.vI4H&TrBs%N+vP'H[dR;#%5,)K_Is$`6@`E_Lwt$7Uq4fe3*20N`N+rAmF%#,c/^1p4m;-t,OJ-Kxsr2K19a0%vg>-ni$K%-ch,230+=(o;:A#/pjpeIG?R*.t>/]"
        ":.Sf$TtHQcGLbb$M`lT[DA*H/Erl8+:0A9/._]T]JGg;-P%`5/#'iQ]C=rkLfeH1M(NJ#M%mb#&[,OB5>Cm:]]C[O(T*`84PL_v%kbNT/1T&f3gY;U%AR(W)gO3H+w'xP0QWCj$9uBM("
        "#;GK1+jQu[I_=X(NY*)#1)7O(E*=8%)[2H*J#gb4$2f]4pDcs-%GKp7NcHC#>U^:/.m@d)c6o8%^^D.3s;KmA,N)w$Z)(_,_+#5EGFFZ-1?fnEU<wu5qIv(5>#^B+JVM11d8W`5828:/"
        "J#;`d.`db+]0m1<vqmu/Dl5[5tKY&Jmvpp9FHDS0vRke)a>rg(IIDX8`j0?-F(#<6':*/1KaB#v-OI[#ag[%#9tAo%*T`oe=b5##B7mrejdGc*r0aW[Wx=S[6MtD'FK2sed01q[sb`W["
        "2rEd/$d(K.h-AF%->6n]X%Bb*_q`e$u],(dw=NK(jc4Y[[a_/%>=qM(.[S?5*NxeMpAg;.d5UlMbK/[#']J[>In`#5H0&+4Ov([##tWnBLc;*HSun9K;MY/6U6g&6u*:[>G&*e,CfoQD"
        "<M<^9mD'F#(M&3:sEq;8P:De0l'gE#lYXI#qev`*q+-p/KhgE#%XZ_>[fo70X^#&47b)YuP3<-vsSSY,K1HP/#jh2q,rvo%F=?>#>Ff5/i1],&)E(gL7)1W$wN>/]J)F#5/29f3SU(f)"
        ",x3BG(PEGH=FPifa*[&r;SvD-h=9C-vPvD-bNvD-[(m<-h,tG5^VH(#f8/X[O%j2$*9noebfq,2c(vj[[_[T2Wv,Q#'>1,2-K)R8iw%t[X)U'#D&0J3ee-lL(Q)+=vTZ+&ms5*uNbtS4"
        "`HLR#],5>#JUG+#1G0X[-XV#)*l>b*s@k&4-N^2-@3K+3T245&b0g&-.%aW[82gLC,8-?$8%p>2xuAN%Gx*)#&*S&G$3:kFAU^:/jBuD#)<>x60[1f)#F/[#[*'u$-*ihLt#F^,wCjc)"
        "GO=j1Ou%R0`)l:.Ku9F*uHIx,.eg)=%2a4'Y57h(?PWm/48>91n2b]%b@?S1O?uX$3.k,)[0&:1C)G;-FB@j13[Pb#PJGp8<ArP-iArP-wArP-u@gG01-h5#:[3.2:UWEecZ0X[jN?a'"
        "PbVse,M,:]J#aEeGiWs%.n/Q/-@Hv$#J'O.LC5Z2fc/T/2_08M^T/%#^mC^,?kRlLx1E.3YKZHd>Gg+4$`>H0*6qB#IjE.3<a;*e4Y0f)gv+F%4GL8.<sZ3'ApGO0YQ*1)u5mN'frX21"
        ">,?]3sG_h1*KPq8/4)n8^j$N13U5F#)v.U8cIm?6nm$W6vgOq8lt1`#%5YY#MS*fq@ku1geqho.FdCS@r'&M)A0t.2m+$j[-N#N-0(e)3,80X[?^Ac$(kuj['<FW*Ernm-T=P?g2uV-c"
        "6%Lrev;Whb9ce*3O5o/N2TfA,Wo4$$T',)#,ZPgL&`3>5e6:q[eo9D5QO'U[g;Nq-xN=0lG)]L(Y^Bv->;gF49E6C#.m@d)@W/i)-G0+*mS,lLQvN(5A8?@KaRXQ@)'=jE9Q`'H/x$3X"
        "aUSOCm?])cP=Y6HTtic:GrGIFXe#/I>UiF#JTPsoRa#]3PkIJ1UYOxt'-o9.`@Jrd5@@[#xOF&#lxc)4^FQ;$Ov.&GQv.&GL*dA#B$'/3NhVV$<vA>#e5/X[W%n5#,3eoehMft[S]=o$"
        "dtiHiHUQx%m&eO$,os%tQna`a6ZVGi'2i5/Y86Q#bWR>Mp6/W$+qIv#IsgS//OD>#1r$W$Ohe8.0eI;$vvg)&<^/J3cwVvWsHkqWn^dJfG+,##l6qA#H,v@0W7Nm#.?woe@LkkOOtC@O"
        "kxsY$$xIkO5X1?OGcp5#c>@uLO:Mj$xI$D/i4GH3Xk<(PsIhE#W-;G#Qn96V]Xt'4Lq,b#^k4.<r####+2m92Y'$JV)qlWOGv('#3iMuL$eflBVFQV[i7K#$8%-b6[0u'4k3'qBoQl6D"
        "%5YY#@,*fq=Xj%bYu8>,.#k4]Pt<R/qCZJ]iU`i0?)uP/Gx-)go;*j$&H*jB%m9q[_`9D52e6#,@bCg2@&Tj2i<c4:*QPa.h]g5Bc(4G2/D$++`sD=6&3GY>3gFf_?0&v#d;2>5-I;##"
        "^l7K%V_`W[.gBW$g?\?g%1)PfhhGJX[Q./N$.?woe[cJe$c?c2$)JC,2Zmc/1vOg/)skY)4I'qB%@)GG-*VT81WPV-#xml+#tfjL#v`Ma-p[YKFAW?TM<XHM9k&h#$*M3pex<TX:o`d8/"
        "+gB.*;gW3L_p`E@vt`E@$qKq;'d&crkdof1Ed$)*j(g4]RBP6W-b#j[rP)N$.5D<-7Va]$&[rhFvCNO'W5*H&D',)#'^1hLbEZl.&3=1)M)EF&[%1M)*)TF4nGUv-I,:P<ZK:HHl)gT:"
        "AA+R:k87/(AE$GY^V$oX,nVDI?:BuuO/_'#?&Io#YrlY#a=lw'ZL]w'cCwf1Ye</M+2[^4qh&JL0s/s-,ZSrQ#LK/2U;#j[,@Mv)?<;w-5Aufhq=?/]Gm#X$H$L7h>;7^$%3kT[gmWs*"
        "=`5W*Zb@0(Q`YN'xR9E')?28]*^=0jGFT?5EJ)n&n8mN'YX;#PKa4g7cX.Q,RP'U[#'wT-Hasb$0,:D53PbL(a2;3t1I0P:U_l8/3a#0D%><aE@EL:%n`WI);8Lv-38eD6OX[g3@v;H)"
        "jaA7/CMU4bJ)3W/i.A_/,7jd4*$#%ZHC`;$a*/G5>D:l0t#G#J#&>uu@-Fxu5F?_#YrlY#Z9###N#h#vJCJt#e3=&#,Q%Q,*9noeh>/X[IhP1%-2fk'LvOg7wZ]j0$LK/2c(vj[3;Mj-"
        "e/E#5IW8[tnkf9&u;CR'RX*l$AkT&tb#Hba%%j:6u[FI)>]%r%f)Ja'QkTk1k8]a''su'&im-a3]72K(^44L(GgJo[S8Rh(FlDA+MdD]$O%lo7E;Qv$I]o'HsUcW0DDg71ZL0^7GfEk'"
        "-^2;?3UEX$?*O1D1h;+6m49B-Wu,w9Vv6H)GkAiN+iJ]A2[((#%/5##RNft#;P;4#aQk&#Q&?W*T_`W[6>`/.729qeiA/X[Rx=S[(-h5#;J]j/o]JX[uK+N-6AO&4'l%t[+&Sh(LPuJ("
        "YtY@5U_9q[p-wW_[&SiL0xDG)W:6^(+4Y?5K='U[pxDj$.bm58j]'^#[?Gd;RMu`4KvLT%m4+;/.wVO;;<oB5NsuZ##nERBHPmdGg1-Z83m;=8/-95/Kx>Y9+]GFN?XvSJ^(cjX5^lo;"
        "$f,)#.[ZC#(-n=P850s-,'k%=bl$-2?u_kD>CEYl@IV='`G9&tYHTaa-ID>#BMBkLN)So[^re;SV/Jo[YGRh(pPJ6a#n/>GL:CW-iF3]-=B`G#I-OX$Wpb]unFeouq$M8%`6o8%fa9]7"
        ".otNOR)>>#PNft#?6D@(a;5f$0_e6/%=Eh#;,BkL3sb1#[paJ2K2lM(Tl#<Iw.>>#Yh2I$tRV9`tp=VH#7+Q/Yw^)'=gq,2pMe>.Y<IMIIb*T.L)wG&*B@6%aj#6&Z_5GM=N4g7:Xj%="
        "oDhCG#gxi'&rN3_Xq?G#WY*O'd?*fu^DcQji&V98##,Yul1]`*M?m-Z8t#j[mLtD'g0d8+*&)8%kqW5&RS#6(CaeQK#<cu[j)U'#QVGJ(QD7,)8+;D5JIpQ]Ja10(qbm1M^`tD#`nHa$"
        "m%ET%IJJC4ng,+<wN'03h'l=.NL@,Ge@bR/>cWEQf*(1;&`r7BJW?l=UmFoLn;4%vM$Gu#&e:N._17HpUPbi5.@<$@U_,$8`+Ad%Wj?d)P8kxO8pJ?7)G'x8qUX]Y_6&<-j%x/&b/5##"
        "s/^i#mKX&#>4i$#cJf5#<)wD3^S#j[dx5l9OP2W%P)WePuA5p%3^6)3lLw-2e.vj[p(Ag%,f?)3F#06&JaIZ%JskZ-mV1C&%,JfLLW()3k+8Zn>(0.a9Bed49pgf1FbN`a41t%t_g,ba"
        "</VJ(3To4]d5g*%vm4g7MEHg%VYBq[^V9D5gxfb4J6M<d&[V-*4mirCO?]wjM2Rh(Gt=]b``NxRd(/##T3,xu`=a%v]T(Z#YrlY#4HJfL5r[$v4$4]##32X-.bmw'HFk^oI*w--;U8&#"
        "W<Xc2RPc6'2vdc)'jU`3%8=JC:%i50?uEiLb^5T#>o0X[&(xG/-Z63(>&]ihdD*pee5/X[K:;X-K;aQj&U#j[cw[:.>N3T4H12vm,X)98U3`I3*xFeaIkb%t_ATe]<fF.)Uo#KMFYb/M"
        "24(W3K5SI3`FD=-SDg;-i4K59B_2W[VDV,/[gj--[r+@5?j+)#a;WF3]`Zs.]dme<XglV)gO3H+pFD8/PN(N$6c'M(q]&30+jQu[DR=X(@P*)#*^hN(Dwwr$UN(]$E4@x6W.(1&(<5=-"
        "XoOk%^]pP/a^ln0_MErCX+xXAVHEkN.EGs80BWv%8q;h)[/Qc5-[Mb*g&F5(dNiE=1b1f<.vpj<_%-D>Z8PJ#,lkm1o9)n'%2Fe)xLKo4B^+l()#/P'';*)#j:^l8=rQ(#bWt&#Mp,W*"
        "(-[oeh>/X[1,)N-L>_8.5DX)'jQF9.s-Q#)@&N)3vPRh('kk@5;+UM(F>cj'M^rhLEfRD*6Y<++'^IK(i`4Y[ZWCj$>=qM(;j:%%n^D.3Ti?CdwB^d<@E+FFOn:/FJl*x>[VRvK'n'^9"
        "k'h)31c,A@6890<43)(A;_^&A6x3oOKx>Y9N*R'5KSPS;@T7+#O)q#v?30q#DrB'#897#Ma(h>$>tW.2cc#j[+(-B($C]T]8b^q%*t1a0<l_ghn.$j[dYTc$?K$j[_<pZ$_8'$&d=`98"
        ">tX59_lV^HtH4aaL6U&teAXh[U>)V%&/hQ]5m81)l*'q%*]*)#L5TQ&,qC:&O+,Y[0eRo[oSRh(klOu[&^Rh(*qb@56Aj;%@>mg)V',)#,YNjLWO<T/_$Js*?LD>#6s#W.41qA(i9vb*"
        "hlj6/-a0i)U,6^=+rS&$Ynn8%jm?l1J4`C,m>1@6Ol*&7qg5tAd8](>sb/@'/sWm;VgTH>:r=R0`cQw-a?'r8.V`c>8k..4f%jl0?1Mh3$XQp@dd?(#Rq[f1RnBfq_#wx+BR1S[uvEp+"
        "@PgqeL]P7&Cw5E#^$aW[pl%K%3:**3q;L-Mnd=T%_88S[8[Is*=u?k0r[b,&&NUA#r8(&#]bV2(qjX,*IK(]$sYT6]04c@5lh:<%S>)n&9.US-:sU1.InN.N0nIb%q+6J*f8<K1Lt$EH"
        "N,a6CQJ%f;SFJZA'pxl1:QD`=vD1?A`86J=,^(F,*><99KK)X8u3K-d-o$##9<+)<LU5JCPWCK1wY)N$K.TF3WA#j[QZ[qT?xe.21i.Q/vWV#)w/1]#5+/.rsUQ,4;8>nKa_i32v&Zo9"
        "s+429]`CB?eGn4:dM&C>USaW]TOqkLF;l`#-xw%#:LVp+T_`W[qZIs*+'Roe$?i?^frb<0=n]j0%8,:]1,I-d$8xfL0Qu(3eDi/u'&+qeqAu8.^l3f0wjpJ1n:YT[GNRS[K&e,&X)1C&"
        "Yq[;$fW9D#$p4F5o0Mv)wxe0(8:k%tuBg?.4;1r$W=9T]ENC,)7bU,M9nR:.ch@1(=pgJ).LH$$;QtS%Ss:k'.T;3;^Yk1^FHPN'2`ww'UO3H+53+<$$n/S%[$JE%(-C)&^#G:.qA0I$"
        "8^F:.-mqI.Ut9lF$$8)*G=5iO(ks`XO/2G7F/kYn;x-r/>i+E5>0&MP+_AG2#&P:vMt=u#B`''#2DT,/5)3pF*ee8+88BqewuJX[cI-W*fF^U[7lpf`EWP)uhVm/(Rgs-]Y<6%+H)dZ%"
        "+5+M(5kU@5LSf)*tB:a#g.Y)4%eqA$iW8x,-/6<.-DSfL[mL?%)a1T/x'>M(0HYx#D<a>&YAoB5LK5O082q_,lHCWH>+P,2XMQP9l#Rd)]=D^<*n%X/Gc(Z#D.mAFY>o96Th=t$'4q'#"
        "WYd$v5*=]#AXt&##Zd%&XV,##vDTaEKf'a#6lH)3jx#j[CG@d/nK7W*Pc^6]IH.B5GgJo[72[U.J7tT[`$Uo-rrlbH<X^=%;XqhLi0aA&D<4u7_B,Q:3Jip2b`.Q0?pc$u<.n8%dfY?*"
        "-:_U/l@t=I5=u46O=)v@V0b=&VU=&-QQGS9_NBtH,6YY#LeD;$R4Xoe5R/2'``f4]2F;qi(<1,2te[k;;/RI/ew^)'eIn8I)qKn'V;Jo[V>Rh(kCD>53'j&4WD8f3<Q_)3'sUv-Vc*5A"
        "$:^Y5a=jI=HN/Sm>nk<Vd^(##g1KP8*X@G;QAcw#f9%##hE5:)Zet9)hfWoewULMU<HoP'S[T;.R&XD=8FiiU71mQWU#>_/&TH]b?9cf(0d?RW*(/X[.RgMHob0^#1I>)QI%&.2[iuj["
        "r:xG&.rQ)3d9f+MvpXT%`,$6#T_jU%7Fft[jb`W[cUHt3#?\?g8oKs%$a'(N$atX#)G)=^(Dst2$MeTk1_':N$98/X[0eRo[P,Rh(rT*)#gaXgL1qugLkZ)1)o#b1)ZH/i)aqGH3d(]v$"
        ";v-ifelF#7pq#Z#NVfH#%H_C#vPWO8Gx^g5o#&C8o^1p/VQ8#?hAV',q>j4]`X`i0XP)Z<*/jW[_c`/%sWTE*x#,k0]u]B#&&0X[#g0T+S)(9.O2l9v%&Z<-Cj-44w#lkM*IG,MbUE>5"
        "LC9q[r)ISDRd`a4+G`p.g]/J3aSNGung'n^BO2R'#4m)4ul6w-M5nrYL2j]+3vp%@JAOK3vb@R9Sx6*j$PX8&Loq]?i49^#ll+O/RTn8#(o&ZH4@dV[l?^Bo;rtqe')0X[`x=S[*Hd2$"
        "D?vreb*1q[qb`W[2`e,/rpNp+ru>n]H?cf(56+7%A&/?5,`Im,E<>O-)6+7%P65Y[Q/wG&%Q7K(FJDM2Z,d8/U/A([Hq^K%hvUispZcD:Em[#8cE8],fsV;&'v.T%5ce8/nL=/2u*j]F"
        ")^h1=&#_0:^EG%7.iC32g1[[-SQq&vTPHC#=p[d#Q$vY#k,>>#mZ[76JT'B#0dId#U0`$#p2h'#W[2H&V_`W[di2Q#LMh;--4QL/M:T&1Yd)V@,8D)+4^vr[$Z=K05MX)')('qe$Q(tq"
        "Gj2K($Yf>5YetT[wKm>)IBto%I=A60+h[p&usqgL+HS=-Td:3$V;%L(?<s8&sg_gL^hlr-Ij'a4]]LE41tB:%4<TR/GvPT.Z&PA#`I`o%$xeP/iL0+*Y'YBAb_6cGhr0^HWQ&&,OB]A,"
        "osW#-<Y^f)j6MI3Zw*[7E3W&5HPJ)GLVC)5F7#b+5ot.)c[rZ##8u&,fAZR&9S<N1nI?uu#r$20/W7d#[$vY#A#Cl%eD]CsCZ'DanMm5/l(>uu>RVmLZ^HF#)JBW$8,d3#*lO&#QrU5/"
        "6RC7#1Ux@:p[@E+1%7-2w[<jj9%-ghi+ZJ]uQfj0FSe_+huRg%=(;9.b9]j0gVu8.Nrni[gqgA4CZ_/%jg'M(O2ZbaF:gQ]ET_,)/L;c*h=5gL:=#-&0L2c*@r+@576+W$PqW*,.'exO"
        "GT4g7EhHo[O4SV%u`rN'8+;D53CT:/#RU&$EK$U%mIR8%HDw$$M8]51lOSq/3E*:0n(6$6d;0Jhk_<O:lMPb+mKLO1De<b5.xnW.-CNmLN[?>#=A]Cs-1m1^3x,hk&T.petc/X[:x?M0"
        ",2xG&?wGre?XDZ[8Rw0D5=N'ox>kT[jvs8+MiPs*Q:o&()sBpp>=g,M)sj5,VP'U[6S]`*H[Xj0TQ1N$c`6Y[co4^(Pn&H*@KN#nCMI2.9@id*eiMT%(LOA#_G^M^6(+P0Vf1v-$#`v-"
        "esd.)([ti'_l6B?O*?)4LPq?-Muq/D.D^P8plOp7$j]Mjjs&%#:YXI#C$vY#ctxXu,Nk;-'(LS-2G;=-&srt-q?k$M57MpN_=UkLbf.QMfHL*#l+d3##)>>#$2RA-KkF?-1fF?-(U;=-"
        "5G;=-QODB5K1HP/a;u.UL`OV-B`k4]nR`i0o=ZJ]fv+F%'p3T#+50X[mJ4W*78`OK?0O2(<^,9.QkQ%V?)rJ1?H(N$X+:x#Lv>ba+:-uQ0-Zg)fwpe)Ibr?@G<040*]*)#7bU;$,x9tS"
        ",'exOW/5g7]x5W*MYBq[UJ9D5IFpQ]rT[x,xq7f$U%+)#usbM(<?@A5KLpQ]YIY$,Edo5'P*QQAg(h#$'sUv->jCp._-f<$TY,]S*&DT/+wSI4t,EW/&^-=AY*oa5I3Qa=W@liE'iEW1"
        "3GJm0@_Jn991M>6oHa)+CtR],5A4R:#&>uuP8-$v]fCZ#;`5##=p,0-l$+Ab,BmIql_S,2__e-)S=bF34F5##ZX`>#*@H?$KH`I3(;9a*ZTIi*'F5R/g@h;*u,JGBb+V,ExGm7&:I^;."
        ",>DH.MA:PStsfv*nnl,2iC,29$oM5&14I[#&-&##47C^#GoE/Mmj]w#MEPiKdP7R*?[%##=`2Ab;s<,<UJlM($5j(tVN2^#HQ,hL'Wrc)x^d--nZLfL5rJfLQTSG;O%LS.^K^:%-FV_+"
        "=N?Q#Wq@9]/.7m/qfSX[.04W*fC9K%FH$j[,&;g.WACA#?EL-%77<5at(DB#<BSd*(+j&4_p?g%:(_i(#18?51DOL(qQ*)#@PIh,j0+W$tB2H*FTNI3.&M:%t]DD3K^^e$5)]L(]=]:/"
        "6`p>,h6JT%gX$*$+glH5(F7)*je%/=w+sU8/HAd3cRm@t[=x3:k[osABFLR#G7C^H8G3,2fflS;g+,##Hn8i#%b]=#BU@)?*Fdv$_Jf$#GsiA#V769&w.d8+&r/;%f&e,&S$OO(5jape"
        "PA0q%kI9a'?r<iL+Tsv#dO-W*-,+L(50>@5:d[B#Ul#R]drEI)lw.a4Gl.i$a%#d=_5P)4YH4f4B#Y59/:h1;3T(`?>FUG)0uO`^:Y+igbY1P<7%e]e4o>N1@X(RW/8cM90J9WJ#1#,M"
        "prugL`f@g%AVpqe.S,:]/:8J.#@/G3Kv@t.@..hhgo#j[dtI$T,knp1CD4jL3i1)3S;>/]D:si-+/bHZ?35Y[[DW&H2nLj(qx4Y[?Q1N$2<Gk-4b3t__GGW-i:t-ZPiuwnNxnM.^^D.3"
        "I2S#$?Xqm*DG-8%niAgL6[em6kWOto_D4TKUe94.o6&vLL1;'#eNb#)^e;q&Eo>re2`,:].%vW-LAsQjmTjQjXH0X[-TOs*uZb1(GHP?g&#h;-Z6#-2c>-Q#Tdi>#.x`W[%7Ba0uV2^,"
        "-A;>4@v>j-Xi.O'nV7d/+.P?5E.9q[Gd^HmDM=M(C_iY#Qp:k'ssDM2DZ)F33cf;S*^n5.]rj=8me8)tm<dMI4xG(#?n*xu=WtA#1C%%#KZ%-#Mo9-m2VpqeB`5*nw,[oeg9OM(4tWtA"
        "CFF/2O(/T.bA$6#^<cW%ggo8.';Mj-Y?o8.OoUK(O=i;-Y,]n$@i);pWh?lL^(0i)ds_]$/DXI)gx)w'QX?RE]>UG)KjZRCmKRqCwaeL2Rpj*4]6'w=JQXa*Y12d>-'l13mRRx6D7%##"
        "kC#29Q`:YlD4[N(?sgx=i8I-M:LXqek)N9`vnY^+obQ<_tr3T#HLYV$OoIe%9Lji0``>/]>@&j-X0pTV@q4Y[])e,&O',)#28`hLNFK?5I4tT[nVeh2b-AH[LO$e#W;w90Ug`xA@$sY2"
        "T:.a5'Y+5_d1#M,&aOMC>+*#MEc?'v/XR[#:+hXQ491^#Q*K;2NRNn8cg,K)13<d*0E39/KH)JC^X`p*%']E3&>uu#Z7'crsAr4fW1PV-U.ar?qt2W--sdF,9xDa,&DI#20#Gfhgo#j["
        "<@2Z)d4[B#0vspejM8n/xjEp+A0t.2ZP>/]0l%t[viRh(M]LK(K1*X.%gJo[4GSh(VfhJ)[vsJ2f+%cEHs>g)e8Xg3aS]F4)cW2*ho@d)lKFQ)EtX?.hn.NMoV)$JbJ$,O5gA^AViT%6"
        "8Lp:/X,?D<MKXc>8nToqQ5Yq<Rjv`#8vPD6>#^%pEn``+mf;p/k[7*;VJat8c8_NkY),##YD?C#nNY##X5o-#Bn,##=6@hLC20X[aUi;-CJUW$+wuj[5#d2-+F9T%2[#j[*ee8+vvP'+"
        "LvOg7oN]j0'#ki0N$.s-qp9g.'^IK(-9LA5)mng(lrdr@w0Q0)5`0i(QlDM2OTR2j`>sI3?VZ/:;32H*[sHd)Lk+T%J6We3D161<nuPG4wksq83dd3D<nJ>#83;<L6Ij&?c6JA6)rmG4"
        "Ou-=7IQgE5j_SJ1Y%992%/5##QI-g#Pi_7#@:r$#(pd4%9hYJ]hA?*3DMX)'g]NpejY+:]?v1'o,gdC#r]/X[GvHU)l80q[]b`W[`AWw]Bb%sA>7fc)=[Q&4PT[S[GAa)'A2X#)H^,m&"
        "C-/rXacah,2v(h1a&&X[KN1N$5KaT[KSAa'(UQo[JeTk14eiY#CBG3'K`;rTZ_-##Jf_K(.@l?5D&0J3mO`S%mkY)4_';a4<T><.2$xg:6$$(;.e-s?]O;FPX<,R&;Q4Iu_e]1PX7BBB"
        "/;$##`etgLrZ+rL3t)$#@tHi$Wt[;$heYRK`TbA#T4?T&5R-DNJ6pfL4rw`*S5(9.c2Q/K7aw'#P[E`aQY70(XYh$`<8vq)^B(N$cIg`'@N$hcRXiY#/@Rm/qm4g7FbOm#1^CL.oVeh2"
        "?uZ/)[Vov2C7cFDOVTS+?EVZY$@l77AWmKY+r9hLUF`c)PEo`%1OA>-khLJ-2hI.o%-D>(r&Q&QP=:&tY)$sncqc]'r&Q&Q=UUp7:P_G3X$,9.6rELH[HOcu;2isrRi*p%)s@YYetYiI"
        "udvi'VBp%#$),##Vbr;-Z5`Y(M>X&Q>;-Mr$;V&Qh>I@+&GTp7uCMN(t%P$D69B*[lsn@t+Qlu>4hQd2w$)##1l:$#*Krc#I$M$#Ux'/#6F###ddPM'IlT&(QWiY#b@tD'jtE)*hN+k0"
        "@g^^[`*N?#p&LW.d;JX[_&ae&Ki-G+$.``nF/0G0M=kT[Pfko[PGx/35A10*[P'U[pVeh2FImO(_R(f)jAqB#*C.p.H,Bf3,ntl&>kJ;O0&0BA2rTX#O>F5:'*gg#7o8rGUWkf##S>j>"
        "FMQmL=/;hL&RfS#'95O-Rd5O-1B5O-P2Ie/q,h5#1xspe[)rr[VRJ)+5Oa8.omJ,1[@jG*ErQ/),lvR%hOD)4F?7H27?P`C>i3^@q7HQ#tx+i285kG#(t?.=qSt7[=b1n1Ol.(#2%ivu"
        "b6[o#J*V$#DTaj$eMij'CII<-2RSJ.nTD^()cJdX%5a0(^ih$`ctiDM@x:^$o)CR'Pas-]);1r$DxH4$8TT5&gdUk12_iY#i`:C&Peu>[[>Mj$90KV8-n]G3'lhL&i7cFD_#qQ:Q^Mm_"
        "rcwM5ZdKj`#rJfLhV/wuI)^E#,a_H/UR`i0^6+gLc2<?#]i@g%5:7#M1I#ghp8nw^hA?N0Hm?g%SV_/%lB(gL13A3o])gN-,B(h.KC0H&0tfN-43G0.cn0HMUE?>#hhb,M=d_H/VARh("
        "gj'-M?kDY$+Vg/)W0^6aqGbD8<f^jCYBiTEcxq881,LB#X0/g4_0j+Ma/,A#%nx?MR@$###)1/#,4VT.54i$#SB`T.%####jB`T.`(<D#1A`T.9=.@#;B`T.q0,b#0A`T.<FI[#FB`T."
        "W;H$$X@`T.:17w#DsG<-/fG<-pA`T.MB'#$dB`T.I'b=$WrG<-8F@6/F6>##_RFgLclFrL0=`T.FEX&#;5xU.'/5##fB`T.Art.#kB`T.LZ0B#kA`T.a#9M#MB`T.MW9^#xA`T.+0Vc#"
        "XB`T.F$Ox#*sG<-/fG<-UA`T.kF/&$'B`T.`Sm$$0hwm/b]2@$Vc/*#f':53e)1/#I<x-#U5C/#lj9'#2_jjL-o@(#/K6(#Xlls-,ABsLk/BnLe'crL9n'*#mW?X.T0f-#jj?x-5'BkL"
        "Dht)#3*B;-ChE3MbwXrL]'crLf92/#ABg;-;BwW%SNQdF>M_oD2<XG-MhW?->K3.3?G0H-qJOG-f*o'IkKv<Bu2DgEW39F.VGi]G)>2eG<QCq1H6]nL8lY[.;ol+#LY:H-Yho?MmsP.#"
        "^P,lLK?UkLb:2,HW+k:BmZfvIeYc*4Tb.5/o3n0#8>qW_[=f?KP0C-d7wF_&rTTEnHm_w'#==SI=)N,Em4Lw^EH2)F`b$N1.BntC++UiBp=g]G&@ucE]#rfDVW*j1oQej1V%TfC*Yo3+"
        "AFx(3HL`G3p?B2Cs0m(#<P@r15;?hFR.xr1-/C4E*]r*H5f*XUhNcrL&0DnB:s^kE5W:q1M`>k1+?tnD+I3I3*gE8M=IoP.4d7JCSF1#HqANaF];8;-fw1hP5U*bR_(ku5<Ax`F<+Rf1"
        "pkn+H5-xF-:?*.34vfs&p&d?4#RY>-k<Xm/WG4.#b:F&#,H5s-7mWrL^@^-##N*rLj92/#FSrt-;6s?8^9F)#jxOVCh<h:B9LtfD8ESE-%O;9CuicdG/iCrCR0xW-9wps/G.(589?'G/"
        "_icxF%['mB.'C2CMi]DF#P#<-B;Mt-5#K4N+e`/#V5C/#OF4v-_Ob0NFxr'#H/r=Bq'rE-xBrE-*>;MFM]#<I4n@F-g.b$'LBUJDnCG>H`m0^5+v4L#?,j+MJ1CkLrCtk')$uM0u2FGH"
        ",C%12wYgA81>=mB-[MfL].lrLS+v.#LtZ&#T?*1#u<*1#q<3ZP_Ii(a,ubA#_W*B4*;G##.GY##2Sl##6`($#:l:$#>xL$#B.`$#F:r$#JF.%#NR@%#R_R%#Vke%#Zww%#xe1)+d-(%'"
        ";45##KA*1#gC17#@M<1#=lj1#kv%5#w9>##3H9:#:F^2#`5s<#H_,3#phh7#I)a<#m&/5#d;&=#hL;4#E7I8#D?S5#>$S-#n*]-#T1f-#b=R8#kIe8#kUw8#t7o-#sb39#OE]5#&xV<#"
        "60k9##+b9#xX)<#EaW1#LH4.#QaX.#Sgb.#3nk.#Zst.#_/:/#c5C/#gG_/#1Oh/#mSq/#rl?0#X%Y6#D#R0#x([0#<`2<##<1R#.Ml>#2Y(?#5]u##w+GY#:rL?#=uC$#%2>>#B4r?#"
        "65G>#HF7@#LRI@#P_[@#Tkn@#Xw*A#[$x%#mcoX#a9OA#eEbA#iQtA#m^0B#qjBB#uvTB##-hB#&0_'#L@9U#+E6C#/QHC#3^ZC#7jmC#;v)D#?,<D#C8ND#Ax,;#EFaD#KPsD#O]/E#"
        "SiAE#WuSE#[+gE#`7#F#c:p*#1Z4Q#hOGF#l[YF#phlF#tt(G#wwu+#rlo=#D?dV#&7MG#*C`G#.OrG#2[.H#6h@H#:tRH#>*fH#B6xH#FB4I#JNFI#MQ=.#LbbI#TmtI##;Q;#&rk.#"
        "<*:J#_5LJ#p;':#6OB:#3[T:#3C0:#$C_J#gMqJ#kY-K#of?K#srQK#w(eK#%5wK#)A3L#-MEL#1YWL#5fjL#9r&M#=(9M#A4KM#E@^M#ILpM#MX,N#Qe>N#UqPN#Y'dN#^3vN#b?2O#"
        "fKDO#jWVO#ndiO#rp%P#v&8P#$3JP#(?]P#,KoP#0W+Q#4d=Q#8pOQ#<&cQ#@2uQ#D>1R#HJCR#LVUR#PchR#To$S#X%7S#]1IS#a=[S#eInS#iU*T#mb<T#qnNT#u$bT##1tT#'=0U#"
        "+IBU#/UTU#3bgU#7n#V#;$6V#?0HV#C<ZV#GHmV#KT)W#Oa;W#SmMW#W#aW#[/sW#`;/X#dGAX#hSSX#l`fX#plxX#tx4Y#x.GY#'>YY#*GlY#.S(Z#2`:Z#6lLZ#:x_Z#>.rZ#B:.[#"
        "FF@[#JRR[#N_e[#Rkw[#Vw3]#Z-F]#_9X]#cEk]#gQ'^#k^9^#ojK^#sv^^#w,q^#%9-_#)E?_#-QQ_#1^d_#5jv_#9v2`#=,E`#A8W`#EDj`#IP&a#M]8a#QiJa#Uu]a#Y+pa#^7,b#"
        "bC>b#fOPb#j[cb##Vx5#8pF6#Joq7#8j=6#l5n0#nSE1#@%.8#LPC7#2jub#rt1c#v*Dc#$7Vc#(Cic#,O%d#0[7d#4hId#8t[d#:n7-#JrM<#^ji4#GLg2#t0xd#Z)'q#GUL7#MC=e#"
        "HNOe#LZbe#Pgte#Ts0f#X)Cf#]5Uf#aAhf#eM$g#iY6g#mfHg#qrZg#u(ng##5*h#'A<h#+MNh#/Yah#3fsh#7r/i#;(Bi#?4Ti#C@gi#GL#j#KX5j#OeGj#SqYj#W'mj#[3)k#`?;k#"
        "dKMk#hW`k#ldrk#pp.l#t&Al#x2Sl#&?fl#*Kxl#.W4m#2dFm#6pXm#:&lm#>2(n#B>:n#FJLn#JV_n#Ncqn#Ro-o#V%@o#Z1Ro#_=eo#cIwo#-5SMF.#nt7a_3N0sE_,Fu@ViF*6emM"
        "DbCp7)`I'Iu)IQMEkLp7-2vLF]Ta2B=W=U&P%VeG%^4rC#8A^&G=901D5+hFkt1tBv1WA&<8;9.2_O<B'2Kv$:;.Q/W@ViFEsg299fg;%6a>W-]qUqD4AnQMD3*39jSb8&<&ZW-t4E[K"
        "6M3nMAqZ29*mZMC/b%T&Hw*f-*N1`&up9-O)lBkNQasj9&5H1F-Dsi--^U%'w#C-OHw@HD7O?\?$LGcdGl<3I$e]fBHnWrTCs^&+%pN4kMwi7dD,7Hv$*q:l-s^&+%pN4kMai7dD.7h^#"
        "xpacDm0U-Og3x)E:$Ap&M$+f-3vh%'@GFVCpjM=BnKitB:'usB#qb'%;W5W-.[<`/FmU%'V*^qB*SvLFvg&+%m<SnL^sn`E&.Hv$VSwA-wSwA-Osq[-4sU%'saFOMF9bAFC/1V&(/DiF"
        "BuViFe0f*$ANx*$fs9C%dKWq-&*KF%tgOOMZD'^F?s07'jXVMF)rNcH),`aHJ(2iOT;hA=KCLv$AW5W--2D+IM-2MOS;hA=KCLv$AQp;-JHL[-'''+%90Ux7=j%T&L/dW-NO1c7O9DMO"
        "UMH#>.(H>H-@?\?$XGcdGxa3I$qO(DHnWrTC)-'+%&BLlM9+)WH,7Hv$BdRm-)-'+%m:GcGhaXb$BN,W-IeaLlQA%A'70hx7C;d;%Fa>W-[kxqVQH`MO2(OJOQ5W2OZ.As?_(Pv$IW5W-"
        "0^`2`&iw5J7[dZ$*ZX7D+tmIOQ7vvG=tD<%KGRR2NQ^/Ngg/NMZsmL20aKs-?Cw-Nan).NYt2.NZ$<.N[*E.N]0N.N^6W.N_<a.N`Bj.N0s`a-o>a_A$<[R*kXRF%l[RF%lXIF%,@n-N"
        "Whv-NP-iH-%.iH-%.iH-%.iH-%.iH-%.iH-%.iH-6t?6N4)3i2%w*g2%w*g2%w*g2%w*g2'0O,3rX:d-juQF%&*F,3&*F,3&*F,3&*F,3&*F,3&*F,3&*F,3&*F,3QWJ,3&*F,3&*F,3"
        "&*F,3&*F,3(9kG3rX:d-kuQF%'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3'3bG3)B0d3rX:d-luQF%(<'d3(<'d3(<'d3(<'d3(<'d3(<'d3(<'d3"
        "(<'d3(<'d3(<'d3(<'d3(<'d3(<'d3*KK)4rX:d-muQF%)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4)EB)4*N^D4ps]D4q&#a4fYu`4kLhwK+piwK"
        "bPW_AbPW_AbPW_AbPW_AbPW_AbPW_A3ORhM1Gai2AiU_AcSW_AcSW_AcSW_A8/Hkk8/Hkk8/Hkk8/Hkk-viwK-viwK-viwK-viwK-viwK-viwKkZSs-On[hM5u]/N5u]/N5u]/N5u]/N"
        "5u]/N5u]/N5u]/N5u]/N5u]/N5u]/N5u]/N5u]/N5u]/N5u]/N6tAN2.SW88iIP)N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N6%g/N7$KN2/]sS8"
        "iIP)N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N8*TN20f8p8iIP)N81#0N81#0N81#0N81#0N81#0N81#0N81#0N81#0N81#0N81#0N81#0N"
        "81#0N81#0N90^N21oS59iIP)N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N97,0N:6gN22xoP9iIP)N:=50N:=50N:=50N:=50N:=50N:=50N94pjM"
        "=5]79d,>)4<,^87ng,89sUXnD,<s=BsB66J3+S+H652eG%;&#'6=ofGDw,gD=F:%'.[doDSM%q.*bI'I7q_@'(s*7Dh8/o36x>LFkk-F@.>=rC1o:T&DK3kN<%@DIID`T.*RMeGYUiIM"
        "h.AY-DL'XL8_%XL:k7XLjL6XL:h.XL8_Q?$kwViF%b;2FaO$T&r8up.%0=gGA7(hcfD2[Aj_j-$<g?RM7RxqLsZ3%&o<C[-(si34,hrLFC)BgL+[,<-9qVYMlaMgCVGt4N0FvXM,L>gL"
        "uZ,<-.1ZtM*l#XM/[c,M,uq&4+-]/G88Ir1l;OVCvqcdGt8fUC;tU[':AR['4D+7DGr*R/ji.>Bw7iEHR5lM(fnJ+.;SEX(QUdI-:AR['H0e;%&.Vt/&($pD$QT0F2S9C-ZW['Ou):<."
        "+HX7D@V3FReVkt(Y5TT&h9Z<B7$5_]#+Q0FM]v0)*g^oDk9iTC3A2eG;2$.-F#CcH/GqoD*d,hF;$5O/tRFvB<T&lNmBHNBeM4oM(<x5JCfRr1+GR+HqkrLF9pPW-SaE:)in`2ME^kV."
        "#n3cH__X;.tQn'Il.>#HIgWU)m<xJNM,l?-RI.f$4ni8&0WNI?UHI>HR7,(&L1#(&QCY_&QFPC&M:>C&=/c3FOB(4FQBu3FPBu3F=[t2CxdM=Bx'bQjnxeTC<7Tb%?m9GH&j'oD34l$'"
        ",O-WCA)Vp.p$vhF8.>C&`S]^HF6*:)3k6WCFsREF3,2eG0(8fG;h+kbEWcB]=?4m'l'r`Nw,&hCS+or1SrS6a<0S5'Tob@'sYOg3F$)eMRNMt-?(ThOP:iHMS/pTC-g0oDxaBK-.(MmO"
        "/+DQO>H7eM%N)=-7XI3P6O%RO;*D-M)Bm<->wenO?$]RO>9iHM;VKk0&(:oDCmaI35F?P;_2#d3eDYD4gV:&5h`UA5pR/s7q[J88u*cP9c8,d3v<7BOUISFOUISFOUISFOeurU8N^H59"
        "a)^G3U_iG3vE=r.MxZt7kquEeAsc,ObBJFOnBJFOpV=C5%/?)4skoS8pw%Y-+AN_&s?*1#J,P:v&2>>#2t7p&@x8v-&%_^#'5>>#TLm-$R_tr?-m68@/2k--:.(4+Y'hw0p6e4]FG#v#"
        "Ner*>jP0$J:fpx4)>MMFV+?;$I5Ak=eTIl`Nme'(XJ>>#u`wC-ML$##8%o--%#$Y:6cgEWx>=Q'l;OVCLffKF]XCS@lEvsB[7'oDm$m.L6c;2F00whF*^^xOEs*^GRhArL9>LlSH]W/1"
        "c2?LFLh11HPDS(#)?[20'ZI2H'->/#DK:L,pg]'S#q]e$5KKe$S^cu>_Ou&#&8YY#wCg;-@i&gLK@?>#kPg*%Vb+/(4B0j(9pcG*:#)d*;,D)+8gG,*E$]v5Rww%#J]&*#khc+#5tI-#"
        "U)1/#v4n0#@@T2#aK;4#+Wx5#Kc_7#lnE9#6$-;#V/j<#x=P>#@=r$#Kbq%l)l'B#.24,Mg&DSI`;>F%0VVF%VtWF%pgOF%<-N+Ns`l0N[+K7NO6'$N#kaM0^B(&Pw%/Dt*%h>$VJP)N"
        "w_,Z,F+1Z$kY#<-1KP)NEt[)*4OHv$sY#<-,b>W-wrPF%IKTF%WtNF%RJ5-NckFO1Bv]Y#cS),)@xYi^+)WFuRbgp=M<_-6o.BMBeAv.L)GWfLKCjT.C@^M#Ni4,%()r.UOIqQ0HUcfC"
        "IMJJCa`$Yf*9/g#^Gqf#`M$g#aAhf#c/Lf#r?J]%ehNP&?-,/(/ifr6m6#5A<pViB^Q=SIvum.L#q<209P.&4Z7?_/]`l-$jrqr$Gj$)*fnLS.(T>G2,Kxu#gu5D<_3AF%CCtr?9n6g;"
        "YhMe$B(]Y>oZmJ;WbMe$Hj)L5CB=_/%',F%8Hk-$26k-$Bgk-$`d;A+H)1j(E'DB#RYsx+b`U(&+^$@'Ztbf(i[4R*'EC_&XQ@l+I/>>#R?S-HkMYq;WGK-QA:NR<$$,F%p;E^#)eovL"
        "5N(@-gcq@-L65O-NSPkL][PS0?;G##r,_'#>r-gWea.q0BAP##v8q'#H]&*#P:m]OU.SOUcT%'2EGY##$E-(#Li8*##^n%[E8ChO$k5&#Rj9'#<8E)#e[P+#OZPKbG=Df)(xRS%,#V`3"
        "Tjw.:'[BS@OLdxFgd8gHq0oo%iA-N0mtu+#?B+.#>KKsh)%]*.>`,68fBq^>CYk(ElJ6MKfQbCMDo^jD]Ks$#CeCH-#3d&'3'd]4]t$##h$T`W%+9^dGj@iL[:-##[u_@-^o<$%06MY5"
        "vgQ]O#oPX?AamY8&Rg_-YB<L#Z$(,)#Ki?Bi88JC@=l+D;vK7'R9mo7'CMJ:(2ii'<v./C8P6X1f^9N<EAdl&X/xd#nm$qL%]d##()N/D)DX'8H2>>#I,E>QqUT^#fcDG)Ln;MsZIZY#"
        "%I=_Jxi@JLet75&u4?e6Jc1a-[2(@-L:4R-A_CH-2WE#.QCvv?Qd_A7s#RhL2S()N`sAd#jMOgLg^3uL(@6##E(G5MKKl0UB>x(#g/:/#DFB0'N)fTE?UBh_,L-u9oqo,*=/Pf_Seh#5"
        "JV_n#7+,##/<VG#FTOI#1lsL#h(jW#PxGd.LxhZ#6j=1)=eCB#QVsx+$E+(/6[6gFK-fu-UxefLE1$##@-f;-OcQX.v*^*#Albo&7(K=B85x(3mX:dMFEtV$RA###Qun+M04pfLmU@6/"
        "h$2eGrA=gLBX#l$WAYY#%5YY#G;F=ZA@^U@pVaB#?[cb#O5Uf#1j.T%O[^rd*g:)3OTPYcZ*UfqMo9s-eP'g:'7oY>6ILAOsQGAX:C;L#-%(/qiO.;mdtZ5/FK9T79BXa$(?Vg$'<Rs$"
        "m(h'%oVX.%P`=6%v[qR%h,H;%:PS=%RCl>%(r]E%i2+I%lOhn%IEKU%$DJX%')$_%@bDE-uGT;-LcpC-?[E/1%9e;Z/X00(6);H2?&$c%grGaEFpIAO57LAOe8FN9R7g5fxB%t-Z?vs6"
        "1UXZ>^R$*E:`XB+);t'8;8]p&DCCr&iN*t&c5%`&T^b$MXEVB'5N_7'6/2O'@N<T'o#,b'ADk*(gd=u'%OjuL^OKvLwK2C(0it2(urY7((tY<-f(#d2Y*+h_SoK[,RL'C4o>o68b:6L#"
        "'lm-$-(n-$Ckn-$[uWq)1#]<d890F%gv@L,QVO6fFB,8fY1n--n$aHi)):$u$UEU.PWaj1Q[X0(>7%.$`)Tm([3:r(2'Rs(t#?hM6sWBOjHdk+&O5baqSB$u[jln&.[7=-R^KO0kT;L,"
        "J*31)IL=6)]v%@'mUi/)om?AM;O.Q-SXjfLE<XBOc*$Opr<iS.b+PC+>mFY%_?kQ),_g:%QoLO)&e?S)>WWT)p-wtL1FfqLe5RV)90uY)0/t])X-s`),*P'*h7Xe)Ft2h)BP;e.]gJi)"
        "iMYS.GfIl)eP`S%Vng$cwMFbs@VUV$=h[=lU4^Cse]qRn6S_=lpgC+rgqW4o?/5J_t>Tc`Ca,@'YT`Fr2j%cr=t,fq0PMq2A&Vq24<>X1]GYP/qeRM'A:/R3W*-ip*'hLp4v@(s4C#&+"
        "vAd4qr_J.q-n<8%t(fFr0=0ip:I4lo2(oOo,B0F%#,3R3f5DV?3#%8@NGg9;))p7[;<.S[ln[7n.wBwK)HJ(s3^PY>aEtu>jMIMB#UJSIV%SfLari%X,1B]X<%WZd9a8M^X$w._06M-Z"
        "F*Xf_dWs+`<5'_]1Q'v#9`]fiwJu1qwch2qU&df(n;DD*U-K)+9xeGNeMK'S=vxQE4Ba9D=LpLpmJa9DrQi9Dh3i9DLXT3XsTi9D`>4AOUjXiT`>:JU[V2DW#=8)X$(jEIa=N3bc-TSI"
        "<TpoIBsPPJpTklJffW?gg8./L$jS-Q,tR-Qb8Q'J&bR-Q.$S-Qi(+XLrgA;$Lu*wpE=(crM3^iq7]n+s&?lG*j@IB5D^287$+.>G-9@k=k.L+v7U-,vvfDuL8(^fLDRt<#:7&=#^OE#."
        "*lPlL@qOrLRkm##Hm:*Mp/F'MmKt'MqdB(M8/r%M[Gk'M;KH)M?)i%MW+Wvu.TFv--xclLKK<mLS%T)v1Z4?-;/f/Md?O<#LjK#v5oRfLR'-`MsXf8#3#jE-=J=4%I3LV?xJ-8@$p`lA"
        "gdo8ou6.,;/l0,Dw*YGE<0e_#/nwr$v3kf(eQ7VQE'd1g`0N;nw1lY#G[(T/<S)L>B]72'5luu#?W=Z-/Eo9;]jo9;1xJwKhE,GVt-:VZ:^quZh@8;[(3QV[FE-s[6gOq;WKqLpCiViq"
        "Sb+,sLmI_8$t]e$MS:;$^ilM(FbV5'HHwV%RGc2(P#.kXl4a-?ELQo[7G=sMIU?_8/PR7nS.Z5'NA1j(CPDH*Rpqu5u)%RNroo7[>b^-6_>h3=akH9iS+HDE`St3F%w]e$d'?e6EDX3O"
        "B3IrZY,_,*p7eKc`Gec)XN8m'0rd)4v'4/(o.Ih)kO4YY+OOJ(J89i^[p7Z$a*$qr@ljf(k3GD*tZ(&+CA/<.71EG2wNA/.N81pLXGfqLG_4rLHe=rL+mb-vp-PwL[HK5#D#jE-Plg,."
        "mAhhLG:-)MM3oiL6SGgLF_.iL@7`U##sFu#Dg4u#%s_Z#n2RA-^%@A-Y.$L-j%@A-L(@A-k+$L-acq@-dJL@-_JL@-A_xn04iuu#t2LV?l+p(E2qUDFR+p`FpXZJV2CTL5Mi*449?Q1p"
        "`JtS&h=M/)Oh0DtujT/rlg7VQYTQwB(U&@0FaIwB)X&@0/$[1gqp88oW9]?TP86X1dr6X1l9jY#9aMA+Pm&v#JB@v$`vK_8SrC$#5OF(02B8=#/G.%#VX*+.tg568>;kM($1*v%6t(cr"
        "B<dFr%Lwr$;$dFr@-H+ra22>50NeE[%Y5L,eNKSI]/F>#FARcseQJ8o2%78%6=7m'rj4g)#.J,*`*eJ2Z@`s-aZQIMHXPgLn[6+#A-fu-Q2`*Ma@eA-[kEB-pCg;-GwS$048YuumqUvu"
        "YX)..l'ChLE@UkL$ZF%vV7W%valR)vZU3rL/ib-v+N/Z0xT42vn=YuuC3JnL+Rp$.N7+gLZL>gL>iF?-)Nx>-8Nx>-0H4v-AoRfLkoT=#w-LhLrQrhLa$#xu[f&V-SM.Q-b(KV-)Gl`%"
        "<7@kFF4kf(rL;5&Xs57p=e0ipjoaCs&U<8%5CkLpABD(s]4Ms-Fu[fLeL>gLFN>gLTgcgL3LrM%Jw#XL*]Tk+']QP/RoQ'JA^3igiCs9)p-gKcvD#LGB<-8@VCTk+,aMk44ZfFig-t.r"
        "=Y$^c@HCG)#5Vg),t,)*_T#E+f$I^d9vNs#]+,)MX2bs#w&b9#d<151Z5(3v#NL3vnb($#reh).d1a'MbKH)MkD_kLc9-)MB9X<#k15)MU5$)M6)8o#eKx>-Og$Y%ih-q'_vgi'pp_Fr"
        "xKLk+SB)fq+*hLp$/-F%WPl-$f3X:mAV.Q-_K*nL#3ts#ep8V-4ZlS./Uot#]'l?-fUE#.VA%+M(T'(Mip^=#>&@A-AMC).SZI+M2W/+MC>a*MO<<$#iIa)#F=;mL[B9-#&C#+#7/5##"
        "p'ChL/_YgLCklgLX>+jLJ[b)#Ip9W.4g7-#=wRu-f@=gLT3N*MIX/+Mi^d)MeE?)MBFj*M@:W*MM<jEMQMvu#LMDZ6m=N1p8v1WeW-<;$5+;kFr-oo%`=)R<'Ikl&TZ02'$Imr-br%XL"
        "MQQ'Agq$29?0<J:a'H/;qamJ;fPW'8hao(<v&WG<$pT#?>2);?h_.[?BJ`r?@J%8@CY@S@w),s@t3xSA_N]?T8'j(E,KVGELmi`FP.MTJ7%&GVGgIo[O@(/`hK@Gal5iLr(WGG2ju387"
        "(cOS7_-WM0fHsi0mjSJ1PE*j1rdd/;jR@>>35l]>vV0#?w`K>?xigY?#s,v?[_,^#)NSs%L;;e?_7%_S<CxK>(]wK>iot[t(#l-$P;l-$RAl-$JL?%tvE$`s#[Z@tgMMGsA%x9)cMH_&"
        "a/1F%^do-$_go-$`jo-$amo-$cso-$;Sq-$=Yq-$?`q-$Afq-$n0]w0Ue3F%SFr-$ULr-$WRr-$)X`@tVTj-$O#t[td&k-$/-k-$E=5R*c+;;$2oUV$a,Ke$_[jl&Zs5qV+)lr-.l+87"
        ")cFS7-7$29,3@/;kHZJ;4Wwf;mZ;,<v&WG<,c.TA6JWlAWq?Gas]HJr0.hWhwh?>#&+?v$5W;v-vqN;73b'W7'6&F.H#Y2(f;W6.^4FGMT(c-vwT42vq15##gLv;-@FuG-E@pgLg_uGM"
        "X3DhLqX4%v_<a%v&720vVS'#vvIEjLr(M#vDb>lLdtQlLcaamL3^Y&#FsC*MH5DhLrZ_@-DFuG-L5`P-/bpC-^5`P-b5`P-T5`P-b(9,02=#+#3C,+#IY+(.b<fnLvMpnLT+doL67voL"
        "eZW,#^51pL4mj,#;a.-#=<Y0.1AnqL9XUsLPb*4#:Oo5#x;k$Mxi'=#_HX&#)Ma)#3p&kLC4CkL>N$+#pM.Q-K44R-9h_h.rE>'v)=Mt-TB%+M#oS+MH_E0vjE]5#pqwBM0+m<-wCHL-"
        "tCHL-uCHL-qCHL-uCHL-oCHL-oCHL-nCHL-rh`e.$UG+#YpN+.s;k$M-L'=#Geh).Q0JnLT77+#fUT:#%1H;#kPw8#8nM<#H5T;-`;8F-_LE/1re=6#'F:7#*RL7#wej/1O%6;#63I8#"
        "5__7#p5T;-+A;=-$s:T.?-@8#xM#<-7@^01>eh7#F9R8#IEe8#M'l?-g%,s/0OJ=#cpN9#JT]F-D5`T.tvW9#bm+G-K6T;-L6T;-M6T;-N6T;-O6T;-##iH-*aCH-^6T;-_6T;-`6T;-"
        "a6T;-gZlS.a+j<#VFtJ-YfF?-77T;-97T;-h@:@-=7T;-?7T;-A7T;-Q7T;-S7T;-^*.m/L#jW#sdMW#-5T;-/5T;-=LE/1KNUR#H7mr#*i5r#O(.m/-,0q#/29q#.A;=-u5T;-v5T;-"
        "w5T;-x5T;-'ZlS.l+Zr#ZeF?-86T;-*8fT%Kj^=lpx$GVwRZS%cL4;6N635/hhkr6nADPA42TS.Yubi9E:ii0liIV6xop;-q8rg%m,&crO;M1p$FC(s$WF%kf%#]to>Q1p)cB%t/1?xt"
        "/0<P]G&:5&1FK.qEpw[tCE)crG-MB#hn=u#B1`*Mb8't#P:Lw-Q7i*Mh&F<#Q2?p/L<3-vRm&.v>sX?-:sX?-@AqW.w0J1vD5(@-6G_w-VW[#M:-Z2vOdn#MkDv2v-:%@#J3(@-4hDE-"
        "Q@eA-JLeA-TRE#.AR(xLKx&1vV_3B-]'@A-4*m<-b9wx-Q+V*M34Fs#-]]=#6u_vud5*jL-b'&v3]u%Mp?6)MOK8bMDS[;#U^./MiM.^0f4)0vsq.1v$:a'MkXPgLx_YgLTe52vGfOkL"
        "TW/+MA&6u#wQr&0FoUvu%mR)v^Lm-.YfqpLFh.,voQTsL$H4-v]RZL-Nt9S-b^,%.BClwL[901vxkCvuT[XgL8r%3%AvUfr_GR`t_GR`tm?t.rk-=Mqk-=Mq/_BT.uX(?#.3r?#wg#V#"
        "%/[o#_5gi#;K_n#LD*p#Fr$8#7BC3v%IwM0(b($#W'n,v,W2uLU,NvuIX1xLl;k_$snFF@r_xE@U<d`*in_w$t94on/a%cr_/Y:mVh#,jMl.5goXs+s]Kq`tt9>oeTLs.rv*p(t2*D*t"
        "I58igS^<uu%B@(sh0n-$4=n-$*2GqD6g*cr:EX]cuP$#ZX^o;-c:t+.Z(ofL6sugLYGk'M?U(%M^nV7#4F`t-2vg%M30r%MOIe7vtu:P-&)d11wT@%#usV<#-6&=#$3q-%',h;-PxgK-"
        "KF)e.,U-,vT:6L-RxgK-=<*7%TYlER2)M5&)#T-Q',ui9<14kO3q;kO(O;kOG?t+`bdMkO`fYY#`j%]t/#X@t)nwp&&+82'<a8X:M;bvItbA+M[>a*Mao#u#tHKC-X>qW.k]Ms#3$)t-"
        "Po:*M+Q0=#sIm-.b5*jL,m'&vklR)vG(@A-IML@-EML@-(WgoLa,?u#hKWY.1cf=#7er=-(CrT.]ML3vhgCH-7Nx>-Cm*J-20%I-)x(t-OO0)N*iF?-=gF?-lnvh-ngMe-=,_V$,0(jq"
        "M)mOoC+=,s(r>xtYn+,sClK-Q$cl--'ll--npMS7,DlER/aW?gTr-_S6^@'f7me'fIJ7R316)ed$b_j;p[4$O7#4'Mg4k^Mk=1%O<wB=#$l%1vs6S1vc%>[M>?a*MGN0X#tB%+MpYAFM"
        "fU;;$4<YiqjA,4+3KUfrHr1-k^93$#kSl##kMc##)6T;-C_CH-1#5<1pO(Z#s*Yu#durs#.bYs-X[I+MD=avu7U-,v2Nx>-)/q8/qIY##Zf<CNJ;-)M2dA+M<;+k8=r9B#@Zu##[IwA-"
        "YE^$.LO7+M-Js*M/V/+MeW/+MJ2]Y-c0Me-@kDe--5Rfr'KM`t3]NcsZrcrncws.rm/S]lc/[fi+qt.r$[qxukgr=-xgr=-WNM=-,Sqw-EIFgLg($Y#qH.+MW#1l8VDo`t+#9xtojl(t"
        "&=3W-%+Q9iD#v92/ZKs-k$ffL_u#u#'q;'M+#4'MKrG2vtMx>-kv^DMQ@-##a(4GMEEJBN9R2ANB-aaMBQQ##,`G)N;:-)M)3q=#K.L+vGHII-ENII->;%I-ok&V-.anI-L*LS-PLwA-"
        "W(KV-^mb_.qho=#7*50.7eAL9ob8q`#Zld=J]Bt#*i4u#ZhW$O+pT=#BBG)MiB&wuX'`6(902>5w;LV?m)-8@uF?8%jR9w%EXpLp(oa%XR$rjt@6Tc`SLGL,^6.S[JVUwe0w(hLC_YgL"
        "pjK(MpjK(Mb`j,#qUgs&>Obw'4>q-$'JZc;I0:B#J*=A#sK9o/LjK#vY4G>#o@19MmC/bM=p3<#ZDtJ-p$)t-TIJ_M[+Y<#5oUvuMO&&vMU/&vxlR)v-(C+v>e?,vH1xfLa?b'M@^I;#"
        "2cVs#COft#@XjU-1LM=-?4RA-dLf>-sAf>-)Bf>-,Bf>-0Bf>--t.>-N1'C-`bEB-ZE></&HA=#K6>)Ml>a*Mhupt#w8':#IX+8MPK'=#(Y5<-[dpC-x5S>-W3'C-HI*^-YEI_8w2A_8"
        "][ewuPjRC#4x=Y#,HvV#'70U#..k9#&Y5<-xnls-O%ffL.]8+Mr+E*MLVt<#Caq3vglp[M1?6)MXen&M;_(q#&m=u#+)Yu#p[]=#;LPh%9pb'/:/'`s@fr.rBxRfrT@<Mq5WFVn9pkVn"
        "bWdCsDrr.rH:ffrUeYQs<aeFrn56loRHQ9rm5p3+,>]q)+;]q)LY?8%e%$]kt[*N0s0L+v7U-,vRj#tL2%NvuaEsM->AG[0fUT:#>Dluu?OOgLY<avuq3%wunN>1%0gO`EHU-;Q><woS"
        "bTJxp<X;8v-:%wu3vT#vifjjLu:i#ver&kLW+:kLP1CkL7Cx$vd4G>#G5>##.GY##,_Fs-dlvTI[lxYcTke%#]'+&#kQk&#o^''#sj9'#x&U'#'3h'#,E-(#1Q?(#5^Q(#9jd(#=vv(#"
        "A,3)#E8E)#IDW)#SuJ*#_1g*#hI5+#lUG+#&=M,#.I`,#3[%-#8h7-#HZO.#X#(/#nf60#%/e0#);w0#-G31#;:K2#KLg2#OX#3#Tk>3#b9v3#s>S5#.Kf5#A]U7#Wu$8#e[*9#qh<9#"
        "%C0:#KTv;#TmD<#^5s<#eG8=#vx+>#(DY>#>(`?#E@.@#wLa:Iil(e3<f[]4InPS7mZ9j4SPNG#0[.H#u':v$sY=GDQ:U`EXbQ]Fk?W&&pc,;Hn>CPJZm5>pDpV-I6So)XvgcxX&6`uY"
        "=`FtH-`*#d$aTPa7b1U#+IBU#2bgU#3Z:0%qG6VmW_+MpoltY#nxpcHhpA[#Qw3]#^9X]#2r/vHQD_s-#3$_#'?6_#-QQ_#=,E`#(Cic#/[7d#HNOe#Ogte#v9'cHpgE>H+J<7/@:^i#"
        "(=.iHd`f]AV/mm#Y.Aa$u`)AbA=G##j6Q#ab>)4#b'>uuF*Q7viE*j0:[p6vNN28vIW)<#4,>>#HQhLpkS+##*.r-$*Hu),<adIqJg0(&9Jl>##HnLgY?ip'F<lOov&3fh+N#VmsoZ3q"
        "3ua7eQFS1p)KX+`a6lIq13/>mvr2Gsrf2Gs>U,esMX0fq&;e:d)te@k.*%58$/bl=SW?L.:&$Vm@pWv$q=%`&*u9#viYo9v3kLaN'VC%k1iIR3mi/wOP7S;%Pd:X:Y=aE,-w$aN_@R/_"
        "j;r*MRxr3vZYB%MD`^9viCg;-DIxM.TI8louAWq2-?D^676L1p8L:#vfSf9vaCg;-#6fu-'vC*MH>O<#l289v-Wl)MAGt8vLGS9vs8>)MY#=8vJ<m7v^_v&MY/b8vIdS(MK5t8vcgr=-"
        "-hr=-ZdpC-tL-X.6//9v;0U'vo@e1KIuoxuJ]lO-(RZL-U*Wi-@'Z3#%F8HUgNMiLhR(:#805)MwNC6vRvYhLiE#Vd`=p(k4lah#sup;-C6M9.R+L(j6x/.$t+k9#mlp@MPeH.q^KH(s"
        ",?Oe$T1Y1gE<rIhhKpp$gup*UwEsUmUChxldOpxud]lO-nWrt-5M=]O^9VIM55X,:SPmxuxRSWSB;&crVIsOoIBSe$CmBH.3A(#vi(:c`)6v;MO#Nv7Ux0#vc(>uu[lN7M+E,p7ij9#v"
        "7aM8vUe]2(GHLG)G?QfL)P,ci..>lf_*P.q<3nFi#C.o#N`CSoC>_8.D,c=l00nxukAoY-9k[e$&Y'#vG7^l8x_'#v?A.FM9`c8.lV+##p&Od-Gfi?Kq.4_S7>Y>#4M3igm),:1PO4ip"
        "gB&Yl+mU4o]b_p$2xs_JY05)M`r7>OTh6<-.lHU8%_kxu+mX3MS-1loP5@@@@?L1p95EcMqP/N-'*A>-5A(4ML(rV-5fPkVW7$##n]0:;)(Q7vJS0K-XdldMp,rOf%`DwT)Mt3+,cTk+"
        "sS(YljTNZmcu<lfpfHucMH9_ZQgY7^nHKC-xQbl:0fU_&nN]e$'GbxunO*M,gfkxu>o6f(74d7vmjE9#UXp6vDaM8v%VO19AeMq2jJ[q)(coLp`_Tk+pJ(Ylk^jvm_][4flMh=c]BldF"
        "a^D<M(9A(sOgFF%lH]e$wFbxusrJF,%.CwOU:$TfiB^:db8n,=EEPqL%F_*)gkNqD/ImGM(Fu9#lsjr$bj1;$2_M8vLSgc.rYD8v>bYs-6d(*MEdj?PT]&k&38ViqDe(#v$TuDMeg-ip"
        "`2+##[3L+r7bRe$jD7:)J2gumik[lpej;#vHh,7v=Vt,N*8$##MM%:)5LAulWvGSfFMUSowxkERQfa7eRHF>d,3f'dHj)M-h[lS.2M]9v-3FCM4Tjb$:4B.$*dx`N./oj8nC<x'KSc;-"
        "ReAH9UQ(#vRMSd:=-:#vB<m7v9[lS.Y(>uu*1hL&q9]w0;DUqK4(b+.^Xq'<Gxa-v;V(?#9R8rmAonJjaZdIqEWX<-=V+58xAw<($ffQ(K)+,'0<+##i+-S==ilxuCSgc.)#s8vt6pP;"
        "VLSji=wO4oVgT?[w1?:8%Ytxue?;qioV@:)4SkxutW'2;;>U#vHm`8vr)Q7v1.lxuQOdn<YTkxuo:Lw-6rao7PbBm=6@-eQ_B>EP9])wTF#r^9KOP<2j'N(Z&sx^8&HjE,--TRq&'aFr"
        "xH2eb=qO4oZqDVneE%qgL)&crevTiqgvmxuQr=)+bT'5+en`qK76L1pRlCSo^$<;nKHSe$+LH(sL0(^=xvv:;)mkxuZlEK,jk@s7XkSPY:NYiqO-dxuxXtxu[d/EYm[r4MP@R8.b?1fq"
        "FZ0X-6Qr:0T2)Y8;'lxuh+B;-7oRQ-tL]P1T5#3;jVZ)MP-q(M?YT9vpcIAR7Din8Fon>M]:)<-@KxY7Hq:EG>]g^j>DlWZ^Qrp$2,BP8_]c]:+xlxu0wfV/x,^:m.,7loWO$#m*uX.k"
        "F;]CsR=i;-f[Ia9M=s'Ma0n/,p6l.$ba(*M?&)R@.rkxu:Z=Z-b<IkV.VC%kMPfE[2=1fqI_,cr?2_ooR)DPgpM-/rTtQ4VE0O]Zjb$mL.mg9vWBj[=aE3,8%xlxu76/iMxu9xtmGAxt"
        ",ob&#H;r*MC'MEN<px8.dE1fq&S?q7[5mqTa;CU1dU?xI%vAr-1;T-Q#Eh_&Cqfx=E7dFYG<S>-CpbZ-dQe'/oD$KsIjv)Ml6I7v$/6p%.uEe;mrv9MGdm.4Md)fqxT42q@'Se$fpTpR"
        "8LjX-L3<L##CWW-f%P^?.(So9uILk+p5_p.[EH(sD3Se$j$mekCdH^Q2;/b-4'I_8Fe:#vo(>uu]=4_$(M3f-3mHVW3)P&OUat[t[xAwTux4?.h#mX(t+t926X2m+=I6i$+`*.Bs.0X:"
        "5kH(sjKAW-Rcae6x/Wg9x8ww'AMbxuI?KvP[j=%&MvuZ-]>ad=&*m@.N+W4oB+nJa>Ie;T>/&crnkR'Jrd4F%QG`2TH,q:.mY+##gg#kM9gqp$Gxio$,modMYN=%tcA5IW`ponM_fd8."
        "n>a@tlL>,M,Ex_sRaF?P;L5x'/C3D'ETb9M4ndCs4aDSErl5(OfVX@tIawX12`kxu]x>)/ur+##ubbj`0AHU8'E*#v5-_.9W?L#vH<m7v^sfx=0@8rM+5LW/tZMBRRT:F<nwkxuN/OJ-"
        "+N+Z-2W,$ARp./&g)V*MEYjfLQ4wXlOYCul/;1L5JMkxuYQfn0C#sLg]t`=lUnvI_xHCWfw'#GM3ZtK9eTArgGH57^Zu5f_9DH%b+Lmxu6t9S-q)S7OA)F_$puCt-nb^@MbDA(s>uN.q"
        "_up-$F)J+r18Bl]@UR]cgOn--$f9#v%N28vd5q>YC]X@tEJ1R<'-eK<X`ROA(<tIR_w(#vb%'58fLu'&EK;EGvYU^ZQ$j+;@Y2GsB-=<-g7a#(<T-IEr6$.QB90T.c(>uuh6i/-#vsG%"
        "6f$c;w#cv.E2u<'xtep.Z<-cr[]+F>S5G(jw89&OBEx_sDXPP^n<?#v^//9vA]Kw)av)g$]EG/-kxkxu5bUR1o2QF7kA%+Mq5l`):-/9vE/EK9@2PL>xE/'H$k2n'MiN`tlS2Gs%^nxu"
        "4LpgLLbcHMLU(EN8ZdIq(`kxuXDNX6*YVp.fdH(s^r9?@Xv@-ZQLk3.R1GI:.mt(t=Voo7GF6Jr<3GJN0Y?W-KSA4`0+[=lC7vI_]2S$vti-4vuU<5v<Xi0vfEM0vV8;.MYFqV-5bwH."
        "W013v/*l]UI[LV@=LEx'J&>uutj.1v1NDX-;?B(&F&>uu57T;-#Ii9.jP+##ZR->m>C`Db+vP%boJS,ME4I20_/+##O9`@tqH'6rZ.IRSpN*k)_15gLU>a*M)n&=1/'`D==l@e6Z$KdO"
        "D`t[tM$3C.4KFxk#Ca8.hjH(sdJ,<-TsRU.obN5vb.Y3&aDAh$,DIo8D`=T:*?.^$TwA']Dkp^Q76EPBl2uxufxhi4fL2BP^_NK.m<$/9.Z9dk9Rrt-j/>DMqs?xkniK'S;,>XJb5G)%"
        "xT2@'nVRFMK7$##vt^,bi`,APG;T%)f,(Ylj%J^=Z0v'Z@-1lo*6q+sdaXlpgw;^O+i%;'kcXa&EOE=-9Gxa$aHiB>E)nxu,CNv'>TS=#f#O,Muap('<Y`X-&KK`dbo-fU&XY7eYG'gL"
        "#b38vBEWe$%Yp6v4LZ&M3u+5v=vk2vDc$4vV4ddOoVT._JqL_&#0<09^6bWS*i$]klOsIYi?5MU$do@9InYq;sQ3eQICb)<gp'#vmlZj8&xSe$W1c`k%pvddK`AoeA@W9.kT(fqk&>9o"
        "WR8loMF4ip]noLpe&QZ-SBQwBPFm,Mnv`Frk14R<_pN-M#ZH580udB9,('G.?TS=#^0'<O-6kj&i5i*M,8T;-qku8.[M]9v$=a_OBfdW-00Ww9t6D%t:BPW-H+LjVwRw'C*55t+W-OWQ"
        "&ZF?%#PdZ($.ek4Fg)p9i1'YANo61b/61d/oAa@t_0lIqkLc$8Igk(tO=R<-r:i.(HHQ&QZ+$&%+.X7n4[)##jvdCs$Z.&QLl,hLQ(='MF.e:(q]4A'D@k(tbRb^dW^.a$:nw^$:#Fd:"
        "lv-x.)F8cO1L8rmXW;#vRm57v`qdX.a//9v$,PS(&l&)PYgK9v1H)8vYR-_<GxlxuX`wR*N)K-MG%lOoT?KK:;?arn:?P+vF.AR&)8=0$Bj4:vd=dD-e3B9:%j;qM0U-cresi?.O/0`j"
        "dZh%ufmi1$F/;q8#Rkxu-,^c$@iF_&k'Em8qApDcwV7orCi9xtVqgFaOKJ/O80#[$Ic%1vZ<S5#qPf9v&Y812M$*+&Fd+:vE`x9vSp_j;ZSl&9W00Q_HZdIqn>BQ8Tdkxu;*:-)o7`^6"
        "X`Vl-OZdugCmE8vbC*j$;kbJrLDc=ls@RpRJ=%r7rc[.6g=?v$Cdgt-DLtcMS0AfM8b?p7.UI?;&_4EG[gJT.LI7EG2+Tv.-r'`s53g_&,Skxu2;0(%h5*;&qiXA'0a^r7I:)#vT%P*;"
        "Nk&RN)H&-MS1$##?-5WQ9vJAY>)&crbZXlpiWl(tp<XR1lNU`Qc)&crB=]WQ[eDX-H'<L#N,?=Q&m5=*96)weusU4feif1$RIW20Y9X7n8h)##C/#:;FB.]:gq(#v=q#F:pJ&4=mM7+M"
        "MJXd*,pYX-kCbj`F0vh%sNGA-L_jY.KZp6vbFTc.^#s8v$UGd&C(Nd-,joXZC2aFr+H^:mRK2XCve]f=@EoIDd6r4DO<c#+bj&q7Z2EVno:j^/P1$##,v%t.1BFxk<ns92[s^p.K(sOo"
        "sl;ki>)&cr=R82q3'8xn]#Jg)4S1FNfDx_s'*oDN>Nj29X;-Z$v^*F(@?2HC4%hWh6od@@p?H#9>=IL,(SkxuVXjY.`S;8vAbYs--i0(Epj*#v/I5=PPEECSTQZf,xj[,M$<]Cs4k<b-"
        "IPPD%#bIiF07cZ%V'u-$(P,#v-6W[=Jlg-6(Y'#vmHs[=rdU4+K-c?I6M*HY/UqhMIi9xtOC(X/xt+YY'2.YcwGR&#J@G[?Uk>Gj*gQ[-L3<L#+H#S85)lxu^tlt&xh$m%1.=L:K2M#v"
        "MgV8v6JCV?JRASo-c^w%LAO'EW%FWSZsC?1^-@vY(<TL*@Jv#Zi&a60Vt0fq5_)##:H5@'$f9#vNN28vV2kr$h/`*M;MB9v;pL:)i8[/$_q2F@=tLGusugj^mG?B*T<()JCEZ0Bmb2Gs"
        "4(O8p7WHUS-w9xt/(C%twwaR/]*lIqiM+##ZQ(RS%^_:.hpdCs1F_a=I/W#Nj];onk4&3;<a*8v5&=X=G#L#vY#s8v<Z;c:CcCTNPIHiLTh(IT`^f78#%s2iFqQm89e,:;wvmj8H$xjk"
        "osK_&:mi.dsg*eMl@d8.nc.fqZQK:.k)*`s,_T,X+>fR&>;$s)mM7+MkGQ#+aRM<-te^O(U<,SUf4QxP#V%R8:l9#v;6d7v@vP%.8Bqi8:=IN>);lxuh+B;-fFLg-Yq?KW`1FtL69aFr"
        "bX3onPuZ7nsu`csH?s#JXaLk_P(_1&.Fp3TL6+H*`hcGP(cI]%MpK?P$uhQ825Dl4<W6wD0$wum(V>XJ?x++:$9dF<mRseH')Dj9Kc/f-iRl3D,^nFP>L6,4VhCM'kxw.OW6lR<8Jt&f"
        "t+#<%'Enxuj;@n8i>72h633.bG3JY-4*B(&@XT:@JBuJs'HNo7jnF.X?&C0'VTx^Ouvnk:x^U4+TIto9)24_QsI4s%PP2o?FFL^-E%ZP*EA'=$fxir7?It>7-#LL(T%[w.eTci28AB,="
        ";rYq=oxvkihfF?9Nkov%V1o]-LXUM,R-66Q`h$R87n&F,gLu1))(>jh])+##9[r-$]vv?R*(b=cq/F_/2.u%+`Iq,MU(rOfO?,30<i3ipI;c=l'M6l)#tJ,(l;wU&`OF.$VRRQIMr(#v"
        "@J.+MKa^9vch'C.T2$$[(?94&3wa^O8US7n>-_csF]cV$0p#/M7+2&&/4qS@9sf'/&tssZ`+Ib=de)#v]rao7&W>Q:AuoS:DA09vgUW`=_%dB]Dj4:v%(V5I_2L#vc8&=#$d.*DK%(@0"
        "uFbxulC6M&q.f.OM#CZC.g:#v^<B6v7UgsMhhd[&_Zq3v?Rd&M:+e>Q2ia+M2^3fhxWuOfCb3`abS5c`HA'##:Gb4]<@R(a?Q=8%mU;eM0/-W-)Yn34Xi:f_6slIu6=<ul7tQ+idNVSS"
        "2F*,WdZ,t-Okb+Mk+4%8C=_w0/*@`6I_iX-X3n'/2ed$vR^r0v#k.1vfdO2vFk4:vaMK[M2cg4(Z:u,M33mP*ZR;m8D*<:2'`4ipq5w_sbNx4p2UefMfx`FrcKMgLG>a*M2O`B<ij'#v"
        "@8i*M`PQ)Me`L0%aPBkK./cxu&&^8)CKkOP;d)fqvNxPpbEL+ri*KwK2.?L,P.S^-UZw'ON&0'd&WZX(QtQ_8YfrX-riK>T%mIj8VYu.+5*#O-*v:P-4ERA%DQgq7K%FwTpa@%>80JwB"
        "&PsOoWkGS9Hxb_Ja?t'&98B,M9LI20O)kCjWp*##<er-$:Fu%+gPDcO?U-ip>9nFiO/Lw%BDx_s:0n9@i,lxuR/W_8_j*lX=Fh#vKgV8v@T;8vG3j/4k47O-?Dxn$9389v?H*b.lf+:v"
        "mbYs->SIFM-Zda$Qkg$+$Us58d`EGsS]m6MEo#:vGqlxu[UhlLpapC-f#or'eT;rBLn_W&lb@&(dJ^9MFt*xY8WX@tnrI`t5c-gCw(/DtD6:Gsnfi(t,GcvYlqG6T$WX@tXBOW-+t@^d"
        "i>[L%MZa3$j;r*Mm]8+MnO&+MnR8FMa2F>8K&p2FE97?,Aul?pOG'b*+B8-MGSP8.pc+##p,eh%O1oN'5*S4$Tg90:)PZCF0H(#v#baJKKRkxuj8lg.^T;8vfBRm/P)&9vDm`8vqE]V%"
        "i$4n8'0u?0'`4ipLU0fqV.75pQMDX(5kdCsGc$4=n)kHl0dYp%r0sW-A3t,OJJPx)U+roo:b]9Vb'Se$^q4i:Z`kxu2UUQ8-Ba^m;G(`jhDw+jxTqxune=19<QF&#%VVN0*Z&19xUYCF"
        "^WO?0O/X%,(<#0MD-'a*h3ZEW[&/Z(@MS.;D>(#v@pQN8GRkxu$KRf&7_m&-PXQf:b-Ow9xIS1po-tvKI/.Z8bJj:27,oxu.BNe*gE_s.i/a@tBwr-$5+0MsDgD&.,ohw*C;KgL=`2L&"
        "ws?4vjna5vAQ42vpEM0vL<B6vG*'6v(l^%Meu%4vF'Wq/.8:3vCJU3v;Tj+ODMQW-)Yn344`wFV*[1i:D(:#v>0Z7vuV^C-/;fu-Ld$uM+M,W-ZR3@'qrM=E&7gq)Z-h1(W$#)M%_T_M"
        "5$Ax%>Xl=Y`xp-$*<Z(Wrh(##$e@o8DFlxu&sL%+t=r,Die^-6EY=lfF+l--+<)VdPA7qfh;LxbxF&SeU1g7[(&i-?nla5vj+B;-_)E_8qdNe-24q#v[m`8v.LB:#SIGXP)W-ipVIsOo"
        "0e<<-OW)3Vpn6mL8;Y9#$8,SHL_arnW<1l92Q2QLvt]+Mg%V4fVU+XL_A;on%<MS]H@4Gs[n^c<B9cxu#>jYJ(n%;';Fw29(XhKc4Mkxu]r8V-;#&q*gX)<-Rb[X$Ut.fD%X'BTsHm.3"
        "r%2=-`fDE-q0I])7d%giLi#,;KfScjrE*/Mr0JAF;5L#vKN28v8SE48)ZkxuQ`WV&<S:[8.uKpTYRW:mCgJ%kIY?rmen3c%rUJe?>;QAM$^%a*T7@^Or<73900x[>I0-f;CUNZmaa)`s"
        "lV+##Vn.:`YcZX-M6<L#GQ6locHL+rrK`w9n%]Dt@RBoekZ[cakP^a*@SQs7+30X:^i1#*cVHk=.[dCsQs]Z&X#sxu>qhq7#<pF,E3]Y-lX%Sq$FhLp[b=F#M$`YSYfpI_NI7_6M6V*'"
        "<IZg6JmO%9n+S(S$AppT>/mp%;URC'=E&.MEjg(HZ%hX8GO#**.LZw%J^,5&;V9J.qA+?Y0QU<.hWL+rl^A?PtiDBl+nq&82S-ekYH'+/;)$VmmR;;pQnN_&[(K-+3)B%9BBs&HQvv6'"
        "@diB)>`*4Qt'(X8Me&,O0DcCjq_jv.9AMd%ap`(&+tN?Mv`:F,Q%?p7NRd:;G&:a8&L:#v3n57vNd-j+*qov%2FRM3SVh0'MI@R*7ud_<naNe-m7*.bN-/G;$4L@0@ViuN9=^G&iTx<-"
        "HW`m$bkejOlR_1Mr&V4fES#,;-C3/i,6LX(6Mkxuu--h-'1#4;KLI&MCt74?,OBZdA)(Yl7MR1pSb<N9;3:#v<AJ9vi+B;-Ig6D'#EfD;c>x@[>L$tM7)Ywn(;Fs)$eDfk+SS'Nvr,W-"
        "c@X;^52A4v)9tu*.X*-Mtl:e&r.06v0aXv-95n38K3Vj;?=#**G7Y;^'>.YNoeiT(:+U?.Gx7lo3n'w-w5d+M`6v9'Bs&b*bQtHNgPRp7QU'#m*q;MaS5V-/8o/fqGnu&mHY=%tto+##"
        "t.u,M9an%+@gF.Mm(68Ri6&39L=JH#9Ne7vP1GI:k+F(=GPp&$Z90`&.fjF.t&bL>8,5@Y/T<+&7B5q7r483iV.?M@l[kwTg*9-;`?l_/ws__]4[]wPGntx@gp&P9Wi6(#GYE5vkna5v"
        "W]q3vG213vV.$T/l;l@bO1c4],%u&#4<C3vT+B;-Sj7R(gJsg$8wr8vBS=,KxA_@0'r>7vc3K>BEBdE58X^I<-9K7JFsTB@G<Lq9*;^EYa7M(au(t(kOV8Gj#hB#Zo#@(svwx9;rP>F#"
        "&WYP&Pu2q.J1S1p$K;EGhMm*&Ft_?T1TY[Ph+/G(<:1I.nAQmSgLXjMbcX@tpJ&]tnfi(t:'iJsEM=%tADE/40pe0V<mD+rLk,Z>)*tL>Q*P.-3=r&O2nDQ8Jx)Z88j0T(7w4jM+XX@t"
        "4@Wp7_MF(=vjeF<2R;F7^+8o8dE>R*E3I,t#3:X80d6>'C]O#vIZD8vMfxd:E.mxuw53_('MRaOb*pj9xHAsT*FL'.T;<k8c_a9^T`sa-(XM&d1D[Hc$F#Vdda#e;9VEtCn`N5vu`1EM"
        "NhsJ%f,@8#q+-&Mh*G4>`0-k#Bgo=#r.fu%e^?(F4uL)/A8?Fu)`JFM))u48j/lxuF@.T%5tN_/@6jE,I2A(sH0upR5[dIqPLxpRMdxn8:OYj`&rXs%Ad+:vCv_]$s5rKU)ce@?NTQX1"
        "xK.c<XR;F7jB)c<8]u3+pk>ZA-]8D*uif`&w7(ENVM=%t%Ybxum4n@*EA_6$tm]j9UTs%&sE6U(W1.9.f^-criA<^Z%_fD,)8#dMJV3K(cJAh$EA$?PZH-ipq-+@P(p`pn,po-:+qc>["
        "Kvnh2Uh;eM=Yt%*CA:+X.Lup+iM-.XR>NgDj-)F790F0Mh4qV-;xa=?<i,t;8o%@%9h2v))9nxu[p+-(aZu)M(%EEM`QH.qn`i(t'm#0MWYP8._H-cr_wf)<&Wq*S5uUa*iJbdMwDg;-"
        "D&-rB^5K@P_/)]$U-6%+a=gZ>YBGj`JYA,&?Ax&#pJ]9v.s0D,%p4x'&<3O8bYisDd@@N%5(n0Mx4#X(gS'-Muq?/:.8gf-d`)rT`D>Z-fXsDu2sjfkK>%^Q:-l:2_4o08$Gt8T-=fF/"
        "3$H7v)R)]Fl_kxuLhG<-1-^kQd9(:.%S$s$K3=FNQSpx.-oYI%kK`$<n(N[]VoX@t6Wb=l[9hFr2-TW-<#MnMKwcV3Vopv.e;4GNlAma&>ES9vghPm8b_L.;*4?:;gf?7;`sgCM5;*G)"
        "V^m/$ei9eMqAZ6),Xux)$V%>-i*+n)Wjfv.TCrOC`Hc)697%<[&KR1gSE`@t1q4EP-)e,FstE.De(`lgN*+s^TH@FN89`M%BQi)D?KC4+&Ykxug5_j4M[n68SUh32i@/Ua;r?#_$Xg%)"
        "gkw9[?IhLp(+M]Fjh:bAa26@P45:P%w&<K9qFaQ1rdL]$VwRxK=#0#vX0JT?Z3+5=,MKEYF)ev.)DrU3mv$`=fNaO>=X#42/AaSh=mht'AU3M>(t=AP<C2q7;O$F>grt[t7Zb=l[-wu0"
        "U<0$NOJ2,1m8[f$#al?P[kV9.&uVP&1E(v-Rxx-:Rk%4=SG$I#]s2`1U6gL:,dPkO(S+42_w6[S]j]O(Q)C88>$^k=uBb5XESgU5S/M&k/xt;BKn`s^Co:G.u62ciHSB7;<X7a*a/h8["
        "eW3US[d?^=_baDYx3LZ:8QbK3XxT=uZSv8)FC:+ACS,r*K`K-M#j4v%/Gx]QbtdIqN,0`j`-P.qY<V5A4QEYAl4*i>pgP`(v?QR:cD$XJNqAspQYdX.)If9TGv`Fr3getRU[).MN'hWK"
        "=8wA0w.lxuLIX_$)(6eVEjvT%PTN$)b3)fVp5#gM;f)fq&jRkO6=4Q@C+BF.0cSQ(-W(U;];]ZC-opk+*4AvM.l7a*EL%ENNB&j)`?[G'Hqlxu$.B,M5rP8.tw5fh_=]>GONEY13CLWf"
        "ZaKCM707lfwhfd;Ei?L,$-q(Z5-1lo)D73M%&iP/+S1Z#415##uCbA#;&dG*(uB#$/e;[$,]UV$wBRc;l.6D<%<sc<&u9'#rR2A=(^98%9nQ['':vV%%P]>(B;+w%?X*20vpoh_qVE/2"
        "IcX[%ghno%ialh#RL6Y&x6HS79J5L#nn,87q6,X7G7ox4UH)58UT`l8sZhQ9^/x.:bGXf:QH_h5*OV8&8=^i#85@['4<k-$5OrS&?QO2(2h7p&GqbA,I1BZ-dUPV-E4#W.u1B;-BM#<-"
        "j5lwMtqJfL&Gr'#W&#-3Mgs+;;i(M#g.4>5;]YL#t1<kb%69G;3^lO-0Hl@MtqJfLhgjmL::T;-<54R-5`CH-[GT;-:h+dOjMG&#9Us-$:1Ak=N+T;.$Wi.$QDb9D_lmY6=T)/$1i5kO"
        "Cjk-$Trfr6=C:T/Ad`%Ov-,GMkReA-Q1kB-Un.VNH'@E.;]&*#R9e21G,A]OwFi'#GnA.$6k&_SfpAK2Giv(3G+m-$oZWf:0fjfLXcW3M'C3?P[:9-#M[%-#_G_/#,<#s-5HwqLgKM/#"
        "KR+?-BM.U.0Oi,#DF4v-fT_pL=(SQMJfipL/x.qL.(8qLdep-#HB+.#LN=.#sa6QMBYVpLir%qLW=g-#itVpJuf6MKx-SI`j'0KM-`/GM/9o-$P<o-$`@c%O9XC]O7X_xOnNOJMYUI2L"
        "8aOe$ex@X(?[l&#4bZuPGI1sRub1eQXHUAPDx@X(oW*F.THo-$N?Z/$Ws1R3Dv3'GkCx1B^x<MB0T0F%Xst.$AQtKGbr+BG*-J]F[i%edqS[EeKaYoI>m+.$pSgERPkt-$?'&RECr>YP"
        "[`O-Q-owlB[W%^G-=(qr>r^Qs[Vrw'XNZb%LH`,#Ug/,M3``pL_(8qLV3GDNKl%0#J?L1M%U`.MU]6=.nkj1#P]m--:MCR*/g^D4/RQ?$4O/2'6%VV$C<Wt(1$=m'68PD%oOL/%lUKV6"
        "A%;.$$;)N(+Ip6*9Kk-$:Nk-$mZ(,)jA'.$hEGJ(?&-g)(+L'#xw.>>&:fu>cj9@'$oMe$#`m-$Rd=pS*JNfLSh/KMBsk1TAd8L#o(*@'(&i.UX?PHN`=IfUaB&;Ha^Qk+?f#>P#+w/V"
        "'Auu#Bppl&ElfA#.VWh#LSj+MqW`/#IRYH2CA+.#>xL$#l^Q(#9jd(#4#+v/ppm(#1SE1#TKWfLGx$m/I/`$#1m@-#q5T;-4a#<--xY<-LBg;-xS5s-7)ofL-L+)#c+3)#bRXgL@lP.#"
        "QmA,M%PV'#DA%%#F:r$#/TGs-nm-qLV:T-#b61pL/9MhL/-;hL[.k,#2Tr,#gSl##iYu##;v?]-&0be$F9V)FQ-cc)PS9vHpZNe$PV:5KHg@&GNrep^%(^fL4FT;-]MY@MCUpV-T[aL#"
        "$0c'&5(bKc%%?v$XP;mB1P:M#E?G3b2<'.$DH$.$Ph]3bb<A3kuCF&#*D)s@GT$.$n:B9rLeb?KOJL.$520L,5iR5Bp;IwB1<0j(=R#/$3vNk+3]@5B&K2.$U<Xw01fK#$/C;=-$hSR."
        ":h7-##DF&#2>H;@AF0.$w8o`=k*l.$DbB-d_PU&5axA]OMOH##`mA.$MVC3k:@ZZ$1rqr$]jj-$9mIV6#DT;-qW*;M-u)j96LWt(qNvf;'m'^>NLMe$mrgo.%2-F%/%Y&#h(%3D(P5W-"
        "qV0I$t<)580]Wh#H<s:QbH1I$G*2,#4-:w-B]imLnmsmLH4$##jGg;-ox_5/C-_'#xGLpLjP>&#97p*#x:`T.L:F&#5Z5<-OFrT.r2h'#g'A>-WrY<-1;)=-RGg;-mAg;--u&$.OJ>LM"
        "+Ag-#X0B;-ZF5-M5SMpLYSMpL`C',M<>T;-+S1H-.`CH-gt2JN6t0*#B+a+Oj;3,#[5`P-bf3j.JUG+#TM5s-r>,LMF3L*#WUs-$8x$H3V)i+MjkQMMPl&-#[M.Q-wAdD-R8f/MNj@iL"
        "'f/,M&rJfLPQN,#_Us-$TsN)=&r&xK[C9F%0(P&#K:9[NS*P8MC2&F-XG[m/IB+.#-a($#>o&gL//K;-+5T;-NSLA&Rd;k#fHnM,0#b%OKgfY--D<U)Ckn-$Dnn-$:_&;HmM6MK>T*#H"
        "_XrlK>1Xh##6@D*Kn,87u=`$'I]FS7:5`D+q9[o#dRG`NL/a%O^)EvQfx%5A5LL_&WN#N0dqs1#,`''#JWajL4,D'#T:.6/_05##)#ffLF4$##%MYS.-Yu##;Rrt-k_kgLd?W$#l4+gL"
        "5SrhLq2g%#OxL$#M0G0.RU`mLxV.(#,<#s-^GwqL=T-+#7<#s-l:9sL?a?+#+Q`S%PDl.LajS`<uiFi^E<&J_N+0DNur4##C?jY#2)a4fWa.29+n<D<:u7/(uv4JU6ri+V'i/5A%?@VZ"
        "C<Jf_%V#)E[-CfqbP<crilQcVtco=uuq:##8OB]XaLcV-^ZeS.jNTuc)Q5,2&r3&4/8+Mg,_tr?aANJChg[(jMlFGDn1,)Eo8X%k['WYG$=<;H+J2VmpDLPJ6ZLMK;I+Po(8*/Ldxr%X"
        "'pd1p$,>>##ct&#xHfW%&1ei0LSsIr#####LSsIr,@73kU?&##";
/*
 * DEFAULT IMGUI FONT.
static const char proggy_clean_ttf_compressed_data_base85[11980 + 1] =
        "7])#######hV0qs'/###[),##/l:$#Q6>##5[n42>c-TH`->>#/e>11NNV=Bv(*:.F?uu#(gRU.o0XGH`$vhLG1hxt9?W`#,5LsCp#-i>.r$<$6pD>Lb';9Crc6tgXmKVeU2cD4Eo3R/"
        "2*>]b(MC;$jPfY.;h^`IWM9<Lh2TlS+f-s$o6Q<BWH`YiU.xfLq$N;$0iR/GX:U(jcW2p/W*q?-qmnUCI;jHSAiFWM.R*kU@C=GH?a9wp8f$e.-4^Qg1)Q-GL(lf(r/7GrRgwV%MS=C#"
        "`8ND>Qo#t'X#(v#Y9w0#1D$CIf;W'#pWUPXOuxXuU(H9M(1<q-UE31#^-V'8IRUo7Qf./L>=Ke$$'5F%)]0^#0X@U.a<r:QLtFsLcL6##lOj)#.Y5<-R&KgLwqJfLgN&;Q?gI^#DY2uL"
        "i@^rMl9t=cWq6##weg>$FBjVQTSDgEKnIS7EM9>ZY9w0#L;>>#Mx&4Mvt//L[MkA#W@lK.N'[0#7RL_&#w+F%HtG9M#XL`N&.,GM4Pg;-<nLENhvx>-VsM.M0rJfLH2eTM`*oJMHRC`N"
        "kfimM2J,W-jXS:)r0wK#@Fge$U>`w'N7G#$#fB#$E^$#:9:hk+eOe--6x)F7*E%?76%^GMHePW-Z5l'&GiF#$956:rS?dA#fiK:)Yr+`&#0j@'DbG&#^$PG.Ll+DNa<XCMKEV*N)LN/N"
        "*b=%Q6pia-Xg8I$<MR&,VdJe$<(7G;Ckl'&hF;;$<_=X(b.RS%%)###MPBuuE1V:v&cX&#2m#(&cV]`k9OhLMbn%s$G2,B$BfD3X*sp5#l,$R#]x_X1xKX%b5U*[r5iMfUo9U`N99hG)"
        "tm+/Us9pG)XPu`<0s-)WTt(gCRxIg(%6sfh=ktMKn3j)<6<b5Sk_/0(^]AaN#(p/L>&VZ>1i%h1S9u5o@YaaW$e+b<TWFn/Z:Oh(Cx2$lNEoN^e)#CFY@@I;BOQ*sRwZtZxRcU7uW6CX"
        "ow0i(?$Q[cjOd[P4d)]>ROPOpxTO7Stwi1::iB1q)C_=dV26J;2,]7op$]uQr@_V7$q^%lQwtuHY]=DX,n3L#0PHDO4f9>dC@O>HBuKPpP*E,N+b3L#lpR/MrTEH.IAQk.a>D[.e;mc."
        "x]Ip.PH^'/aqUO/$1WxLoW0[iLA<QT;5HKD+@qQ'NQ(3_PLhE48R.qAPSwQ0/WK?Z,[x?-J;jQTWA0X@KJ(_Y8N-:/M74:/-ZpKrUss?d#dZq]DAbkU*JqkL+nwX@@47`5>w=4h(9.`G"
        "CRUxHPeR`5Mjol(dUWxZa(>STrPkrJiWx`5U7F#.g*jrohGg`cg:lSTvEY/EV_7H4Q9[Z%cnv;JQYZ5q.l7Zeas:HOIZOB?G<Nald$qs]@]L<J7bR*>gv:[7MI2k).'2($5FNP&EQ(,)"
        "U]W]+fh18.vsai00);D3@4ku5P?DP8aJt+;qUM]=+b'8@;mViBKx0DE[-auGl8:PJ&Dj+M6OC]O^((##]`0i)drT;-7X`=-H3[igUnPG-NZlo.#k@h#=Ork$m>a>$-?Tm$UV(?#P6YY#"
        "'/###xe7q.73rI3*pP/$1>s9)W,JrM7SN]'/4C#v$U`0#V.[0>xQsH$fEmPMgY2u7Kh(G%siIfLSoS+MK2eTM$=5,M8p`A.;_R%#u[K#$x4AG8.kK/HSB==-'Ie/QTtG?-.*^N-4B/ZM"
        "_3YlQC7(p7q)&](`6_c)$/*JL(L-^(]$wIM`dPtOdGA,U3:w2M-0<q-]L_?^)1vw'.,MRsqVr.L;aN&#/EgJ)PBc[-f>+WomX2u7lqM2iEumMTcsF?-aT=Z-97UEnXglEn1K-bnEO`gu"
        "Ft(c%=;Am_Qs@jLooI&NX;]0#j4#F14;gl8-GQpgwhrq8'=l_f-b49'UOqkLu7-##oDY2L(te+Mch&gLYtJ,MEtJfLh'x'M=$CS-ZZ%P]8bZ>#S?YY#%Q&q'3^Fw&?D)UDNrocM3A76/"
        "/oL?#h7gl85[qW/NDOk%16ij;+:1a'iNIdb-ou8.P*w,v5#EI$TWS>Pot-R*H'-SEpA:g)f+O$%%`kA#G=8RMmG1&O`>to8bC]T&$,n.LoO>29sp3dt-52U%VM#q7'DHpg+#Z9%H[K<L"
        "%a2E-grWVM3@2=-k22tL]4$##6We'8UJCKE[d_=%wI;'6X-GsLX4j^SgJ$##R*w,vP3wK#iiW&#*h^D&R?jp7+/u&#(AP##XU8c$fSYW-J95_-Dp[g9wcO&#M-h1OcJlc-*vpw0xUX&#"
        "OQFKNX@QI'IoPp7nb,QU//MQ&ZDkKP)X<WSVL(68uVl&#c'[0#(s1X&xm$Y%B7*K:eDA323j998GXbA#pwMs-jgD$9QISB-A_(aN4xoFM^@C58D0+Q+q3n0#3U1InDjF682-SjMXJK)("
        "h$hxua_K]ul92%'BOU&#BRRh-slg8KDlr:%L71Ka:.A;%YULjDPmL<LYs8i#XwJOYaKPKc1h:'9Ke,g)b),78=I39B;xiY$bgGw-&.Zi9InXDuYa%G*f2Bq7mn9^#p1vv%#(Wi-;/Z5h"
        "o;#2:;%d&#x9v68C5g?ntX0X)pT`;%pB3q7mgGN)3%(P8nTd5L7GeA-GL@+%J3u2:(Yf>et`e;)f#Km8&+DC$I46>#Kr]]u-[=99tts1.qb#q72g1WJO81q+eN'03'eM>&1XxY-caEnO"
        "j%2n8)),?ILR5^.Ibn<-X-Mq7[a82Lq:F&#ce+S9wsCK*x`569E8ew'He]h:sI[2LM$[guka3ZRd6:t%IG:;$%YiJ:Nq=?eAw;/:nnDq0(CYcMpG)qLN4$##&J<j$UpK<Q4a1]MupW^-"
        "sj_$%[HK%'F####QRZJ::Y3EGl4'@%FkiAOg#p[##O`gukTfBHagL<LHw%q&OV0##F=6/:chIm0@eCP8X]:kFI%hl8hgO@RcBhS-@Qb$%+m=hPDLg*%K8ln(wcf3/'DW-$.lR?n[nCH-"
        "eXOONTJlh:.RYF%3'p6sq:UIMA945&^HFS87@$EP2iG<-lCO$%c`uKGD3rC$x0BL8aFn--`ke%#HMP'vh1/R&O_J9'um,.<tx[@%wsJk&bUT2`0uMv7gg#qp/ij.L56'hl;.s5CUrxjO"
        "M7-##.l+Au'A&O:-T72L]P`&=;ctp'XScX*rU.>-XTt,%OVU4)S1+R-#dg0/Nn?Ku1^0f$B*P:Rowwm-`0PKjYDDM'3]d39VZHEl4,.j']Pk-M.h^&:0FACm$maq-&sgw0t7/6(^xtk%"
        "LuH88Fj-ekm>GA#_>568x6(OFRl-IZp`&b,_P'$M<Jnq79VsJW/mWS*PUiq76;]/NM_>hLbxfc$mj`,O;&%W2m`Zh:/)Uetw:aJ%]K9h:TcF]u_-Sj9,VK3M.*'&0D[Ca]J9gp8,kAW]"
        "%(?A%R$f<->Zts'^kn=-^@c4%-pY6qI%J%1IGxfLU9CP8cbPlXv);C=b),<2mOvP8up,UVf3839acAWAW-W?#ao/^#%KYo8fRULNd2.>%m]UK:n%r$'sw]J;5pAoO_#2mO3n,'=H5(et"
        "Hg*`+RLgv>=4U8guD$I%D:W>-r5V*%j*W:Kvej.Lp$<M-SGZ':+Q_k+uvOSLiEo(<aD/K<CCc`'Lx>'?;++O'>()jLR-^u68PHm8ZFWe+ej8h:9r6L*0//c&iH&R8pRbA#Kjm%upV1g:"
        "a_#Ur7FuA#(tRh#.Y5K+@?3<-8m0$PEn;J:rh6?I6uG<-`wMU'ircp0LaE_OtlMb&1#6T.#FDKu#1Lw%u%+GM+X'e?YLfjM[VO0MbuFp7;>Q&#WIo)0@F%q7c#4XAXN-U&VB<HFF*qL("
        "$/V,;(kXZejWO`<[5?\?ewY(*9=%wDc;,u<'9t3W-(H1th3+G]ucQ]kLs7df($/*JL]@*t7Bu_G3_7mp7<iaQjO@.kLg;x3B0lqp7Hf,^Ze7-##@/c58Mo(3;knp0%)A7?-W+eI'o8)b<"
        "nKnw'Ho8C=Y>pqB>0ie&jhZ[?iLR@@_AvA-iQC(=ksRZRVp7`.=+NpBC%rh&3]R:8XDmE5^V8O(x<<aG/1N$#FX$0V5Y6x'aErI3I$7x%E`v<-BY,)%-?Psf*l?%C3.mM(=/M0:JxG'?"
        "7WhH%o'a<-80g0NBxoO(GH<dM]n.+%q@jH?f.UsJ2Ggs&4<-e47&Kl+f//9@`b+?.TeN_&B8Ss?v;^Trk;f#YvJkl&w$]>-+k?'(<S:68tq*WoDfZu';mM?8X[ma8W%*`-=;D.(nc7/;"
        ")g:T1=^J$&BRV(-lTmNB6xqB[@0*o.erM*<SWF]u2=st-*(6v>^](H.aREZSi,#1:[IXaZFOm<-ui#qUq2$##Ri;u75OK#(RtaW-K-F`S+cF]uN`-KMQ%rP/Xri.LRcB##=YL3BgM/3M"
        "D?@f&1'BW-)Ju<L25gl8uhVm1hL$##*8###'A3/LkKW+(^rWX?5W_8g)a(m&K8P>#bmmWCMkk&#TR`C,5d>g)F;t,4:@_l8G/5h4vUd%&%950:VXD'QdWoY-F$BtUwmfe$YqL'8(PWX("
        "P?^@Po3$##`MSs?DWBZ/S>+4%>fX,VWv/w'KD`LP5IbH;rTV>n3cEK8U#bX]l-/V+^lj3;vlMb&[5YQ8#pekX9JP3XUC72L,,?+Ni&co7ApnO*5NK,((W-i:$,kp'UDAO(G0Sq7MVjJs"
        "bIu)'Z,*[>br5fX^:FPAWr-m2KgL<LUN098kTF&#lvo58=/vjDo;.;)Ka*hLR#/k=rKbxuV`>Q_nN6'8uTG&#1T5g)uLv:873UpTLgH+#FgpH'_o1780Ph8KmxQJ8#H72L4@768@Tm&Q"
        "h4CB/5OvmA&,Q&QbUoi$a_%3M01H)4x7I^&KQVgtFnV+;[Pc>[m4k//,]1?#`VY[Jr*3&&slRfLiVZJ:]?=K3Sw=[$=uRB?3xk48@aeg<Z'<$#4H)6,>e0jT6'N#(q%.O=?2S]u*(m<-"
        "V8J'(1)G][68hW$5'q[GC&5j`TE?m'esFGNRM)j,ffZ?-qx8;->g4t*:CIP/[Qap7/9'#(1sao7w-.qNUdkJ)tCF&#B^;xGvn2r9FEPFFFcL@.iFNkTve$m%#QvQS8U@)2Z+3K:AKM5i"
        "sZ88+dKQ)W6>J%CL<KE>`.d*(B`-n8D9oK<Up]c$X$(,)M8Zt7/[rdkqTgl-0cuGMv'?>-XV1q['-5k'cAZ69e;D_?$ZPP&s^+7])$*$#@QYi9,5P&#9r+$%CE=68>K8r0=dSC%%(@p7"
        ".m7jilQ02'0-VWAg<a/''3u.=4L$Y)6k/K:_[3=&jvL<L0C/2'v:^;-DIBW,B4E68:kZ;%?8(Q8BH=kO65BW?xSG&#@uU,DS*,?.+(o(#1vCS8#CHF>TlGW'b)Tq7VT9q^*^$$.:&N@@"
        "$&)WHtPm*5_rO0&e%K&#-30j(E4#'Zb.o/(Tpm$>K'f@[PvFl,hfINTNU6u'0pao7%XUp9]5.>%h`8_=VYbxuel.NTSsJfLacFu3B'lQSu/m6-Oqem8T+oE--$0a/k]uj9EwsG>%veR*"
        "hv^BFpQj:K'#SJ,sB-'#](j.Lg92rTw-*n%@/;39rrJF,l#qV%OrtBeC6/,;qB3ebNW[?,Hqj2L.1NP&GjUR=1D8QaS3Up&@*9wP?+lo7b?@%'k4`p0Z$22%K3+iCZj?XJN4Nm&+YF]u"
        "@-W$U%VEQ/,,>>#)D<h#`)h0:<Q6909ua+&VU%n2:cG3FJ-%@Bj-DgLr`Hw&HAKjKjseK</xKT*)B,N9X3]krc12t'pgTV(Lv-tL[xg_%=M_q7a^x?7Ubd>#%8cY#YZ?=,`Wdxu/ae&#"
        "w6)R89tI#6@s'(6Bf7a&?S=^ZI_kS&ai`&=tE72L_D,;^R)7[$s<Eh#c&)q.MXI%#v9ROa5FZO%sF7q7Nwb&#ptUJ:aqJe$Sl68%.D###EC><?-aF&#RNQv>o8lKN%5/$(vdfq7+ebA#"
        "u1p]ovUKW&Y%q]'>$1@-[xfn$7ZTp7mM,G,Ko7a&Gu%G[RMxJs[0MM%wci.LFDK)(<c`Q8N)jEIF*+?P2a8g%)$q]o2aH8C&<SibC/q,(e:v;-b#6[$NtDZ84Je2KNvB#$P5?tQ3nt(0"
        "d=j.LQf./Ll33+(;q3L-w=8dX$#WF&uIJ@-bfI>%:_i2B5CsR8&9Z&#=mPEnm0f`<&c)QL5uJ#%u%lJj+D-r;BoF&#4DoS97h5g)E#o:&S4weDF,9^Hoe`h*L+_a*NrLW-1pG_&2UdB8"
        "6e%B/:=>)N4xeW.*wft-;$'58-ESqr<b?UI(_%@[P46>#U`'6AQ]m&6/`Z>#S?YY#Vc;r7U2&326d=w&H####?TZ`*4?&.MK?LP8Vxg>$[QXc%QJv92.(Db*B)gb*BM9dM*hJMAo*c&#"
        "b0v=Pjer]$gG&JXDf->'StvU7505l9$AFvgYRI^&<^b68?j#q9QX4SM'RO#&sL1IM.rJfLUAj221]d##DW=m83u5;'bYx,*Sl0hL(W;;$doB&O/TQ:(Z^xBdLjL<Lni;''X.`$#8+1GD"
        ":k$YUWsbn8ogh6rxZ2Z9]%nd+>V#*8U_72Lh+2Q8Cj0i:6hp&$C/:p(HK>T8Y[gHQ4`4)'$Ab(Nof%V'8hL&#<NEdtg(n'=S1A(Q1/I&4([%dM`,Iu'1:_hL>SfD07&6D<fp8dHM7/g+"
        "tlPN9J*rKaPct&?'uBCem^jn%9_K)<,C5K3s=5g&GmJb*[SYq7K;TRLGCsM-$$;S%:Y@r7AK0pprpL<Lrh,q7e/%KWK:50I^+m'vi`3?%Zp+<-d+$L-Sv:@.o19n$s0&39;kn;S%BSq*"
        "$3WoJSCLweV[aZ'MQIjO<7;X-X;&+dMLvu#^UsGEC9WEc[X(wI7#2.(F0jV*eZf<-Qv3J-c+J5AlrB#$p(H68LvEA'q3n0#m,[`*8Ft)FcYgEud]CWfm68,(aLA$@EFTgLXoBq/UPlp7"
        ":d[/;r_ix=:TF`S5H-b<LI&HY(K=h#)]Lk$K14lVfm:x$H<3^Ql<M`$OhapBnkup'D#L$Pb_`N*g]2e;X/Dtg,bsj&K#2[-:iYr'_wgH)NUIR8a1n#S?Yej'h8^58UbZd+^FKD*T@;6A"
        "7aQC[K8d-(v6GI$x:T<&'Gp5Uf>@M.*J:;$-rv29'M]8qMv-tLp,'886iaC=Hb*YJoKJ,(j%K=H`K.v9HggqBIiZu'QvBT.#=)0ukruV&.)3=(^1`o*Pj4<-<aN((^7('#Z0wK#5GX@7"
        "u][`*S^43933A4rl][`*O4CgLEl]v$1Q3AeF37dbXk,.)vj#x'd`;qgbQR%FW,2(?LO=s%Sc68%NP'##Aotl8x=BE#j1UD([3$M(]UI2LX3RpKN@;/#f'f/&_mt&F)XdF<9t4)Qa.*kT"
        "LwQ'(TTB9.xH'>#MJ+gLq9-##@HuZPN0]u:h7.T..G:;$/Usj(T7`Q8tT72LnYl<-qx8;-HV7Q-&Xdx%1a,hC=0u+HlsV>nuIQL-5<N?)NBS)QN*_I,?&)2'IM%L3I)X((e/dl2&8'<M"
        ":^#M*Q+[T.Xri.LYS3v%fF`68h;b-X[/En'CR.q7E)p'/kle2HM,u;^%OKC-N+Ll%F9CF<Nf'^#t2L,;27W:0O@6##U6W7:$rJfLWHj$#)woqBefIZ.PK<b*t7ed;p*_m;4ExK#h@&]>"
        "_>@kXQtMacfD.m-VAb8;IReM3$wf0''hra*so568'Ip&vRs849'MRYSp%:t:h5qSgwpEr$B>Q,;s(C#$)`svQuF$##-D,##,g68@2[T;.XSdN9Qe)rpt._K-#5wF)sP'##p#C0c%-Gb%"
        "hd+<-j'Ai*x&&HMkT]C'OSl##5RG[JXaHN;d'uA#x._U;.`PU@(Z3dt4r152@:v,'R.Sj'w#0<-;kPI)FfJ&#AYJ&#//)>-k=m=*XnK$>=)72L]0I%>.G690a:$##<,);?;72#?x9+d;"
        "^V'9;jY@;)br#q^YQpx:X#Te$Z^'=-=bGhLf:D6&bNwZ9-ZD#n^9HhLMr5G;']d&6'wYmTFmL<LD)F^%[tC'8;+9E#C$g%#5Y>q9wI>P(9mI[>kC-ekLC/R&CH+s'B;K-M6$EB%is00:"
        "+A4[7xks.LrNk0&E)wILYF@2L'0Nb$+pv<(2.768/FrY&h$^3i&@+G%JT'<-,v`3;_)I9M^AE]CN?Cl2AZg+%4iTpT3<n-&%H%b<FDj2M<hH=&Eh<2Len$b*aTX=-8QxN)k11IM1c^j%"
        "9s<L<NFSo)B?+<-(GxsF,^-Eh@$4dXhN$+#rxK8'je'D7k`e;)2pYwPA'_p9&@^18ml1^[@g4t*[JOa*[=Qp7(qJ_oOL^('7fB&Hq-:sf,sNj8xq^>$U4O]GKx'm9)b@p7YsvK3w^YR-"
        "CdQ*:Ir<($u&)#(&?L9Rg3H)4fiEp^iI9O8KnTj,]H?D*r7'M;PwZ9K0E^k&-cpI;.p/6_vwoFMV<->#%Xi.LxVnrU(4&8/P+:hLSKj$#U%]49t'I:rgMi'FL@a:0Y-uA[39',(vbma*"
        "hU%<-SRF`Tt:542R_VV$p@[p8DV[A,?1839FWdF<TddF<9Ah-6&9tWoDlh]&1SpGMq>Ti1O*H&#(AL8[_P%.M>v^-))qOT*F5Cq0`Ye%+$B6i:7@0IX<N+T+0MlMBPQ*Vj>SsD<U4JHY"
        "8kD2)2fU/M#$e.)T4,_=8hLim[&);?UkK'-x?'(:siIfL<$pFM`i<?%W(mGDHM%>iWP,##P`%/L<eXi:@Z9C.7o=@(pXdAO/NLQ8lPl+HPOQa8wD8=^GlPa8TKI1CjhsCTSLJM'/Wl>-"
        "S(qw%sf/@%#B6;/U7K]uZbi^Oc^2n<bhPmUkMw>%t<)'mEVE''n`WnJra$^TKvX5B>;_aSEK',(hwa0:i4G?.Bci.(X[?b*($,=-n<.Q%`(X=?+@Am*Js0&=3bh8K]mL<LoNs'6,'85`"
        "0?t/'_U59@]ddF<#LdF<eWdF<OuN/45rY<-L@&#+fm>69=Lb,OcZV/);TTm8VI;?%OtJ<(b4mq7M6:u?KRdF<gR@2L=FNU-<b[(9c/ML3m;Z[$oF3g)GAWqpARc=<ROu7cL5l;-[A]%/"
        "+fsd;l#SafT/f*W]0=O'$(Tb<[)*@e775R-:Yob%g*>l*:xP?Yb.5)%w_I?7uk5JC+FS(m#i'k.'a0i)9<7b'fs'59hq$*5Uhv##pi^8+hIEBF`nvo`;'l0.^S1<-wUK2/Coh58KKhLj"
        "M=SO*rfO`+qC`W-On.=AJ56>>i2@2LH6A:&5q`?9I3@@'04&p2/LVa*T-4<-i3;M9UvZd+N7>b*eIwg:CC)c<>nO&#<IGe;__.thjZl<%w(Wk2xmp4Q@I#I9,DF]u7-P=.-_:YJ]aS@V"
        "?6*C()dOp7:WL,b&3Rg/.cmM9&r^>$(>.Z-I&J(Q0Hd5Q%7Co-b`-c<N(6r@ip+AurK<m86QIth*#v;-OBqi+L7wDE-Ir8K['m+DDSLwK&/.?-V%U_%3:qKNu$_b*B-kp7NaD'QdWQPK"
        "Yq[@>P)hI;*_F]u`Rb[.j8_Q/<&>uu+VsH$sM9TA%?)(vmJ80),P7E>)tjD%2L=-t#fK[%`v=Q8<FfNkgg^oIbah*#8/Qt$F&:K*-(N/'+1vMB,u()-a.VUU*#[e%gAAO(S>WlA2);Sa"
        ">gXm8YB`1d@K#n]76-a$U,mF<fX]idqd)<3,]J7JmW4`6]uks=4-72L(jEk+:bJ0M^q-8Dm_Z?0olP1C9Sa&H[d&c$ooQUj]Exd*3ZM@-WGW2%s',B-_M%>%Ul:#/'xoFM9QX-$.QN'>"
        "[%$Z$uF6pA6Ki2O5:8w*vP1<-1`[G,)-m#>0`P&#eb#.3i)rtB61(o'$?X3B</R90;eZ]%Ncq;-Tl]#F>2Qft^ae_5tKL9MUe9b*sLEQ95C&`=G?@Mj=wh*'3E>=-<)Gt*Iw)'QG:`@I"
        "wOf7&]1i'S01B+Ev/Nac#9S;=;YQpg_6U`*kVY39xK,[/6Aj7:'1Bm-_1EYfa1+o&o4hp7KN_Q(OlIo@S%;jVdn0'1<Vc52=u`3^o-n1'g4v58Hj&6_t7$##?M)c<$bgQ_'SY((-xkA#"
        "Y(,p'H9rIVY-b,'%bCPF7.J<Up^,(dU1VY*5#WkTU>h19w,WQhLI)3S#f$2(eb,jr*b;3Vw]*7NH%$c4Vs,eD9>XW8?N]o+(*pgC%/72LV-u<Hp,3@e^9UB1J+ak9-TN/mhKPg+AJYd$"
        "MlvAF_jCK*.O-^(63adMT->W%iewS8W6m2rtCpo'RS1R84=@paTKt)>=%&1[)*vp'u+x,VrwN;&]kuO9JDbg=pO$J*.jVe;u'm0dr9l,<*wMK*Oe=g8lV_KEBFkO'oU]^=[-792#ok,)"
        "i]lR8qQ2oA8wcRCZ^7w/Njh;?.stX?Q1>S1q4Bn$)K1<-rGdO'$Wr.Lc.CG)$/*JL4tNR/,SVO3,aUw'DJN:)Ss;wGn9A32ijw%FL+Z0Fn.U9;reSq)bmI32U==5ALuG&#Vf1398/pVo"
        "1*c-(aY168o<`JsSbk-,1N;$>0:OUas(3:8Z972LSfF8eb=c-;>SPw7.6hn3m`9^Xkn(r.qS[0;T%&Qc=+STRxX'q1BNk3&*eu2;&8q$&x>Q#Q7^Tf+6<(d%ZVmj2bDi%.3L2n+4W'$P"
        "iDDG)g,r%+?,$@?uou5tSe2aN_AQU*<h`e-GI7)?OK2A.d7_c)?wQ5AS@DL3r#7fSkgl6-++D:'A,uq7SvlB$pcpH'q3n0#_%dY#xCpr-l<F0NR@-##FEV6NTF6##$l84N1w?AO>'IAO"
        "URQ##V^Fv-XFbGM7Fl(N<3DhLGF%q.1rC$#:T__&Pi68%0xi_&[qFJ(77j_&JWoF.V735&T,[R*:xFR*K5>>#`bW-?4Ne_&6Ne_&6Ne_&n`kr-#GJcM6X;uM6X;uM(.a..^2TkL%oR(#"
        ";u.T%fAr%4tJ8&><1=GHZ_+m9/#H1F^R#SC#*N=BA9(D?v[UiFY>>^8p,KKF.W]L29uLkLlu/+4T<XoIB&hx=T1PcDaB&;HH+-AFr?(m9HZV)FKS8JCw;SD=6[^/DZUL`EUDf]GGlG&>"
        "w$)F./^n3+rlo+DB;5sIYGNk+i1t-69Jg--0pao7Sm#K)pdHW&;LuDNH@H>#/X-TI(;P>#,Gc>#0Su>#4`1?#8lC?#<xU?#@.i?#D:%@#HF7@#LRI@#P_[@#Tkn@#Xw*A#]-=A#a9OA#"
        "d<F&#*;G##.GY##2Sl##6`($#:l:$#>xL$#B.`$#F:r$#JF.%#NR@%#R_R%#Vke%#Zww%#_-4&#3^Rh%Sflr-k'MS.o?.5/sWel/wpEM0%3'/1)K^f1-d>G21&v(35>V`39V7A4=onx4"
        "A1OY5EI0;6Ibgr6M$HS7Q<)58C5w,;WoA*#[%T*#`1g*#d=#+#hI5+#lUG+#pbY+#tnl+#x$),#&1;,#*=M,#.I`,#2Ur,#6b.-#;w[H#iQtA#m^0B#qjBB#uvTB##-hB#'9$C#+E6C#"
        "/QHC#3^ZC#7jmC#;v)D#?,<D#C8ND#GDaD#KPsD#O]/E#g1A5#KA*1#gC17#MGd;#8(02#L-d3#rWM4#Hga1#,<w0#T.j<#O#'2#CYN1#qa^:#_4m3#o@/=#eG8=#t8J5#`+78#4uI-#"
        "m3B2#SB[8#Q0@8#i[*9#iOn8#1Nm;#^sN9#qh<9#:=x-#P;K2#$%X9#bC+.#Rg;<#mN=.#MTF.#RZO.#2?)4#Y#(/#[)1/#b;L/#dAU/#0Sv;#lY$0#n`-0#sf60#(F24#wrH0#%/e0#"
        "TmD<#%JSMFove:CTBEXI:<eh2g)B,3h2^G3i;#d3jD>)4kMYD4lVu`4m`:&5niUA5@(A5BA1]PBB:xlBCC=2CDLXMCEUtiCf&0g2'tN?PGT4CPGT4CPGT4CPGT4CPGT4CPGT4CPGT4CP"
        "GT4CPGT4CPGT4CPGT4CPGT4CPGT4CP-qekC`.9kEg^+F$kwViFJTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5o,^<-28ZI'O?;xp"
        "O?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xp;7q-#lLYI:xvD=#";
*/

static const char* GetDefaultCompressedFontDataTTFBase85()
{
    return proggy_clean_ttf_compressed_data_base85;
}

#endif // #ifndef IMGUI_DISABLE
