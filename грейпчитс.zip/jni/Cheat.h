//
// Created by proco on 22.05.2022.
//

#ifndef Z9INJECTOR_CHEAT_H
#define Z9INJECTOR_CHEAT_H
#include "Dobby/dobby.h"

JNIEnv* gJNIEnv = NULL;
float currentTimeInMilliseconds();
void displayKeyboard();
void UpdateInput();
bool HandleInputEvent(JNIEnv *env, int motionEvent, int x, int y, int p);
void InitTheme();
void UpdateInput();
bool setupGraphics(float w, float h);
ImDrawList* getDrawList();
void Render();
void StartBackend(JNIEnv* env);
#endif //Z9INJECTOR_CHEAT_H
