APP_ABI := armeabi-v7a
APP_PLATFORM := android-19
APP_STL := c++_static
APP_OPTIM := release
APP_CPPFLAGS := -std=c++17 -fno-rtti -fexceptions
APP_LDFLAGS := -llog